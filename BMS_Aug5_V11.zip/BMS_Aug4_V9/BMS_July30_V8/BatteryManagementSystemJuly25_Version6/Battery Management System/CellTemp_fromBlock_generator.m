% Model and subsystem path
model = 'Simulink_Program';
subsystem = [model '/Subsystem/Rice'];
load_system(model);

% Parameters
numSignals = 105;
fromX = 100;
fromYStart = 100;
ySpacing = 30;
blockWidth = 180;

% Create Bus Creator
busCreatorName = [subsystem '/BusCreator_Temp'];
busX = fromX + blockWidth + 150;
busY = fromYStart;
add_block('simulink/Signal Routing/Bus Creator', busCreatorName, ...
    'Inputs', num2str(numSignals), ...
    'Position', [busX, busY, busX+40, busY + numSignals * ySpacing]);

% Create From blocks and connect to Bus Creator with signal names
for i = 1:numSignals
    idxStr = sprintf('%03d', i);
    tag = ['HVBatCell_Temp' idxStr];
    signalName = sprintf('Cell Temperature %d', i);

    % Block and position info
    fromBlock = [subsystem '/From_Temp' idxStr];
    posY = fromYStart + (i-1)*ySpacing;

    % Add From block
    add_block('simulink/Signal Routing/From', fromBlock, ...
        'GotoTag', tag, ...
        'Position', [fromX, posY, fromX + blockWidth, posY + 20]);

    % Connect From block to Bus Creator
    line = add_line(subsystem, ...
        ['From_Temp' idxStr '/1'], ...
        ['BusCreator_Temp/' num2str(i)], ...
        'autorouting', 'on');

    % Set signal name on the line (to appear as bus element name)
    set_param(line, 'Name', signalName);
end

% Final Goto block for the output bus
gotoName = [subsystem '/HVBatCell_Temperatures'];
gotoY = fromYStart + numSignals * ySpacing / 2;
add_block('simulink/Signal Routing/Goto', gotoName, ...
    'GotoTag', 'HVBatCell_Temperatures', ...
    'TagVisibility', 'local', ...
    'Position', [busX + 100, gotoY, busX + 140, gotoY + 20]);

% Connect Bus Creator to Goto
add_line(subsystem, 'BusCreator_Temp/1', 'HVBatCell_Temperatures/1', 'autorouting', 'on');
