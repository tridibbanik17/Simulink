%% === Optimized DCFC Plot Script ===
clear; clc; close all;

%% --- Load data ---
load dcfc_plots_signals.mat
assert(exist('data','var') && isa(data,'Simulink.SimulationData.Dataset'), ...
    '"data" must be a Simulink.SimulationData.Dataset.');

%% --- Helper: get signal safely from DatasetElement ---
names = getElementNames(data);
getSignal = @(n) struct( ...
    't', data.get(names{find(strcmpi(names,n),1)}).Values.Time, ...
    'y', data.get(names{find(strcmpi(names,n),1)}).Values.Data ...
);

%% --- Extract signals ---
sigNames = {'voltageCell','socCell','HVBatPack_Current_Prim','MaxChargeCurrentAllowed','temperatureCell','Fault_General','HVBat_DC_CntctrStat','HVBatChargeStat'};
signals = struct();
for i = 1:numel(sigNames)
    try
        s = getSignal(sigNames{i});
        signals.(sigNames{i}) = s.y;
        if ~isfield(signals,'time')
            signals.time = s.t;   % Use time from first available signal
        end
    catch
        signals.(sigNames{i}) = [];
        warning('%s not found.', sigNames{i});
    end
end
t = signals.time;  
assert(~isempty(t), 'No valid time vector found.');

%% --- Common settings ---
colorVoltage     = [0, 0.45, 0.74];   % Blue
colorSOC         = [1, 0.4, 0.2];    % Orange
colorPackCurrent = [0, 0.45, 0.74];   % Blue
colorMaxCurrent  = [0.85, 0.33, 0.10]; % Orange

% Time in minutes
time_min = t / 60;
idx = t <= 9000;   % up to 9000 s (150 min)

%% === FIGURE 1: Voltage + SOC (dual y-axis) ===
figure(1); clf; hold on; grid on;
set(gcf,'Color','w'); set(gca,'FontSize',18);

% Left axis: Cell Voltage
yyaxis left
if ~isempty(signals.voltageCell)
    plot(time_min(idx), mean(signals.voltageCell(idx,:),2), 'LineWidth', 2, 'Color', colorVoltage);
end
ylabel('Cell Voltage (V)','FontSize',22);
ax.YColor = colorVoltage;
ylim([3.5 4.3]);

% Right axis: Cell SOC
yyaxis right
if ~isempty(signals.socCell)
    plot(time_min(idx), mean(signals.socCell(idx,:),2)*100, 'LineWidth', 2, 'Color', colorSOC);
end
ylabel('Cell SoC (%)','FontSize',22);
ax.YColor = colorSOC;
ylim([0 100]);

% X-axis
xlabel('Time (min)','FontSize',22);
xlim([0 150]);

% legend({'Cell Voltage','Cell SoC'}, 'FontSize',18,'Location','southeast');
exportgraphics(gcf,'Fig1_dcfc.png','Resolution',600);
disp('✅ Saved: Fig1_dcfc.png');

%% === FIGURE 2: Pack Current + Max Allowed Current (dual y-axis) ===
figure(2); clf; hold on; grid on;
set(gcf,'Color','w'); set(gca,'FontSize',18);

% Left axis: Pack Current
yyaxis left
if ~isempty(signals.HVBatPack_Current_Prim)
    y1 = signals.HVBatPack_Current_Prim;
    if size(y1,2) > 1, y1 = mean(y1,2); end  % average if multi-column
    plot(time_min(idx), y1(idx), 'LineWidth', 2, 'Color', colorPackCurrent);
end
ylabel('Pack Current (A)','FontSize',22);
ylim([0 170]);
ax = gca; ax.YColor = colorPackCurrent;

% Right axis: Max Allowed Current
yyaxis right
y2 = [];
if ~isempty(signals.MaxChargeCurrentAllowed)
    y2 = signals.MaxChargeCurrentAllowed;
    if size(y2,2) > 1, y2 = mean(y2,2); end
    % Ensure y2 length matches time vector
    if length(y2) ~= length(time_min)
        y2 = interp1((1:length(y2))', y2, linspace(1,length(y2),length(time_min)))';
    end
    plot(time_min(idx), y2(idx), 'LineWidth', 2, 'Color', colorMaxCurrent);
end
ylabel('Max Allowed Current (A)','FontSize',22);
ylim([0 70]);
ax.YColor = colorMaxCurrent;

xlabel('Time (min)','FontSize',22);
xlim([0 150]);
% legend({'Pack Current','Max Allowed Current'},'FontSize',18,'Location','southeast');
exportgraphics(gcf,'Fig2_dcfc_Current.png','Resolution',600);
disp('✅ Saved: Fig2_dcfc_Current.png');


%% Figure 3
figure(3); clf; hold on; grid on;
set(gcf,'Color','w'); set(gca,'FontSize',18);

% Colors
colorTemp  = [0, 0.45, 0.74];  % Blue
colorFault = [1, 0.0, 0.0];    % Red

% --- Left axis: Temperature ---
yyaxis left
if ~isempty(signals.temperatureCell)
    temp = signals.temperatureCell;
    if size(temp,2) > 1, temp = mean(temp,2); end
    plot(time_min(idx), temp(idx), 'LineWidth',2,'Color',colorTemp);
end
ylabel('Max Cell Temperature (°C)','FontSize',22);
ylim([45 50]);
ax = gca; ax.YColor = colorTemp;

% --- Right axis: Fault (0/1) ---
yyaxis right
if ~isempty(signals.Fault_General)
    fault = signals.Fault_General;
    if isscalar(fault)
        fault = repmat(fault, length(time_min),1);  % replicate scalar to match time
    end
    plot(time_min(idx), fault(idx), 'LineWidth',2,'Color',colorFault);
end
ylabel('Fault Detection (0/1)','FontSize',22);
ylim([0 1]);
ax.YColor = colorFault;
yticks([0 1]); 

xlabel('Time (min)','FontSize',22);
xlim([0 150]);

% legend({'Cell Temperature','Fault'},'FontSize',18,'Location','southeast');
exportgraphics(gcf,'Fig3_dcfc_Temp_Fault.png','Resolution',600);
disp('✅ Saved: Fig3_dcfc_Temp_Fault.png');

%% Figure 4
figure(4); clf; hold on; grid on;
set(gcf,'Color','w'); set(gca,'FontSize',18);

% Colors
colorDC     = [0, 0.45, 0.74];  % Blue
colorCharge = [1, 0.4, 0.2];    % Orange

% Plot DC Contactor Status
if ~isempty(signals.HVBat_DC_CntctrStat)
    dcStat = signals.HVBat_DC_CntctrStat;
    if size(dcStat,2) > 1, dcStat = mean(dcStat,2); end
    plot(time_min(idx), dcStat(idx), 'LineWidth',2,'Color',colorDC,'DisplayName','DC Contactor Status');
end

% Plot Charge Status
if ~isempty(signals.HVBatChargeStat)
    chargeStat = signals.HVBatChargeStat;
    if size(chargeStat,2) > 1, chargeStat = mean(chargeStat,2); end
    plot(time_min(idx), chargeStat(idx), 'LineWidth',2,'Color',colorCharge,'DisplayName','Charge Status');
end

ylabel('Status','FontSize',22);
xlabel('Time (min)','FontSize',22);
xlim([0 150]);
ylim([0 6]);  % Set max y-axis to 6 for consistency
legend('FontSize',18,'Location','southeast');

exportgraphics(gcf,'Fig4_dcfc_DC_Charge_singleY.png','Resolution',600);
disp('✅ Saved: Fig4_dcfc_DC_Charge_singleY.png');