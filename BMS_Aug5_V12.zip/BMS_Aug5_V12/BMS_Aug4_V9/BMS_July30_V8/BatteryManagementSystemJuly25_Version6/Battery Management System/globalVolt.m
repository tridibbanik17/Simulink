modelName = 'Simulink_Program';
load_system(modelName);  % Load the model without opening it

% Find all Goto blocks in the model
gotoBlocks = find_system(modelName, 'BlockType', 'Goto');

count = 0;

for i = 1:length(gotoBlocks)
    block = gotoBlocks{i};
    
    % Get the tag name
    tagName = get_param(block, 'GotoTag');
    
    % Check if it starts with 'HVBatCell_Voltage'
    if startsWith(tagName, 'HVBatCell_Voltage')
        % Change the tag visibility to 'global'
        set_param(block, 'TagVisibility', 'global');
        count = count + 1;
    end
end

fprintf('✅ %d Goto blocks updated to global visibility.\n', count);
