% Define model and subsystem
model = 'Simulink_Program';  % Replace with your actual model name
subsystem = 'Simulink_Program/Subsystem/Rice';  % Replace with the path to your subsystem

% Load model if not open
load_system(model);

% Find all Goto blocks under the subsystem
gotos = find_system(subsystem, 'BlockType', 'Goto');

% Loop through them and rename tag if it contains the typo
for i = 1:length(gotos)
    tag = get_param(gotos{i}, 'GotoTag');
    if contains(tag, 'HVBatCell_Voltage')
        newTag = strrep(tag, 'HVBatCell_Voltage', 'HVBatCell_Temp');
        set_param(gotos{i}, 'GotoTag', newTag);
        fprintf('Updated GotoTag: %s -> %s\n', tag, newTag);
    end
end
