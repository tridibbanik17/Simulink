function [Fault_Contactor, Fault_K1_Shorted_High, Fault_K4_Shorted_High] = detectCntctrFaults( ...
    K1, K4, HVBatPack_DCFCVoltage, HVBatPack_EDMVoltage, ...
    PlugInChargingCmd, MainHVBatCntctrCmd)

%----------------------------------------------------
% Detect faults: K1 or K4 contactors shorted high
%----------------------------------------------------

% -- Persistent Variables --
persistent last_Fault_K1_Shorted_High last_Fault_K4_Shorted_High ShortedHighCounter

if isempty(last_Fault_K1_Shorted_High)
    last_Fault_K1_Shorted_High = 0;
end
if isempty(last_Fault_K4_Shorted_High)
    last_Fault_K4_Shorted_High = 0;
end
if isempty(ShortedHighCounter)
    ShortedHighCounter = 0;
end

% -- Output Defaults --
Fault_Contactor = 0;
Fault_K1_Shorted_High = 0;  % 0 = OK, 1 = Shorted High
Fault_K4_Shorted_High = 0;

% === Fault Detection Logic ===

% --- K1 Shorted High Detection after Precharge (Main Contactor OFF) ---
if MainHVBatCntctrCmd == 0 && HVBatPack_EDMVoltage > 270
    ShortedHighCounter = ShortedHighCounter + 1;
    if ShortedHighCounter > 2
        Fault_Contactor = 1;
        Fault_K1_Shorted_High = 1;  % Shorted High
        last_Fault_K1_Shorted_High = Fault_K1_Shorted_High;
    end
elseif MainHVBatCntctrCmd == 0
    ShortedHighCounter = 0;
end

% --- K4 Shorted High Detection (DCFC Mode) ---
if PlugInChargingCmd == 0 && K1 == 0 && HVBatPack_DCFCVoltage > 270
    Fault_Contactor = 1;
    Fault_K4_Shorted_High = 1;
    last_Fault_K4_Shorted_High = Fault_K4_Shorted_High;

% --- K1 Shorted High Again (DCFC Mode, K4 not commanded) ---
elseif PlugInChargingCmd == 0 && K4 == 0 && HVBatPack_DCFCVoltage > 270
    Fault_Contactor = 1;
    Fault_K1_Shorted_High = 1;
    last_Fault_K1_Shorted_High = Fault_K1_Shorted_High;
end

% --- Latching Behaviour (Hold Shorted State) ---
if last_Fault_K1_Shorted_High == 1
    Fault_K1_Shorted_High = 1;
end
if last_Fault_K4_Shorted_High == 1
    Fault_K4_Shorted_High = 1;
end

end
