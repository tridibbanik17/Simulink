% % Driving and charging commands included
% Pre_charge_Voltage_Threshold = max(simOut.Ke_V_HighVoltagePreChargeThreshold);
% 
% %% === FIGURE 1: Contactors/Relays with Background Colors ===
% figure(1)
% clf;
% 
% % Get Sail color palette
% tmpFig = figure('Visible','off');
% tmpAx = axes(tmpFig);
% colororder(tmpAx, 'sail');
% colors = colororder(tmpAx);
% close(tmpFig);
% 
% % Original time intervals (10 segments)
% time_stamps = [0, 0.101, 0.2, 0.301, 14.928, 15.102, 15.182, 29.511, 29.612, 29.801, 29.883, 30.001, 44.832, 45.001, 45.101, 45.2];
% categories  = {'Open','Precharging','Driving Normal','Driving Shorted High','Open', ...
%                'Precharging','Driving Normal','Driving Shorted Low','Open','Precharging','Charging Normal','Charging Shorted High','Driving Normal', ...
%                'Charging Shorted Low','Driving Normal'};
% time_stamps_one_decimal = [0, 0.1, 0.2, 0.3, 14.9, 15.1, 15.2, 29.5, 29.6, 29.8, 29.9, 30, 44.8, 45, 45.1, 45.2];
% 
% % Map intervals to equal-width segments
% nSegments = numel(time_stamps)-1;
% x_equal = linspace(0,1,nSegments+1);   % normalized equally spaced x for plotting
% 
% % Background colors (5 categories)
% color_open      = [0.95 0.95 0.96];  % light gray
% color_precharge = [0.93 0.96 1.00];  % soft blue
% color_driving_normal    = [0.85 0.90 0.98];  % darker bluish-gray
% color_driving_short_hi  = [0.80 0.88 1.00];  % new blue shade
% color_driving_short_lo  = [0.70 0.82 0.95];  % another blue shade
% color_charging_normal = [0.60 0.76 0.92];  % medium light blue
% color_charging_short_hi = [0.50 0.70 0.90];  % medium blue
% color_charging_short_lo = [0.40 0.64 0.88];  % deeper blue
% 
% cat_colors = containers.Map( ...
%     {'Open','Precharging','Driving Normal','Driving Shorted High','Driving Shorted Low','Charging Normal','Charging Shorted High','Charging Shorted Low'}, ...
%     {color_open, color_precharge, color_driving_normal, color_driving_short_hi, color_driving_short_lo, color_charging_normal, color_charging_short_hi, color_charging_short_lo});
% 
% % --- Tiled Layout ---
% t = tiledlayout(2,1);
% t.TileSpacing = 'compact';
% t.Padding = 'compact';
% 
% ylabel(t, 'Contactors/Relays Signals and Commands', 'FontSize', 22);
% xlabel(t, 'Time (s)', 'FontSize', 22);
% 
% ymin = -0.5; ymax = 1.5;
% 
% %% === Top Tile: K1 & K4 ===
% nexttile
% hold on
% 
% % Draw background per segment
% for i = 1:nSegments
%     fill([x_equal(i) x_equal(i+1) x_equal(i+1) x_equal(i)], ...
%          [ymin ymin ymax ymax], cat_colors(categories{i}), 'EdgeColor','none');
% end
% 
% % Step values per segment (use first value after entering the segment)
% K1_mapped = nan(size(simOut.K1));
% K4_mapped = nan(size(simOut.K4));
% K2_mapped = nan(size(simOut.K2));
% K3_mapped = nan(size(simOut.K3));
% 
% x_mapped  = nan(size(simOut.tout));
% 
% for i = 1:nSegments
%     start_time = time_stamps(i) + eps; 
%     idx_start = find(simOut.tout >= start_time, 1, 'first');
%     idx_end   = find(simOut.tout <= time_stamps(i+1), 1, 'last');
% 
%     if ~isempty(idx_start) && ~isempty(idx_end)
%         idx = idx_start:idx_end;
%         K1_mapped(idx) = simOut.K1(idx_start);
%         K4_mapped(idx) = simOut.K4(idx_start);
%         K2_mapped(idx) = simOut.K2(idx_start);
%         K3_mapped(idx) = simOut.K3(idx_start);
%         x_mapped(idx)  = linspace(x_equal(i), x_equal(i+1), length(idx));
%     end
% end
% 
% % Plot signals
% h_K2 = plot(x_mapped, K2_mapped, '-',  'Color', colors(2,:), 'LineWidth', 2);
% h_K3 = plot(x_mapped, K3_mapped, '--', 'Color', colors(5,:), 'LineWidth', 2);
% h_K1 = plot(x_mapped, K1_mapped, '-', 'Color', colors(1,:), 'LineWidth', 2);
% h_K4 = plot(x_mapped, K4_mapped, '--','Color', colors(3,:), 'LineWidth', 2);
% 
% xlim([0 1]); ylim([ymin ymax]);
% yticks([0 1]);
% ax = gca; 
% ax.FontSize = 18;
% ax.Layer = 'top';
% grid on
% 
% % Legend shows lines only
% legend([h_K1, h_K4, h_K2, h_K3], ...
%     {'Main Contactor', 'DCFC Contactor', 'Precharge Relay (-)', 'Precharge Relay (+)'}, ...
%     'FontSize', 18, 'Location', 'east');
% 
% % Custom ticks at middle of each segment
% xticks(x_equal(2:end));
% xticklabels(string(time_stamps_one_decimal(2:end)));
% 
% %% === Bottom Tile: Contactor Commands ===
% nexttile
% hold on
% 
% % Draw background per segment
% for i = 1:nSegments
%     fill([x_equal(i) x_equal(i+1) x_equal(i+1) x_equal(i)], ...
%          [ymin ymin ymax ymax], cat_colors(categories{i}), 'EdgeColor','none');
% end
% 
% % Step values per segment
% MainHVBatCntctrCmd_mapped = nan(size(simOut.MainHVBatCntctrCmd));
% PlugInChargingCmd_mapped = nan(size(simOut.PlugInChargingCmd));
% 
% for i = 1:nSegments
%     start_time = time_stamps(i) + eps; 
%     idx_start = find(simOut.tout >= start_time, 1, 'first');
%     idx_end   = find(simOut.tout <= time_stamps(i+1), 1, 'last');
% 
%     if ~isempty(idx_start) && ~isempty(idx_end)
%         idx = idx_start:idx_end;
%         MainHVBatCntctrCmd_mapped(idx) = simOut.MainHVBatCntctrCmd(idx_start);
%         PlugInChargingCmd_mapped(idx) = simOut.PlugInChargingCmd(idx_start);
%         x_mapped(idx)  = linspace(x_equal(i), x_equal(i+1), length(idx));
%     end
% end
% 
% % Plot signals
% h_MainHVBatCntctrCmd = plot(x_mapped, MainHVBatCntctrCmd_mapped, '-',  'Color', colors(1,:), 'LineWidth', 2);
% h_PlugInChargingCmd = plot(x_mapped, PlugInChargingCmd_mapped, '--', 'Color', colors(3,:), 'LineWidth', 2);
% 
% xlim([0 1]); ylim([ymin ymax]);
% yticks([0 1]);
% ax = gca; 
% ax.FontSize = 18;
% ax.Layer = 'top';
% grid on
% 
% xticks(x_equal(2:end));
% xticklabels(string(time_stamps_one_decimal(2:end)));
% 
% % Legend shows lines only
% legend([h_MainHVBatCntctrCmd, h_PlugInChargingCmd], ...
%     {'Driving Command', 'Charging Command'}, ...
%     'FontSize', 18, 'Location', 'northeast');
% 
% % Export figure
% exportgraphics(gcf, 'Fig1.png', 'Resolution', 1200);
% 
% 
% %% === FIGURE 2: Precharge Current (Equal-area segments, same formatting as Fig 1) ===
% figure(2)
% clf;
% 
% % Use the same segmentation as Fig 1
% nSegments = numel(time_stamps) - 1;
% x_equal   = linspace(0,1,nSegments+1);   % equally spaced compressed x
% 
% % --- Background ---
% ymin = 0; ymax = 20;
% hold on
% for i = 1:nSegments
%     fill([x_equal(i) x_equal(i+1) x_equal(i+1) x_equal(i)], ...
%          [ymin ymin ymax ymax], cat_colors(categories{i}), 'EdgeColor','none');
% end
% 
% % --- Plot current with compressed x ---
% x_map_I = interp1(time_stamps, x_equal, simOut.tout, 'linear', 'extrap');
% h_current = plot(x_map_I, simOut.HVBatPack_Current_Prim, ...
%     'Color', [0.9290 0.6940 0.1250], 'LineWidth', 2);  % keep original line color/width
% 
% % --- Two precharge windows & annotations ---
% precharge_windows = [0.1 0.198; 15.1 15.181; 29.8 29.881];
% segWidth = x_equal(2)-x_equal(1);  % for a small offset in compressed axis
% 
% for k = 1:size(precharge_windows,1)
%     t_start = precharge_windows(k,1);
%     t_end   = precharge_windows(k,2);
%     idx = simOut.tout >= t_start & simOut.tout <= t_end;
% 
%     if any(idx)
%         mpc = max(simOut.HVBatPack_Current_Prim(idx));          % window-specific max
%         xs  = interp1(time_stamps, x_equal, t_start, 'linear','extrap');
%         xe  = interp1(time_stamps, x_equal, t_end,   'linear','extrap');
% 
%         xline(xs, '--', 'HandleVisibility','off');
%         xline(xe, '--', 'HandleVisibility','off');
% 
%         % placement rule: after precharge ends
%         xt = xe + 0.05*segWidth;
% 
%         text(xt, mpc, ...
%         sprintf('Maximum current\non precharge\nsequence: %.0f A', mpc), ...
%         'HorizontalAlignment','left', ...
%         'VerticalAlignment','bottom', ...
%         'FontSize', 16);
%     end
% end
% 
% % --- Axes, ticks, legend, export ---
% xlim([0 1]); ylim([ymin ymax]);
% ax = gca; ax.FontSize = 18; ax.Layer = 'top'; grid on
% xlabel('Time (s)', 'FontSize', 22);
% ylabel('Measured Current (A)', 'FontSize', 22);
% 
% xticks(x_equal(2:end));
% xticklabels(string(time_stamps_one_decimal(2:end)));
% 
% legend(h_current, 'Battery Pack Current', 'FontSize', 18, 'Location','northeast');
% exportgraphics(gcf, 'Fig2.png', 'Resolution', 1200);
% 
% 
% 
% %% === FIGURE 3: Precharge Voltages (Equal-area segments, same formatting as Fig 1) ===
% figure(3)
% clf;
% 
% % Use the same segmentation as Fig 1
% nSegments = numel(time_stamps) - 1;
% x_equal   = linspace(0,1,nSegments+1);   % equally spaced compressed x
% 
% % --- Background ---
% ymin = 0; ymax = 500;
% hold on
% for i = 1:nSegments
%     fill([x_equal(i) x_equal(i+1) x_equal(i+1) x_equal(i)], ...
%          [ymin ymin ymax ymax], cat_colors(categories{i}), 'EdgeColor','none');
% end
% 
% % --- Plot voltages with compressed x ---
% x_map_V = interp1(time_stamps, x_equal, simOut.tout, 'linear', 'extrap');
% 
% % keep original line colors for these three traces
% c3 = [
%     0.9290 0.6940 0.1250;  % (used for EDM bus)
%     0.8500 0.3250 0.0980;  % pack voltage (reddish)
%     0.0000 0.4470 0.7410;  % DCFC or bus (blue)
% ];
% 
% h_pack = plot(x_map_V, simOut.HVBatPack_Voltage,     'Color', c3(2,:), 'LineWidth', 2);
% h_dcfc = plot(x_map_V, simOut.HVBatPack_DCFCVoltage, 'Color', c3(3,:), 'LineWidth', 2);
% h_bus  = plot(x_map_V, simOut.HVBatPack_EDMVoltage,  'Color', c3(1,:), 'LineWidth', 2);
% 
% % --- Threshold line & label (place just after first precharge ends) ---
% yline(Pre_charge_Voltage_Threshold, '--', 'HandleVisibility', 'off');
% segWidth = x_equal(2)-x_equal(1);
% x_label  = interp1(time_stamps, x_equal, 0.198, 'linear','extrap') + 0.05*segWidth;
% 
% text(x_label, Pre_charge_Voltage_Threshold, ...
%     sprintf('Precharge voltage threshold = %.1f V', Pre_charge_Voltage_Threshold), ...
%     'HorizontalAlignment', 'left', ...
%     'VerticalAlignment', 'top', ...
%     'FontSize', 16);
% 
% % --- Axes, ticks, legend, export ---
% xlabel('Time (s)', 'FontSize', 18);
% ylabel('Measured Voltage (V)', 'FontSize', 18);
% xlim([0 1]); ylim([ymin ymax]);
% ax = gca; ax.FontSize = 18; ax.Layer = 'top'; grid on
% 
% xticks(x_equal(2:end));
% xticklabels(string(time_stamps_one_decimal(2:end)));
% 
% legend([h_pack, h_dcfc, h_bus], ...
%     {'Battery Pack Voltage','DCFC Voltage','EDM Voltage'}, ...
%     'FontSize', 18, 'Location', 'southeast');
% 
% exportgraphics(gcf, 'Fig3.png', 'Resolution', 1200);
% 
% 
% %% === FIGURE 4: Battery Contactor Control Status ===
% figure(4)
% clf;
% 
% % === Background limits ===
% ymin = 0;
% ymax = 8;
% 
% hold on
% 
% % Draw background regions
% for i = 1:nSegments
%     fill([x_equal(i) x_equal(i+1) x_equal(i+1) x_equal(i)], ...
%          [ymin ymin ymax ymax], cat_colors(categories{i}), 'EdgeColor','none');
% end
% 
% % --- Map time to equal x-axis ---
% x_mapped = nan(size(simOut.tout));
% HVBatCntctrStat_mapped = nan(size(simOut.HVBatCntctrStat));
% 
% for i = 1:nSegments
%     idx_start = find(simOut.tout >= time_stamps(i)+eps, 1, 'first');
%     idx_end   = find(simOut.tout <= time_stamps(i+1), 1, 'last');
%     if ~isempty(idx_start) && ~isempty(idx_end)
%         idx = idx_start:idx_end;
%         x_mapped(idx) = linspace(x_equal(i), x_equal(i+1), length(idx));
%         HVBatCntctrStat_mapped(idx) = simOut.HVBatCntctrStat(idx);
%     end
% end
% 
% % --- Plot signal ---
% h_signal = plot(x_mapped, HVBatCntctrStat_mapped, 'k', 'LineWidth', 2);
% 
% y_offset = 0.05 * (ymax - ymin); 
% 
% for k = 1:size(precharge_windows,1)
%     t_start = precharge_windows(k,1);
%     t_end   = precharge_windows(k,2);
% 
%     % Map to equalized x-axis
%     x_start = interp1(time_stamps, x_equal, t_start);
%     x_end   = interp1(time_stamps, x_equal, t_end);
% 
%     % Vertical dashed lines
%     xline(x_start, '--', 'HandleVisibility','off');
%     xline(x_end,   '--', 'HandleVisibility','off');
% 
%     % --- Annotations: each sequence takes 2 lines ---
%     y_start = ymax - y_offset*(2*k-2);  % line 1 for sequence k
%     y_end   = ymax - y_offset*(2*k-1);  % line 2 for sequence k
% 
%     if k == 1
%         % Full text for the first sequence
%         text(x_start + 0.005, y_start, ...
%             sprintf('Start of precharge 1: t_{s_1} = %.2f s', t_start), ...
%             'HorizontalAlignment','left', ...
%             'VerticalAlignment','top', ...
%             'FontSize', 16);
% 
%         text(x_end + 0.005, y_end, ...
%             sprintf('End of precharge 1: t_{e_1} = %.2f s', t_end), ...
%             'HorizontalAlignment','left', ...
%             'VerticalAlignment','top', ...
%             'FontSize', 16);
%     else
%         % Short labels for remaining sequences
%         text(x_start + 0.005, y_start, ...
%             sprintf('t_{s_%d} = %.2f s', k, t_start), ...
%             'HorizontalAlignment','left', ...
%             'VerticalAlignment','top', ...
%             'FontSize', 16);
% 
%         text(x_end + 0.005, y_end, ...
%             sprintf('t_{e_%d} = %.2f s', k, t_end), ...
%             'HorizontalAlignment','left', ...
%             'VerticalAlignment','top', ...
%             'FontSize', 16);
%     end
% end
% 
% 
% % --- Axes and grid ---
% xlabel('Time (s)', 'FontSize', 22);
% ylabel('Battery Contactor State', 'FontSize', 22);
% xlim([0 1]); ylim([ymin ymax]);
% ax = gca;
% ax.FontSize = 18;
% ax.Layer = 'top';
% grid on;
% 
% xticks(x_equal(2:end));
% xticklabels(string(time_stamps_one_decimal(2:end)));
% 
% legend(h_signal, {'Contactor State'}, 'FontSize', 18, 'Location','northeast');
% 
% % --- Export figure ---
% exportgraphics(gcf, 'Fig4.png', 'Resolution', 1200);

%% === FIGURE 5: All categories in one figure ===
figure(5)
clf;

% === Axes setup (invisible) ===
ax = axes('Position',[0 0 1 1],'Visible','off');
hold(ax,'on');

% All categories in order
all_categories = {'Open','Precharging','Driving Normal','Driving Shorted High','Driving Shorted Low', ...
                  'Charging Normal','Charging Shorted High','Charging Shorted Low'};

% Plot dummy patches for all categories
for i = 1:numel(all_categories)
    h(i) = plot(ax, nan, nan, 's', 'MarkerSize', 14, ...
        'MarkerFaceColor', cat_colors(all_categories{i}), ...
        'MarkerEdgeColor', 'k');
end

% Single legend with 8 entries
lgd = legend(ax, h, all_categories, 'FontSize', 16, ...
             'Location','northoutside', 'Orientation','horizontal');

% Make first 5 categories appear on first "row", last 3 on second
lgd.NumColumns = 8;  % all entries in one line; spacing will auto-wrap if figure is narrow

% Adjust position to keep top alignment
lgd.Position(2) = 0.95;  

% Turn off axes
axis(ax,'off'); box(ax,'off');

% --- Export high-resolution figure ---
exportgraphics(gcf, 'Fig5.png', 'Resolution', 1200);


