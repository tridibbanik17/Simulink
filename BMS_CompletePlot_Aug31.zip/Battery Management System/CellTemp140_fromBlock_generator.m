function CellTemp140_fromBlock_generator()
    model = 'Simulink_Program';
    subsystem = [model '/Subsystem/Rice'];
    load_system(model);

    % Parameters
    total_signals = 140;
    real_signals = 105;
    dummy_signals = total_signals - real_signals;
    avg_temp = 25.0; % average temperature for dummy blocks

    % Positioning
    x0 = 30; y0 = 50;
    x_spacing = 150; y_spacing = 40;

    % Create From blocks for 105 real signals
    for i = 1:real_signals
        tag = sprintf('HVBatCell_Temp%03d', i);
        block_name = ['From_' tag];
        block_path = [subsystem '/' block_name];
        add_block('simulink/Signal Routing/From', block_path, ...
            'GotoTag', tag, ...
            'Position', [x0, y0 + (i-1)*y_spacing, x0+60*6, y0 + (i-1)*y_spacing + 15]);  % widened
    end

    % Create Constant blocks for remaining 35 dummy signals
    for i = (real_signals+1):total_signals
        const_name = sprintf('Const_HVBatCell_Temp%03d', i);
        block_path = [subsystem '/' const_name];
        add_block('simulink/Sources/Constant', block_path, ...
            'Value', num2str(avg_temp), ...
            'Position', [x0, y0 + (i-1)*y_spacing, x0+60*6, y0 + (i-1)*y_spacing + 15]);
    end

    % Create Mux
    mux_path = [subsystem '/CellTempMux'];
    add_block('simulink/Signal Routing/Mux', mux_path, ...
        'Inputs', num2str(total_signals), ...
        'Position', [x0 + 300, y0, x0 + 300 + 60, y0 + total_signals*y_spacing]);

    % Connect all blocks to Mux
    for i = 1:total_signals
        if i <= real_signals
            src = [subsystem '/From_' sprintf('HVBatCell_Temp%03d', i)];
        else
            src = [subsystem '/Const_' sprintf('HVBatCell_Temp%03d', i)];
        end
        dst = mux_path;
        add_line(subsystem, [get_param(src, 'Name') '/1'], ['CellTempMux/' num2str(i)], 'autorouting', 'on');
    end

    % Create Goto block
    goto_path = [subsystem '/HVBatCell_Temperatures_140'];
    add_block('simulink/Signal Routing/Goto', goto_path, ...
        'GotoTag', 'HVBatCell_Temperatures_140', ...
        'TagVisibility', 'local', ...
        'Position', [x0 + 500, y0 + 100, x0 + 500 + 60*6, y0 + 120]);

    % Connect Mux to Goto
    add_line(subsystem, 'CellTempMux/1', 'HVBatCell_Temperatures_140/1', 'autorouting', 'on');

    save_system(model);
end
