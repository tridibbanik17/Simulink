function setGotoTagsToGlobal()
    model = 'Simulink_Program';
    subsystem = [model '/Subsystem/SOC'];
    % Ensure model is loaded
    load_system(model);

    % Generate tag names
    tags = arrayfun(@(i) sprintf('HVBatCell_Temp%03d', i), 1:105, 'UniformOutput', false);

    % Loop over tags and update Goto blocks
    for i = 1:length(tags)
        tagName = tags{i};
        % Search for the Goto block with this tag in the subsystem
        block = find_system(subsystem, ...
            'SearchDepth', 1, ...
            'BlockType', 'Goto', ...
            'GotoTag', tagName);
        
        if ~isempty(block)
            % Set the GotoTagVisibility to global
            set_param(block{1}, 'TagVisibility', 'global');
            fprintf('Updated: %s\n', block{1});
        else
            warning('Goto block not found for tag: %s', tagName);
        end
    end

    % Save and close model if needed
    % save_system(model);
end
