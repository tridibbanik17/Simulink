figure('Visible','on', 'Position', [100, 100, 900, 200]);

% === Row 1 (5 categories, centered) ===
ax1 = axes('Position',[0 0 1 1],'Visible','off');
hold(ax1,'on');
row1 = {'Open','Precharging','Driving Normal','Driving Shorted High','Driving Shorted Low'};
for i = 1:numel(row1)
    h1(i) = plot(ax1, nan, nan, 's', 'MarkerSize', 16, ...
        'MarkerFaceColor', cat_colors(row1{i}), ...
        'MarkerEdgeColor', 'k');
end
lgd1 = legend(ax1, h1, row1, 'FontSize', 22, ...
    'Location','northoutside','Orientation','horizontal');
lgd1.NumColumns = numel(row1);

% === Row 2 (3 categories, right-aligned) ===
ax2 = axes('Position',[0 0 1 1],'Visible','off');
hold(ax2,'on');
row2 = {'Charging Normal','Charging Shorted High','Charging Shorted Low'};
for i = 1:numel(row2)
    h2(i) = plot(ax2, nan, nan, 's', 'MarkerSize', 16, ...
        'MarkerFaceColor', cat_colors(row2{i}), ...
        'MarkerEdgeColor', 'k');
end
lgd2 = legend(ax2, h2, row2, 'FontSize', 22, ...
    'Location','northoutside','Orientation','horizontal');
lgd2.NumColumns = numel(row2);

% === Align row 2 under row 1, flush right ===
lgd2.Position(1) = lgd1.Position(1) + lgd1.Position(3) - lgd2.Position(3); % right align
lgd2.Position(2) = lgd1.Position(2) - 0.15; % push it down
