#ifndef CAN_C5_H
#define CAN_C5_H

#include <stdint.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" { 
#endif

#ifndef PREPACK
#define PREPACK
#endif

#ifndef POSTPACK
#define POSTPACK
#endif

#ifndef DBCC_DOUBLE_TYPE
#define DBCC_DOUBLE_TYPE
typedef double dbcc_double_t;
#endif

#ifndef DBCC_FLOAT_TYPE
#define DBCC_FLOAT_TYPE
typedef float dbcc_float_t;
#endif

#ifndef DBCC_TIME_STAMP
#define DBCC_TIME_STAMP
typedef uint32_t dbcc_time_stamp_t; /* Time stamp for message; you decide on units */
#endif

#ifndef DBCC_STATUS_ENUM
#define DBCC_STATUS_ENUM
typedef enum {
	DBCC_SIG_STAT_UNINITIALIZED_E = 0, /* Message never sent/received */
	DBCC_SIG_STAT_OK_E            = 1, /* Message ok */
	DBCC_SIG_STAT_ERROR_E         = 2, /* Encode/Decode/Timestamp/Any error */
} dbcc_signal_status_e;
#endif

#define CAN_ID_BPCM_STATUS1_BEV (149) /* 0x95 */
#define CAN_ID_HYBRID_STATUS1 (180) /* 0xb4 */
#define CAN_ID_BPCM_IMPACT (224) /* 0xe0 */
#define CAN_ID_BPCM_DC_STATUS (263) /* 0x107 */
#define CAN_ID_DC_CHARGING_COMMAND (264) /* 0x108 */
#define CAN_ID_BPCM_MSG_01 (336) /* 0x150 */
#define CAN_ID_BPCM_PHEV_2 (337) /* 0x151 */
#define CAN_ID_IMPACT_INFO (346) /* 0x15a */
#define CAN_ID_BPCM_HV_MODULES1 (464) /* 0x1d0 */
#define CAN_ID_HYBRID_STATUS2 (471) /* 0x1d7 */
#define CAN_ID_HYBRID_COMMAND_BPCM (472) /* 0x1d8 */
#define CAN_ID_SBW_ROT1_DPT (528) /* 0x210 */
#define CAN_ID_HCP_GW_20 (530) /* 0x212 */
#define CAN_ID_BPCM_MSG_02 (544) /* 0x220 */
#define CAN_ID_BPCM_DISCHARGEPOWERLIMITS_BEV (641) /* 0x281 */
#define CAN_ID_BPCM_CHARGEPOWERLIMITS_BEV (645) /* 0x285 */
#define CAN_ID_BPCM_HV_IMPEDANCE (710) /* 0x2c6 */
#define CAN_ID_BPCM_HV_SOC (774) /* 0x306 */
#define CAN_ID_BPCM_HV_TEMPERATURE (775) /* 0x307 */
#define CAN_ID_BP_CNC_CO (786) /* 0x312 */
#define CAN_ID_DC_CHARGING_STATUS1 (802) /* 0x322 */
#define CAN_ID_BPCM_MSG_04 (852) /* 0x354 */
#define CAN_ID_BPCM_HV_VOLTLIMITS (854) /* 0x356 */
#define CAN_ID_HYBRIDRMS_SAFETY (856) /* 0x358 */
#define CAN_ID_BPCM_STATUS2_BEV (857) /* 0x359 */
#define CAN_ID_GPS_POS3 (908) /* 0x38c */
#define CAN_ID_NET_CFG_EPT (926) /* 0x39e */
#define CAN_ID_HCP_CHARGING_STAT2 (977) /* 0x3d1 */
#define CAN_ID_HCP_GW_1000 (978) /* 0x3d2 */
#define CAN_ID_VIN (992) /* 0x3e0 */
#define CAN_ID_BPCM_MSG_05 (1000) /* 0x3e8 */
#define CAN_ID_BPCM_LTRACTPUMP1 (1002) /* 0x3ea */
#define CAN_ID_BPCM_LTRACTPUMP2 (1003) /* 0x3eb */
#define CAN_ID_BPCM_BATTHTR1 (1004) /* 0x3ec */
#define CAN_ID_BPCM_BATTHTR2 (1005) /* 0x3ed */
#define CAN_ID_THERMAL_COMMAND (1006) /* 0x3ee */
#define CAN_ID_PROXI_CFG (1021) /* 0x3fd */
#define CAN_ID_DG_RQ_GLOBAL_UDS (1089) /* 0x441 */
#define CAN_ID_TRANSM2 (1448) /* 0x5a8 */
#define CAN_ID_ECU_APPL_BPCM (1471) /* 0x5bf */
#define CAN_ID_SD_RS_BPCM (1599) /* 0x63f */
#define CAN_ID_APPL_ECU_BPCM (1791) /* 0x6ff */
#define CAN_ID_DG_RQ_GLOBAL (2015) /* 0x7df */
#define CAN_ID_D_RQ_BPCM (2023) /* 0x7e7 */
#define CAN_ID_D_RS_BPCM (2031) /* 0x7ef */

typedef PREPACK struct {
	/* HVBatteryCurrent_BEV: High voltage battery pack current */
	/* scaling 0.1, offset -1500.0, units Amp */
	uint16_t HVBatteryCurrent_BEV;
	/* HVBatteryVoltage_BEV: High voltage battery pack voltage */
	/* scaling 0.1, offset 100.0, units Volts */
	uint16_t HVBatteryVoltage_BEV;
	/* CellVoltage_NumMax_BEV: Cell number with maximum voltage */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CellVoltage_NumMax_BEV;
	/* CellVoltage_NumMin_BEV: Cell number with Minimum voltage */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CellVoltage_NumMin_BEV;
} POSTPACK can_0x095_BPCM_Status1_BEV_t;

typedef PREPACK struct {
	/* CRC_0B4h: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_0B4h;
	/* MC_0B4h: Message counter 0B4h */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_0B4h;
	/* HCPShutDwnCmd: HCP System Shutdown Command */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HCPShutDwnCmd;
	/* EPT_LOC_DiagEnable: . */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t EPT_LOC_DiagEnable;
	/* PrplsnSysAtv: Propulsion system active, [1] = active */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t PrplsnSysAtv;
	/* DriveReady: Ready to Drive, [1] = Vehicle is allowed to shift out of park or neutral */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t DriveReady;
} POSTPACK can_0x0b4_Hybrid_Status1_t;

typedef PREPACK struct {
	/* ImpactHardwireV: Valid serial line comunication */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t ImpactHardwireV;
	/* ImpactHardwire: This signal is used to indicate that a crash happened */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t ImpactHardwire;
} POSTPACK can_0x0e0_BPCM_IMPACT_t;

typedef PREPACK struct {
	/* HVBat_DC_CntctrStat: HV Battery pack DC contactor state */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBat_DC_CntctrStat;
	/* HVBat_DC_CntctrOpn: HV Battery Pack DC contactor Open */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBat_DC_CntctrOpn;
	/* HVBat_DC_CntctrReq: HV Battery pack DC contactor request */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBat_DC_CntctrReq;
	/* DC_Isolation_Sts: Isolation status for DC charging;0x0 = Enabled 0x1= Disabled */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t DC_Isolation_Sts;
	/* HVBatCntctrStkOpnChk: Flag to indicate if HV Battery contactor stuck open check is complete */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCntctrStkOpnChk;
} POSTPACK can_0x107_BPCM_DC_Status_t;

typedef PREPACK struct {
	/* CRC_DC_Charging_Command: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_DC_Charging_Command;
	/* MC_DC_Charging_Command: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_DC_Charging_Command;
	/* DC_CntctrCmd: High voltage battery DC contactor command */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t DC_CntctrCmd;
	/* DC_Isolation_Cmd: Isolation Disabling command for DC charging;0x0 = Enable 0x1 = Disable */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t DC_Isolation_Cmd;
} POSTPACK can_0x108_DC_Charging_Command_t;

typedef PREPACK struct {
	/* CRC_150h: CRC-Checksum Byte 1 - 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_150h;
	/* MC_150h: HV Battery pack contactor state message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_150h;
	/* HVBatCntctrStat: HV Battery pack contactor state */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCntctrStat;
	/* HVBatCntrWeld_ImpdOpn: Contactor welded and has impeded opening when commanded by BPCM. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCntrWeld_ImpdOpn;
	/* HVBatIntrlkStat: High Voltage Battery interlock state */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatIntrlkStat;
	/* HVBatIntrlk_InternalStat: HVIL Status internal */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatIntrlk_InternalStat;
	/* HVBatIsolStat: High voltage battery pack Isolation state */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatIsolStat;
	/* PwrtrnHV_IsolStat: Powertrain High voltage Isolation state */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t PwrtrnHV_IsolStat;
	/* HVBatCntctrOpn: HV Battery Pack contactor Open */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCntctrOpn;
	/* HVBatCntctrReq: HV Battery pack contactor request */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCntctrReq;
	/* HVBatRdy: High Voltage Battery Ready */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatRdy;
} POSTPACK can_0x150_BPCM_MSG_01_t;

typedef PREPACK struct {
	/* HVBat_Real_Time_Clock: 32 bit Real Time Clock */
	/* scaling 1.0, offset 0.0, units sec */
	uint32_t HVBat_Real_Time_Clock;
	/* HVBat_Real_Time_Clock_V: - */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBat_Real_Time_Clock_V;
} POSTPACK can_0x151_BPCM_PHEV_2_t;

typedef PREPACK struct {
	/* CRC_II: CRC according to SAE J1850 standard that has to be calculated from bit 63 to bit 8 at each frame transmission. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_II;
	/* MessageCounter_II: This signal is a counter used for safety checks strategies. This counter is incremented of 1 (one) unit at each frame transmission. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MessageCounter_II;
	/* IMPACTCommand: This signal is used to indicate that a crash happened */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t IMPACTCommand;
	/* IMPACTConfirm: This signal is used to confirm that a crash happened */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t IMPACTConfirm;
} POSTPACK can_0x15a_IMPACT_INFO_t;

typedef PREPACK struct {
	/* HVBatModuleTemp_Max: HV Battery pack maximum temperature */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatModuleTemp_Max;
	/* CRC_BPCM_HV_Modules1: CRC-Checksum Byte 1 - 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_BPCM_HV_Modules1;
	/* HVBatModuleVoltage_NumMin: Module number - minimum voltage */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatModuleVoltage_NumMin;
	/* HVBatModuleTemp_NumMax: Module number - maximum temperature */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatModuleTemp_NumMax;
	/* HVBatModuleTemp_NumMin: Module number - minimum temperature */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatModuleTemp_NumMin;
	/* HVBatModuleVoltage_NumMax: Module number - maximum voltage */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatModuleVoltage_NumMax;
	/* MC_BPCM_HV_Modules1: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_BPCM_HV_Modules1;
} POSTPACK can_0x1d0_BPCM_HV_Modules1_t;

typedef PREPACK struct {
	/* CRC_1D7h: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_1D7h;
	/* MC_1D7h: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_1D7h;
	/* Charger_Plugin_Status: Charger plug-in status */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t Charger_Plugin_Status;
} POSTPACK can_0x1d7_Hybrid_Status2_t;

typedef PREPACK struct {
	/* HVInvRatVlt: ?? */
	/* scaling 1.0, offset 0.0, units V */
	uint16_t HVInvRatVlt;
	/* CRC_1D8h: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_1D8h;
	/* MC_1D8h: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_1D8h;
	/* MainHighVltCntctrCmd: High voltage battery contactor command */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MainHighVltCntctrCmd;
	/* HVBat_CoolantLvlLo: Battery coolant level low */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBat_CoolantLvlLo;
	/* HVInvRatVltV: . */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVInvRatVltV;
} POSTPACK can_0x1d8_Hybrid_Command_BPCM_t;

typedef PREPACK struct {
	/* CRC_SBW_ROT1_DPT: CRC-checksum byte 1 to 4 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_SBW_ROT1_DPT;
	/* MC_SBW_ROT1_DPT: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_SBW_ROT1_DPT;
	/* DrvRqShftROT_DPT: Driver requested gear shift position */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t DrvRqShftROT_DPT;
} POSTPACK can_0x210_SBW_ROT1_DPT_t;

typedef PREPACK struct {
	/* VEH_SPEED: Vehicle speed */
	/* scaling 0.0, offset 0.0, units km/h */
	uint16_t VEH_SPEED;
	/* CRC_VEH_SPEED: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_VEH_SPEED;
	/* MC_VEH_SPEED: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_VEH_SPEED;
	/* CmdIgnStat: Commanded ignition switch status */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CmdIgnStat;
} POSTPACK can_0x212_HCP_GW_20_t;

typedef PREPACK struct {
	/* HVBatCellVltAvg: Average cell voltage */
	/* scaling 0.0, offset 0.0, units Volts */
	uint16_t HVBatCellVltAvg;
	/* HVBatCellVltMax: Max cell voltage */
	/* scaling 0.0, offset 0.0, units Volts */
	uint16_t HVBatCellVltMax;
	/* HVBatCellVltMin: Min cell voltage */
	/* scaling 0.0, offset 0.0, units Volts */
	uint16_t HVBatCellVltMin;
	/* HVBatCellVltMinV: Min cell voltage valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCellVltMinV;
	/* HVBatCellVltAvgV: Average cell voltage valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCellVltAvgV;
	/* HVBatCellVltMaxV: Max cell voltage valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatCellVltMaxV;
} POSTPACK can_0x220_BPCM_MSG_02_t;

typedef PREPACK struct {
	/* BPCM_HVBatDischrgPowInstant: High voltage battery discharge power (instant window) */
	/* scaling 0.1, offset 0.0, units kW */
	uint16_t BPCM_HVBatDischrgPowInstant;
	/* BPCM_HVBatDischrgPowShort: High voltage battery discharge power (short window) */
	/* scaling 0.1, offset 0.0, units kW */
	uint16_t BPCM_HVBatDischrgPowShort;
	/* BPCM_HVBatDischrgPowLong: High voltage battery discharge power (long window) */
	/* scaling 0.1, offset 0.0, units kW */
	uint16_t BPCM_HVBatDischrgPowLong;
} POSTPACK can_0x281_BPCM_DischargePowerLimits_BEV_t;

typedef PREPACK struct {
	/* BPCM_HVBatChrgPowInstant: High voltage battery charge power (instant window) */
	/* scaling 0.1, offset 0.0, units kW */
	uint16_t BPCM_HVBatChrgPowInstant;
	/* BPCM_HVBatChrgPowShort: High voltage battery charge power (short window) */
	/* scaling 0.1, offset 0.0, units kW */
	uint16_t BPCM_HVBatChrgPowShort;
	/* BPCM_HVBatChrgPowLong: High voltage battery charge power (long window) */
	/* scaling 0.1, offset 0.0, units kW */
	uint16_t BPCM_HVBatChrgPowLong;
	/* BEV_HVBatPwrLim_On_BPCM: Limp Home mode enabled */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BEV_HVBatPwrLim_On_BPCM;
} POSTPACK can_0x285_BPCM_ChargePowerLimits_BEV_t;

typedef PREPACK struct {
	/* HVBatMin_Cell_Dischrg_Imped: Minimum cell discharge impedance */
	/* scaling 0.0, offset 0.0, units Ohms */
	uint16_t HVBatMin_Cell_Dischrg_Imped;
	/* HVBatMax_Cell_Dischrg_Imped: Maximum Cell disCharge Impedance */
	/* scaling 0.0, offset 0.0, units Ohms */
	uint16_t HVBatMax_Cell_Dischrg_Imped;
	/* HVBatMax_Cell_Dischrg_Imped_V: Maximum cell discharge impedance valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatMax_Cell_Dischrg_Imped_V;
	/* HVBatMin_Cell_Dischrg_Imped_V: Minimum cell discharge impedance validity; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatMin_Cell_Dischrg_Imped_V;
} POSTPACK can_0x2c6_BPCM_HV_Impedance_t;

typedef PREPACK struct {
	/* HVBatSOC: High voltage battery pack state of charge */
	/* scaling 0.0, offset 0.0, units % */
	uint16_t HVBatSOC;
	/* HVBatSOH: HV Battery percentage of State of Health.  Last-Known value to be stored in EEPROM. */
	/* scaling 0.2, offset 50.0, units % */
	uint8_t HVBatSOH;
	/* HVBatSOHLow: HV Battery percentage of State of Health Low */
	/* scaling 0.2, offset 50.0, units % */
	uint8_t HVBatSOHLow;
	/* HVBatSOCMax: Maximum HV battery cell state of charge */
	/* scaling 0.4, offset 0.0, units % */
	uint8_t HVBatSOCMax;
	/* HVBatSOCMin: Minimum HV battery cell state of charge */
	/* scaling 0.4, offset 0.0, units % */
	uint8_t HVBatSOCMin;
	/* HVBatSOCV: High voltage battery state of charge validity. 0-Valid, 1-Invalid. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatSOCV;
} POSTPACK can_0x306_BPCM_HV_SOC_t;

typedef PREPACK struct {
	/* HVBatClgInletTemp: High voltage pack outlet cooling temperature */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatClgInletTemp;
	/* HVBatClgOutletTemp: High voltage pack outlet cooling temperature valid */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatClgOutletTemp;
	/* HVBatModTempMin: HV Battery pack Minimum temperature */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatModTempMin;
	/* HVBatModTempMax: HV Battery pack Maximum temperature */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatModTempMax;
	/* HVBatModTempAvg: HV Battery pack average temperature */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatModTempAvg;
	/* HVBatClgInletTempV: High voltage pack outlet cooling temperature valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatClgInletTempV;
	/* HVBatClgOutletTempV: High voltage pack outlet cooling temperature valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatClgOutletTempV;
	/* HVBatModTempMaxV: HV battery pack maximum temperature validity; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatModTempMaxV;
	/* HVBatModlTempAvgV: HV battery pack average temperature validity; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatModlTempAvgV;
	/* HVBatModTempMinV: HV battery pack minimum temperature validity; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatModTempMinV;
} POSTPACK can_0x307_BPCM_HV_Temperature_t;

typedef PREPACK struct {
	/* HBCO_CellVltMax_High: Cell Voltage too High */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HBCO_CellVltMax_High;
	/* HBCO_CellVltMin_Low: Cell Voltage too Low */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HBCO_CellVltMin_Low;
	/* HBCNC_BUT: HV Battery under temperature */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HBCNC_BUT;
	/* HBCNC_BOT: Battery over temperature */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HBCNC_BOT;
} POSTPACK can_0x312_BP_CNC_CO_t;

typedef PREPACK struct {
	/* DCChargeInitialized: DC charge initialized */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t DCChargeInitialized;
} POSTPACK can_0x322_DC_Charging_Status1_t;

typedef PREPACK struct {
	/* HVBatCell_Voltage_High_Thrsh: Cell voltage high threshold */
	/* scaling 0.0, offset 0.0, units Volts */
	uint16_t HVBatCell_Voltage_High_Thrsh;
	/* HVBatCell_Voltage_Low_Thrsh: Cell voltage low threshold */
	/* scaling 0.0, offset 0.0, units Volts */
	uint16_t HVBatCell_Voltage_Low_Thrsh;
	/* HVBatHighTempThrsh: High Voltage Battery High Temperature Threshold */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatHighTempThrsh;
	/* HVBatLowTempThrsh: High Voltage Battery low Temperature Threshold */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t HVBatLowTempThrsh;
} POSTPACK can_0x354_BPCM_MSG_04_t;

typedef PREPACK struct {
	/* HVBatMinCellVltAlld: Minimum cell voltage allowed */
	/* scaling 0.0, offset 1.5, units Volts */
	uint16_t HVBatMinCellVltAlld;
	/* HVBatMaxCellVltAlld: Maximum cell voltage allowed */
	/* scaling 0.0, offset 1.5, units Volts */
	uint16_t HVBatMaxCellVltAlld;
	/* HVBatMinPkVltAllwd: Minimum battery pack voltage allowed */
	/* scaling 1.0, offset 175.0, units V */
	uint16_t HVBatMinPkVltAllwd;
	/* HVBatMaxPkVltAllwd: Maximum pack voltage allowed */
	/* scaling 1.0, offset 175.0, units V */
	uint16_t HVBatMaxPkVltAllwd;
	/* HVBatMaxCellVltAlld_V: Maximum cell voltage allowed valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatMaxCellVltAlld_V;
	/* HVBatMinCellVltAlld_V: Minimum cell voltage allowed valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatMinCellVltAlld_V;
	/* HVBatMinPkVltAllwd_V: Minimum battery pack voltage allowed valid; Invalid = [1] */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatMinPkVltAllwd_V;
} POSTPACK can_0x356_BPCM_HV_VoltLimits_t;

typedef PREPACK struct {
	/* CRC_HybridRMS_Safety: CRC-Checksum Byte 1 - 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_HybridRMS_Safety;
	/* MC_HybridRMS_Safety: Message Counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_HybridRMS_Safety;
	/* ThermalRunaway_Warning: Thermal runaway detection status. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t ThermalRunaway_Warning;
} POSTPACK can_0x358_HybridRMS_Safety_t;

typedef PREPACK struct {
	/* MaxChargeCurrentAllowed: High voltage battery pack maximum charge current allowed */
	/* scaling 0.1, offset 0.0, units Amp */
	uint16_t MaxChargeCurrentAllowed;
	/* TotalAmpHrCapacity: High voltage battery pack total amp-hour capacity */
	/* scaling 0.1, offset 0.0, units Ah */
	uint16_t TotalAmpHrCapacity;
	/* MaxPackVoltageAllowed: High voltage battery pack maximum voltage allowed */
	/* scaling 1.0, offset 100.0, units Ah */
	uint16_t MaxPackVoltageAllowed;
	/* MinPackVoltageAllowed: High voltage battery pack maximum voltage allowed */
	/* scaling 1.0, offset 100.0, units Volts */
	uint16_t MinPackVoltageAllowed;
} POSTPACK can_0x359_BPCM_Status2_BEV_t;

typedef PREPACK struct {
	/* GPS_Date_Year: GPS date year */
	/* scaling 1.0, offset 0.0, units Years */
	uint16_t GPS_Date_Year;
	/* GPS_UTC_Second: GPS UTC second */
	/* scaling 0.0, offset 0.0, units s */
	uint16_t GPS_UTC_Second;
	/* GPS_Date_Month: GPS date month */
	/* scaling 1.0, offset 0.0, units Months */
	uint8_t GPS_Date_Month;
	/* GPS_Date_Day: GPS date day */
	/* scaling 1.0, offset 0.0, units Days */
	uint8_t GPS_Date_Day;
	/* GPS_UTC_Hour: GPS UTC hour */
	/* scaling 1.0, offset 0.0, units h */
	uint8_t GPS_UTC_Hour;
	/* GPS_UTC_Minute: GPS UTC minute */
	/* scaling 1.0, offset 0.0, units min */
	uint8_t GPS_UTC_Minute;
} POSTPACK can_0x38c_GPS_POS3_t;

typedef PREPACK struct {
	/* NET_CFG_STAT_ePT: Network configuration status. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t NET_CFG_STAT_ePT;
	/* NetCfg_OBCM_ePT: On Board Charging Module. 1=present */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t NetCfg_OBCM_ePT;
	/* NetCfg_AHCP_ePT: Transmission Control Processor (1=present) */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t NetCfg_AHCP_ePT;
	/* NetCfg_BPCM_ePT: Battery Pack Control Module (1=present) */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t NetCfg_BPCM_ePT;
	/* NetCfg_APM_ePT: Auxiliary Power Module (1=present) */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t NetCfg_APM_ePT;
} POSTPACK can_0x39e_NET_CFG_EPT_t;

typedef PREPACK struct {
	/* ChargingSysSts: Charging System status */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t ChargingSysSts;
} POSTPACK can_0x3d1_HCP_Charging_Stat2_t;

typedef PREPACK struct {
	/* ODO: Odometer */
	/* scaling 0.1, offset 0.0, units km */
	uint32_t ODO;
	/* BATT_VOLT: System voltage */
	/* scaling 0.1, offset 0.0, units Volts */
	uint8_t BATT_VOLT;
} POSTPACK can_0x3d2_HCP_GW_1000_t;

typedef PREPACK struct {
	/* VIN_DATA: VIN Digits (8 bit ascii encoded) - see Signal Description Doc for details */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t VIN_DATA;
	/* VIN_MSG: VIN Message Information */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t VIN_MSG;
} POSTPACK can_0x3e0_VIN_t;

typedef PREPACK struct {
	/* Prchrgpnltytimer: Precharge Penalty Timer */
	/* scaling 2.0, offset 0.0, units sec */
	uint16_t Prchrgpnltytimer;
	/* HVBatCntctrOpnTime: Time Since Bat contactors last transitioned to Open */
	/* scaling 0.2, offset 0.0, units Hours */
	uint8_t HVBatCntctrOpnTime;
	/* HVBatSleepTime: Time since BPCM last went to sleep. */
	/* scaling 0.2, offset 0.0, units Days */
	uint8_t HVBatSleepTime;
	/* HVBatChargeStat: ChargeStat */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HVBatChargeStat;
	/* BPCM_LIN_BusFault: A BPCM LIN bus fault has occurred; True = [1]. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BPCM_LIN_BusFault;
	/* HEV_OnRq_BPCM: Ev service On request from BPCM */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t HEV_OnRq_BPCM;
} POSTPACK can_0x3e8_BPCM_MSG_05_t;

typedef PREPACK struct {
	/* LTAP_Temp: Low Temp Active Pump temperature */
	/* scaling 1.0, offset -50.0, units �C */
	uint8_t LTAP_Temp;
	/* LTAP_PmpRPMTgt: Low Temp Active Pump RPM Target */
	/* scaling 0.4, offset 0.0, units % */
	uint8_t LTAP_PmpRPMTgt;
	/* LTAP_RPMAct: Low Temp Active Pump RPM Actual */
	/* scaling 0.4, offset 0.0, units % */
	uint8_t LTAP_RPMAct;
	/* LTAP_Crnt: Low Temp Active Pump Current */
	/* scaling 0.2, offset 0.0, units Amp */
	uint8_t LTAP_Crnt;
	/* LTAP_Vlt: Low Temp Active Pump Voltage */
	/* scaling 0.1, offset 0.0, units V */
	uint8_t LTAP_Vlt;
	/* CRC_3EAh: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_3EAh;
	/* MC_3EAh: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_3EAh;
} POSTPACK can_0x3ea_BPCM_LTRActPump1_t;

typedef PREPACK struct {
	/* BATHTR_HVCurrCons: Battery heater high voltage current consumption. */
	/* scaling 0.2, offset 0.0, units Amp */
	uint8_t BATHTR_HVCurrCons;
	/* CRC_3EBh: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_3EBh;
	/* LTAP_Supplier: Low Temp Active Pump Supplier Identification Number */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_Supplier;
	/* MC_3EBh: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_3EBh;
	/* LTAP_PostRunSts: Low Temp Active Pump Post run status */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_PostRunSts;
	/* LTAP_MontrngRPM: Low Temp Active Pump RPM monitoring active */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_MontrngRPM;
	/* LTAP_LimpHmAnON: Low Temp Active Pump limp home analog signal is on */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_LimpHmAnON;
	/* LTAP_OvrCrnt: Low Temp Active Pump Overcurrent */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_OvrCrnt;
	/* LTAP_OvrTemp: Low Temp Active Pump Overtemp */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_OvrTemp;
	/* LTAP_SuppVltErr: specified range (7V > Vbat >20V) */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_SuppVltErr;
	/* LTAP_NodeErr: Low Temp Active Pump Node Error */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_NodeErr;
	/* LTAP_Deblock: Low Temp Active Pump Deblocking */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_Deblock;
	/* LTAP_DryRun: Low Temp Active Pump Dry Run */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_DryRun;
	/* LTAP_Failsafe: Low Temp Active Pump Failsafe */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_Failsafe;
	/* LTAP_AirPreErr: Low Temp Active Pump Air Present Error */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_AirPreErr;
	/* BCP_LOC_Fault: Lost communication with Battery Coolant Pump; True = [1]. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BCP_LOC_Fault;
	/* LTAP_RespErr: 0x0 No Error, 0x1 Error in the response of of a message frame */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_RespErr;
} POSTPACK can_0x3eb_BPCM_LTRActPump2_t;

typedef PREPACK struct {
	/* BATHTR_PwrCnsDes: Battery heater desired power consumption. */
	/* scaling 20.0, offset 0.0, units W */
	uint16_t BATHTR_PwrCnsDes;
	/* BATHTR_PwrCnsAct: Battery heater actual power consumption. */
	/* scaling 20.0, offset 0.0, units W */
	uint16_t BATHTR_PwrCnsAct;
	/* BATHTR_MeasuredHV: Battery heater measured high voltage. */
	/* scaling 1.0, offset 0.0, units V */
	uint16_t BATHTR_MeasuredHV;
	/* CRC_3ECh: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_3ECh;
	/* MC_3ECh: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_3ECh;
} POSTPACK can_0x3ec_BPCM_BattHtr1_t;

typedef PREPACK struct {
	/* BATHTR_CoolantTempInlet: Battery heater coolant temperature at inlet. */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t BATHTR_CoolantTempInlet;
	/* BATHTR_CoolantTempOutlet: Battery heater coolant temperature at outlet. */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t BATHTR_CoolantTempOutlet;
	/* CRC_3EDh: CRC-checksum byte 1 to 7 according to SAE J1850 */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t CRC_3EDh;
	/* MC_3EDh: Message counter */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t MC_3EDh;
	/* BATHTR_Status: Battery heater status */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_Status;
	/* BATHTR_WarnCommFlt: Battery heater warning - internal communications fault. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_WarnCommFlt;
	/* BATHTR_ServiceMemErr: Battery heater service required for Memory Error. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_ServiceMemErr;
	/* BATHTR_CoolantOutletSnsrFlt: Battery heater coolant outlet sensor fault. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_CoolantOutletSnsrFlt;
	/* BATHTR_HCSensorFlt: Battery heater core temp sensor fault. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_HCSensorFlt;
	/* BATHTR_CoolantInletSnsrFlt: Battery heater coolant inlet sensor fault. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_CoolantInletSnsrFlt;
	/* BATHTR_WARNCoolantTempOOR: Battery heater warning - coolant temperature out of range error. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_WARNCoolantTempOOR;
	/* BATHTR_WarnLV_OOR: Battery heater warning - low voltage out of range error. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_WarnLV_OOR;
	/* BATHTR_WarnHV_OOR: Battery heater warning - high voltage out of range error. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_WarnHV_OOR;
	/* BATHTR_SelfProtectHW: Battery heater self-protection active - hardware fault. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_SelfProtectHW;
	/* BATHTR_SelfProtectOvrHeat: Battery heater self-protection active - overheating. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_SelfProtectOvrHeat;
	/* BATHTR_ServiceRqrd: Battery heater service required. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_ServiceRqrd;
	/* BATHTR_ServiceCurrOutofRng: Battery heater service required - current consumption out of range. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_ServiceCurrOutofRng;
	/* BATHTR_ServiceDrvrCirc: Battery heater service required - driver circuit short or open. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_ServiceDrvrCirc;
	/* BCH_LOC_Fault: Lost communication with Battery Coolant Heater; True = [1]. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BCH_LOC_Fault;
	/* BATHTR_RespErr: 0x0 No Error, 0x1 Error in the response of of a message frame */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_RespErr;
} POSTPACK can_0x3ed_BPCM_BattHtr2_t;

typedef PREPACK struct {
	/* LTAP_Cmd: Low Temp Active Pump Command */
	/* scaling 0.4, offset 0.0, units % */
	uint8_t LTAP_Cmd;
	/* BATHTR_PwrCnsAllwd: Battery heater allowed power consumption */
	/* scaling 40.0, offset 0.0, units W */
	uint8_t BATHTR_PwrCnsAllwd;
	/* BATHTR_WtrTempDes: Battery heater desired water temperature */
	/* scaling 1.0, offset -40.0, units �C */
	uint8_t BATHTR_WtrTempDes;
	/* LTAP_PostRunCom: Low temp active pump post run command */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_PostRunCom;
	/* LTAP_Failsafe_ACT: Low Temp Active Pump Failsafe */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t LTAP_Failsafe_ACT;
	/* Thermal_System_Relay_Status: Thermal System Relay Status signal to BPCM */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t Thermal_System_Relay_Status;
	/* BATHTR_Enbl: Battery Heater enable. */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t BATHTR_Enbl;
} POSTPACK can_0x3ee_Thermal_Command_t;

typedef PREPACK struct {
	/* Country_Code: The signal provides the information of the proxi parameter 'Country_Code' */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t Country_Code;
	/* Model_Year: The signal provides the information of the proxi parameter 'Model_Year' */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t Model_Year;
	/* Vehicle_Line_Configuration: The signal provides the information of the proxi parameter 'Vehicle_Line_Configuration' */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t Vehicle_Line_Configuration;
	/* Car_Shape_Configuration: The signal provides the information of the proxi parameter 'Car_Shape_Configuration' */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t Car_Shape_Configuration;
	/* Proxi_Cfg_Stat: The signal provides the information of the proxi parameters learned correctly */
	/* scaling 1.0, offset 0.0, units none */
	uint8_t Proxi_Cfg_Stat;
} POSTPACK can_0x3fd_Proxi_Cfg_t;

typedef PREPACK struct {
	/* DG_RQ_GLOBAL_UDS: Diagnostic-Request */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t DG_RQ_GLOBAL_UDS;
} POSTPACK can_0x441_DG_RQ_GLOBAL_UDS_t;

typedef PREPACK struct {
	/* CRC_T2: CRC according to SAE J1850 standard that has to be calculated from bit 63 to bit 8 at each frame transmission. */
	/* scaling 1.0, offset 0.0, units count */
	uint8_t CRC_T2;
	/* ShiftLeverPosition: This signal indicates the executed shift lever position. */
	/* scaling 1.0, offset 0.0, units - */
	uint8_t ShiftLeverPosition;
	/* MessageCounter_T2:  */
	/* scaling 1.0, offset 0.0, units - */
	uint8_t MessageCounter_T2;
} POSTPACK can_0x5a8_TRANSM2_t;

typedef PREPACK struct {
	/* ECU_APPL_BPCM: ECU to External Application */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t ECU_APPL_BPCM;
} POSTPACK can_0x5bf_ECU_APPL_BPCM_t;

typedef PREPACK struct {
	/* SD_RS_BPCM: Response on Event - light */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t SD_RS_BPCM;
} POSTPACK can_0x63f_SD_RS_BPCM_t;

typedef PREPACK struct {
	/* APPL_ECU_BPCM: External Application to ECU */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t APPL_ECU_BPCM;
} POSTPACK can_0x6ff_APPL_ECU_BPCM_t;

typedef PREPACK struct {
	/* DG_RQ_GLOBAL: Diagnostic-Request */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t DG_RQ_GLOBAL;
} POSTPACK can_0x7df_DG_RQ_GLOBAL_t;

typedef PREPACK struct {
	/* D_RQ_BPCM: Diagnostic-Request */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t D_RQ_BPCM;
} POSTPACK can_0x7e7_D_RQ_BPCM_t;

typedef PREPACK struct {
	/* D_RS_BPCM: Diagnostic-Response */
	/* scaling 1.0, offset 0.0, units none */
	uint64_t D_RS_BPCM;
} POSTPACK can_0x7ef_D_RS_BPCM_t;

typedef PREPACK struct {
	dbcc_time_stamp_t can_0x095_BPCM_Status1_BEV_time_stamp_rx;
	dbcc_time_stamp_t can_0x0b4_Hybrid_Status1_time_stamp_rx;
	dbcc_time_stamp_t can_0x0e0_BPCM_IMPACT_time_stamp_rx;
	dbcc_time_stamp_t can_0x107_BPCM_DC_Status_time_stamp_rx;
	dbcc_time_stamp_t can_0x108_DC_Charging_Command_time_stamp_rx;
	dbcc_time_stamp_t can_0x150_BPCM_MSG_01_time_stamp_rx;
	dbcc_time_stamp_t can_0x151_BPCM_PHEV_2_time_stamp_rx;
	dbcc_time_stamp_t can_0x15a_IMPACT_INFO_time_stamp_rx;
	dbcc_time_stamp_t can_0x1d0_BPCM_HV_Modules1_time_stamp_rx;
	dbcc_time_stamp_t can_0x1d7_Hybrid_Status2_time_stamp_rx;
	dbcc_time_stamp_t can_0x1d8_Hybrid_Command_BPCM_time_stamp_rx;
	dbcc_time_stamp_t can_0x210_SBW_ROT1_DPT_time_stamp_rx;
	dbcc_time_stamp_t can_0x212_HCP_GW_20_time_stamp_rx;
	dbcc_time_stamp_t can_0x220_BPCM_MSG_02_time_stamp_rx;
	dbcc_time_stamp_t can_0x281_BPCM_DischargePowerLimits_BEV_time_stamp_rx;
	dbcc_time_stamp_t can_0x285_BPCM_ChargePowerLimits_BEV_time_stamp_rx;
	dbcc_time_stamp_t can_0x2c6_BPCM_HV_Impedance_time_stamp_rx;
	dbcc_time_stamp_t can_0x306_BPCM_HV_SOC_time_stamp_rx;
	dbcc_time_stamp_t can_0x307_BPCM_HV_Temperature_time_stamp_rx;
	dbcc_time_stamp_t can_0x312_BP_CNC_CO_time_stamp_rx;
	dbcc_time_stamp_t can_0x322_DC_Charging_Status1_time_stamp_rx;
	dbcc_time_stamp_t can_0x354_BPCM_MSG_04_time_stamp_rx;
	dbcc_time_stamp_t can_0x356_BPCM_HV_VoltLimits_time_stamp_rx;
	dbcc_time_stamp_t can_0x358_HybridRMS_Safety_time_stamp_rx;
	dbcc_time_stamp_t can_0x359_BPCM_Status2_BEV_time_stamp_rx;
	dbcc_time_stamp_t can_0x38c_GPS_POS3_time_stamp_rx;
	dbcc_time_stamp_t can_0x39e_NET_CFG_EPT_time_stamp_rx;
	dbcc_time_stamp_t can_0x3d1_HCP_Charging_Stat2_time_stamp_rx;
	dbcc_time_stamp_t can_0x3d2_HCP_GW_1000_time_stamp_rx;
	dbcc_time_stamp_t can_0x3e0_VIN_time_stamp_rx;
	dbcc_time_stamp_t can_0x3e8_BPCM_MSG_05_time_stamp_rx;
	dbcc_time_stamp_t can_0x3ea_BPCM_LTRActPump1_time_stamp_rx;
	dbcc_time_stamp_t can_0x3eb_BPCM_LTRActPump2_time_stamp_rx;
	dbcc_time_stamp_t can_0x3ec_BPCM_BattHtr1_time_stamp_rx;
	dbcc_time_stamp_t can_0x3ed_BPCM_BattHtr2_time_stamp_rx;
	dbcc_time_stamp_t can_0x3ee_Thermal_Command_time_stamp_rx;
	dbcc_time_stamp_t can_0x3fd_Proxi_Cfg_time_stamp_rx;
	dbcc_time_stamp_t can_0x441_DG_RQ_GLOBAL_UDS_time_stamp_rx;
	dbcc_time_stamp_t can_0x5a8_TRANSM2_time_stamp_rx;
	dbcc_time_stamp_t can_0x5bf_ECU_APPL_BPCM_time_stamp_rx;
	dbcc_time_stamp_t can_0x63f_SD_RS_BPCM_time_stamp_rx;
	dbcc_time_stamp_t can_0x6ff_APPL_ECU_BPCM_time_stamp_rx;
	dbcc_time_stamp_t can_0x7df_DG_RQ_GLOBAL_time_stamp_rx;
	dbcc_time_stamp_t can_0x7e7_D_RQ_BPCM_time_stamp_rx;
	dbcc_time_stamp_t can_0x7ef_D_RS_BPCM_time_stamp_rx;
	unsigned can_0x095_BPCM_Status1_BEV_status : 2;
	unsigned can_0x095_BPCM_Status1_BEV_tx : 1;
	unsigned can_0x095_BPCM_Status1_BEV_rx : 1;
	unsigned can_0x0b4_Hybrid_Status1_status : 2;
	unsigned can_0x0b4_Hybrid_Status1_tx : 1;
	unsigned can_0x0b4_Hybrid_Status1_rx : 1;
	unsigned can_0x0e0_BPCM_IMPACT_status : 2;
	unsigned can_0x0e0_BPCM_IMPACT_tx : 1;
	unsigned can_0x0e0_BPCM_IMPACT_rx : 1;
	unsigned can_0x107_BPCM_DC_Status_status : 2;
	unsigned can_0x107_BPCM_DC_Status_tx : 1;
	unsigned can_0x107_BPCM_DC_Status_rx : 1;
	unsigned can_0x108_DC_Charging_Command_status : 2;
	unsigned can_0x108_DC_Charging_Command_tx : 1;
	unsigned can_0x108_DC_Charging_Command_rx : 1;
	unsigned can_0x150_BPCM_MSG_01_status : 2;
	unsigned can_0x150_BPCM_MSG_01_tx : 1;
	unsigned can_0x150_BPCM_MSG_01_rx : 1;
	unsigned can_0x151_BPCM_PHEV_2_status : 2;
	unsigned can_0x151_BPCM_PHEV_2_tx : 1;
	unsigned can_0x151_BPCM_PHEV_2_rx : 1;
	unsigned can_0x15a_IMPACT_INFO_status : 2;
	unsigned can_0x15a_IMPACT_INFO_tx : 1;
	unsigned can_0x15a_IMPACT_INFO_rx : 1;
	unsigned can_0x1d0_BPCM_HV_Modules1_status : 2;
	unsigned can_0x1d0_BPCM_HV_Modules1_tx : 1;
	unsigned can_0x1d0_BPCM_HV_Modules1_rx : 1;
	unsigned can_0x1d7_Hybrid_Status2_status : 2;
	unsigned can_0x1d7_Hybrid_Status2_tx : 1;
	unsigned can_0x1d7_Hybrid_Status2_rx : 1;
	unsigned can_0x1d8_Hybrid_Command_BPCM_status : 2;
	unsigned can_0x1d8_Hybrid_Command_BPCM_tx : 1;
	unsigned can_0x1d8_Hybrid_Command_BPCM_rx : 1;
	unsigned can_0x210_SBW_ROT1_DPT_status : 2;
	unsigned can_0x210_SBW_ROT1_DPT_tx : 1;
	unsigned can_0x210_SBW_ROT1_DPT_rx : 1;
	unsigned can_0x212_HCP_GW_20_status : 2;
	unsigned can_0x212_HCP_GW_20_tx : 1;
	unsigned can_0x212_HCP_GW_20_rx : 1;
	unsigned can_0x220_BPCM_MSG_02_status : 2;
	unsigned can_0x220_BPCM_MSG_02_tx : 1;
	unsigned can_0x220_BPCM_MSG_02_rx : 1;
	unsigned can_0x281_BPCM_DischargePowerLimits_BEV_status : 2;
	unsigned can_0x281_BPCM_DischargePowerLimits_BEV_tx : 1;
	unsigned can_0x281_BPCM_DischargePowerLimits_BEV_rx : 1;
	unsigned can_0x285_BPCM_ChargePowerLimits_BEV_status : 2;
	unsigned can_0x285_BPCM_ChargePowerLimits_BEV_tx : 1;
	unsigned can_0x285_BPCM_ChargePowerLimits_BEV_rx : 1;
	unsigned can_0x2c6_BPCM_HV_Impedance_status : 2;
	unsigned can_0x2c6_BPCM_HV_Impedance_tx : 1;
	unsigned can_0x2c6_BPCM_HV_Impedance_rx : 1;
	unsigned can_0x306_BPCM_HV_SOC_status : 2;
	unsigned can_0x306_BPCM_HV_SOC_tx : 1;
	unsigned can_0x306_BPCM_HV_SOC_rx : 1;
	unsigned can_0x307_BPCM_HV_Temperature_status : 2;
	unsigned can_0x307_BPCM_HV_Temperature_tx : 1;
	unsigned can_0x307_BPCM_HV_Temperature_rx : 1;
	unsigned can_0x312_BP_CNC_CO_status : 2;
	unsigned can_0x312_BP_CNC_CO_tx : 1;
	unsigned can_0x312_BP_CNC_CO_rx : 1;
	unsigned can_0x322_DC_Charging_Status1_status : 2;
	unsigned can_0x322_DC_Charging_Status1_tx : 1;
	unsigned can_0x322_DC_Charging_Status1_rx : 1;
	unsigned can_0x354_BPCM_MSG_04_status : 2;
	unsigned can_0x354_BPCM_MSG_04_tx : 1;
	unsigned can_0x354_BPCM_MSG_04_rx : 1;
	unsigned can_0x356_BPCM_HV_VoltLimits_status : 2;
	unsigned can_0x356_BPCM_HV_VoltLimits_tx : 1;
	unsigned can_0x356_BPCM_HV_VoltLimits_rx : 1;
	unsigned can_0x358_HybridRMS_Safety_status : 2;
	unsigned can_0x358_HybridRMS_Safety_tx : 1;
	unsigned can_0x358_HybridRMS_Safety_rx : 1;
	unsigned can_0x359_BPCM_Status2_BEV_status : 2;
	unsigned can_0x359_BPCM_Status2_BEV_tx : 1;
	unsigned can_0x359_BPCM_Status2_BEV_rx : 1;
	unsigned can_0x38c_GPS_POS3_status : 2;
	unsigned can_0x38c_GPS_POS3_tx : 1;
	unsigned can_0x38c_GPS_POS3_rx : 1;
	unsigned can_0x39e_NET_CFG_EPT_status : 2;
	unsigned can_0x39e_NET_CFG_EPT_tx : 1;
	unsigned can_0x39e_NET_CFG_EPT_rx : 1;
	unsigned can_0x3d1_HCP_Charging_Stat2_status : 2;
	unsigned can_0x3d1_HCP_Charging_Stat2_tx : 1;
	unsigned can_0x3d1_HCP_Charging_Stat2_rx : 1;
	unsigned can_0x3d2_HCP_GW_1000_status : 2;
	unsigned can_0x3d2_HCP_GW_1000_tx : 1;
	unsigned can_0x3d2_HCP_GW_1000_rx : 1;
	unsigned can_0x3e0_VIN_status : 2;
	unsigned can_0x3e0_VIN_tx : 1;
	unsigned can_0x3e0_VIN_rx : 1;
	unsigned can_0x3e8_BPCM_MSG_05_status : 2;
	unsigned can_0x3e8_BPCM_MSG_05_tx : 1;
	unsigned can_0x3e8_BPCM_MSG_05_rx : 1;
	unsigned can_0x3ea_BPCM_LTRActPump1_status : 2;
	unsigned can_0x3ea_BPCM_LTRActPump1_tx : 1;
	unsigned can_0x3ea_BPCM_LTRActPump1_rx : 1;
	unsigned can_0x3eb_BPCM_LTRActPump2_status : 2;
	unsigned can_0x3eb_BPCM_LTRActPump2_tx : 1;
	unsigned can_0x3eb_BPCM_LTRActPump2_rx : 1;
	unsigned can_0x3ec_BPCM_BattHtr1_status : 2;
	unsigned can_0x3ec_BPCM_BattHtr1_tx : 1;
	unsigned can_0x3ec_BPCM_BattHtr1_rx : 1;
	unsigned can_0x3ed_BPCM_BattHtr2_status : 2;
	unsigned can_0x3ed_BPCM_BattHtr2_tx : 1;
	unsigned can_0x3ed_BPCM_BattHtr2_rx : 1;
	unsigned can_0x3ee_Thermal_Command_status : 2;
	unsigned can_0x3ee_Thermal_Command_tx : 1;
	unsigned can_0x3ee_Thermal_Command_rx : 1;
	unsigned can_0x3fd_Proxi_Cfg_status : 2;
	unsigned can_0x3fd_Proxi_Cfg_tx : 1;
	unsigned can_0x3fd_Proxi_Cfg_rx : 1;
	unsigned can_0x441_DG_RQ_GLOBAL_UDS_status : 2;
	unsigned can_0x441_DG_RQ_GLOBAL_UDS_tx : 1;
	unsigned can_0x441_DG_RQ_GLOBAL_UDS_rx : 1;
	unsigned can_0x5a8_TRANSM2_status : 2;
	unsigned can_0x5a8_TRANSM2_tx : 1;
	unsigned can_0x5a8_TRANSM2_rx : 1;
	unsigned can_0x5bf_ECU_APPL_BPCM_status : 2;
	unsigned can_0x5bf_ECU_APPL_BPCM_tx : 1;
	unsigned can_0x5bf_ECU_APPL_BPCM_rx : 1;
	unsigned can_0x63f_SD_RS_BPCM_status : 2;
	unsigned can_0x63f_SD_RS_BPCM_tx : 1;
	unsigned can_0x63f_SD_RS_BPCM_rx : 1;
	unsigned can_0x6ff_APPL_ECU_BPCM_status : 2;
	unsigned can_0x6ff_APPL_ECU_BPCM_tx : 1;
	unsigned can_0x6ff_APPL_ECU_BPCM_rx : 1;
	unsigned can_0x7df_DG_RQ_GLOBAL_status : 2;
	unsigned can_0x7df_DG_RQ_GLOBAL_tx : 1;
	unsigned can_0x7df_DG_RQ_GLOBAL_rx : 1;
	unsigned can_0x7e7_D_RQ_BPCM_status : 2;
	unsigned can_0x7e7_D_RQ_BPCM_tx : 1;
	unsigned can_0x7e7_D_RQ_BPCM_rx : 1;
	unsigned can_0x7ef_D_RS_BPCM_status : 2;
	unsigned can_0x7ef_D_RS_BPCM_tx : 1;
	unsigned can_0x7ef_D_RS_BPCM_rx : 1;
	can_0x095_BPCM_Status1_BEV_t can_0x095_BPCM_Status1_BEV;
	can_0x0b4_Hybrid_Status1_t can_0x0b4_Hybrid_Status1;
	can_0x0e0_BPCM_IMPACT_t can_0x0e0_BPCM_IMPACT;
	can_0x107_BPCM_DC_Status_t can_0x107_BPCM_DC_Status;
	can_0x108_DC_Charging_Command_t can_0x108_DC_Charging_Command;
	can_0x150_BPCM_MSG_01_t can_0x150_BPCM_MSG_01;
	can_0x151_BPCM_PHEV_2_t can_0x151_BPCM_PHEV_2;
	can_0x15a_IMPACT_INFO_t can_0x15a_IMPACT_INFO;
	can_0x1d0_BPCM_HV_Modules1_t can_0x1d0_BPCM_HV_Modules1;
	can_0x1d7_Hybrid_Status2_t can_0x1d7_Hybrid_Status2;
	can_0x1d8_Hybrid_Command_BPCM_t can_0x1d8_Hybrid_Command_BPCM;
	can_0x210_SBW_ROT1_DPT_t can_0x210_SBW_ROT1_DPT;
	can_0x212_HCP_GW_20_t can_0x212_HCP_GW_20;
	can_0x220_BPCM_MSG_02_t can_0x220_BPCM_MSG_02;
	can_0x281_BPCM_DischargePowerLimits_BEV_t can_0x281_BPCM_DischargePowerLimits_BEV;
	can_0x285_BPCM_ChargePowerLimits_BEV_t can_0x285_BPCM_ChargePowerLimits_BEV;
	can_0x2c6_BPCM_HV_Impedance_t can_0x2c6_BPCM_HV_Impedance;
	can_0x306_BPCM_HV_SOC_t can_0x306_BPCM_HV_SOC;
	can_0x307_BPCM_HV_Temperature_t can_0x307_BPCM_HV_Temperature;
	can_0x312_BP_CNC_CO_t can_0x312_BP_CNC_CO;
	can_0x322_DC_Charging_Status1_t can_0x322_DC_Charging_Status1;
	can_0x354_BPCM_MSG_04_t can_0x354_BPCM_MSG_04;
	can_0x356_BPCM_HV_VoltLimits_t can_0x356_BPCM_HV_VoltLimits;
	can_0x358_HybridRMS_Safety_t can_0x358_HybridRMS_Safety;
	can_0x359_BPCM_Status2_BEV_t can_0x359_BPCM_Status2_BEV;
	can_0x38c_GPS_POS3_t can_0x38c_GPS_POS3;
	can_0x39e_NET_CFG_EPT_t can_0x39e_NET_CFG_EPT;
	can_0x3d1_HCP_Charging_Stat2_t can_0x3d1_HCP_Charging_Stat2;
	can_0x3d2_HCP_GW_1000_t can_0x3d2_HCP_GW_1000;
	can_0x3e0_VIN_t can_0x3e0_VIN;
	can_0x3e8_BPCM_MSG_05_t can_0x3e8_BPCM_MSG_05;
	can_0x3ea_BPCM_LTRActPump1_t can_0x3ea_BPCM_LTRActPump1;
	can_0x3eb_BPCM_LTRActPump2_t can_0x3eb_BPCM_LTRActPump2;
	can_0x3ec_BPCM_BattHtr1_t can_0x3ec_BPCM_BattHtr1;
	can_0x3ed_BPCM_BattHtr2_t can_0x3ed_BPCM_BattHtr2;
	can_0x3ee_Thermal_Command_t can_0x3ee_Thermal_Command;
	can_0x3fd_Proxi_Cfg_t can_0x3fd_Proxi_Cfg;
	can_0x441_DG_RQ_GLOBAL_UDS_t can_0x441_DG_RQ_GLOBAL_UDS;
	can_0x5a8_TRANSM2_t can_0x5a8_TRANSM2;
	can_0x5bf_ECU_APPL_BPCM_t can_0x5bf_ECU_APPL_BPCM;
	can_0x63f_SD_RS_BPCM_t can_0x63f_SD_RS_BPCM;
	can_0x6ff_APPL_ECU_BPCM_t can_0x6ff_APPL_ECU_BPCM;
	can_0x7df_DG_RQ_GLOBAL_t can_0x7df_DG_RQ_GLOBAL;
	can_0x7e7_D_RQ_BPCM_t can_0x7e7_D_RQ_BPCM;
	can_0x7ef_D_RS_BPCM_t can_0x7ef_D_RS_BPCM;
} POSTPACK can_obj_can_c5_h_t;

int unpack_message(can_obj_can_c5_h_t *o, const unsigned long id, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp);
int pack_message(can_obj_can_c5_h_t *o, const unsigned long id, uint64_t *data);
int message_dlc(const unsigned long id);
int print_message(const can_obj_can_c5_h_t *o, const unsigned long id, FILE *output);

int decode_can_0x095_HVBatteryCurrent_BEV(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x095_HVBatteryCurrent_BEV(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x095_HVBatteryVoltage_BEV(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x095_HVBatteryVoltage_BEV(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x095_CellVoltage_NumMax_BEV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x095_CellVoltage_NumMax_BEV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x095_CellVoltage_NumMin_BEV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x095_CellVoltage_NumMin_BEV(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x0b4_CRC_0B4h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0b4_CRC_0B4h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x0b4_MC_0B4h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0b4_MC_0B4h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x0b4_HCPShutDwnCmd(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0b4_HCPShutDwnCmd(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x0b4_EPT_LOC_DiagEnable(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0b4_EPT_LOC_DiagEnable(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x0b4_PrplsnSysAtv(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0b4_PrplsnSysAtv(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x0b4_DriveReady(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0b4_DriveReady(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x0e0_ImpactHardwireV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0e0_ImpactHardwireV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x0e0_ImpactHardwire(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x0e0_ImpactHardwire(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x107_HVBat_DC_CntctrStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x107_HVBat_DC_CntctrStat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x107_HVBat_DC_CntctrOpn(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x107_HVBat_DC_CntctrOpn(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x107_HVBat_DC_CntctrReq(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x107_HVBat_DC_CntctrReq(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x107_DC_Isolation_Sts(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x107_DC_Isolation_Sts(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x107_HVBatCntctrStkOpnChk(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x107_HVBatCntctrStkOpnChk(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x108_CRC_DC_Charging_Command(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x108_CRC_DC_Charging_Command(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x108_MC_DC_Charging_Command(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x108_MC_DC_Charging_Command(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x108_DC_CntctrCmd(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x108_DC_CntctrCmd(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x108_DC_Isolation_Cmd(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x108_DC_Isolation_Cmd(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x150_CRC_150h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_CRC_150h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_MC_150h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_MC_150h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatCntctrStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatCntctrStat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatCntrWeld_ImpdOpn(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatCntrWeld_ImpdOpn(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatIntrlkStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatIntrlkStat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatIntrlk_InternalStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatIntrlk_InternalStat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatIsolStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatIsolStat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_PwrtrnHV_IsolStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_PwrtrnHV_IsolStat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatCntctrOpn(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatCntctrOpn(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatCntctrReq(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatCntctrReq(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x150_HVBatRdy(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x150_HVBatRdy(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x151_HVBat_Real_Time_Clock(const can_obj_can_c5_h_t *o, uint32_t *out);
int encode_can_0x151_HVBat_Real_Time_Clock(can_obj_can_c5_h_t *o, uint32_t in);
int decode_can_0x151_HVBat_Real_Time_Clock_V(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x151_HVBat_Real_Time_Clock_V(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x15a_CRC_II(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x15a_CRC_II(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x15a_MessageCounter_II(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x15a_MessageCounter_II(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x15a_IMPACTCommand(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x15a_IMPACTCommand(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x15a_IMPACTConfirm(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x15a_IMPACTConfirm(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x1d0_HVBatModuleTemp_Max(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x1d0_HVBatModuleTemp_Max(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x1d0_CRC_BPCM_HV_Modules1(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d0_CRC_BPCM_HV_Modules1(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d0_HVBatModuleVoltage_NumMin(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d0_HVBatModuleVoltage_NumMin(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d0_HVBatModuleTemp_NumMax(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d0_HVBatModuleTemp_NumMax(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d0_HVBatModuleTemp_NumMin(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d0_HVBatModuleTemp_NumMin(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d0_HVBatModuleVoltage_NumMax(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d0_HVBatModuleVoltage_NumMax(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d0_MC_BPCM_HV_Modules1(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d0_MC_BPCM_HV_Modules1(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x1d7_CRC_1D7h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d7_CRC_1D7h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d7_MC_1D7h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d7_MC_1D7h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d7_Charger_Plugin_Status(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d7_Charger_Plugin_Status(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x1d8_HVInvRatVlt(const can_obj_can_c5_h_t *o, uint16_t *out);
int encode_can_0x1d8_HVInvRatVlt(can_obj_can_c5_h_t *o, uint16_t in);
int decode_can_0x1d8_CRC_1D8h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d8_CRC_1D8h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d8_MC_1D8h(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d8_MC_1D8h(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d8_MainHighVltCntctrCmd(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d8_MainHighVltCntctrCmd(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d8_HVBat_CoolantLvlLo(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d8_HVBat_CoolantLvlLo(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x1d8_HVInvRatVltV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x1d8_HVInvRatVltV(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x210_CRC_SBW_ROT1_DPT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x210_CRC_SBW_ROT1_DPT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x210_MC_SBW_ROT1_DPT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x210_MC_SBW_ROT1_DPT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x210_DrvRqShftROT_DPT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x210_DrvRqShftROT_DPT(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x212_VEH_SPEED(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x212_VEH_SPEED(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x212_CRC_VEH_SPEED(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x212_CRC_VEH_SPEED(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x212_MC_VEH_SPEED(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x212_MC_VEH_SPEED(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x212_CmdIgnStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x212_CmdIgnStat(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x220_HVBatCellVltAvg(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x220_HVBatCellVltAvg(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x220_HVBatCellVltMax(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x220_HVBatCellVltMax(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x220_HVBatCellVltMin(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x220_HVBatCellVltMin(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x220_HVBatCellVltMinV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x220_HVBatCellVltMinV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x220_HVBatCellVltAvgV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x220_HVBatCellVltAvgV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x220_HVBatCellVltMaxV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x220_HVBatCellVltMaxV(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x281_BPCM_HVBatDischrgPowInstant(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x281_BPCM_HVBatDischrgPowInstant(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x281_BPCM_HVBatDischrgPowShort(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x281_BPCM_HVBatDischrgPowShort(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x281_BPCM_HVBatDischrgPowLong(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x281_BPCM_HVBatDischrgPowLong(can_obj_can_c5_h_t *o, dbcc_double_t in);


int decode_can_0x285_BPCM_HVBatChrgPowInstant(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x285_BPCM_HVBatChrgPowInstant(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x285_BPCM_HVBatChrgPowShort(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x285_BPCM_HVBatChrgPowShort(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x285_BPCM_HVBatChrgPowLong(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x285_BPCM_HVBatChrgPowLong(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x285_BEV_HVBatPwrLim_On_BPCM(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x285_BEV_HVBatPwrLim_On_BPCM(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped_V(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped_V(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped_V(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped_V(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x306_HVBatSOC(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x306_HVBatSOC(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x306_HVBatSOH(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x306_HVBatSOH(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x306_HVBatSOHLow(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x306_HVBatSOHLow(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x306_HVBatSOCMax(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x306_HVBatSOCMax(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x306_HVBatSOCMin(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x306_HVBatSOCMin(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x306_HVBatSOCV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x306_HVBatSOCV(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x307_HVBatClgInletTemp(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x307_HVBatClgInletTemp(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x307_HVBatClgOutletTemp(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x307_HVBatClgOutletTemp(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x307_HVBatModTempMin(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x307_HVBatModTempMin(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x307_HVBatModTempMax(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x307_HVBatModTempMax(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x307_HVBatModTempAvg(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x307_HVBatModTempAvg(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x307_HVBatClgInletTempV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x307_HVBatClgInletTempV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x307_HVBatClgOutletTempV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x307_HVBatClgOutletTempV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x307_HVBatModTempMaxV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x307_HVBatModTempMaxV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x307_HVBatModlTempAvgV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x307_HVBatModlTempAvgV(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x307_HVBatModTempMinV(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x307_HVBatModTempMinV(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x312_HBCO_CellVltMax_High(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x312_HBCO_CellVltMax_High(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x312_HBCO_CellVltMin_Low(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x312_HBCO_CellVltMin_Low(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x312_HBCNC_BUT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x312_HBCNC_BUT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x312_HBCNC_BOT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x312_HBCNC_BOT(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x322_DCChargeInitialized(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x322_DCChargeInitialized(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x354_HVBatCell_Voltage_High_Thrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x354_HVBatCell_Voltage_High_Thrsh(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x354_HVBatCell_Voltage_Low_Thrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x354_HVBatCell_Voltage_Low_Thrsh(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x354_HVBatHighTempThrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x354_HVBatHighTempThrsh(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x354_HVBatLowTempThrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x354_HVBatLowTempThrsh(can_obj_can_c5_h_t *o, dbcc_double_t in);


int decode_can_0x356_HVBatMinCellVltAlld(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x356_HVBatMinCellVltAlld(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x356_HVBatMaxCellVltAlld(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x356_HVBatMaxCellVltAlld(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x356_HVBatMinPkVltAllwd(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x356_HVBatMinPkVltAllwd(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x356_HVBatMaxPkVltAllwd(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x356_HVBatMaxPkVltAllwd(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x356_HVBatMaxCellVltAlld_V(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x356_HVBatMaxCellVltAlld_V(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x356_HVBatMinCellVltAlld_V(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x356_HVBatMinCellVltAlld_V(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x356_HVBatMinPkVltAllwd_V(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x356_HVBatMinPkVltAllwd_V(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x358_CRC_HybridRMS_Safety(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x358_CRC_HybridRMS_Safety(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x358_MC_HybridRMS_Safety(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x358_MC_HybridRMS_Safety(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x358_ThermalRunaway_Warning(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x358_ThermalRunaway_Warning(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x359_MaxChargeCurrentAllowed(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x359_MaxChargeCurrentAllowed(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x359_TotalAmpHrCapacity(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x359_TotalAmpHrCapacity(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x359_MaxPackVoltageAllowed(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x359_MaxPackVoltageAllowed(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x359_MinPackVoltageAllowed(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x359_MinPackVoltageAllowed(can_obj_can_c5_h_t *o, dbcc_double_t in);


int decode_can_0x38c_GPS_Date_Year(const can_obj_can_c5_h_t *o, uint16_t *out);
int encode_can_0x38c_GPS_Date_Year(can_obj_can_c5_h_t *o, uint16_t in);
int decode_can_0x38c_GPS_UTC_Second(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x38c_GPS_UTC_Second(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x38c_GPS_Date_Month(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x38c_GPS_Date_Month(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x38c_GPS_Date_Day(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x38c_GPS_Date_Day(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x38c_GPS_UTC_Hour(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x38c_GPS_UTC_Hour(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x38c_GPS_UTC_Minute(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x38c_GPS_UTC_Minute(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x39e_NET_CFG_STAT_ePT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x39e_NET_CFG_STAT_ePT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x39e_NetCfg_OBCM_ePT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x39e_NetCfg_OBCM_ePT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x39e_NetCfg_AHCP_ePT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x39e_NetCfg_AHCP_ePT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x39e_NetCfg_BPCM_ePT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x39e_NetCfg_BPCM_ePT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x39e_NetCfg_APM_ePT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x39e_NetCfg_APM_ePT(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3d1_ChargingSysSts(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3d1_ChargingSysSts(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3d2_ODO(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3d2_ODO(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3d2_BATT_VOLT(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3d2_BATT_VOLT(can_obj_can_c5_h_t *o, dbcc_double_t in);


int decode_can_0x3e0_VIN_DATA(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x3e0_VIN_DATA(can_obj_can_c5_h_t *o, uint64_t in);
int decode_can_0x3e0_VIN_MSG(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3e0_VIN_MSG(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3e8_Prchrgpnltytimer(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3e8_Prchrgpnltytimer(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3e8_HVBatCntctrOpnTime(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3e8_HVBatCntctrOpnTime(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3e8_HVBatSleepTime(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3e8_HVBatSleepTime(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3e8_HVBatChargeStat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3e8_HVBatChargeStat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3e8_BPCM_LIN_BusFault(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3e8_BPCM_LIN_BusFault(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3e8_HEV_OnRq_BPCM(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3e8_HEV_OnRq_BPCM(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3ea_LTAP_Temp(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ea_LTAP_Temp(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ea_LTAP_PmpRPMTgt(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ea_LTAP_PmpRPMTgt(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ea_LTAP_RPMAct(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ea_LTAP_RPMAct(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ea_LTAP_Crnt(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ea_LTAP_Crnt(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ea_LTAP_Vlt(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ea_LTAP_Vlt(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ea_CRC_3EAh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ea_CRC_3EAh(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ea_MC_3EAh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ea_MC_3EAh(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3eb_BATHTR_HVCurrCons(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3eb_BATHTR_HVCurrCons(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3eb_CRC_3EBh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_CRC_3EBh(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_Supplier(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_Supplier(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_MC_3EBh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_MC_3EBh(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_PostRunSts(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_PostRunSts(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_MontrngRPM(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_MontrngRPM(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_LimpHmAnON(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_LimpHmAnON(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_OvrCrnt(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_OvrCrnt(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_OvrTemp(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_OvrTemp(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_SuppVltErr(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_SuppVltErr(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_NodeErr(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_NodeErr(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_Deblock(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_Deblock(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_DryRun(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_DryRun(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_Failsafe(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_Failsafe(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_AirPreErr(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_AirPreErr(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_BCP_LOC_Fault(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_BCP_LOC_Fault(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3eb_LTAP_RespErr(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3eb_LTAP_RespErr(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3ec_BATHTR_PwrCnsDes(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ec_BATHTR_PwrCnsDes(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ec_BATHTR_PwrCnsAct(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ec_BATHTR_PwrCnsAct(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ec_BATHTR_MeasuredHV(const can_obj_can_c5_h_t *o, uint16_t *out);
int encode_can_0x3ec_BATHTR_MeasuredHV(can_obj_can_c5_h_t *o, uint16_t in);
int decode_can_0x3ec_CRC_3ECh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ec_CRC_3ECh(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ec_MC_3ECh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ec_MC_3ECh(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3ed_BATHTR_CoolantTempInlet(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ed_BATHTR_CoolantTempInlet(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ed_BATHTR_CoolantTempOutlet(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ed_BATHTR_CoolantTempOutlet(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ed_CRC_3EDh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_CRC_3EDh(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_MC_3EDh(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_MC_3EDh(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_Status(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_Status(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_WarnCommFlt(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_WarnCommFlt(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_ServiceMemErr(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_ServiceMemErr(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_CoolantOutletSnsrFlt(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_CoolantOutletSnsrFlt(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_HCSensorFlt(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_HCSensorFlt(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_CoolantInletSnsrFlt(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_CoolantInletSnsrFlt(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_WARNCoolantTempOOR(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_WARNCoolantTempOOR(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_WarnLV_OOR(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_WarnLV_OOR(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_WarnHV_OOR(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_WarnHV_OOR(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_SelfProtectHW(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_SelfProtectHW(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_SelfProtectOvrHeat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_SelfProtectOvrHeat(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_ServiceRqrd(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_ServiceRqrd(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_ServiceCurrOutofRng(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_ServiceCurrOutofRng(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_ServiceDrvrCirc(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_ServiceDrvrCirc(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BCH_LOC_Fault(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BCH_LOC_Fault(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ed_BATHTR_RespErr(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ed_BATHTR_RespErr(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3ee_LTAP_Cmd(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ee_LTAP_Cmd(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ee_BATHTR_PwrCnsAllwd(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ee_BATHTR_PwrCnsAllwd(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ee_BATHTR_WtrTempDes(const can_obj_can_c5_h_t *o, dbcc_double_t *out);
int encode_can_0x3ee_BATHTR_WtrTempDes(can_obj_can_c5_h_t *o, dbcc_double_t in);
int decode_can_0x3ee_LTAP_PostRunCom(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ee_LTAP_PostRunCom(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ee_LTAP_Failsafe_ACT(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ee_LTAP_Failsafe_ACT(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ee_Thermal_System_Relay_Status(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ee_Thermal_System_Relay_Status(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3ee_BATHTR_Enbl(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3ee_BATHTR_Enbl(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x3fd_Country_Code(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3fd_Country_Code(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3fd_Model_Year(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3fd_Model_Year(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3fd_Vehicle_Line_Configuration(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3fd_Vehicle_Line_Configuration(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3fd_Car_Shape_Configuration(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3fd_Car_Shape_Configuration(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x3fd_Proxi_Cfg_Stat(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x3fd_Proxi_Cfg_Stat(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x441_DG_RQ_GLOBAL_UDS(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x441_DG_RQ_GLOBAL_UDS(can_obj_can_c5_h_t *o, uint64_t in);


int decode_can_0x5a8_CRC_T2(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x5a8_CRC_T2(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x5a8_ShiftLeverPosition(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x5a8_ShiftLeverPosition(can_obj_can_c5_h_t *o, uint8_t in);
int decode_can_0x5a8_MessageCounter_T2(const can_obj_can_c5_h_t *o, uint8_t *out);
int encode_can_0x5a8_MessageCounter_T2(can_obj_can_c5_h_t *o, uint8_t in);


int decode_can_0x5bf_ECU_APPL_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x5bf_ECU_APPL_BPCM(can_obj_can_c5_h_t *o, uint64_t in);


int decode_can_0x63f_SD_RS_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x63f_SD_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t in);


int decode_can_0x6ff_APPL_ECU_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x6ff_APPL_ECU_BPCM(can_obj_can_c5_h_t *o, uint64_t in);


int decode_can_0x7df_DG_RQ_GLOBAL(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x7df_DG_RQ_GLOBAL(can_obj_can_c5_h_t *o, uint64_t in);


int decode_can_0x7e7_D_RQ_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x7e7_D_RQ_BPCM(can_obj_can_c5_h_t *o, uint64_t in);


int decode_can_0x7ef_D_RS_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out);
int encode_can_0x7ef_D_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t in);


#ifdef __cplusplus
} 
#endif

#endif
