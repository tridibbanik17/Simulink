#include "CAN_C5.h"
#include <inttypes.h>
#include <assert.h>

#define UNUSED(X) ((void)(X))

static inline uint64_t reverse_byte_order(uint64_t x) {
	x = (x & 0x00000000FFFFFFFF) << 32 | (x & 0xFFFFFFFF00000000) >> 32;
	x = (x & 0x0000FFFF0000FFFF) << 16 | (x & 0xFFFF0000FFFF0000) >> 16;
	x = (x & 0x00FF00FF00FF00FF) << 8  | (x & 0xFF00FF00FF00FF00) >> 8;
	return x;
}

static inline int print_helper(int r, int print_return_value) {
	return ((r >= 0) && (print_return_value >= 0)) ? r + print_return_value : -1;
}

static int pack_can_0x095_BPCM_Status1_BEV(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVBatteryCurrent_BEV: start-bit 6, length 15, endianess motorola, scaling 0.1, offset -1500 */
	x = ((uint16_t)(o->can_0x095_BPCM_Status1_BEV.HVBatteryCurrent_BEV)) & 0x7fff;
	x <<= 48; 
	m |= x;
	/* HVBatteryVoltage_BEV: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 100 */
	x = ((uint16_t)(o->can_0x095_BPCM_Status1_BEV.HVBatteryVoltage_BEV)) & 0x1fff;
	x <<= 32; 
	m |= x;
	/* CellVoltage_NumMax_BEV: start-bit 32, length 5, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMax_BEV)) & 0x1f;
	x <<= 32; 
	i |= x;
	/* CellVoltage_NumMin_BEV: start-bit 40, length 5, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMin_BEV)) & 0x1f;
	x <<= 40; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x095_BPCM_Status1_BEV_tx = 1;
	return 8;
}

static int unpack_can_0x095_BPCM_Status1_BEV(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatteryCurrent_BEV: start-bit 6, length 15, endianess motorola, scaling 0.1, offset -1500 */
	x = (m >> 48) & 0x7fff;
	o->can_0x095_BPCM_Status1_BEV.HVBatteryCurrent_BEV = x;
	/* HVBatteryVoltage_BEV: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 100 */
	x = (m >> 32) & 0x1fff;
	o->can_0x095_BPCM_Status1_BEV.HVBatteryVoltage_BEV = x;
	/* CellVoltage_NumMax_BEV: start-bit 32, length 5, endianess intel, scaling 1, offset 0 */
	x = (i >> 32) & 0x1f;
	o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMax_BEV = x;
	/* CellVoltage_NumMin_BEV: start-bit 40, length 5, endianess intel, scaling 1, offset 0 */
	x = (i >> 40) & 0x1f;
	o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMin_BEV = x;
	o->can_0x095_BPCM_Status1_BEV_rx = 1;
	o->can_0x095_BPCM_Status1_BEV_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x095_HVBatteryCurrent_BEV(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x095_BPCM_Status1_BEV.HVBatteryCurrent_BEV);
	rval *= 0.1;
	rval += -1500;
	if (rval <= 1776.6) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x095_HVBatteryCurrent_BEV(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x095_BPCM_Status1_BEV.HVBatteryCurrent_BEV = 0;
	if (in > 1776.6)
		return -1;
	in += 1500;
	in *= 10;
	o->can_0x095_BPCM_Status1_BEV.HVBatteryCurrent_BEV = in;
	return 0;
}

int decode_can_0x095_HVBatteryVoltage_BEV(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x095_BPCM_Status1_BEV.HVBatteryVoltage_BEV);
	rval *= 0.1;
	rval += 100;
	if ((rval >= 100) && (rval <= 919)) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x095_HVBatteryVoltage_BEV(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x095_BPCM_Status1_BEV.HVBatteryVoltage_BEV = 0;
	if (in < 100)
		return -1;
	if (in > 919)
		return -1;
	in += -100;
	in *= 10;
	o->can_0x095_BPCM_Status1_BEV.HVBatteryVoltage_BEV = in;
	return 0;
}

int decode_can_0x095_CellVoltage_NumMax_BEV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMax_BEV);
	if (rval <= 30) {
		*out = rval;
		return 0;
	} else {
		*out = (uint8_t)0;
		return -1;
	}
}

int encode_can_0x095_CellVoltage_NumMax_BEV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMax_BEV = 0;
	if (in > 30)
		return -1;
	o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMax_BEV = in;
	return 0;
}

int decode_can_0x095_CellVoltage_NumMin_BEV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMin_BEV);
	if (rval <= 30) {
		*out = rval;
		return 0;
	} else {
		*out = (uint8_t)0;
		return -1;
	}
}

int encode_can_0x095_CellVoltage_NumMin_BEV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMin_BEV = 0;
	if (in > 30)
		return -1;
	o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMin_BEV = in;
	return 0;
}

int print_can_0x095_BPCM_Status1_BEV(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatteryCurrent_BEV = (wire: %.0f)\n", (double)(o->can_0x095_BPCM_Status1_BEV.HVBatteryCurrent_BEV)));
	r = print_helper(r, fprintf(output, "HVBatteryVoltage_BEV = (wire: %.0f)\n", (double)(o->can_0x095_BPCM_Status1_BEV.HVBatteryVoltage_BEV)));
	r = print_helper(r, fprintf(output, "CellVoltage_NumMax_BEV = (wire: %.0f)\n", (double)(o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMax_BEV)));
	r = print_helper(r, fprintf(output, "CellVoltage_NumMin_BEV = (wire: %.0f)\n", (double)(o->can_0x095_BPCM_Status1_BEV.CellVoltage_NumMin_BEV)));
	return r;
}

static int pack_can_0x0b4_Hybrid_Status1(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_0B4h: start-bit 48, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0b4_Hybrid_Status1.CRC_0B4h)) & 0xff;
	x <<= 48; 
	i |= x;
	/* MC_0B4h: start-bit 44, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0b4_Hybrid_Status1.MC_0B4h)) & 0xf;
	x <<= 44; 
	i |= x;
	/* HCPShutDwnCmd: start-bit 21, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0b4_Hybrid_Status1.HCPShutDwnCmd)) & 0x7;
	x <<= 21; 
	i |= x;
	/* EPT_LOC_DiagEnable: start-bit 8, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0b4_Hybrid_Status1.EPT_LOC_DiagEnable)) & 0x3;
	x <<= 8; 
	i |= x;
	/* PrplsnSysAtv: start-bit 10, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0b4_Hybrid_Status1.PrplsnSysAtv)) & 0x1;
	x <<= 10; 
	i |= x;
	/* DriveReady: start-bit 11, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0b4_Hybrid_Status1.DriveReady)) & 0x1;
	x <<= 11; 
	i |= x;
	*data = (i);
	o->can_0x0b4_Hybrid_Status1_tx = 1;
	return 7;
}

static int unpack_can_0x0b4_Hybrid_Status1(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 7)
		return -1;
	/* CRC_0B4h: start-bit 48, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 48) & 0xff;
	o->can_0x0b4_Hybrid_Status1.CRC_0B4h = x;
	/* MC_0B4h: start-bit 44, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 44) & 0xf;
	o->can_0x0b4_Hybrid_Status1.MC_0B4h = x;
	/* HCPShutDwnCmd: start-bit 21, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 21) & 0x7;
	o->can_0x0b4_Hybrid_Status1.HCPShutDwnCmd = x;
	/* EPT_LOC_DiagEnable: start-bit 8, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 8) & 0x3;
	o->can_0x0b4_Hybrid_Status1.EPT_LOC_DiagEnable = x;
	/* PrplsnSysAtv: start-bit 10, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 10) & 0x1;
	o->can_0x0b4_Hybrid_Status1.PrplsnSysAtv = x;
	/* DriveReady: start-bit 11, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 11) & 0x1;
	o->can_0x0b4_Hybrid_Status1.DriveReady = x;
	o->can_0x0b4_Hybrid_Status1_rx = 1;
	o->can_0x0b4_Hybrid_Status1_time_stamp_rx = time_stamp;
	return 7;
}

int decode_can_0x0b4_CRC_0B4h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0b4_Hybrid_Status1.CRC_0B4h);
	*out = rval;
	return 0;
}

int encode_can_0x0b4_CRC_0B4h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0b4_Hybrid_Status1.CRC_0B4h = in;
	return 0;
}

int decode_can_0x0b4_MC_0B4h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0b4_Hybrid_Status1.MC_0B4h);
	*out = rval;
	return 0;
}

int encode_can_0x0b4_MC_0B4h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0b4_Hybrid_Status1.MC_0B4h = in;
	return 0;
}

int decode_can_0x0b4_HCPShutDwnCmd(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0b4_Hybrid_Status1.HCPShutDwnCmd);
	*out = rval;
	return 0;
}

int encode_can_0x0b4_HCPShutDwnCmd(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0b4_Hybrid_Status1.HCPShutDwnCmd = in;
	return 0;
}

int decode_can_0x0b4_EPT_LOC_DiagEnable(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0b4_Hybrid_Status1.EPT_LOC_DiagEnable);
	*out = rval;
	return 0;
}

int encode_can_0x0b4_EPT_LOC_DiagEnable(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0b4_Hybrid_Status1.EPT_LOC_DiagEnable = in;
	return 0;
}

int decode_can_0x0b4_PrplsnSysAtv(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0b4_Hybrid_Status1.PrplsnSysAtv);
	*out = rval;
	return 0;
}

int encode_can_0x0b4_PrplsnSysAtv(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0b4_Hybrid_Status1.PrplsnSysAtv = in;
	return 0;
}

int decode_can_0x0b4_DriveReady(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0b4_Hybrid_Status1.DriveReady);
	*out = rval;
	return 0;
}

int encode_can_0x0b4_DriveReady(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0b4_Hybrid_Status1.DriveReady = in;
	return 0;
}

int print_can_0x0b4_Hybrid_Status1(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_0B4h = (wire: %.0f)\n", (double)(o->can_0x0b4_Hybrid_Status1.CRC_0B4h)));
	r = print_helper(r, fprintf(output, "MC_0B4h = (wire: %.0f)\n", (double)(o->can_0x0b4_Hybrid_Status1.MC_0B4h)));
	r = print_helper(r, fprintf(output, "HCPShutDwnCmd = (wire: %.0f)\n", (double)(o->can_0x0b4_Hybrid_Status1.HCPShutDwnCmd)));
	r = print_helper(r, fprintf(output, "EPT_LOC_DiagEnable = (wire: %.0f)\n", (double)(o->can_0x0b4_Hybrid_Status1.EPT_LOC_DiagEnable)));
	r = print_helper(r, fprintf(output, "PrplsnSysAtv = (wire: %.0f)\n", (double)(o->can_0x0b4_Hybrid_Status1.PrplsnSysAtv)));
	r = print_helper(r, fprintf(output, "DriveReady = (wire: %.0f)\n", (double)(o->can_0x0b4_Hybrid_Status1.DriveReady)));
	return r;
}

static int pack_can_0x0e0_BPCM_IMPACT(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* ImpactHardwireV: start-bit 6, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0e0_BPCM_IMPACT.ImpactHardwireV)) & 0x1;
	x <<= 6; 
	i |= x;
	/* ImpactHardwire: start-bit 7, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x0e0_BPCM_IMPACT.ImpactHardwire)) & 0x1;
	x <<= 7; 
	i |= x;
	*data = (i);
	o->can_0x0e0_BPCM_IMPACT_tx = 1;
	return 8;
}

static int unpack_can_0x0e0_BPCM_IMPACT(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* ImpactHardwireV: start-bit 6, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 6) & 0x1;
	o->can_0x0e0_BPCM_IMPACT.ImpactHardwireV = x;
	/* ImpactHardwire: start-bit 7, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 7) & 0x1;
	o->can_0x0e0_BPCM_IMPACT.ImpactHardwire = x;
	o->can_0x0e0_BPCM_IMPACT_rx = 1;
	o->can_0x0e0_BPCM_IMPACT_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x0e0_ImpactHardwireV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0e0_BPCM_IMPACT.ImpactHardwireV);
	*out = rval;
	return 0;
}

int encode_can_0x0e0_ImpactHardwireV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0e0_BPCM_IMPACT.ImpactHardwireV = in;
	return 0;
}

int decode_can_0x0e0_ImpactHardwire(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x0e0_BPCM_IMPACT.ImpactHardwire);
	*out = rval;
	return 0;
}

int encode_can_0x0e0_ImpactHardwire(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x0e0_BPCM_IMPACT.ImpactHardwire = in;
	return 0;
}

int print_can_0x0e0_BPCM_IMPACT(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "ImpactHardwireV = (wire: %.0f)\n", (double)(o->can_0x0e0_BPCM_IMPACT.ImpactHardwireV)));
	r = print_helper(r, fprintf(output, "ImpactHardwire = (wire: %.0f)\n", (double)(o->can_0x0e0_BPCM_IMPACT.ImpactHardwire)));
	return r;
}

static int pack_can_0x107_BPCM_DC_Status(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* HVBat_DC_CntctrStat: start-bit 2, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrStat)) & 0x3;
	x <<= 2; 
	i |= x;
	/* HVBat_DC_CntctrOpn: start-bit 0, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrOpn)) & 0x1;
	i |= x;
	/* HVBat_DC_CntctrReq: start-bit 1, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrReq)) & 0x1;
	x <<= 1; 
	i |= x;
	/* DC_Isolation_Sts: start-bit 4, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x107_BPCM_DC_Status.DC_Isolation_Sts)) & 0x1;
	x <<= 4; 
	i |= x;
	/* HVBatCntctrStkOpnChk: start-bit 5, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x107_BPCM_DC_Status.HVBatCntctrStkOpnChk)) & 0x1;
	x <<= 5; 
	i |= x;
	*data = (i);
	o->can_0x107_BPCM_DC_Status_tx = 1;
	return 8;
}

static int unpack_can_0x107_BPCM_DC_Status(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBat_DC_CntctrStat: start-bit 2, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 2) & 0x3;
	o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrStat = x;
	/* HVBat_DC_CntctrOpn: start-bit 0, length 1, endianess intel, scaling 1, offset 0 */
	x = i & 0x1;
	o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrOpn = x;
	/* HVBat_DC_CntctrReq: start-bit 1, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 1) & 0x1;
	o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrReq = x;
	/* DC_Isolation_Sts: start-bit 4, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 4) & 0x1;
	o->can_0x107_BPCM_DC_Status.DC_Isolation_Sts = x;
	/* HVBatCntctrStkOpnChk: start-bit 5, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 5) & 0x1;
	o->can_0x107_BPCM_DC_Status.HVBatCntctrStkOpnChk = x;
	o->can_0x107_BPCM_DC_Status_rx = 1;
	o->can_0x107_BPCM_DC_Status_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x107_HVBat_DC_CntctrStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrStat);
	*out = rval;
	return 0;
}

int encode_can_0x107_HVBat_DC_CntctrStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrStat = in;
	return 0;
}

int decode_can_0x107_HVBat_DC_CntctrOpn(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrOpn);
	*out = rval;
	return 0;
}

int encode_can_0x107_HVBat_DC_CntctrOpn(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrOpn = in;
	return 0;
}

int decode_can_0x107_HVBat_DC_CntctrReq(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrReq);
	*out = rval;
	return 0;
}

int encode_can_0x107_HVBat_DC_CntctrReq(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrReq = in;
	return 0;
}

int decode_can_0x107_DC_Isolation_Sts(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x107_BPCM_DC_Status.DC_Isolation_Sts);
	*out = rval;
	return 0;
}

int encode_can_0x107_DC_Isolation_Sts(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x107_BPCM_DC_Status.DC_Isolation_Sts = in;
	return 0;
}

int decode_can_0x107_HVBatCntctrStkOpnChk(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x107_BPCM_DC_Status.HVBatCntctrStkOpnChk);
	*out = rval;
	return 0;
}

int encode_can_0x107_HVBatCntctrStkOpnChk(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x107_BPCM_DC_Status.HVBatCntctrStkOpnChk = in;
	return 0;
}

int print_can_0x107_BPCM_DC_Status(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBat_DC_CntctrStat = (wire: %.0f)\n", (double)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrStat)));
	r = print_helper(r, fprintf(output, "HVBat_DC_CntctrOpn = (wire: %.0f)\n", (double)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrOpn)));
	r = print_helper(r, fprintf(output, "HVBat_DC_CntctrReq = (wire: %.0f)\n", (double)(o->can_0x107_BPCM_DC_Status.HVBat_DC_CntctrReq)));
	r = print_helper(r, fprintf(output, "DC_Isolation_Sts = (wire: %.0f)\n", (double)(o->can_0x107_BPCM_DC_Status.DC_Isolation_Sts)));
	r = print_helper(r, fprintf(output, "HVBatCntctrStkOpnChk = (wire: %.0f)\n", (double)(o->can_0x107_BPCM_DC_Status.HVBatCntctrStkOpnChk)));
	return r;
}

static int pack_can_0x108_DC_Charging_Command(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_DC_Charging_Command: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x108_DC_Charging_Command.CRC_DC_Charging_Command)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_DC_Charging_Command: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x108_DC_Charging_Command.MC_DC_Charging_Command)) & 0xf;
	x <<= 52; 
	i |= x;
	/* DC_CntctrCmd: start-bit 48, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x108_DC_Charging_Command.DC_CntctrCmd)) & 0x7;
	x <<= 48; 
	i |= x;
	/* DC_Isolation_Cmd: start-bit 51, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x108_DC_Charging_Command.DC_Isolation_Cmd)) & 0x1;
	x <<= 51; 
	i |= x;
	*data = (i);
	o->can_0x108_DC_Charging_Command_tx = 1;
	return 8;
}

static int unpack_can_0x108_DC_Charging_Command(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* CRC_DC_Charging_Command: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x108_DC_Charging_Command.CRC_DC_Charging_Command = x;
	/* MC_DC_Charging_Command: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x108_DC_Charging_Command.MC_DC_Charging_Command = x;
	/* DC_CntctrCmd: start-bit 48, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 48) & 0x7;
	o->can_0x108_DC_Charging_Command.DC_CntctrCmd = x;
	/* DC_Isolation_Cmd: start-bit 51, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 51) & 0x1;
	o->can_0x108_DC_Charging_Command.DC_Isolation_Cmd = x;
	o->can_0x108_DC_Charging_Command_rx = 1;
	o->can_0x108_DC_Charging_Command_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x108_CRC_DC_Charging_Command(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x108_DC_Charging_Command.CRC_DC_Charging_Command);
	*out = rval;
	return 0;
}

int encode_can_0x108_CRC_DC_Charging_Command(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x108_DC_Charging_Command.CRC_DC_Charging_Command = in;
	return 0;
}

int decode_can_0x108_MC_DC_Charging_Command(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x108_DC_Charging_Command.MC_DC_Charging_Command);
	*out = rval;
	return 0;
}

int encode_can_0x108_MC_DC_Charging_Command(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x108_DC_Charging_Command.MC_DC_Charging_Command = in;
	return 0;
}

int decode_can_0x108_DC_CntctrCmd(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x108_DC_Charging_Command.DC_CntctrCmd);
	*out = rval;
	return 0;
}

int encode_can_0x108_DC_CntctrCmd(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x108_DC_Charging_Command.DC_CntctrCmd = in;
	return 0;
}

int decode_can_0x108_DC_Isolation_Cmd(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x108_DC_Charging_Command.DC_Isolation_Cmd);
	*out = rval;
	return 0;
}

int encode_can_0x108_DC_Isolation_Cmd(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x108_DC_Charging_Command.DC_Isolation_Cmd = in;
	return 0;
}

int print_can_0x108_DC_Charging_Command(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_DC_Charging_Command = (wire: %.0f)\n", (double)(o->can_0x108_DC_Charging_Command.CRC_DC_Charging_Command)));
	r = print_helper(r, fprintf(output, "MC_DC_Charging_Command = (wire: %.0f)\n", (double)(o->can_0x108_DC_Charging_Command.MC_DC_Charging_Command)));
	r = print_helper(r, fprintf(output, "DC_CntctrCmd = (wire: %.0f)\n", (double)(o->can_0x108_DC_Charging_Command.DC_CntctrCmd)));
	r = print_helper(r, fprintf(output, "DC_Isolation_Cmd = (wire: %.0f)\n", (double)(o->can_0x108_DC_Charging_Command.DC_Isolation_Cmd)));
	return r;
}

static int pack_can_0x150_BPCM_MSG_01(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_150h: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.CRC_150h)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_150h: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.MC_150h)) & 0xf;
	x <<= 52; 
	i |= x;
	/* HVBatCntctrStat: start-bit 40, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntctrStat)) & 0x7;
	x <<= 40; 
	i |= x;
	/* HVBatCntrWeld_ImpdOpn: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntrWeld_ImpdOpn)) & 0x3;
	i |= x;
	/* HVBatIntrlkStat: start-bit 30, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatIntrlkStat)) & 0x3;
	x <<= 30; 
	i |= x;
	/* HVBatIntrlk_InternalStat: start-bit 43, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatIntrlk_InternalStat)) & 0x3;
	x <<= 43; 
	i |= x;
	/* HVBatIsolStat: start-bit 48, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatIsolStat)) & 0x3;
	x <<= 48; 
	i |= x;
	/* PwrtrnHV_IsolStat: start-bit 50, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.PwrtrnHV_IsolStat)) & 0x3;
	x <<= 50; 
	i |= x;
	/* HVBatCntctrOpn: start-bit 14, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntctrOpn)) & 0x1;
	x <<= 14; 
	i |= x;
	/* HVBatCntctrReq: start-bit 15, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntctrReq)) & 0x1;
	x <<= 15; 
	i |= x;
	/* HVBatRdy: start-bit 45, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatRdy)) & 0x1;
	x <<= 45; 
	i |= x;
	*data = (i);
	o->can_0x150_BPCM_MSG_01_tx = 1;
	return 8;
}

static int unpack_can_0x150_BPCM_MSG_01(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* CRC_150h: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x150_BPCM_MSG_01.CRC_150h = x;
	/* MC_150h: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x150_BPCM_MSG_01.MC_150h = x;
	/* HVBatCntctrStat: start-bit 40, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 40) & 0x7;
	o->can_0x150_BPCM_MSG_01.HVBatCntctrStat = x;
	/* HVBatCntrWeld_ImpdOpn: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = i & 0x3;
	o->can_0x150_BPCM_MSG_01.HVBatCntrWeld_ImpdOpn = x;
	/* HVBatIntrlkStat: start-bit 30, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 30) & 0x3;
	o->can_0x150_BPCM_MSG_01.HVBatIntrlkStat = x;
	/* HVBatIntrlk_InternalStat: start-bit 43, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 43) & 0x3;
	o->can_0x150_BPCM_MSG_01.HVBatIntrlk_InternalStat = x;
	/* HVBatIsolStat: start-bit 48, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 48) & 0x3;
	o->can_0x150_BPCM_MSG_01.HVBatIsolStat = x;
	/* PwrtrnHV_IsolStat: start-bit 50, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 50) & 0x3;
	o->can_0x150_BPCM_MSG_01.PwrtrnHV_IsolStat = x;
	/* HVBatCntctrOpn: start-bit 14, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 14) & 0x1;
	o->can_0x150_BPCM_MSG_01.HVBatCntctrOpn = x;
	/* HVBatCntctrReq: start-bit 15, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 15) & 0x1;
	o->can_0x150_BPCM_MSG_01.HVBatCntctrReq = x;
	/* HVBatRdy: start-bit 45, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 45) & 0x1;
	o->can_0x150_BPCM_MSG_01.HVBatRdy = x;
	o->can_0x150_BPCM_MSG_01_rx = 1;
	o->can_0x150_BPCM_MSG_01_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x150_CRC_150h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.CRC_150h);
	*out = rval;
	return 0;
}

int encode_can_0x150_CRC_150h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.CRC_150h = in;
	return 0;
}

int decode_can_0x150_MC_150h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.MC_150h);
	*out = rval;
	return 0;
}

int encode_can_0x150_MC_150h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.MC_150h = in;
	return 0;
}

int decode_can_0x150_HVBatCntctrStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntctrStat);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatCntctrStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatCntctrStat = in;
	return 0;
}

int decode_can_0x150_HVBatCntrWeld_ImpdOpn(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntrWeld_ImpdOpn);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatCntrWeld_ImpdOpn(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatCntrWeld_ImpdOpn = in;
	return 0;
}

int decode_can_0x150_HVBatIntrlkStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatIntrlkStat);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatIntrlkStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatIntrlkStat = in;
	return 0;
}

int decode_can_0x150_HVBatIntrlk_InternalStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatIntrlk_InternalStat);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatIntrlk_InternalStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatIntrlk_InternalStat = in;
	return 0;
}

int decode_can_0x150_HVBatIsolStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatIsolStat);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatIsolStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatIsolStat = in;
	return 0;
}

int decode_can_0x150_PwrtrnHV_IsolStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.PwrtrnHV_IsolStat);
	*out = rval;
	return 0;
}

int encode_can_0x150_PwrtrnHV_IsolStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.PwrtrnHV_IsolStat = in;
	return 0;
}

int decode_can_0x150_HVBatCntctrOpn(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntctrOpn);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatCntctrOpn(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatCntctrOpn = in;
	return 0;
}

int decode_can_0x150_HVBatCntctrReq(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatCntctrReq);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatCntctrReq(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatCntctrReq = in;
	return 0;
}

int decode_can_0x150_HVBatRdy(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x150_BPCM_MSG_01.HVBatRdy);
	*out = rval;
	return 0;
}

int encode_can_0x150_HVBatRdy(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x150_BPCM_MSG_01.HVBatRdy = in;
	return 0;
}

int print_can_0x150_BPCM_MSG_01(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_150h = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.CRC_150h)));
	r = print_helper(r, fprintf(output, "MC_150h = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.MC_150h)));
	r = print_helper(r, fprintf(output, "HVBatCntctrStat = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatCntctrStat)));
	r = print_helper(r, fprintf(output, "HVBatCntrWeld_ImpdOpn = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatCntrWeld_ImpdOpn)));
	r = print_helper(r, fprintf(output, "HVBatIntrlkStat = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatIntrlkStat)));
	r = print_helper(r, fprintf(output, "HVBatIntrlk_InternalStat = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatIntrlk_InternalStat)));
	r = print_helper(r, fprintf(output, "HVBatIsolStat = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatIsolStat)));
	r = print_helper(r, fprintf(output, "PwrtrnHV_IsolStat = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.PwrtrnHV_IsolStat)));
	r = print_helper(r, fprintf(output, "HVBatCntctrOpn = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatCntctrOpn)));
	r = print_helper(r, fprintf(output, "HVBatCntctrReq = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatCntctrReq)));
	r = print_helper(r, fprintf(output, "HVBatRdy = (wire: %.0f)\n", (double)(o->can_0x150_BPCM_MSG_01.HVBatRdy)));
	return r;
}

static int pack_can_0x151_BPCM_PHEV_2(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVBat_Real_Time_Clock: start-bit 7, length 32, endianess motorola, scaling 1, offset 0 */
	x = ((uint32_t)(o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock)) & 0xffffffff;
	x <<= 32; 
	m |= x;
	/* HVBat_Real_Time_Clock_V: start-bit 39, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock_V)) & 0x1;
	x <<= 39; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x151_BPCM_PHEV_2_tx = 1;
	return 8;
}

static int unpack_can_0x151_BPCM_PHEV_2(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBat_Real_Time_Clock: start-bit 7, length 32, endianess motorola, scaling 1, offset 0 */
	x = (m >> 32) & 0xffffffff;
	o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock = x;
	/* HVBat_Real_Time_Clock_V: start-bit 39, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 39) & 0x1;
	o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock_V = x;
	o->can_0x151_BPCM_PHEV_2_rx = 1;
	o->can_0x151_BPCM_PHEV_2_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x151_HVBat_Real_Time_Clock(const can_obj_can_c5_h_t *o, uint32_t *out) {
	assert(o);
	assert(out);
	uint32_t rval = (uint32_t)(o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock);
	if (rval <= 4.29497e+09) {
		*out = rval;
		return 0;
	} else {
		*out = (uint32_t)0;
		return -1;
	}
}

int encode_can_0x151_HVBat_Real_Time_Clock(can_obj_can_c5_h_t *o, uint32_t in) {
	assert(o);
	o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock = 0;
	if (in > 4.29497e+09)
		return -1;
	o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock = in;
	return 0;
}

int decode_can_0x151_HVBat_Real_Time_Clock_V(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock_V);
	*out = rval;
	return 0;
}

int encode_can_0x151_HVBat_Real_Time_Clock_V(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock_V = in;
	return 0;
}

int print_can_0x151_BPCM_PHEV_2(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBat_Real_Time_Clock = (wire: %.0f)\n", (double)(o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock)));
	r = print_helper(r, fprintf(output, "HVBat_Real_Time_Clock_V = (wire: %.0f)\n", (double)(o->can_0x151_BPCM_PHEV_2.HVBat_Real_Time_Clock_V)));
	return r;
}

static int pack_can_0x15a_IMPACT_INFO(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_II: start-bit 24, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x15a_IMPACT_INFO.CRC_II)) & 0xff;
	x <<= 24; 
	i |= x;
	/* MessageCounter_II: start-bit 16, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x15a_IMPACT_INFO.MessageCounter_II)) & 0xf;
	x <<= 16; 
	i |= x;
	/* IMPACTCommand: start-bit 6, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x15a_IMPACT_INFO.IMPACTCommand)) & 0x1;
	x <<= 6; 
	i |= x;
	/* IMPACTConfirm: start-bit 7, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x15a_IMPACT_INFO.IMPACTConfirm)) & 0x1;
	x <<= 7; 
	i |= x;
	*data = (i);
	o->can_0x15a_IMPACT_INFO_tx = 1;
	return 4;
}

static int unpack_can_0x15a_IMPACT_INFO(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 4)
		return -1;
	/* CRC_II: start-bit 24, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 24) & 0xff;
	o->can_0x15a_IMPACT_INFO.CRC_II = x;
	/* MessageCounter_II: start-bit 16, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 16) & 0xf;
	o->can_0x15a_IMPACT_INFO.MessageCounter_II = x;
	/* IMPACTCommand: start-bit 6, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 6) & 0x1;
	o->can_0x15a_IMPACT_INFO.IMPACTCommand = x;
	/* IMPACTConfirm: start-bit 7, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 7) & 0x1;
	o->can_0x15a_IMPACT_INFO.IMPACTConfirm = x;
	o->can_0x15a_IMPACT_INFO_rx = 1;
	o->can_0x15a_IMPACT_INFO_time_stamp_rx = time_stamp;
	return 4;
}

int decode_can_0x15a_CRC_II(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x15a_IMPACT_INFO.CRC_II);
	*out = rval;
	return 0;
}

int encode_can_0x15a_CRC_II(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x15a_IMPACT_INFO.CRC_II = in;
	return 0;
}

int decode_can_0x15a_MessageCounter_II(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x15a_IMPACT_INFO.MessageCounter_II);
	*out = rval;
	return 0;
}

int encode_can_0x15a_MessageCounter_II(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x15a_IMPACT_INFO.MessageCounter_II = in;
	return 0;
}

int decode_can_0x15a_IMPACTCommand(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x15a_IMPACT_INFO.IMPACTCommand);
	*out = rval;
	return 0;
}

int encode_can_0x15a_IMPACTCommand(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x15a_IMPACT_INFO.IMPACTCommand = in;
	return 0;
}

int decode_can_0x15a_IMPACTConfirm(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x15a_IMPACT_INFO.IMPACTConfirm);
	*out = rval;
	return 0;
}

int encode_can_0x15a_IMPACTConfirm(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x15a_IMPACT_INFO.IMPACTConfirm = in;
	return 0;
}

int print_can_0x15a_IMPACT_INFO(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_II = (wire: %.0f)\n", (double)(o->can_0x15a_IMPACT_INFO.CRC_II)));
	r = print_helper(r, fprintf(output, "MessageCounter_II = (wire: %.0f)\n", (double)(o->can_0x15a_IMPACT_INFO.MessageCounter_II)));
	r = print_helper(r, fprintf(output, "IMPACTCommand = (wire: %.0f)\n", (double)(o->can_0x15a_IMPACT_INFO.IMPACTCommand)));
	r = print_helper(r, fprintf(output, "IMPACTConfirm = (wire: %.0f)\n", (double)(o->can_0x15a_IMPACT_INFO.IMPACTConfirm)));
	return r;
}

static int pack_can_0x1d0_BPCM_HV_Modules1(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* HVBatModuleTemp_Max: start-bit 0, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_Max)) & 0xff;
	i |= x;
	/* CRC_BPCM_HV_Modules1: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.CRC_BPCM_HV_Modules1)) & 0xff;
	x <<= 56; 
	i |= x;
	/* HVBatModuleVoltage_NumMin: start-bit 11, length 5, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMin)) & 0x1f;
	x <<= 11; 
	i |= x;
	/* HVBatModuleTemp_NumMax: start-bit 19, length 5, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMax)) & 0x1f;
	x <<= 19; 
	i |= x;
	/* HVBatModuleTemp_NumMin: start-bit 27, length 5, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMin)) & 0x1f;
	x <<= 27; 
	i |= x;
	/* HVBatModuleVoltage_NumMax: start-bit 35, length 5, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMax)) & 0x1f;
	x <<= 35; 
	i |= x;
	/* MC_BPCM_HV_Modules1: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.MC_BPCM_HV_Modules1)) & 0xf;
	x <<= 52; 
	i |= x;
	*data = (i);
	o->can_0x1d0_BPCM_HV_Modules1_tx = 1;
	return 8;
}

static int unpack_can_0x1d0_BPCM_HV_Modules1(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatModuleTemp_Max: start-bit 0, length 8, endianess intel, scaling 1, offset -40 */
	x = i & 0xff;
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_Max = x;
	/* CRC_BPCM_HV_Modules1: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x1d0_BPCM_HV_Modules1.CRC_BPCM_HV_Modules1 = x;
	/* HVBatModuleVoltage_NumMin: start-bit 11, length 5, endianess intel, scaling 1, offset 0 */
	x = (i >> 11) & 0x1f;
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMin = x;
	/* HVBatModuleTemp_NumMax: start-bit 19, length 5, endianess intel, scaling 1, offset 0 */
	x = (i >> 19) & 0x1f;
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMax = x;
	/* HVBatModuleTemp_NumMin: start-bit 27, length 5, endianess intel, scaling 1, offset 0 */
	x = (i >> 27) & 0x1f;
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMin = x;
	/* HVBatModuleVoltage_NumMax: start-bit 35, length 5, endianess intel, scaling 1, offset 0 */
	x = (i >> 35) & 0x1f;
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMax = x;
	/* MC_BPCM_HV_Modules1: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x1d0_BPCM_HV_Modules1.MC_BPCM_HV_Modules1 = x;
	o->can_0x1d0_BPCM_HV_Modules1_rx = 1;
	o->can_0x1d0_BPCM_HV_Modules1_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x1d0_HVBatModuleTemp_Max(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_Max);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x1d0_HVBatModuleTemp_Max(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_Max = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_Max = in;
	return 0;
}

int decode_can_0x1d0_CRC_BPCM_HV_Modules1(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.CRC_BPCM_HV_Modules1);
	*out = rval;
	return 0;
}

int encode_can_0x1d0_CRC_BPCM_HV_Modules1(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d0_BPCM_HV_Modules1.CRC_BPCM_HV_Modules1 = in;
	return 0;
}

int decode_can_0x1d0_HVBatModuleVoltage_NumMin(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMin);
	*out = rval;
	return 0;
}

int encode_can_0x1d0_HVBatModuleVoltage_NumMin(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMin = in;
	return 0;
}

int decode_can_0x1d0_HVBatModuleTemp_NumMax(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMax);
	*out = rval;
	return 0;
}

int encode_can_0x1d0_HVBatModuleTemp_NumMax(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMax = in;
	return 0;
}

int decode_can_0x1d0_HVBatModuleTemp_NumMin(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMin);
	*out = rval;
	return 0;
}

int encode_can_0x1d0_HVBatModuleTemp_NumMin(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMin = in;
	return 0;
}

int decode_can_0x1d0_HVBatModuleVoltage_NumMax(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMax);
	*out = rval;
	return 0;
}

int encode_can_0x1d0_HVBatModuleVoltage_NumMax(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMax = in;
	return 0;
}

int decode_can_0x1d0_MC_BPCM_HV_Modules1(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d0_BPCM_HV_Modules1.MC_BPCM_HV_Modules1);
	*out = rval;
	return 0;
}

int encode_can_0x1d0_MC_BPCM_HV_Modules1(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d0_BPCM_HV_Modules1.MC_BPCM_HV_Modules1 = in;
	return 0;
}

int print_can_0x1d0_BPCM_HV_Modules1(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatModuleTemp_Max = (wire: %.0f)\n", (double)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_Max)));
	r = print_helper(r, fprintf(output, "CRC_BPCM_HV_Modules1 = (wire: %.0f)\n", (double)(o->can_0x1d0_BPCM_HV_Modules1.CRC_BPCM_HV_Modules1)));
	r = print_helper(r, fprintf(output, "HVBatModuleVoltage_NumMin = (wire: %.0f)\n", (double)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMin)));
	r = print_helper(r, fprintf(output, "HVBatModuleTemp_NumMax = (wire: %.0f)\n", (double)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMax)));
	r = print_helper(r, fprintf(output, "HVBatModuleTemp_NumMin = (wire: %.0f)\n", (double)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleTemp_NumMin)));
	r = print_helper(r, fprintf(output, "HVBatModuleVoltage_NumMax = (wire: %.0f)\n", (double)(o->can_0x1d0_BPCM_HV_Modules1.HVBatModuleVoltage_NumMax)));
	r = print_helper(r, fprintf(output, "MC_BPCM_HV_Modules1 = (wire: %.0f)\n", (double)(o->can_0x1d0_BPCM_HV_Modules1.MC_BPCM_HV_Modules1)));
	return r;
}

static int pack_can_0x1d7_Hybrid_Status2(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_1D7h: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d7_Hybrid_Status2.CRC_1D7h)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_1D7h: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d7_Hybrid_Status2.MC_1D7h)) & 0xf;
	x <<= 52; 
	i |= x;
	/* Charger_Plugin_Status: start-bit 15, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d7_Hybrid_Status2.Charger_Plugin_Status)) & 0x1;
	x <<= 15; 
	i |= x;
	*data = (i);
	o->can_0x1d7_Hybrid_Status2_tx = 1;
	return 8;
}

static int unpack_can_0x1d7_Hybrid_Status2(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* CRC_1D7h: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x1d7_Hybrid_Status2.CRC_1D7h = x;
	/* MC_1D7h: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x1d7_Hybrid_Status2.MC_1D7h = x;
	/* Charger_Plugin_Status: start-bit 15, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 15) & 0x1;
	o->can_0x1d7_Hybrid_Status2.Charger_Plugin_Status = x;
	o->can_0x1d7_Hybrid_Status2_rx = 1;
	o->can_0x1d7_Hybrid_Status2_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x1d7_CRC_1D7h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d7_Hybrid_Status2.CRC_1D7h);
	*out = rval;
	return 0;
}

int encode_can_0x1d7_CRC_1D7h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d7_Hybrid_Status2.CRC_1D7h = in;
	return 0;
}

int decode_can_0x1d7_MC_1D7h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d7_Hybrid_Status2.MC_1D7h);
	*out = rval;
	return 0;
}

int encode_can_0x1d7_MC_1D7h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d7_Hybrid_Status2.MC_1D7h = in;
	return 0;
}

int decode_can_0x1d7_Charger_Plugin_Status(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d7_Hybrid_Status2.Charger_Plugin_Status);
	*out = rval;
	return 0;
}

int encode_can_0x1d7_Charger_Plugin_Status(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d7_Hybrid_Status2.Charger_Plugin_Status = in;
	return 0;
}

int print_can_0x1d7_Hybrid_Status2(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_1D7h = (wire: %.0f)\n", (double)(o->can_0x1d7_Hybrid_Status2.CRC_1D7h)));
	r = print_helper(r, fprintf(output, "MC_1D7h = (wire: %.0f)\n", (double)(o->can_0x1d7_Hybrid_Status2.MC_1D7h)));
	r = print_helper(r, fprintf(output, "Charger_Plugin_Status = (wire: %.0f)\n", (double)(o->can_0x1d7_Hybrid_Status2.Charger_Plugin_Status)));
	return r;
}

static int pack_can_0x1d8_Hybrid_Command_BPCM(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVInvRatVlt: start-bit 32, length 9, endianess motorola, scaling 1, offset 0 */
	x = ((uint16_t)(o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVlt)) & 0x1ff;
	x <<= 16; 
	m |= x;
	/* CRC_1D8h: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.CRC_1D8h)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_1D8h: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.MC_1D8h)) & 0xf;
	x <<= 52; 
	i |= x;
	/* MainHighVltCntctrCmd: start-bit 37, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.MainHighVltCntctrCmd)) & 0x7;
	x <<= 37; 
	i |= x;
	/* HVBat_CoolantLvlLo: start-bit 48, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.HVBat_CoolantLvlLo)) & 0x3;
	x <<= 48; 
	i |= x;
	/* HVInvRatVltV: start-bit 35, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVltV)) & 0x1;
	x <<= 35; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x1d8_Hybrid_Command_BPCM_tx = 1;
	return 8;
}

static int unpack_can_0x1d8_Hybrid_Command_BPCM(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVInvRatVlt: start-bit 32, length 9, endianess motorola, scaling 1, offset 0 */
	x = (m >> 16) & 0x1ff;
	o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVlt = x;
	/* CRC_1D8h: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x1d8_Hybrid_Command_BPCM.CRC_1D8h = x;
	/* MC_1D8h: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x1d8_Hybrid_Command_BPCM.MC_1D8h = x;
	/* MainHighVltCntctrCmd: start-bit 37, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 37) & 0x7;
	o->can_0x1d8_Hybrid_Command_BPCM.MainHighVltCntctrCmd = x;
	/* HVBat_CoolantLvlLo: start-bit 48, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 48) & 0x3;
	o->can_0x1d8_Hybrid_Command_BPCM.HVBat_CoolantLvlLo = x;
	/* HVInvRatVltV: start-bit 35, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 35) & 0x1;
	o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVltV = x;
	o->can_0x1d8_Hybrid_Command_BPCM_rx = 1;
	o->can_0x1d8_Hybrid_Command_BPCM_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x1d8_HVInvRatVlt(const can_obj_can_c5_h_t *o, uint16_t *out) {
	assert(o);
	assert(out);
	uint16_t rval = (uint16_t)(o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVlt);
	if (rval <= 510) {
		*out = rval;
		return 0;
	} else {
		*out = (uint16_t)0;
		return -1;
	}
}

int encode_can_0x1d8_HVInvRatVlt(can_obj_can_c5_h_t *o, uint16_t in) {
	assert(o);
	o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVlt = 0;
	if (in > 510)
		return -1;
	o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVlt = in;
	return 0;
}

int decode_can_0x1d8_CRC_1D8h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.CRC_1D8h);
	*out = rval;
	return 0;
}

int encode_can_0x1d8_CRC_1D8h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d8_Hybrid_Command_BPCM.CRC_1D8h = in;
	return 0;
}

int decode_can_0x1d8_MC_1D8h(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.MC_1D8h);
	*out = rval;
	return 0;
}

int encode_can_0x1d8_MC_1D8h(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d8_Hybrid_Command_BPCM.MC_1D8h = in;
	return 0;
}

int decode_can_0x1d8_MainHighVltCntctrCmd(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.MainHighVltCntctrCmd);
	*out = rval;
	return 0;
}

int encode_can_0x1d8_MainHighVltCntctrCmd(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d8_Hybrid_Command_BPCM.MainHighVltCntctrCmd = in;
	return 0;
}

int decode_can_0x1d8_HVBat_CoolantLvlLo(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.HVBat_CoolantLvlLo);
	*out = rval;
	return 0;
}

int encode_can_0x1d8_HVBat_CoolantLvlLo(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d8_Hybrid_Command_BPCM.HVBat_CoolantLvlLo = in;
	return 0;
}

int decode_can_0x1d8_HVInvRatVltV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVltV);
	*out = rval;
	return 0;
}

int encode_can_0x1d8_HVInvRatVltV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVltV = in;
	return 0;
}

int print_can_0x1d8_Hybrid_Command_BPCM(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVInvRatVlt = (wire: %.0f)\n", (double)(o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVlt)));
	r = print_helper(r, fprintf(output, "CRC_1D8h = (wire: %.0f)\n", (double)(o->can_0x1d8_Hybrid_Command_BPCM.CRC_1D8h)));
	r = print_helper(r, fprintf(output, "MC_1D8h = (wire: %.0f)\n", (double)(o->can_0x1d8_Hybrid_Command_BPCM.MC_1D8h)));
	r = print_helper(r, fprintf(output, "MainHighVltCntctrCmd = (wire: %.0f)\n", (double)(o->can_0x1d8_Hybrid_Command_BPCM.MainHighVltCntctrCmd)));
	r = print_helper(r, fprintf(output, "HVBat_CoolantLvlLo = (wire: %.0f)\n", (double)(o->can_0x1d8_Hybrid_Command_BPCM.HVBat_CoolantLvlLo)));
	r = print_helper(r, fprintf(output, "HVInvRatVltV = (wire: %.0f)\n", (double)(o->can_0x1d8_Hybrid_Command_BPCM.HVInvRatVltV)));
	return r;
}

static int pack_can_0x210_SBW_ROT1_DPT(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_SBW_ROT1_DPT: start-bit 32, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x210_SBW_ROT1_DPT.CRC_SBW_ROT1_DPT)) & 0xff;
	x <<= 32; 
	i |= x;
	/* MC_SBW_ROT1_DPT: start-bit 28, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x210_SBW_ROT1_DPT.MC_SBW_ROT1_DPT)) & 0xf;
	x <<= 28; 
	i |= x;
	/* DrvRqShftROT_DPT: start-bit 0, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x210_SBW_ROT1_DPT.DrvRqShftROT_DPT)) & 0x7;
	i |= x;
	*data = (i);
	o->can_0x210_SBW_ROT1_DPT_tx = 1;
	return 5;
}

static int unpack_can_0x210_SBW_ROT1_DPT(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 5)
		return -1;
	/* CRC_SBW_ROT1_DPT: start-bit 32, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 32) & 0xff;
	o->can_0x210_SBW_ROT1_DPT.CRC_SBW_ROT1_DPT = x;
	/* MC_SBW_ROT1_DPT: start-bit 28, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 28) & 0xf;
	o->can_0x210_SBW_ROT1_DPT.MC_SBW_ROT1_DPT = x;
	/* DrvRqShftROT_DPT: start-bit 0, length 3, endianess intel, scaling 1, offset 0 */
	x = i & 0x7;
	o->can_0x210_SBW_ROT1_DPT.DrvRqShftROT_DPT = x;
	o->can_0x210_SBW_ROT1_DPT_rx = 1;
	o->can_0x210_SBW_ROT1_DPT_time_stamp_rx = time_stamp;
	return 5;
}

int decode_can_0x210_CRC_SBW_ROT1_DPT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x210_SBW_ROT1_DPT.CRC_SBW_ROT1_DPT);
	*out = rval;
	return 0;
}

int encode_can_0x210_CRC_SBW_ROT1_DPT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x210_SBW_ROT1_DPT.CRC_SBW_ROT1_DPT = in;
	return 0;
}

int decode_can_0x210_MC_SBW_ROT1_DPT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x210_SBW_ROT1_DPT.MC_SBW_ROT1_DPT);
	*out = rval;
	return 0;
}

int encode_can_0x210_MC_SBW_ROT1_DPT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x210_SBW_ROT1_DPT.MC_SBW_ROT1_DPT = in;
	return 0;
}

int decode_can_0x210_DrvRqShftROT_DPT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x210_SBW_ROT1_DPT.DrvRqShftROT_DPT);
	*out = rval;
	return 0;
}

int encode_can_0x210_DrvRqShftROT_DPT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x210_SBW_ROT1_DPT.DrvRqShftROT_DPT = in;
	return 0;
}

int print_can_0x210_SBW_ROT1_DPT(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_SBW_ROT1_DPT = (wire: %.0f)\n", (double)(o->can_0x210_SBW_ROT1_DPT.CRC_SBW_ROT1_DPT)));
	r = print_helper(r, fprintf(output, "MC_SBW_ROT1_DPT = (wire: %.0f)\n", (double)(o->can_0x210_SBW_ROT1_DPT.MC_SBW_ROT1_DPT)));
	r = print_helper(r, fprintf(output, "DrvRqShftROT_DPT = (wire: %.0f)\n", (double)(o->can_0x210_SBW_ROT1_DPT.DrvRqShftROT_DPT)));
	return r;
}

static int pack_can_0x212_HCP_GW_20(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* VEH_SPEED: start-bit 39, length 16, endianess motorola, scaling 0.0078125, offset 0 */
	x = ((uint16_t)(o->can_0x212_HCP_GW_20.VEH_SPEED)) & 0xffff;
	x <<= 16; 
	m |= x;
	/* CRC_VEH_SPEED: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x212_HCP_GW_20.CRC_VEH_SPEED)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_VEH_SPEED: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x212_HCP_GW_20.MC_VEH_SPEED)) & 0xf;
	x <<= 52; 
	i |= x;
	/* CmdIgnStat: start-bit 48, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x212_HCP_GW_20.CmdIgnStat)) & 0x7;
	x <<= 48; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x212_HCP_GW_20_tx = 1;
	return 8;
}

static int unpack_can_0x212_HCP_GW_20(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* VEH_SPEED: start-bit 39, length 16, endianess motorola, scaling 0.0078125, offset 0 */
	x = (m >> 16) & 0xffff;
	o->can_0x212_HCP_GW_20.VEH_SPEED = x;
	/* CRC_VEH_SPEED: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x212_HCP_GW_20.CRC_VEH_SPEED = x;
	/* MC_VEH_SPEED: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x212_HCP_GW_20.MC_VEH_SPEED = x;
	/* CmdIgnStat: start-bit 48, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 48) & 0x7;
	o->can_0x212_HCP_GW_20.CmdIgnStat = x;
	o->can_0x212_HCP_GW_20_rx = 1;
	o->can_0x212_HCP_GW_20_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x212_VEH_SPEED(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x212_HCP_GW_20.VEH_SPEED);
	rval *= 0.0078125;
	if (rval <= 511.984) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x212_VEH_SPEED(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x212_HCP_GW_20.VEH_SPEED = 0;
	if (in > 511.984)
		return -1;
	in *= 128;
	o->can_0x212_HCP_GW_20.VEH_SPEED = in;
	return 0;
}

int decode_can_0x212_CRC_VEH_SPEED(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x212_HCP_GW_20.CRC_VEH_SPEED);
	*out = rval;
	return 0;
}

int encode_can_0x212_CRC_VEH_SPEED(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x212_HCP_GW_20.CRC_VEH_SPEED = in;
	return 0;
}

int decode_can_0x212_MC_VEH_SPEED(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x212_HCP_GW_20.MC_VEH_SPEED);
	*out = rval;
	return 0;
}

int encode_can_0x212_MC_VEH_SPEED(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x212_HCP_GW_20.MC_VEH_SPEED = in;
	return 0;
}

int decode_can_0x212_CmdIgnStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x212_HCP_GW_20.CmdIgnStat);
	*out = rval;
	return 0;
}

int encode_can_0x212_CmdIgnStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x212_HCP_GW_20.CmdIgnStat = in;
	return 0;
}

int print_can_0x212_HCP_GW_20(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "VEH_SPEED = (wire: %.0f)\n", (double)(o->can_0x212_HCP_GW_20.VEH_SPEED)));
	r = print_helper(r, fprintf(output, "CRC_VEH_SPEED = (wire: %.0f)\n", (double)(o->can_0x212_HCP_GW_20.CRC_VEH_SPEED)));
	r = print_helper(r, fprintf(output, "MC_VEH_SPEED = (wire: %.0f)\n", (double)(o->can_0x212_HCP_GW_20.MC_VEH_SPEED)));
	r = print_helper(r, fprintf(output, "CmdIgnStat = (wire: %.0f)\n", (double)(o->can_0x212_HCP_GW_20.CmdIgnStat)));
	return r;
}

static int pack_can_0x220_BPCM_MSG_02(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVBatCellVltAvg: start-bit 4, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = ((uint16_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltAvg)) & 0x1fff;
	x <<= 48; 
	m |= x;
	/* HVBatCellVltMax: start-bit 20, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = ((uint16_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMax)) & 0x1fff;
	x <<= 32; 
	m |= x;
	/* HVBatCellVltMin: start-bit 36, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = ((uint16_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMin)) & 0x1fff;
	x <<= 16; 
	m |= x;
	/* HVBatCellVltMinV: start-bit 21, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMinV)) & 0x1;
	x <<= 21; 
	i |= x;
	/* HVBatCellVltAvgV: start-bit 37, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltAvgV)) & 0x1;
	x <<= 37; 
	i |= x;
	/* HVBatCellVltMaxV: start-bit 39, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMaxV)) & 0x1;
	x <<= 39; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x220_BPCM_MSG_02_tx = 1;
	return 8;
}

static int unpack_can_0x220_BPCM_MSG_02(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatCellVltAvg: start-bit 4, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = (m >> 48) & 0x1fff;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltAvg = x;
	/* HVBatCellVltMax: start-bit 20, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = (m >> 32) & 0x1fff;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMax = x;
	/* HVBatCellVltMin: start-bit 36, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = (m >> 16) & 0x1fff;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMin = x;
	/* HVBatCellVltMinV: start-bit 21, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 21) & 0x1;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMinV = x;
	/* HVBatCellVltAvgV: start-bit 37, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 37) & 0x1;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltAvgV = x;
	/* HVBatCellVltMaxV: start-bit 39, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 39) & 0x1;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMaxV = x;
	o->can_0x220_BPCM_MSG_02_rx = 1;
	o->can_0x220_BPCM_MSG_02_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x220_HVBatCellVltAvg(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltAvg);
	rval *= 0.001;
	if (rval <= 5) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x220_HVBatCellVltAvg(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x220_BPCM_MSG_02.HVBatCellVltAvg = 0;
	if (in > 5)
		return -1;
	in *= 1000;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltAvg = in;
	return 0;
}

int decode_can_0x220_HVBatCellVltMax(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMax);
	rval *= 0.001;
	if (rval <= 5) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x220_HVBatCellVltMax(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMax = 0;
	if (in > 5)
		return -1;
	in *= 1000;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMax = in;
	return 0;
}

int decode_can_0x220_HVBatCellVltMin(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMin);
	rval *= 0.001;
	if (rval <= 5) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x220_HVBatCellVltMin(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMin = 0;
	if (in > 5)
		return -1;
	in *= 1000;
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMin = in;
	return 0;
}

int decode_can_0x220_HVBatCellVltMinV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMinV);
	*out = rval;
	return 0;
}

int encode_can_0x220_HVBatCellVltMinV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMinV = in;
	return 0;
}

int decode_can_0x220_HVBatCellVltAvgV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltAvgV);
	*out = rval;
	return 0;
}

int encode_can_0x220_HVBatCellVltAvgV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x220_BPCM_MSG_02.HVBatCellVltAvgV = in;
	return 0;
}

int decode_can_0x220_HVBatCellVltMaxV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMaxV);
	*out = rval;
	return 0;
}

int encode_can_0x220_HVBatCellVltMaxV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x220_BPCM_MSG_02.HVBatCellVltMaxV = in;
	return 0;
}

int print_can_0x220_BPCM_MSG_02(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatCellVltAvg = (wire: %.0f)\n", (double)(o->can_0x220_BPCM_MSG_02.HVBatCellVltAvg)));
	r = print_helper(r, fprintf(output, "HVBatCellVltMax = (wire: %.0f)\n", (double)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMax)));
	r = print_helper(r, fprintf(output, "HVBatCellVltMin = (wire: %.0f)\n", (double)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMin)));
	r = print_helper(r, fprintf(output, "HVBatCellVltMinV = (wire: %.0f)\n", (double)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMinV)));
	r = print_helper(r, fprintf(output, "HVBatCellVltAvgV = (wire: %.0f)\n", (double)(o->can_0x220_BPCM_MSG_02.HVBatCellVltAvgV)));
	r = print_helper(r, fprintf(output, "HVBatCellVltMaxV = (wire: %.0f)\n", (double)(o->can_0x220_BPCM_MSG_02.HVBatCellVltMaxV)));
	return r;
}

static int pack_can_0x281_BPCM_DischargePowerLimits_BEV(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* BPCM_HVBatDischrgPowInstant: start-bit 4, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowInstant)) & 0x1fff;
	x <<= 48; 
	m |= x;
	/* BPCM_HVBatDischrgPowShort: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowShort)) & 0x1fff;
	x <<= 32; 
	m |= x;
	/* BPCM_HVBatDischrgPowLong: start-bit 36, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowLong)) & 0x1fff;
	x <<= 16; 
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x281_BPCM_DischargePowerLimits_BEV_tx = 1;
	return 8;
}

static int unpack_can_0x281_BPCM_DischargePowerLimits_BEV(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* BPCM_HVBatDischrgPowInstant: start-bit 4, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 48) & 0x1fff;
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowInstant = x;
	/* BPCM_HVBatDischrgPowShort: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 32) & 0x1fff;
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowShort = x;
	/* BPCM_HVBatDischrgPowLong: start-bit 36, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 16) & 0x1fff;
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowLong = x;
	o->can_0x281_BPCM_DischargePowerLimits_BEV_rx = 1;
	o->can_0x281_BPCM_DischargePowerLimits_BEV_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x281_BPCM_HVBatDischrgPowInstant(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowInstant);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x281_BPCM_HVBatDischrgPowInstant(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowInstant = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowInstant = in;
	return 0;
}

int decode_can_0x281_BPCM_HVBatDischrgPowShort(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowShort);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x281_BPCM_HVBatDischrgPowShort(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowShort = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowShort = in;
	return 0;
}

int decode_can_0x281_BPCM_HVBatDischrgPowLong(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowLong);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x281_BPCM_HVBatDischrgPowLong(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowLong = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowLong = in;
	return 0;
}

int print_can_0x281_BPCM_DischargePowerLimits_BEV(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "BPCM_HVBatDischrgPowInstant = (wire: %.0f)\n", (double)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowInstant)));
	r = print_helper(r, fprintf(output, "BPCM_HVBatDischrgPowShort = (wire: %.0f)\n", (double)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowShort)));
	r = print_helper(r, fprintf(output, "BPCM_HVBatDischrgPowLong = (wire: %.0f)\n", (double)(o->can_0x281_BPCM_DischargePowerLimits_BEV.BPCM_HVBatDischrgPowLong)));
	return r;
}

static int pack_can_0x285_BPCM_ChargePowerLimits_BEV(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* BPCM_HVBatChrgPowInstant: start-bit 4, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowInstant)) & 0x1fff;
	x <<= 48; 
	m |= x;
	/* BPCM_HVBatChrgPowShort: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowShort)) & 0x1fff;
	x <<= 32; 
	m |= x;
	/* BPCM_HVBatChrgPowLong: start-bit 36, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowLong)) & 0x1fff;
	x <<= 16; 
	m |= x;
	/* BEV_HVBatPwrLim_On_BPCM: start-bit 5, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BEV_HVBatPwrLim_On_BPCM)) & 0x1;
	x <<= 5; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x285_BPCM_ChargePowerLimits_BEV_tx = 1;
	return 8;
}

static int unpack_can_0x285_BPCM_ChargePowerLimits_BEV(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* BPCM_HVBatChrgPowInstant: start-bit 4, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 48) & 0x1fff;
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowInstant = x;
	/* BPCM_HVBatChrgPowShort: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 32) & 0x1fff;
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowShort = x;
	/* BPCM_HVBatChrgPowLong: start-bit 36, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 16) & 0x1fff;
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowLong = x;
	/* BEV_HVBatPwrLim_On_BPCM: start-bit 5, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 5) & 0x1;
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BEV_HVBatPwrLim_On_BPCM = x;
	o->can_0x285_BPCM_ChargePowerLimits_BEV_rx = 1;
	o->can_0x285_BPCM_ChargePowerLimits_BEV_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x285_BPCM_HVBatChrgPowInstant(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowInstant);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x285_BPCM_HVBatChrgPowInstant(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowInstant = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowInstant = in;
	return 0;
}

int decode_can_0x285_BPCM_HVBatChrgPowShort(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowShort);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x285_BPCM_HVBatChrgPowShort(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowShort = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowShort = in;
	return 0;
}

int decode_can_0x285_BPCM_HVBatChrgPowLong(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowLong);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x285_BPCM_HVBatChrgPowLong(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowLong = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowLong = in;
	return 0;
}

int decode_can_0x285_BEV_HVBatPwrLim_On_BPCM(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BEV_HVBatPwrLim_On_BPCM);
	*out = rval;
	return 0;
}

int encode_can_0x285_BEV_HVBatPwrLim_On_BPCM(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x285_BPCM_ChargePowerLimits_BEV.BEV_HVBatPwrLim_On_BPCM = in;
	return 0;
}

int print_can_0x285_BPCM_ChargePowerLimits_BEV(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "BPCM_HVBatChrgPowInstant = (wire: %.0f)\n", (double)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowInstant)));
	r = print_helper(r, fprintf(output, "BPCM_HVBatChrgPowShort = (wire: %.0f)\n", (double)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowShort)));
	r = print_helper(r, fprintf(output, "BPCM_HVBatChrgPowLong = (wire: %.0f)\n", (double)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BPCM_HVBatChrgPowLong)));
	r = print_helper(r, fprintf(output, "BEV_HVBatPwrLim_On_BPCM = (wire: %.0f)\n", (double)(o->can_0x285_BPCM_ChargePowerLimits_BEV.BEV_HVBatPwrLim_On_BPCM)));
	return r;
}

static int pack_can_0x2c6_BPCM_HV_Impedance(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVBatMin_Cell_Dischrg_Imped: start-bit 3, length 12, endianess motorola, scaling 0.01, offset 0 */
	x = ((uint16_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped)) & 0xfff;
	x <<= 48; 
	m |= x;
	/* HVBatMax_Cell_Dischrg_Imped: start-bit 35, length 12, endianess motorola, scaling 0.01, offset 0 */
	x = ((uint16_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped)) & 0xfff;
	x <<= 16; 
	m |= x;
	/* HVBatMax_Cell_Dischrg_Imped_V: start-bit 52, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped_V)) & 0x1;
	x <<= 52; 
	i |= x;
	/* HVBatMin_Cell_Dischrg_Imped_V: start-bit 54, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped_V)) & 0x1;
	x <<= 54; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x2c6_BPCM_HV_Impedance_tx = 1;
	return 8;
}

static int unpack_can_0x2c6_BPCM_HV_Impedance(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatMin_Cell_Dischrg_Imped: start-bit 3, length 12, endianess motorola, scaling 0.01, offset 0 */
	x = (m >> 48) & 0xfff;
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped = x;
	/* HVBatMax_Cell_Dischrg_Imped: start-bit 35, length 12, endianess motorola, scaling 0.01, offset 0 */
	x = (m >> 16) & 0xfff;
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped = x;
	/* HVBatMax_Cell_Dischrg_Imped_V: start-bit 52, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0x1;
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped_V = x;
	/* HVBatMin_Cell_Dischrg_Imped_V: start-bit 54, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 54) & 0x1;
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped_V = x;
	o->can_0x2c6_BPCM_HV_Impedance_rx = 1;
	o->can_0x2c6_BPCM_HV_Impedance_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped);
	rval *= 0.01;
	if (rval <= 40.9) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped = 0;
	if (in > 40.9)
		return -1;
	in *= 100;
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped = in;
	return 0;
}

int decode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped);
	rval *= 0.01;
	if (rval <= 40.9) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped = 0;
	if (in > 40.9)
		return -1;
	in *= 100;
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped = in;
	return 0;
}

int decode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped_V(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped_V);
	*out = rval;
	return 0;
}

int encode_can_0x2c6_HVBatMax_Cell_Dischrg_Imped_V(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped_V = in;
	return 0;
}

int decode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped_V(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped_V);
	*out = rval;
	return 0;
}

int encode_can_0x2c6_HVBatMin_Cell_Dischrg_Imped_V(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped_V = in;
	return 0;
}

int print_can_0x2c6_BPCM_HV_Impedance(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatMin_Cell_Dischrg_Imped = (wire: %.0f)\n", (double)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped)));
	r = print_helper(r, fprintf(output, "HVBatMax_Cell_Dischrg_Imped = (wire: %.0f)\n", (double)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped)));
	r = print_helper(r, fprintf(output, "HVBatMax_Cell_Dischrg_Imped_V = (wire: %.0f)\n", (double)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMax_Cell_Dischrg_Imped_V)));
	r = print_helper(r, fprintf(output, "HVBatMin_Cell_Dischrg_Imped_V = (wire: %.0f)\n", (double)(o->can_0x2c6_BPCM_HV_Impedance.HVBatMin_Cell_Dischrg_Imped_V)));
	return r;
}

static int pack_can_0x306_BPCM_HV_SOC(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVBatSOC: start-bit 51, length 12, endianess motorola, scaling 0.02442, offset 0 */
	x = ((uint16_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOC)) & 0xfff;
	m |= x;
	/* HVBatSOH: start-bit 16, length 8, endianess intel, scaling 0.2, offset 50 */
	x = ((uint8_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOH)) & 0xff;
	x <<= 16; 
	i |= x;
	/* HVBatSOHLow: start-bit 24, length 8, endianess intel, scaling 0.2, offset 50 */
	x = ((uint8_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOHLow)) & 0xff;
	x <<= 24; 
	i |= x;
	/* HVBatSOCMax: start-bit 32, length 8, endianess intel, scaling 0.392157, offset 0 */
	x = ((uint8_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOCMax)) & 0xff;
	x <<= 32; 
	i |= x;
	/* HVBatSOCMin: start-bit 40, length 8, endianess intel, scaling 0.392157, offset 0 */
	x = ((uint8_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOCMin)) & 0xff;
	x <<= 40; 
	i |= x;
	/* HVBatSOCV: start-bit 55, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOCV)) & 0x1;
	x <<= 55; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x306_BPCM_HV_SOC_tx = 1;
	return 8;
}

static int unpack_can_0x306_BPCM_HV_SOC(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatSOC: start-bit 51, length 12, endianess motorola, scaling 0.02442, offset 0 */
	x = m & 0xfff;
	o->can_0x306_BPCM_HV_SOC.HVBatSOC = x;
	/* HVBatSOH: start-bit 16, length 8, endianess intel, scaling 0.2, offset 50 */
	x = (i >> 16) & 0xff;
	o->can_0x306_BPCM_HV_SOC.HVBatSOH = x;
	/* HVBatSOHLow: start-bit 24, length 8, endianess intel, scaling 0.2, offset 50 */
	x = (i >> 24) & 0xff;
	o->can_0x306_BPCM_HV_SOC.HVBatSOHLow = x;
	/* HVBatSOCMax: start-bit 32, length 8, endianess intel, scaling 0.392157, offset 0 */
	x = (i >> 32) & 0xff;
	o->can_0x306_BPCM_HV_SOC.HVBatSOCMax = x;
	/* HVBatSOCMin: start-bit 40, length 8, endianess intel, scaling 0.392157, offset 0 */
	x = (i >> 40) & 0xff;
	o->can_0x306_BPCM_HV_SOC.HVBatSOCMin = x;
	/* HVBatSOCV: start-bit 55, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 55) & 0x1;
	o->can_0x306_BPCM_HV_SOC.HVBatSOCV = x;
	o->can_0x306_BPCM_HV_SOC_rx = 1;
	o->can_0x306_BPCM_HV_SOC_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x306_HVBatSOC(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOC);
	rval *= 0.02442;
	if (rval <= 100) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x306_HVBatSOC(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x306_BPCM_HV_SOC.HVBatSOC = 0;
	if (in > 100)
		return -1;
	in *= 40.95;
	o->can_0x306_BPCM_HV_SOC.HVBatSOC = in;
	return 0;
}

int decode_can_0x306_HVBatSOH(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOH);
	rval *= 0.2;
	rval += 50;
	if ((rval >= 50) && (rval <= 100)) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x306_HVBatSOH(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x306_BPCM_HV_SOC.HVBatSOH = 0;
	if (in < 50)
		return -1;
	if (in > 100)
		return -1;
	in += -50;
	in *= 5;
	o->can_0x306_BPCM_HV_SOC.HVBatSOH = in;
	return 0;
}

int decode_can_0x306_HVBatSOHLow(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOHLow);
	rval *= 0.2;
	rval += 50;
	if ((rval >= 50) && (rval <= 100)) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x306_HVBatSOHLow(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x306_BPCM_HV_SOC.HVBatSOHLow = 0;
	if (in < 50)
		return -1;
	if (in > 100)
		return -1;
	in += -50;
	in *= 5;
	o->can_0x306_BPCM_HV_SOC.HVBatSOHLow = in;
	return 0;
}

int decode_can_0x306_HVBatSOCMax(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOCMax);
	rval *= 0.392157;
	if (rval <= 100) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x306_HVBatSOCMax(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x306_BPCM_HV_SOC.HVBatSOCMax = 0;
	if (in > 100)
		return -1;
	in *= 2.55;
	o->can_0x306_BPCM_HV_SOC.HVBatSOCMax = in;
	return 0;
}

int decode_can_0x306_HVBatSOCMin(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOCMin);
	rval *= 0.392157;
	if (rval <= 100) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x306_HVBatSOCMin(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x306_BPCM_HV_SOC.HVBatSOCMin = 0;
	if (in > 100)
		return -1;
	in *= 2.55;
	o->can_0x306_BPCM_HV_SOC.HVBatSOCMin = in;
	return 0;
}

int decode_can_0x306_HVBatSOCV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x306_BPCM_HV_SOC.HVBatSOCV);
	*out = rval;
	return 0;
}

int encode_can_0x306_HVBatSOCV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x306_BPCM_HV_SOC.HVBatSOCV = in;
	return 0;
}

int print_can_0x306_BPCM_HV_SOC(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatSOC = (wire: %.0f)\n", (double)(o->can_0x306_BPCM_HV_SOC.HVBatSOC)));
	r = print_helper(r, fprintf(output, "HVBatSOH = (wire: %.0f)\n", (double)(o->can_0x306_BPCM_HV_SOC.HVBatSOH)));
	r = print_helper(r, fprintf(output, "HVBatSOHLow = (wire: %.0f)\n", (double)(o->can_0x306_BPCM_HV_SOC.HVBatSOHLow)));
	r = print_helper(r, fprintf(output, "HVBatSOCMax = (wire: %.0f)\n", (double)(o->can_0x306_BPCM_HV_SOC.HVBatSOCMax)));
	r = print_helper(r, fprintf(output, "HVBatSOCMin = (wire: %.0f)\n", (double)(o->can_0x306_BPCM_HV_SOC.HVBatSOCMin)));
	r = print_helper(r, fprintf(output, "HVBatSOCV = (wire: %.0f)\n", (double)(o->can_0x306_BPCM_HV_SOC.HVBatSOCV)));
	return r;
}

static int pack_can_0x307_BPCM_HV_Temperature(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* HVBatClgInletTemp: start-bit 0, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTemp)) & 0xff;
	i |= x;
	/* HVBatClgOutletTemp: start-bit 8, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTemp)) & 0xff;
	x <<= 8; 
	i |= x;
	/* HVBatModTempMin: start-bit 32, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMin)) & 0xff;
	x <<= 32; 
	i |= x;
	/* HVBatModTempMax: start-bit 40, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMax)) & 0xff;
	x <<= 40; 
	i |= x;
	/* HVBatModTempAvg: start-bit 48, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempAvg)) & 0xff;
	x <<= 48; 
	i |= x;
	/* HVBatClgInletTempV: start-bit 20, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTempV)) & 0x1;
	x <<= 20; 
	i |= x;
	/* HVBatClgOutletTempV: start-bit 28, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTempV)) & 0x1;
	x <<= 28; 
	i |= x;
	/* HVBatModTempMaxV: start-bit 29, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMaxV)) & 0x1;
	x <<= 29; 
	i |= x;
	/* HVBatModlTempAvgV: start-bit 30, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModlTempAvgV)) & 0x1;
	x <<= 30; 
	i |= x;
	/* HVBatModTempMinV: start-bit 31, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMinV)) & 0x1;
	x <<= 31; 
	i |= x;
	*data = (i);
	o->can_0x307_BPCM_HV_Temperature_tx = 1;
	return 8;
}

static int unpack_can_0x307_BPCM_HV_Temperature(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatClgInletTemp: start-bit 0, length 8, endianess intel, scaling 1, offset -40 */
	x = i & 0xff;
	o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTemp = x;
	/* HVBatClgOutletTemp: start-bit 8, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 8) & 0xff;
	o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTemp = x;
	/* HVBatModTempMin: start-bit 32, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 32) & 0xff;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMin = x;
	/* HVBatModTempMax: start-bit 40, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 40) & 0xff;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMax = x;
	/* HVBatModTempAvg: start-bit 48, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 48) & 0xff;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempAvg = x;
	/* HVBatClgInletTempV: start-bit 20, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 20) & 0x1;
	o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTempV = x;
	/* HVBatClgOutletTempV: start-bit 28, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 28) & 0x1;
	o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTempV = x;
	/* HVBatModTempMaxV: start-bit 29, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 29) & 0x1;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMaxV = x;
	/* HVBatModlTempAvgV: start-bit 30, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 30) & 0x1;
	o->can_0x307_BPCM_HV_Temperature.HVBatModlTempAvgV = x;
	/* HVBatModTempMinV: start-bit 31, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 31) & 0x1;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMinV = x;
	o->can_0x307_BPCM_HV_Temperature_rx = 1;
	o->can_0x307_BPCM_HV_Temperature_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x307_HVBatClgInletTemp(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTemp);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x307_HVBatClgInletTemp(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTemp = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTemp = in;
	return 0;
}

int decode_can_0x307_HVBatClgOutletTemp(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTemp);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x307_HVBatClgOutletTemp(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTemp = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTemp = in;
	return 0;
}

int decode_can_0x307_HVBatModTempMin(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMin);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x307_HVBatModTempMin(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMin = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMin = in;
	return 0;
}

int decode_can_0x307_HVBatModTempMax(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMax);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x307_HVBatModTempMax(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMax = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMax = in;
	return 0;
}

int decode_can_0x307_HVBatModTempAvg(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempAvg);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x307_HVBatModTempAvg(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempAvg = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempAvg = in;
	return 0;
}

int decode_can_0x307_HVBatClgInletTempV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTempV);
	*out = rval;
	return 0;
}

int encode_can_0x307_HVBatClgInletTempV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTempV = in;
	return 0;
}

int decode_can_0x307_HVBatClgOutletTempV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTempV);
	*out = rval;
	return 0;
}

int encode_can_0x307_HVBatClgOutletTempV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTempV = in;
	return 0;
}

int decode_can_0x307_HVBatModTempMaxV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMaxV);
	*out = rval;
	return 0;
}

int encode_can_0x307_HVBatModTempMaxV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMaxV = in;
	return 0;
}

int decode_can_0x307_HVBatModlTempAvgV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModlTempAvgV);
	*out = rval;
	return 0;
}

int encode_can_0x307_HVBatModlTempAvgV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatModlTempAvgV = in;
	return 0;
}

int decode_can_0x307_HVBatModTempMinV(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMinV);
	*out = rval;
	return 0;
}

int encode_can_0x307_HVBatModTempMinV(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x307_BPCM_HV_Temperature.HVBatModTempMinV = in;
	return 0;
}

int print_can_0x307_BPCM_HV_Temperature(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatClgInletTemp = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTemp)));
	r = print_helper(r, fprintf(output, "HVBatClgOutletTemp = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTemp)));
	r = print_helper(r, fprintf(output, "HVBatModTempMin = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMin)));
	r = print_helper(r, fprintf(output, "HVBatModTempMax = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMax)));
	r = print_helper(r, fprintf(output, "HVBatModTempAvg = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempAvg)));
	r = print_helper(r, fprintf(output, "HVBatClgInletTempV = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatClgInletTempV)));
	r = print_helper(r, fprintf(output, "HVBatClgOutletTempV = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatClgOutletTempV)));
	r = print_helper(r, fprintf(output, "HVBatModTempMaxV = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMaxV)));
	r = print_helper(r, fprintf(output, "HVBatModlTempAvgV = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatModlTempAvgV)));
	r = print_helper(r, fprintf(output, "HVBatModTempMinV = (wire: %.0f)\n", (double)(o->can_0x307_BPCM_HV_Temperature.HVBatModTempMinV)));
	return r;
}

static int pack_can_0x312_BP_CNC_CO(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* HBCO_CellVltMax_High: start-bit 13, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x312_BP_CNC_CO.HBCO_CellVltMax_High)) & 0x1;
	x <<= 13; 
	i |= x;
	/* HBCO_CellVltMin_Low: start-bit 14, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x312_BP_CNC_CO.HBCO_CellVltMin_Low)) & 0x1;
	x <<= 14; 
	i |= x;
	/* HBCNC_BUT: start-bit 24, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x312_BP_CNC_CO.HBCNC_BUT)) & 0x1;
	x <<= 24; 
	i |= x;
	/* HBCNC_BOT: start-bit 39, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x312_BP_CNC_CO.HBCNC_BOT)) & 0x1;
	x <<= 39; 
	i |= x;
	*data = (i);
	o->can_0x312_BP_CNC_CO_tx = 1;
	return 8;
}

static int unpack_can_0x312_BP_CNC_CO(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HBCO_CellVltMax_High: start-bit 13, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 13) & 0x1;
	o->can_0x312_BP_CNC_CO.HBCO_CellVltMax_High = x;
	/* HBCO_CellVltMin_Low: start-bit 14, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 14) & 0x1;
	o->can_0x312_BP_CNC_CO.HBCO_CellVltMin_Low = x;
	/* HBCNC_BUT: start-bit 24, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 24) & 0x1;
	o->can_0x312_BP_CNC_CO.HBCNC_BUT = x;
	/* HBCNC_BOT: start-bit 39, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 39) & 0x1;
	o->can_0x312_BP_CNC_CO.HBCNC_BOT = x;
	o->can_0x312_BP_CNC_CO_rx = 1;
	o->can_0x312_BP_CNC_CO_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x312_HBCO_CellVltMax_High(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x312_BP_CNC_CO.HBCO_CellVltMax_High);
	*out = rval;
	return 0;
}

int encode_can_0x312_HBCO_CellVltMax_High(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x312_BP_CNC_CO.HBCO_CellVltMax_High = in;
	return 0;
}

int decode_can_0x312_HBCO_CellVltMin_Low(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x312_BP_CNC_CO.HBCO_CellVltMin_Low);
	*out = rval;
	return 0;
}

int encode_can_0x312_HBCO_CellVltMin_Low(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x312_BP_CNC_CO.HBCO_CellVltMin_Low = in;
	return 0;
}

int decode_can_0x312_HBCNC_BUT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x312_BP_CNC_CO.HBCNC_BUT);
	*out = rval;
	return 0;
}

int encode_can_0x312_HBCNC_BUT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x312_BP_CNC_CO.HBCNC_BUT = in;
	return 0;
}

int decode_can_0x312_HBCNC_BOT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x312_BP_CNC_CO.HBCNC_BOT);
	*out = rval;
	return 0;
}

int encode_can_0x312_HBCNC_BOT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x312_BP_CNC_CO.HBCNC_BOT = in;
	return 0;
}

int print_can_0x312_BP_CNC_CO(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HBCO_CellVltMax_High = (wire: %.0f)\n", (double)(o->can_0x312_BP_CNC_CO.HBCO_CellVltMax_High)));
	r = print_helper(r, fprintf(output, "HBCO_CellVltMin_Low = (wire: %.0f)\n", (double)(o->can_0x312_BP_CNC_CO.HBCO_CellVltMin_Low)));
	r = print_helper(r, fprintf(output, "HBCNC_BUT = (wire: %.0f)\n", (double)(o->can_0x312_BP_CNC_CO.HBCNC_BUT)));
	r = print_helper(r, fprintf(output, "HBCNC_BOT = (wire: %.0f)\n", (double)(o->can_0x312_BP_CNC_CO.HBCNC_BOT)));
	return r;
}

static int pack_can_0x322_DC_Charging_Status1(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* DCChargeInitialized: start-bit 55, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x322_DC_Charging_Status1.DCChargeInitialized)) & 0x1;
	x <<= 55; 
	i |= x;
	*data = (i);
	o->can_0x322_DC_Charging_Status1_tx = 1;
	return 8;
}

static int unpack_can_0x322_DC_Charging_Status1(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* DCChargeInitialized: start-bit 55, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 55) & 0x1;
	o->can_0x322_DC_Charging_Status1.DCChargeInitialized = x;
	o->can_0x322_DC_Charging_Status1_rx = 1;
	o->can_0x322_DC_Charging_Status1_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x322_DCChargeInitialized(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x322_DC_Charging_Status1.DCChargeInitialized);
	*out = rval;
	return 0;
}

int encode_can_0x322_DCChargeInitialized(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x322_DC_Charging_Status1.DCChargeInitialized = in;
	return 0;
}

int print_can_0x322_DC_Charging_Status1(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "DCChargeInitialized = (wire: %.0f)\n", (double)(o->can_0x322_DC_Charging_Status1.DCChargeInitialized)));
	return r;
}

static int pack_can_0x354_BPCM_MSG_04(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVBatCell_Voltage_High_Thrsh: start-bit 36, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = ((uint16_t)(o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_High_Thrsh)) & 0x1fff;
	x <<= 16; 
	m |= x;
	/* HVBatCell_Voltage_Low_Thrsh: start-bit 52, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = ((uint16_t)(o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_Low_Thrsh)) & 0x1fff;
	m |= x;
	/* HVBatHighTempThrsh: start-bit 16, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x354_BPCM_MSG_04.HVBatHighTempThrsh)) & 0xff;
	x <<= 16; 
	i |= x;
	/* HVBatLowTempThrsh: start-bit 24, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x354_BPCM_MSG_04.HVBatLowTempThrsh)) & 0xff;
	x <<= 24; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x354_BPCM_MSG_04_tx = 1;
	return 8;
}

static int unpack_can_0x354_BPCM_MSG_04(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatCell_Voltage_High_Thrsh: start-bit 36, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = (m >> 16) & 0x1fff;
	o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_High_Thrsh = x;
	/* HVBatCell_Voltage_Low_Thrsh: start-bit 52, length 13, endianess motorola, scaling 0.001, offset 0 */
	x = m & 0x1fff;
	o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_Low_Thrsh = x;
	/* HVBatHighTempThrsh: start-bit 16, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 16) & 0xff;
	o->can_0x354_BPCM_MSG_04.HVBatHighTempThrsh = x;
	/* HVBatLowTempThrsh: start-bit 24, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 24) & 0xff;
	o->can_0x354_BPCM_MSG_04.HVBatLowTempThrsh = x;
	o->can_0x354_BPCM_MSG_04_rx = 1;
	o->can_0x354_BPCM_MSG_04_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x354_HVBatCell_Voltage_High_Thrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_High_Thrsh);
	rval *= 0.001;
	if (rval <= 5) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x354_HVBatCell_Voltage_High_Thrsh(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_High_Thrsh = 0;
	if (in > 5)
		return -1;
	in *= 1000;
	o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_High_Thrsh = in;
	return 0;
}

int decode_can_0x354_HVBatCell_Voltage_Low_Thrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_Low_Thrsh);
	rval *= 0.001;
	if (rval <= 5) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x354_HVBatCell_Voltage_Low_Thrsh(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_Low_Thrsh = 0;
	if (in > 5)
		return -1;
	in *= 1000;
	o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_Low_Thrsh = in;
	return 0;
}

int decode_can_0x354_HVBatHighTempThrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x354_BPCM_MSG_04.HVBatHighTempThrsh);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x354_HVBatHighTempThrsh(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x354_BPCM_MSG_04.HVBatHighTempThrsh = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x354_BPCM_MSG_04.HVBatHighTempThrsh = in;
	return 0;
}

int decode_can_0x354_HVBatLowTempThrsh(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x354_BPCM_MSG_04.HVBatLowTempThrsh);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x354_HVBatLowTempThrsh(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x354_BPCM_MSG_04.HVBatLowTempThrsh = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x354_BPCM_MSG_04.HVBatLowTempThrsh = in;
	return 0;
}

int print_can_0x354_BPCM_MSG_04(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatCell_Voltage_High_Thrsh = (wire: %.0f)\n", (double)(o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_High_Thrsh)));
	r = print_helper(r, fprintf(output, "HVBatCell_Voltage_Low_Thrsh = (wire: %.0f)\n", (double)(o->can_0x354_BPCM_MSG_04.HVBatCell_Voltage_Low_Thrsh)));
	r = print_helper(r, fprintf(output, "HVBatHighTempThrsh = (wire: %.0f)\n", (double)(o->can_0x354_BPCM_MSG_04.HVBatHighTempThrsh)));
	r = print_helper(r, fprintf(output, "HVBatLowTempThrsh = (wire: %.0f)\n", (double)(o->can_0x354_BPCM_MSG_04.HVBatLowTempThrsh)));
	return r;
}

static int pack_can_0x356_BPCM_HV_VoltLimits(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* HVBatMinCellVltAlld: start-bit 3, length 12, endianess motorola, scaling 0.001, offset 1.5 */
	x = ((uint16_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld)) & 0xfff;
	x <<= 48; 
	m |= x;
	/* HVBatMaxCellVltAlld: start-bit 51, length 12, endianess motorola, scaling 0.001, offset 1.5 */
	x = ((uint16_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld)) & 0xfff;
	m |= x;
	/* HVBatMinPkVltAllwd: start-bit 16, length 9, endianess motorola, scaling 1, offset 175 */
	x = ((uint16_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd)) & 0x1ff;
	x <<= 32; 
	m |= x;
	/* HVBatMaxPkVltAllwd: start-bit 32, length 9, endianess motorola, scaling 1, offset 175 */
	x = ((uint16_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxPkVltAllwd)) & 0x1ff;
	x <<= 16; 
	m |= x;
	/* HVBatMaxCellVltAlld_V: start-bit 53, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld_V)) & 0x1;
	x <<= 53; 
	i |= x;
	/* HVBatMinCellVltAlld_V: start-bit 54, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld_V)) & 0x1;
	x <<= 54; 
	i |= x;
	/* HVBatMinPkVltAllwd_V: start-bit 55, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd_V)) & 0x1;
	x <<= 55; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x356_BPCM_HV_VoltLimits_tx = 1;
	return 8;
}

static int unpack_can_0x356_BPCM_HV_VoltLimits(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* HVBatMinCellVltAlld: start-bit 3, length 12, endianess motorola, scaling 0.001, offset 1.5 */
	x = (m >> 48) & 0xfff;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld = x;
	/* HVBatMaxCellVltAlld: start-bit 51, length 12, endianess motorola, scaling 0.001, offset 1.5 */
	x = m & 0xfff;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld = x;
	/* HVBatMinPkVltAllwd: start-bit 16, length 9, endianess motorola, scaling 1, offset 175 */
	x = (m >> 32) & 0x1ff;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd = x;
	/* HVBatMaxPkVltAllwd: start-bit 32, length 9, endianess motorola, scaling 1, offset 175 */
	x = (m >> 16) & 0x1ff;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxPkVltAllwd = x;
	/* HVBatMaxCellVltAlld_V: start-bit 53, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 53) & 0x1;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld_V = x;
	/* HVBatMinCellVltAlld_V: start-bit 54, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 54) & 0x1;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld_V = x;
	/* HVBatMinPkVltAllwd_V: start-bit 55, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 55) & 0x1;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd_V = x;
	o->can_0x356_BPCM_HV_VoltLimits_rx = 1;
	o->can_0x356_BPCM_HV_VoltLimits_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x356_HVBatMinCellVltAlld(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld);
	rval *= 0.001;
	rval += 1.5;
	if ((rval >= 1.5) && (rval <= 4.5)) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x356_HVBatMinCellVltAlld(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld = 0;
	if (in < 1.5)
		return -1;
	if (in > 4.5)
		return -1;
	in += -1.5;
	in *= 1000;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld = in;
	return 0;
}

int decode_can_0x356_HVBatMaxCellVltAlld(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld);
	rval *= 0.001;
	rval += 1.5;
	if ((rval >= 1.5) && (rval <= 4.5)) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x356_HVBatMaxCellVltAlld(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld = 0;
	if (in < 1.5)
		return -1;
	if (in > 4.5)
		return -1;
	in += -1.5;
	in *= 1000;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld = in;
	return 0;
}

int decode_can_0x356_HVBatMinPkVltAllwd(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd);
	rval += 175;
	if ((rval >= 175) && (rval <= 440)) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x356_HVBatMinPkVltAllwd(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd = 0;
	if (in < 175)
		return -1;
	if (in > 440)
		return -1;
	in += -175;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd = in;
	return 0;
}

int decode_can_0x356_HVBatMaxPkVltAllwd(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxPkVltAllwd);
	rval += 175;
	if (rval >= 175) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x356_HVBatMaxPkVltAllwd(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxPkVltAllwd = 0;
	if (in < 175)
		return -1;
	in += -175;
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxPkVltAllwd = in;
	return 0;
}

int decode_can_0x356_HVBatMaxCellVltAlld_V(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld_V);
	*out = rval;
	return 0;
}

int encode_can_0x356_HVBatMaxCellVltAlld_V(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld_V = in;
	return 0;
}

int decode_can_0x356_HVBatMinCellVltAlld_V(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld_V);
	*out = rval;
	return 0;
}

int encode_can_0x356_HVBatMinCellVltAlld_V(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld_V = in;
	return 0;
}

int decode_can_0x356_HVBatMinPkVltAllwd_V(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd_V);
	*out = rval;
	return 0;
}

int encode_can_0x356_HVBatMinPkVltAllwd_V(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd_V = in;
	return 0;
}

int print_can_0x356_BPCM_HV_VoltLimits(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "HVBatMinCellVltAlld = (wire: %.0f)\n", (double)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld)));
	r = print_helper(r, fprintf(output, "HVBatMaxCellVltAlld = (wire: %.0f)\n", (double)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld)));
	r = print_helper(r, fprintf(output, "HVBatMinPkVltAllwd = (wire: %.0f)\n", (double)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd)));
	r = print_helper(r, fprintf(output, "HVBatMaxPkVltAllwd = (wire: %.0f)\n", (double)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxPkVltAllwd)));
	r = print_helper(r, fprintf(output, "HVBatMaxCellVltAlld_V = (wire: %.0f)\n", (double)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMaxCellVltAlld_V)));
	r = print_helper(r, fprintf(output, "HVBatMinCellVltAlld_V = (wire: %.0f)\n", (double)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinCellVltAlld_V)));
	r = print_helper(r, fprintf(output, "HVBatMinPkVltAllwd_V = (wire: %.0f)\n", (double)(o->can_0x356_BPCM_HV_VoltLimits.HVBatMinPkVltAllwd_V)));
	return r;
}

static int pack_can_0x358_HybridRMS_Safety(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_HybridRMS_Safety: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x358_HybridRMS_Safety.CRC_HybridRMS_Safety)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_HybridRMS_Safety: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x358_HybridRMS_Safety.MC_HybridRMS_Safety)) & 0xf;
	x <<= 52; 
	i |= x;
	/* ThermalRunaway_Warning: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x358_HybridRMS_Safety.ThermalRunaway_Warning)) & 0x3;
	i |= x;
	*data = (i);
	o->can_0x358_HybridRMS_Safety_tx = 1;
	return 8;
}

static int unpack_can_0x358_HybridRMS_Safety(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* CRC_HybridRMS_Safety: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x358_HybridRMS_Safety.CRC_HybridRMS_Safety = x;
	/* MC_HybridRMS_Safety: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x358_HybridRMS_Safety.MC_HybridRMS_Safety = x;
	/* ThermalRunaway_Warning: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = i & 0x3;
	o->can_0x358_HybridRMS_Safety.ThermalRunaway_Warning = x;
	o->can_0x358_HybridRMS_Safety_rx = 1;
	o->can_0x358_HybridRMS_Safety_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x358_CRC_HybridRMS_Safety(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x358_HybridRMS_Safety.CRC_HybridRMS_Safety);
	*out = rval;
	return 0;
}

int encode_can_0x358_CRC_HybridRMS_Safety(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x358_HybridRMS_Safety.CRC_HybridRMS_Safety = in;
	return 0;
}

int decode_can_0x358_MC_HybridRMS_Safety(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x358_HybridRMS_Safety.MC_HybridRMS_Safety);
	*out = rval;
	return 0;
}

int encode_can_0x358_MC_HybridRMS_Safety(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x358_HybridRMS_Safety.MC_HybridRMS_Safety = in;
	return 0;
}

int decode_can_0x358_ThermalRunaway_Warning(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x358_HybridRMS_Safety.ThermalRunaway_Warning);
	if (rval <= 2) {
		*out = rval;
		return 0;
	} else {
		*out = (uint8_t)0;
		return -1;
	}
}

int encode_can_0x358_ThermalRunaway_Warning(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x358_HybridRMS_Safety.ThermalRunaway_Warning = 0;
	if (in > 2)
		return -1;
	o->can_0x358_HybridRMS_Safety.ThermalRunaway_Warning = in;
	return 0;
}

int print_can_0x358_HybridRMS_Safety(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_HybridRMS_Safety = (wire: %.0f)\n", (double)(o->can_0x358_HybridRMS_Safety.CRC_HybridRMS_Safety)));
	r = print_helper(r, fprintf(output, "MC_HybridRMS_Safety = (wire: %.0f)\n", (double)(o->can_0x358_HybridRMS_Safety.MC_HybridRMS_Safety)));
	r = print_helper(r, fprintf(output, "ThermalRunaway_Warning = (wire: %.0f)\n", (double)(o->can_0x358_HybridRMS_Safety.ThermalRunaway_Warning)));
	return r;
}

static int pack_can_0x359_BPCM_Status2_BEV(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* MaxChargeCurrentAllowed: start-bit 4, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x359_BPCM_Status2_BEV.MaxChargeCurrentAllowed)) & 0x1fff;
	x <<= 48; 
	m |= x;
	/* TotalAmpHrCapacity: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint16_t)(o->can_0x359_BPCM_Status2_BEV.TotalAmpHrCapacity)) & 0x1fff;
	x <<= 32; 
	m |= x;
	/* MaxPackVoltageAllowed: start-bit 32, length 9, endianess motorola, scaling 1, offset 100 */
	x = ((uint16_t)(o->can_0x359_BPCM_Status2_BEV.MaxPackVoltageAllowed)) & 0x1ff;
	x <<= 16; 
	m |= x;
	/* MinPackVoltageAllowed: start-bit 48, length 9, endianess motorola, scaling 1, offset 100 */
	x = ((uint16_t)(o->can_0x359_BPCM_Status2_BEV.MinPackVoltageAllowed)) & 0x1ff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x359_BPCM_Status2_BEV_tx = 1;
	return 8;
}

static int unpack_can_0x359_BPCM_Status2_BEV(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* MaxChargeCurrentAllowed: start-bit 4, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 48) & 0x1fff;
	o->can_0x359_BPCM_Status2_BEV.MaxChargeCurrentAllowed = x;
	/* TotalAmpHrCapacity: start-bit 20, length 13, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 32) & 0x1fff;
	o->can_0x359_BPCM_Status2_BEV.TotalAmpHrCapacity = x;
	/* MaxPackVoltageAllowed: start-bit 32, length 9, endianess motorola, scaling 1, offset 100 */
	x = (m >> 16) & 0x1ff;
	o->can_0x359_BPCM_Status2_BEV.MaxPackVoltageAllowed = x;
	/* MinPackVoltageAllowed: start-bit 48, length 9, endianess motorola, scaling 1, offset 100 */
	x = m & 0x1ff;
	o->can_0x359_BPCM_Status2_BEV.MinPackVoltageAllowed = x;
	o->can_0x359_BPCM_Status2_BEV_rx = 1;
	o->can_0x359_BPCM_Status2_BEV_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x359_MaxChargeCurrentAllowed(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x359_BPCM_Status2_BEV.MaxChargeCurrentAllowed);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x359_MaxChargeCurrentAllowed(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x359_BPCM_Status2_BEV.MaxChargeCurrentAllowed = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x359_BPCM_Status2_BEV.MaxChargeCurrentAllowed = in;
	return 0;
}

int decode_can_0x359_TotalAmpHrCapacity(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x359_BPCM_Status2_BEV.TotalAmpHrCapacity);
	rval *= 0.1;
	if (rval <= 819) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x359_TotalAmpHrCapacity(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x359_BPCM_Status2_BEV.TotalAmpHrCapacity = 0;
	if (in > 819)
		return -1;
	in *= 10;
	o->can_0x359_BPCM_Status2_BEV.TotalAmpHrCapacity = in;
	return 0;
}

int decode_can_0x359_MaxPackVoltageAllowed(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x359_BPCM_Status2_BEV.MaxPackVoltageAllowed);
	rval += 100;
	if (rval >= 100) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x359_MaxPackVoltageAllowed(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x359_BPCM_Status2_BEV.MaxPackVoltageAllowed = 0;
	if (in < 100)
		return -1;
	in += -100;
	o->can_0x359_BPCM_Status2_BEV.MaxPackVoltageAllowed = in;
	return 0;
}

int decode_can_0x359_MinPackVoltageAllowed(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x359_BPCM_Status2_BEV.MinPackVoltageAllowed);
	rval += 100;
	if (rval >= 100) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x359_MinPackVoltageAllowed(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x359_BPCM_Status2_BEV.MinPackVoltageAllowed = 0;
	if (in < 100)
		return -1;
	in += -100;
	o->can_0x359_BPCM_Status2_BEV.MinPackVoltageAllowed = in;
	return 0;
}

int print_can_0x359_BPCM_Status2_BEV(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "MaxChargeCurrentAllowed = (wire: %.0f)\n", (double)(o->can_0x359_BPCM_Status2_BEV.MaxChargeCurrentAllowed)));
	r = print_helper(r, fprintf(output, "TotalAmpHrCapacity = (wire: %.0f)\n", (double)(o->can_0x359_BPCM_Status2_BEV.TotalAmpHrCapacity)));
	r = print_helper(r, fprintf(output, "MaxPackVoltageAllowed = (wire: %.0f)\n", (double)(o->can_0x359_BPCM_Status2_BEV.MaxPackVoltageAllowed)));
	r = print_helper(r, fprintf(output, "MinPackVoltageAllowed = (wire: %.0f)\n", (double)(o->can_0x359_BPCM_Status2_BEV.MinPackVoltageAllowed)));
	return r;
}

static int pack_can_0x38c_GPS_POS3(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* GPS_Date_Year: start-bit 7, length 16, endianess motorola, scaling 1, offset 0 */
	x = ((uint16_t)(o->can_0x38c_GPS_POS3.GPS_Date_Year)) & 0xffff;
	x <<= 48; 
	m |= x;
	/* GPS_UTC_Second: start-bit 55, length 16, endianess motorola, scaling 0.01, offset 0 */
	x = ((uint16_t)(o->can_0x38c_GPS_POS3.GPS_UTC_Second)) & 0xffff;
	m |= x;
	/* GPS_Date_Month: start-bit 16, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x38c_GPS_POS3.GPS_Date_Month)) & 0xff;
	x <<= 16; 
	i |= x;
	/* GPS_Date_Day: start-bit 24, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x38c_GPS_POS3.GPS_Date_Day)) & 0xff;
	x <<= 24; 
	i |= x;
	/* GPS_UTC_Hour: start-bit 32, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x38c_GPS_POS3.GPS_UTC_Hour)) & 0xff;
	x <<= 32; 
	i |= x;
	/* GPS_UTC_Minute: start-bit 40, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x38c_GPS_POS3.GPS_UTC_Minute)) & 0xff;
	x <<= 40; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x38c_GPS_POS3_tx = 1;
	return 8;
}

static int unpack_can_0x38c_GPS_POS3(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* GPS_Date_Year: start-bit 7, length 16, endianess motorola, scaling 1, offset 0 */
	x = (m >> 48) & 0xffff;
	o->can_0x38c_GPS_POS3.GPS_Date_Year = x;
	/* GPS_UTC_Second: start-bit 55, length 16, endianess motorola, scaling 0.01, offset 0 */
	x = m & 0xffff;
	o->can_0x38c_GPS_POS3.GPS_UTC_Second = x;
	/* GPS_Date_Month: start-bit 16, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 16) & 0xff;
	o->can_0x38c_GPS_POS3.GPS_Date_Month = x;
	/* GPS_Date_Day: start-bit 24, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 24) & 0xff;
	o->can_0x38c_GPS_POS3.GPS_Date_Day = x;
	/* GPS_UTC_Hour: start-bit 32, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 32) & 0xff;
	o->can_0x38c_GPS_POS3.GPS_UTC_Hour = x;
	/* GPS_UTC_Minute: start-bit 40, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 40) & 0xff;
	o->can_0x38c_GPS_POS3.GPS_UTC_Minute = x;
	o->can_0x38c_GPS_POS3_rx = 1;
	o->can_0x38c_GPS_POS3_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x38c_GPS_Date_Year(const can_obj_can_c5_h_t *o, uint16_t *out) {
	assert(o);
	assert(out);
	uint16_t rval = (uint16_t)(o->can_0x38c_GPS_POS3.GPS_Date_Year);
	if (rval <= 65534) {
		*out = rval;
		return 0;
	} else {
		*out = (uint16_t)0;
		return -1;
	}
}

int encode_can_0x38c_GPS_Date_Year(can_obj_can_c5_h_t *o, uint16_t in) {
	assert(o);
	o->can_0x38c_GPS_POS3.GPS_Date_Year = 0;
	if (in > 65534)
		return -1;
	o->can_0x38c_GPS_POS3.GPS_Date_Year = in;
	return 0;
}

int decode_can_0x38c_GPS_UTC_Second(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x38c_GPS_POS3.GPS_UTC_Second);
	rval *= 0.01;
	if (rval <= 59.99) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x38c_GPS_UTC_Second(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x38c_GPS_POS3.GPS_UTC_Second = 0;
	if (in > 59.99)
		return -1;
	in *= 100;
	o->can_0x38c_GPS_POS3.GPS_UTC_Second = in;
	return 0;
}

int decode_can_0x38c_GPS_Date_Month(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x38c_GPS_POS3.GPS_Date_Month);
	if ((rval >= 1) && (rval <= 12)) {
		*out = rval;
		return 0;
	} else {
		*out = (uint8_t)0;
		return -1;
	}
}

int encode_can_0x38c_GPS_Date_Month(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x38c_GPS_POS3.GPS_Date_Month = 0;
	if (in < 1)
		return -1;
	if (in > 12)
		return -1;
	o->can_0x38c_GPS_POS3.GPS_Date_Month = in;
	return 0;
}

int decode_can_0x38c_GPS_Date_Day(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x38c_GPS_POS3.GPS_Date_Day);
	if ((rval >= 1) && (rval <= 31)) {
		*out = rval;
		return 0;
	} else {
		*out = (uint8_t)0;
		return -1;
	}
}

int encode_can_0x38c_GPS_Date_Day(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x38c_GPS_POS3.GPS_Date_Day = 0;
	if (in < 1)
		return -1;
	if (in > 31)
		return -1;
	o->can_0x38c_GPS_POS3.GPS_Date_Day = in;
	return 0;
}

int decode_can_0x38c_GPS_UTC_Hour(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x38c_GPS_POS3.GPS_UTC_Hour);
	if (rval <= 23) {
		*out = rval;
		return 0;
	} else {
		*out = (uint8_t)0;
		return -1;
	}
}

int encode_can_0x38c_GPS_UTC_Hour(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x38c_GPS_POS3.GPS_UTC_Hour = 0;
	if (in > 23)
		return -1;
	o->can_0x38c_GPS_POS3.GPS_UTC_Hour = in;
	return 0;
}

int decode_can_0x38c_GPS_UTC_Minute(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x38c_GPS_POS3.GPS_UTC_Minute);
	if (rval <= 59) {
		*out = rval;
		return 0;
	} else {
		*out = (uint8_t)0;
		return -1;
	}
}

int encode_can_0x38c_GPS_UTC_Minute(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x38c_GPS_POS3.GPS_UTC_Minute = 0;
	if (in > 59)
		return -1;
	o->can_0x38c_GPS_POS3.GPS_UTC_Minute = in;
	return 0;
}

int print_can_0x38c_GPS_POS3(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "GPS_Date_Year = (wire: %.0f)\n", (double)(o->can_0x38c_GPS_POS3.GPS_Date_Year)));
	r = print_helper(r, fprintf(output, "GPS_UTC_Second = (wire: %.0f)\n", (double)(o->can_0x38c_GPS_POS3.GPS_UTC_Second)));
	r = print_helper(r, fprintf(output, "GPS_Date_Month = (wire: %.0f)\n", (double)(o->can_0x38c_GPS_POS3.GPS_Date_Month)));
	r = print_helper(r, fprintf(output, "GPS_Date_Day = (wire: %.0f)\n", (double)(o->can_0x38c_GPS_POS3.GPS_Date_Day)));
	r = print_helper(r, fprintf(output, "GPS_UTC_Hour = (wire: %.0f)\n", (double)(o->can_0x38c_GPS_POS3.GPS_UTC_Hour)));
	r = print_helper(r, fprintf(output, "GPS_UTC_Minute = (wire: %.0f)\n", (double)(o->can_0x38c_GPS_POS3.GPS_UTC_Minute)));
	return r;
}

static int pack_can_0x39e_NET_CFG_EPT(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* NET_CFG_STAT_ePT: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x39e_NET_CFG_EPT.NET_CFG_STAT_ePT)) & 0x3;
	i |= x;
	/* NetCfg_OBCM_ePT: start-bit 8, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_OBCM_ePT)) & 0x1;
	x <<= 8; 
	i |= x;
	/* NetCfg_AHCP_ePT: start-bit 9, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_AHCP_ePT)) & 0x1;
	x <<= 9; 
	i |= x;
	/* NetCfg_BPCM_ePT: start-bit 12, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_BPCM_ePT)) & 0x1;
	x <<= 12; 
	i |= x;
	/* NetCfg_APM_ePT: start-bit 13, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_APM_ePT)) & 0x1;
	x <<= 13; 
	i |= x;
	*data = (i);
	o->can_0x39e_NET_CFG_EPT_tx = 1;
	return 3;
}

static int unpack_can_0x39e_NET_CFG_EPT(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 3)
		return -1;
	/* NET_CFG_STAT_ePT: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = i & 0x3;
	o->can_0x39e_NET_CFG_EPT.NET_CFG_STAT_ePT = x;
	/* NetCfg_OBCM_ePT: start-bit 8, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 8) & 0x1;
	o->can_0x39e_NET_CFG_EPT.NetCfg_OBCM_ePT = x;
	/* NetCfg_AHCP_ePT: start-bit 9, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 9) & 0x1;
	o->can_0x39e_NET_CFG_EPT.NetCfg_AHCP_ePT = x;
	/* NetCfg_BPCM_ePT: start-bit 12, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 12) & 0x1;
	o->can_0x39e_NET_CFG_EPT.NetCfg_BPCM_ePT = x;
	/* NetCfg_APM_ePT: start-bit 13, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 13) & 0x1;
	o->can_0x39e_NET_CFG_EPT.NetCfg_APM_ePT = x;
	o->can_0x39e_NET_CFG_EPT_rx = 1;
	o->can_0x39e_NET_CFG_EPT_time_stamp_rx = time_stamp;
	return 3;
}

int decode_can_0x39e_NET_CFG_STAT_ePT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x39e_NET_CFG_EPT.NET_CFG_STAT_ePT);
	*out = rval;
	return 0;
}

int encode_can_0x39e_NET_CFG_STAT_ePT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x39e_NET_CFG_EPT.NET_CFG_STAT_ePT = in;
	return 0;
}

int decode_can_0x39e_NetCfg_OBCM_ePT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_OBCM_ePT);
	*out = rval;
	return 0;
}

int encode_can_0x39e_NetCfg_OBCM_ePT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x39e_NET_CFG_EPT.NetCfg_OBCM_ePT = in;
	return 0;
}

int decode_can_0x39e_NetCfg_AHCP_ePT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_AHCP_ePT);
	*out = rval;
	return 0;
}

int encode_can_0x39e_NetCfg_AHCP_ePT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x39e_NET_CFG_EPT.NetCfg_AHCP_ePT = in;
	return 0;
}

int decode_can_0x39e_NetCfg_BPCM_ePT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_BPCM_ePT);
	*out = rval;
	return 0;
}

int encode_can_0x39e_NetCfg_BPCM_ePT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x39e_NET_CFG_EPT.NetCfg_BPCM_ePT = in;
	return 0;
}

int decode_can_0x39e_NetCfg_APM_ePT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x39e_NET_CFG_EPT.NetCfg_APM_ePT);
	*out = rval;
	return 0;
}

int encode_can_0x39e_NetCfg_APM_ePT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x39e_NET_CFG_EPT.NetCfg_APM_ePT = in;
	return 0;
}

int print_can_0x39e_NET_CFG_EPT(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "NET_CFG_STAT_ePT = (wire: %.0f)\n", (double)(o->can_0x39e_NET_CFG_EPT.NET_CFG_STAT_ePT)));
	r = print_helper(r, fprintf(output, "NetCfg_OBCM_ePT = (wire: %.0f)\n", (double)(o->can_0x39e_NET_CFG_EPT.NetCfg_OBCM_ePT)));
	r = print_helper(r, fprintf(output, "NetCfg_AHCP_ePT = (wire: %.0f)\n", (double)(o->can_0x39e_NET_CFG_EPT.NetCfg_AHCP_ePT)));
	r = print_helper(r, fprintf(output, "NetCfg_BPCM_ePT = (wire: %.0f)\n", (double)(o->can_0x39e_NET_CFG_EPT.NetCfg_BPCM_ePT)));
	r = print_helper(r, fprintf(output, "NetCfg_APM_ePT = (wire: %.0f)\n", (double)(o->can_0x39e_NET_CFG_EPT.NetCfg_APM_ePT)));
	return r;
}

static int pack_can_0x3d1_HCP_Charging_Stat2(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* ChargingSysSts: start-bit 37, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3d1_HCP_Charging_Stat2.ChargingSysSts)) & 0x7;
	x <<= 37; 
	i |= x;
	*data = (i);
	o->can_0x3d1_HCP_Charging_Stat2_tx = 1;
	return 8;
}

static int unpack_can_0x3d1_HCP_Charging_Stat2(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* ChargingSysSts: start-bit 37, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 37) & 0x7;
	o->can_0x3d1_HCP_Charging_Stat2.ChargingSysSts = x;
	o->can_0x3d1_HCP_Charging_Stat2_rx = 1;
	o->can_0x3d1_HCP_Charging_Stat2_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3d1_ChargingSysSts(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3d1_HCP_Charging_Stat2.ChargingSysSts);
	*out = rval;
	return 0;
}

int encode_can_0x3d1_ChargingSysSts(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3d1_HCP_Charging_Stat2.ChargingSysSts = in;
	return 0;
}

int print_can_0x3d1_HCP_Charging_Stat2(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "ChargingSysSts = (wire: %.0f)\n", (double)(o->can_0x3d1_HCP_Charging_Stat2.ChargingSysSts)));
	return r;
}

static int pack_can_0x3d2_HCP_GW_1000(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* ODO: start-bit 23, length 24, endianess motorola, scaling 0.1, offset 0 */
	x = ((uint32_t)(o->can_0x3d2_HCP_GW_1000.ODO)) & 0xffffff;
	x <<= 24; 
	m |= x;
	/* BATT_VOLT: start-bit 0, length 8, endianess intel, scaling 0.1, offset 0 */
	x = ((uint8_t)(o->can_0x3d2_HCP_GW_1000.BATT_VOLT)) & 0xff;
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x3d2_HCP_GW_1000_tx = 1;
	return 8;
}

static int unpack_can_0x3d2_HCP_GW_1000(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* ODO: start-bit 23, length 24, endianess motorola, scaling 0.1, offset 0 */
	x = (m >> 24) & 0xffffff;
	o->can_0x3d2_HCP_GW_1000.ODO = x;
	/* BATT_VOLT: start-bit 0, length 8, endianess intel, scaling 0.1, offset 0 */
	x = i & 0xff;
	o->can_0x3d2_HCP_GW_1000.BATT_VOLT = x;
	o->can_0x3d2_HCP_GW_1000_rx = 1;
	o->can_0x3d2_HCP_GW_1000_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3d2_ODO(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3d2_HCP_GW_1000.ODO);
	rval *= 0.1;
	if (rval <= 1.67772e+06) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3d2_ODO(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3d2_HCP_GW_1000.ODO = 0;
	if (in > 1.67772e+06)
		return -1;
	in *= 10;
	o->can_0x3d2_HCP_GW_1000.ODO = in;
	return 0;
}

int decode_can_0x3d2_BATT_VOLT(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3d2_HCP_GW_1000.BATT_VOLT);
	rval *= 0.1;
	if ((rval >= 5) && (rval <= 18)) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3d2_BATT_VOLT(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3d2_HCP_GW_1000.BATT_VOLT = 0;
	if (in < 5)
		return -1;
	if (in > 18)
		return -1;
	in *= 10;
	o->can_0x3d2_HCP_GW_1000.BATT_VOLT = in;
	return 0;
}

int print_can_0x3d2_HCP_GW_1000(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "ODO = (wire: %.0f)\n", (double)(o->can_0x3d2_HCP_GW_1000.ODO)));
	r = print_helper(r, fprintf(output, "BATT_VOLT = (wire: %.0f)\n", (double)(o->can_0x3d2_HCP_GW_1000.BATT_VOLT)));
	return r;
}

static int pack_can_0x3e0_VIN(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* VIN_DATA: start-bit 15, length 56, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x3e0_VIN.VIN_DATA)) & 0xffffffffffffff;
	m |= x;
	/* VIN_MSG: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3e0_VIN.VIN_MSG)) & 0x3;
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x3e0_VIN_tx = 1;
	return 8;
}

static int unpack_can_0x3e0_VIN(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* VIN_DATA: start-bit 15, length 56, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffff;
	o->can_0x3e0_VIN.VIN_DATA = x;
	/* VIN_MSG: start-bit 0, length 2, endianess intel, scaling 1, offset 0 */
	x = i & 0x3;
	o->can_0x3e0_VIN.VIN_MSG = x;
	o->can_0x3e0_VIN_rx = 1;
	o->can_0x3e0_VIN_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3e0_VIN_DATA(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x3e0_VIN.VIN_DATA);
	*out = rval;
	return 0;
}

int encode_can_0x3e0_VIN_DATA(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x3e0_VIN.VIN_DATA = in;
	return 0;
}

int decode_can_0x3e0_VIN_MSG(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3e0_VIN.VIN_MSG);
	*out = rval;
	return 0;
}

int encode_can_0x3e0_VIN_MSG(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3e0_VIN.VIN_MSG = in;
	return 0;
}

int print_can_0x3e0_VIN(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "VIN_DATA = (wire: %.0f)\n", (double)(o->can_0x3e0_VIN.VIN_DATA)));
	r = print_helper(r, fprintf(output, "VIN_MSG = (wire: %.0f)\n", (double)(o->can_0x3e0_VIN.VIN_MSG)));
	return r;
}

static int pack_can_0x3e8_BPCM_MSG_05(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* Prchrgpnltytimer: start-bit 25, length 10, endianess motorola, scaling 2, offset 0 */
	x = ((uint16_t)(o->can_0x3e8_BPCM_MSG_05.Prchrgpnltytimer)) & 0x3ff;
	x <<= 24; 
	m |= x;
	/* HVBatCntctrOpnTime: start-bit 40, length 8, endianess intel, scaling 0.2, offset 0 */
	x = ((uint8_t)(o->can_0x3e8_BPCM_MSG_05.HVBatCntctrOpnTime)) & 0xff;
	x <<= 40; 
	i |= x;
	/* HVBatSleepTime: start-bit 48, length 8, endianess intel, scaling 0.2, offset 0 */
	x = ((uint8_t)(o->can_0x3e8_BPCM_MSG_05.HVBatSleepTime)) & 0xff;
	x <<= 48; 
	i |= x;
	/* HVBatChargeStat: start-bit 61, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3e8_BPCM_MSG_05.HVBatChargeStat)) & 0x7;
	x <<= 61; 
	i |= x;
	/* BPCM_LIN_BusFault: start-bit 2, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3e8_BPCM_MSG_05.BPCM_LIN_BusFault)) & 0x3;
	x <<= 2; 
	i |= x;
	/* HEV_OnRq_BPCM: start-bit 57, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3e8_BPCM_MSG_05.HEV_OnRq_BPCM)) & 0x1;
	x <<= 57; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x3e8_BPCM_MSG_05_tx = 1;
	return 8;
}

static int unpack_can_0x3e8_BPCM_MSG_05(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* Prchrgpnltytimer: start-bit 25, length 10, endianess motorola, scaling 2, offset 0 */
	x = (m >> 24) & 0x3ff;
	o->can_0x3e8_BPCM_MSG_05.Prchrgpnltytimer = x;
	/* HVBatCntctrOpnTime: start-bit 40, length 8, endianess intel, scaling 0.2, offset 0 */
	x = (i >> 40) & 0xff;
	o->can_0x3e8_BPCM_MSG_05.HVBatCntctrOpnTime = x;
	/* HVBatSleepTime: start-bit 48, length 8, endianess intel, scaling 0.2, offset 0 */
	x = (i >> 48) & 0xff;
	o->can_0x3e8_BPCM_MSG_05.HVBatSleepTime = x;
	/* HVBatChargeStat: start-bit 61, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 61) & 0x7;
	o->can_0x3e8_BPCM_MSG_05.HVBatChargeStat = x;
	/* BPCM_LIN_BusFault: start-bit 2, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 2) & 0x3;
	o->can_0x3e8_BPCM_MSG_05.BPCM_LIN_BusFault = x;
	/* HEV_OnRq_BPCM: start-bit 57, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 57) & 0x1;
	o->can_0x3e8_BPCM_MSG_05.HEV_OnRq_BPCM = x;
	o->can_0x3e8_BPCM_MSG_05_rx = 1;
	o->can_0x3e8_BPCM_MSG_05_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3e8_Prchrgpnltytimer(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3e8_BPCM_MSG_05.Prchrgpnltytimer);
	rval *= 2;
	if (rval >= 2) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3e8_Prchrgpnltytimer(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3e8_BPCM_MSG_05.Prchrgpnltytimer = 0;
	if (in < 2)
		return -1;
	in *= 0.5;
	o->can_0x3e8_BPCM_MSG_05.Prchrgpnltytimer = in;
	return 0;
}

int decode_can_0x3e8_HVBatCntctrOpnTime(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3e8_BPCM_MSG_05.HVBatCntctrOpnTime);
	rval *= 0.2;
	if (rval <= 48) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3e8_HVBatCntctrOpnTime(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3e8_BPCM_MSG_05.HVBatCntctrOpnTime = 0;
	if (in > 48)
		return -1;
	in *= 5;
	o->can_0x3e8_BPCM_MSG_05.HVBatCntctrOpnTime = in;
	return 0;
}

int decode_can_0x3e8_HVBatSleepTime(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3e8_BPCM_MSG_05.HVBatSleepTime);
	rval *= 0.2;
	if (rval <= 48) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3e8_HVBatSleepTime(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3e8_BPCM_MSG_05.HVBatSleepTime = 0;
	if (in > 48)
		return -1;
	in *= 5;
	o->can_0x3e8_BPCM_MSG_05.HVBatSleepTime = in;
	return 0;
}

int decode_can_0x3e8_HVBatChargeStat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3e8_BPCM_MSG_05.HVBatChargeStat);
	*out = rval;
	return 0;
}

int encode_can_0x3e8_HVBatChargeStat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3e8_BPCM_MSG_05.HVBatChargeStat = in;
	return 0;
}

int decode_can_0x3e8_BPCM_LIN_BusFault(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3e8_BPCM_MSG_05.BPCM_LIN_BusFault);
	*out = rval;
	return 0;
}

int encode_can_0x3e8_BPCM_LIN_BusFault(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3e8_BPCM_MSG_05.BPCM_LIN_BusFault = in;
	return 0;
}

int decode_can_0x3e8_HEV_OnRq_BPCM(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3e8_BPCM_MSG_05.HEV_OnRq_BPCM);
	*out = rval;
	return 0;
}

int encode_can_0x3e8_HEV_OnRq_BPCM(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3e8_BPCM_MSG_05.HEV_OnRq_BPCM = in;
	return 0;
}

int print_can_0x3e8_BPCM_MSG_05(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "Prchrgpnltytimer = (wire: %.0f)\n", (double)(o->can_0x3e8_BPCM_MSG_05.Prchrgpnltytimer)));
	r = print_helper(r, fprintf(output, "HVBatCntctrOpnTime = (wire: %.0f)\n", (double)(o->can_0x3e8_BPCM_MSG_05.HVBatCntctrOpnTime)));
	r = print_helper(r, fprintf(output, "HVBatSleepTime = (wire: %.0f)\n", (double)(o->can_0x3e8_BPCM_MSG_05.HVBatSleepTime)));
	r = print_helper(r, fprintf(output, "HVBatChargeStat = (wire: %.0f)\n", (double)(o->can_0x3e8_BPCM_MSG_05.HVBatChargeStat)));
	r = print_helper(r, fprintf(output, "BPCM_LIN_BusFault = (wire: %.0f)\n", (double)(o->can_0x3e8_BPCM_MSG_05.BPCM_LIN_BusFault)));
	r = print_helper(r, fprintf(output, "HEV_OnRq_BPCM = (wire: %.0f)\n", (double)(o->can_0x3e8_BPCM_MSG_05.HEV_OnRq_BPCM)));
	return r;
}

static int pack_can_0x3ea_BPCM_LTRActPump1(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* LTAP_Temp: start-bit 0, length 8, endianess intel, scaling 1, offset -50 */
	x = ((uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Temp)) & 0xff;
	i |= x;
	/* LTAP_PmpRPMTgt: start-bit 8, length 8, endianess intel, scaling 0.3937, offset 0 */
	x = ((uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_PmpRPMTgt)) & 0xff;
	x <<= 8; 
	i |= x;
	/* LTAP_RPMAct: start-bit 16, length 8, endianess intel, scaling 0.3937, offset 0 */
	x = ((uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_RPMAct)) & 0xff;
	x <<= 16; 
	i |= x;
	/* LTAP_Crnt: start-bit 24, length 8, endianess intel, scaling 0.2, offset 0 */
	x = ((uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Crnt)) & 0xff;
	x <<= 24; 
	i |= x;
	/* LTAP_Vlt: start-bit 32, length 8, endianess intel, scaling 0.1, offset 0 */
	x = ((uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Vlt)) & 0xff;
	x <<= 32; 
	i |= x;
	/* CRC_3EAh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.CRC_3EAh)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_3EAh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.MC_3EAh)) & 0xf;
	x <<= 52; 
	i |= x;
	*data = (i);
	o->can_0x3ea_BPCM_LTRActPump1_tx = 1;
	return 8;
}

static int unpack_can_0x3ea_BPCM_LTRActPump1(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* LTAP_Temp: start-bit 0, length 8, endianess intel, scaling 1, offset -50 */
	x = i & 0xff;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Temp = x;
	/* LTAP_PmpRPMTgt: start-bit 8, length 8, endianess intel, scaling 0.3937, offset 0 */
	x = (i >> 8) & 0xff;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_PmpRPMTgt = x;
	/* LTAP_RPMAct: start-bit 16, length 8, endianess intel, scaling 0.3937, offset 0 */
	x = (i >> 16) & 0xff;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_RPMAct = x;
	/* LTAP_Crnt: start-bit 24, length 8, endianess intel, scaling 0.2, offset 0 */
	x = (i >> 24) & 0xff;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Crnt = x;
	/* LTAP_Vlt: start-bit 32, length 8, endianess intel, scaling 0.1, offset 0 */
	x = (i >> 32) & 0xff;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Vlt = x;
	/* CRC_3EAh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x3ea_BPCM_LTRActPump1.CRC_3EAh = x;
	/* MC_3EAh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x3ea_BPCM_LTRActPump1.MC_3EAh = x;
	o->can_0x3ea_BPCM_LTRActPump1_rx = 1;
	o->can_0x3ea_BPCM_LTRActPump1_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3ea_LTAP_Temp(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Temp);
	rval += -50;
	if (rval <= 204) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ea_LTAP_Temp(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Temp = 0;
	if (in > 204)
		return -1;
	in += 50;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Temp = in;
	return 0;
}

int decode_can_0x3ea_LTAP_PmpRPMTgt(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_PmpRPMTgt);
	rval *= 0.3937;
	if (rval <= 99.998) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ea_LTAP_PmpRPMTgt(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_PmpRPMTgt = 0;
	if (in > 99.998)
		return -1;
	in *= 2.54001;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_PmpRPMTgt = in;
	return 0;
}

int decode_can_0x3ea_LTAP_RPMAct(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_RPMAct);
	rval *= 0.3937;
	if (rval <= 99.998) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ea_LTAP_RPMAct(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_RPMAct = 0;
	if (in > 99.998)
		return -1;
	in *= 2.54001;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_RPMAct = in;
	return 0;
}

int decode_can_0x3ea_LTAP_Crnt(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Crnt);
	rval *= 0.2;
	if (rval <= 50.8) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ea_LTAP_Crnt(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Crnt = 0;
	if (in > 50.8)
		return -1;
	in *= 5;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Crnt = in;
	return 0;
}

int decode_can_0x3ea_LTAP_Vlt(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Vlt);
	rval *= 0.1;
	if (rval <= 25.4) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ea_LTAP_Vlt(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Vlt = 0;
	if (in > 25.4)
		return -1;
	in *= 10;
	o->can_0x3ea_BPCM_LTRActPump1.LTAP_Vlt = in;
	return 0;
}

int decode_can_0x3ea_CRC_3EAh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.CRC_3EAh);
	*out = rval;
	return 0;
}

int encode_can_0x3ea_CRC_3EAh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ea_BPCM_LTRActPump1.CRC_3EAh = in;
	return 0;
}

int decode_can_0x3ea_MC_3EAh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ea_BPCM_LTRActPump1.MC_3EAh);
	*out = rval;
	return 0;
}

int encode_can_0x3ea_MC_3EAh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ea_BPCM_LTRActPump1.MC_3EAh = in;
	return 0;
}

int print_can_0x3ea_BPCM_LTRActPump1(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "LTAP_Temp = (wire: %.0f)\n", (double)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Temp)));
	r = print_helper(r, fprintf(output, "LTAP_PmpRPMTgt = (wire: %.0f)\n", (double)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_PmpRPMTgt)));
	r = print_helper(r, fprintf(output, "LTAP_RPMAct = (wire: %.0f)\n", (double)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_RPMAct)));
	r = print_helper(r, fprintf(output, "LTAP_Crnt = (wire: %.0f)\n", (double)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Crnt)));
	r = print_helper(r, fprintf(output, "LTAP_Vlt = (wire: %.0f)\n", (double)(o->can_0x3ea_BPCM_LTRActPump1.LTAP_Vlt)));
	r = print_helper(r, fprintf(output, "CRC_3EAh = (wire: %.0f)\n", (double)(o->can_0x3ea_BPCM_LTRActPump1.CRC_3EAh)));
	r = print_helper(r, fprintf(output, "MC_3EAh = (wire: %.0f)\n", (double)(o->can_0x3ea_BPCM_LTRActPump1.MC_3EAh)));
	return r;
}

static int pack_can_0x3eb_BPCM_LTRActPump2(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* BATHTR_HVCurrCons: start-bit 32, length 8, endianess intel, scaling 0.25, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.BATHTR_HVCurrCons)) & 0xff;
	x <<= 32; 
	i |= x;
	/* CRC_3EBh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.CRC_3EBh)) & 0xff;
	x <<= 56; 
	i |= x;
	/* LTAP_Supplier: start-bit 24, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Supplier)) & 0xf;
	x <<= 24; 
	i |= x;
	/* MC_3EBh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.MC_3EBh)) & 0xf;
	x <<= 52; 
	i |= x;
	/* LTAP_PostRunSts: start-bit 5, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_PostRunSts)) & 0x7;
	x <<= 5; 
	i |= x;
	/* LTAP_MontrngRPM: start-bit 1, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_MontrngRPM)) & 0x3;
	x <<= 1; 
	i |= x;
	/* LTAP_LimpHmAnON: start-bit 3, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_LimpHmAnON)) & 0x3;
	x <<= 3; 
	i |= x;
	/* LTAP_OvrCrnt: start-bit 8, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrCrnt)) & 0x3;
	x <<= 8; 
	i |= x;
	/* LTAP_OvrTemp: start-bit 10, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrTemp)) & 0x3;
	x <<= 10; 
	i |= x;
	/* LTAP_SuppVltErr: start-bit 12, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_SuppVltErr)) & 0x3;
	x <<= 12; 
	i |= x;
	/* LTAP_NodeErr: start-bit 14, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_NodeErr)) & 0x3;
	x <<= 14; 
	i |= x;
	/* LTAP_Deblock: start-bit 16, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Deblock)) & 0x3;
	x <<= 16; 
	i |= x;
	/* LTAP_DryRun: start-bit 18, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_DryRun)) & 0x3;
	x <<= 18; 
	i |= x;
	/* LTAP_Failsafe: start-bit 20, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Failsafe)) & 0x3;
	x <<= 20; 
	i |= x;
	/* LTAP_AirPreErr: start-bit 22, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_AirPreErr)) & 0x3;
	x <<= 22; 
	i |= x;
	/* BCP_LOC_Fault: start-bit 28, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.BCP_LOC_Fault)) & 0x3;
	x <<= 28; 
	i |= x;
	/* LTAP_RespErr: start-bit 0, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_RespErr)) & 0x1;
	i |= x;
	*data = (i);
	o->can_0x3eb_BPCM_LTRActPump2_tx = 1;
	return 8;
}

static int unpack_can_0x3eb_BPCM_LTRActPump2(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* BATHTR_HVCurrCons: start-bit 32, length 8, endianess intel, scaling 0.25, offset 0 */
	x = (i >> 32) & 0xff;
	o->can_0x3eb_BPCM_LTRActPump2.BATHTR_HVCurrCons = x;
	/* CRC_3EBh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x3eb_BPCM_LTRActPump2.CRC_3EBh = x;
	/* LTAP_Supplier: start-bit 24, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 24) & 0xf;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_Supplier = x;
	/* MC_3EBh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x3eb_BPCM_LTRActPump2.MC_3EBh = x;
	/* LTAP_PostRunSts: start-bit 5, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 5) & 0x7;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_PostRunSts = x;
	/* LTAP_MontrngRPM: start-bit 1, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 1) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_MontrngRPM = x;
	/* LTAP_LimpHmAnON: start-bit 3, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 3) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_LimpHmAnON = x;
	/* LTAP_OvrCrnt: start-bit 8, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 8) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrCrnt = x;
	/* LTAP_OvrTemp: start-bit 10, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 10) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrTemp = x;
	/* LTAP_SuppVltErr: start-bit 12, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 12) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_SuppVltErr = x;
	/* LTAP_NodeErr: start-bit 14, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 14) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_NodeErr = x;
	/* LTAP_Deblock: start-bit 16, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 16) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_Deblock = x;
	/* LTAP_DryRun: start-bit 18, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 18) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_DryRun = x;
	/* LTAP_Failsafe: start-bit 20, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 20) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_Failsafe = x;
	/* LTAP_AirPreErr: start-bit 22, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 22) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_AirPreErr = x;
	/* BCP_LOC_Fault: start-bit 28, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 28) & 0x3;
	o->can_0x3eb_BPCM_LTRActPump2.BCP_LOC_Fault = x;
	/* LTAP_RespErr: start-bit 0, length 1, endianess intel, scaling 1, offset 0 */
	x = i & 0x1;
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_RespErr = x;
	o->can_0x3eb_BPCM_LTRActPump2_rx = 1;
	o->can_0x3eb_BPCM_LTRActPump2_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3eb_BATHTR_HVCurrCons(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3eb_BPCM_LTRActPump2.BATHTR_HVCurrCons);
	rval *= 0.25;
	if (rval <= 63.5) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3eb_BATHTR_HVCurrCons(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.BATHTR_HVCurrCons = 0;
	if (in > 63.5)
		return -1;
	in *= 4;
	o->can_0x3eb_BPCM_LTRActPump2.BATHTR_HVCurrCons = in;
	return 0;
}

int decode_can_0x3eb_CRC_3EBh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.CRC_3EBh);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_CRC_3EBh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.CRC_3EBh = in;
	return 0;
}

int decode_can_0x3eb_LTAP_Supplier(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Supplier);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_Supplier(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_Supplier = in;
	return 0;
}

int decode_can_0x3eb_MC_3EBh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.MC_3EBh);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_MC_3EBh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.MC_3EBh = in;
	return 0;
}

int decode_can_0x3eb_LTAP_PostRunSts(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_PostRunSts);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_PostRunSts(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_PostRunSts = in;
	return 0;
}

int decode_can_0x3eb_LTAP_MontrngRPM(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_MontrngRPM);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_MontrngRPM(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_MontrngRPM = in;
	return 0;
}

int decode_can_0x3eb_LTAP_LimpHmAnON(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_LimpHmAnON);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_LimpHmAnON(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_LimpHmAnON = in;
	return 0;
}

int decode_can_0x3eb_LTAP_OvrCrnt(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrCrnt);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_OvrCrnt(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrCrnt = in;
	return 0;
}

int decode_can_0x3eb_LTAP_OvrTemp(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrTemp);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_OvrTemp(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrTemp = in;
	return 0;
}

int decode_can_0x3eb_LTAP_SuppVltErr(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_SuppVltErr);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_SuppVltErr(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_SuppVltErr = in;
	return 0;
}

int decode_can_0x3eb_LTAP_NodeErr(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_NodeErr);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_NodeErr(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_NodeErr = in;
	return 0;
}

int decode_can_0x3eb_LTAP_Deblock(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Deblock);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_Deblock(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_Deblock = in;
	return 0;
}

int decode_can_0x3eb_LTAP_DryRun(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_DryRun);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_DryRun(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_DryRun = in;
	return 0;
}

int decode_can_0x3eb_LTAP_Failsafe(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Failsafe);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_Failsafe(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_Failsafe = in;
	return 0;
}

int decode_can_0x3eb_LTAP_AirPreErr(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_AirPreErr);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_AirPreErr(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_AirPreErr = in;
	return 0;
}

int decode_can_0x3eb_BCP_LOC_Fault(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.BCP_LOC_Fault);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_BCP_LOC_Fault(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.BCP_LOC_Fault = in;
	return 0;
}

int decode_can_0x3eb_LTAP_RespErr(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_RespErr);
	*out = rval;
	return 0;
}

int encode_can_0x3eb_LTAP_RespErr(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3eb_BPCM_LTRActPump2.LTAP_RespErr = in;
	return 0;
}

int print_can_0x3eb_BPCM_LTRActPump2(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "BATHTR_HVCurrCons = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.BATHTR_HVCurrCons)));
	r = print_helper(r, fprintf(output, "CRC_3EBh = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.CRC_3EBh)));
	r = print_helper(r, fprintf(output, "LTAP_Supplier = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Supplier)));
	r = print_helper(r, fprintf(output, "MC_3EBh = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.MC_3EBh)));
	r = print_helper(r, fprintf(output, "LTAP_PostRunSts = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_PostRunSts)));
	r = print_helper(r, fprintf(output, "LTAP_MontrngRPM = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_MontrngRPM)));
	r = print_helper(r, fprintf(output, "LTAP_LimpHmAnON = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_LimpHmAnON)));
	r = print_helper(r, fprintf(output, "LTAP_OvrCrnt = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrCrnt)));
	r = print_helper(r, fprintf(output, "LTAP_OvrTemp = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_OvrTemp)));
	r = print_helper(r, fprintf(output, "LTAP_SuppVltErr = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_SuppVltErr)));
	r = print_helper(r, fprintf(output, "LTAP_NodeErr = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_NodeErr)));
	r = print_helper(r, fprintf(output, "LTAP_Deblock = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Deblock)));
	r = print_helper(r, fprintf(output, "LTAP_DryRun = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_DryRun)));
	r = print_helper(r, fprintf(output, "LTAP_Failsafe = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_Failsafe)));
	r = print_helper(r, fprintf(output, "LTAP_AirPreErr = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_AirPreErr)));
	r = print_helper(r, fprintf(output, "BCP_LOC_Fault = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.BCP_LOC_Fault)));
	r = print_helper(r, fprintf(output, "LTAP_RespErr = (wire: %.0f)\n", (double)(o->can_0x3eb_BPCM_LTRActPump2.LTAP_RespErr)));
	return r;
}

static int pack_can_0x3ec_BPCM_BattHtr1(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	register uint64_t i = 0;
	/* BATHTR_PwrCnsDes: start-bit 1, length 10, endianess motorola, scaling 20, offset 0 */
	x = ((uint16_t)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsDes)) & 0x3ff;
	x <<= 48; 
	m |= x;
	/* BATHTR_PwrCnsAct: start-bit 17, length 10, endianess motorola, scaling 20, offset 0 */
	x = ((uint16_t)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsAct)) & 0x3ff;
	x <<= 32; 
	m |= x;
	/* BATHTR_MeasuredHV: start-bit 33, length 10, endianess motorola, scaling 1, offset 0 */
	x = ((uint16_t)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_MeasuredHV)) & 0x3ff;
	x <<= 16; 
	m |= x;
	/* CRC_3ECh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ec_BPCM_BattHtr1.CRC_3ECh)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_3ECh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ec_BPCM_BattHtr1.MC_3ECh)) & 0xf;
	x <<= 52; 
	i |= x;
	*data = reverse_byte_order(m)|(i);
	o->can_0x3ec_BPCM_BattHtr1_tx = 1;
	return 8;
}

static int unpack_can_0x3ec_BPCM_BattHtr1(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* BATHTR_PwrCnsDes: start-bit 1, length 10, endianess motorola, scaling 20, offset 0 */
	x = (m >> 48) & 0x3ff;
	o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsDes = x;
	/* BATHTR_PwrCnsAct: start-bit 17, length 10, endianess motorola, scaling 20, offset 0 */
	x = (m >> 32) & 0x3ff;
	o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsAct = x;
	/* BATHTR_MeasuredHV: start-bit 33, length 10, endianess motorola, scaling 1, offset 0 */
	x = (m >> 16) & 0x3ff;
	o->can_0x3ec_BPCM_BattHtr1.BATHTR_MeasuredHV = x;
	/* CRC_3ECh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x3ec_BPCM_BattHtr1.CRC_3ECh = x;
	/* MC_3ECh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x3ec_BPCM_BattHtr1.MC_3ECh = x;
	o->can_0x3ec_BPCM_BattHtr1_rx = 1;
	o->can_0x3ec_BPCM_BattHtr1_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3ec_BATHTR_PwrCnsDes(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsDes);
	rval *= 20;
	*out = rval;
	return 0;
}

int encode_can_0x3ec_BATHTR_PwrCnsDes(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	in *= 0.05;
	o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsDes = in;
	return 0;
}

int decode_can_0x3ec_BATHTR_PwrCnsAct(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsAct);
	rval *= 20;
	*out = rval;
	return 0;
}

int encode_can_0x3ec_BATHTR_PwrCnsAct(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	in *= 0.05;
	o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsAct = in;
	return 0;
}

int decode_can_0x3ec_BATHTR_MeasuredHV(const can_obj_can_c5_h_t *o, uint16_t *out) {
	assert(o);
	assert(out);
	uint16_t rval = (uint16_t)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_MeasuredHV);
	if (rval <= 1022) {
		*out = rval;
		return 0;
	} else {
		*out = (uint16_t)0;
		return -1;
	}
}

int encode_can_0x3ec_BATHTR_MeasuredHV(can_obj_can_c5_h_t *o, uint16_t in) {
	assert(o);
	o->can_0x3ec_BPCM_BattHtr1.BATHTR_MeasuredHV = 0;
	if (in > 1022)
		return -1;
	o->can_0x3ec_BPCM_BattHtr1.BATHTR_MeasuredHV = in;
	return 0;
}

int decode_can_0x3ec_CRC_3ECh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ec_BPCM_BattHtr1.CRC_3ECh);
	*out = rval;
	return 0;
}

int encode_can_0x3ec_CRC_3ECh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ec_BPCM_BattHtr1.CRC_3ECh = in;
	return 0;
}

int decode_can_0x3ec_MC_3ECh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ec_BPCM_BattHtr1.MC_3ECh);
	*out = rval;
	return 0;
}

int encode_can_0x3ec_MC_3ECh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ec_BPCM_BattHtr1.MC_3ECh = in;
	return 0;
}

int print_can_0x3ec_BPCM_BattHtr1(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "BATHTR_PwrCnsDes = (wire: %.0f)\n", (double)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsDes)));
	r = print_helper(r, fprintf(output, "BATHTR_PwrCnsAct = (wire: %.0f)\n", (double)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_PwrCnsAct)));
	r = print_helper(r, fprintf(output, "BATHTR_MeasuredHV = (wire: %.0f)\n", (double)(o->can_0x3ec_BPCM_BattHtr1.BATHTR_MeasuredHV)));
	r = print_helper(r, fprintf(output, "CRC_3ECh = (wire: %.0f)\n", (double)(o->can_0x3ec_BPCM_BattHtr1.CRC_3ECh)));
	r = print_helper(r, fprintf(output, "MC_3ECh = (wire: %.0f)\n", (double)(o->can_0x3ec_BPCM_BattHtr1.MC_3ECh)));
	return r;
}

static int pack_can_0x3ed_BPCM_BattHtr2(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* BATHTR_CoolantTempInlet: start-bit 0, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempInlet)) & 0xff;
	i |= x;
	/* BATHTR_CoolantTempOutlet: start-bit 8, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempOutlet)) & 0xff;
	x <<= 8; 
	i |= x;
	/* CRC_3EDh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.CRC_3EDh)) & 0xff;
	x <<= 56; 
	i |= x;
	/* MC_3EDh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.MC_3EDh)) & 0xf;
	x <<= 52; 
	i |= x;
	/* BATHTR_Status: start-bit 16, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_Status)) & 0x7;
	x <<= 16; 
	i |= x;
	/* BATHTR_WarnCommFlt: start-bit 19, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnCommFlt)) & 0x3;
	x <<= 19; 
	i |= x;
	/* BATHTR_ServiceMemErr: start-bit 21, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceMemErr)) & 0x3;
	x <<= 21; 
	i |= x;
	/* BATHTR_CoolantOutletSnsrFlt: start-bit 24, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantOutletSnsrFlt)) & 0x3;
	x <<= 24; 
	i |= x;
	/* BATHTR_HCSensorFlt: start-bit 26, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_HCSensorFlt)) & 0x3;
	x <<= 26; 
	i |= x;
	/* BATHTR_CoolantInletSnsrFlt: start-bit 28, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantInletSnsrFlt)) & 0x3;
	x <<= 28; 
	i |= x;
	/* BATHTR_WARNCoolantTempOOR: start-bit 30, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WARNCoolantTempOOR)) & 0x3;
	x <<= 30; 
	i |= x;
	/* BATHTR_WarnLV_OOR: start-bit 32, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnLV_OOR)) & 0x3;
	x <<= 32; 
	i |= x;
	/* BATHTR_WarnHV_OOR: start-bit 34, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnHV_OOR)) & 0x3;
	x <<= 34; 
	i |= x;
	/* BATHTR_SelfProtectHW: start-bit 36, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectHW)) & 0x3;
	x <<= 36; 
	i |= x;
	/* BATHTR_SelfProtectOvrHeat: start-bit 38, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectOvrHeat)) & 0x3;
	x <<= 38; 
	i |= x;
	/* BATHTR_ServiceRqrd: start-bit 40, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceRqrd)) & 0x3;
	x <<= 40; 
	i |= x;
	/* BATHTR_ServiceCurrOutofRng: start-bit 42, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceCurrOutofRng)) & 0x3;
	x <<= 42; 
	i |= x;
	/* BATHTR_ServiceDrvrCirc: start-bit 44, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceDrvrCirc)) & 0x3;
	x <<= 44; 
	i |= x;
	/* BCH_LOC_Fault: start-bit 46, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BCH_LOC_Fault)) & 0x3;
	x <<= 46; 
	i |= x;
	/* BATHTR_RespErr: start-bit 23, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_RespErr)) & 0x1;
	x <<= 23; 
	i |= x;
	*data = (i);
	o->can_0x3ed_BPCM_BattHtr2_tx = 1;
	return 8;
}

static int unpack_can_0x3ed_BPCM_BattHtr2(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* BATHTR_CoolantTempInlet: start-bit 0, length 8, endianess intel, scaling 1, offset -40 */
	x = i & 0xff;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempInlet = x;
	/* BATHTR_CoolantTempOutlet: start-bit 8, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 8) & 0xff;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempOutlet = x;
	/* CRC_3EDh: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x3ed_BPCM_BattHtr2.CRC_3EDh = x;
	/* MC_3EDh: start-bit 52, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 52) & 0xf;
	o->can_0x3ed_BPCM_BattHtr2.MC_3EDh = x;
	/* BATHTR_Status: start-bit 16, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 16) & 0x7;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_Status = x;
	/* BATHTR_WarnCommFlt: start-bit 19, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 19) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnCommFlt = x;
	/* BATHTR_ServiceMemErr: start-bit 21, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 21) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceMemErr = x;
	/* BATHTR_CoolantOutletSnsrFlt: start-bit 24, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 24) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantOutletSnsrFlt = x;
	/* BATHTR_HCSensorFlt: start-bit 26, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 26) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_HCSensorFlt = x;
	/* BATHTR_CoolantInletSnsrFlt: start-bit 28, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 28) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantInletSnsrFlt = x;
	/* BATHTR_WARNCoolantTempOOR: start-bit 30, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 30) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WARNCoolantTempOOR = x;
	/* BATHTR_WarnLV_OOR: start-bit 32, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 32) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnLV_OOR = x;
	/* BATHTR_WarnHV_OOR: start-bit 34, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 34) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnHV_OOR = x;
	/* BATHTR_SelfProtectHW: start-bit 36, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 36) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectHW = x;
	/* BATHTR_SelfProtectOvrHeat: start-bit 38, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 38) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectOvrHeat = x;
	/* BATHTR_ServiceRqrd: start-bit 40, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 40) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceRqrd = x;
	/* BATHTR_ServiceCurrOutofRng: start-bit 42, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 42) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceCurrOutofRng = x;
	/* BATHTR_ServiceDrvrCirc: start-bit 44, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 44) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceDrvrCirc = x;
	/* BCH_LOC_Fault: start-bit 46, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 46) & 0x3;
	o->can_0x3ed_BPCM_BattHtr2.BCH_LOC_Fault = x;
	/* BATHTR_RespErr: start-bit 23, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 23) & 0x1;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_RespErr = x;
	o->can_0x3ed_BPCM_BattHtr2_rx = 1;
	o->can_0x3ed_BPCM_BattHtr2_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3ed_BATHTR_CoolantTempInlet(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempInlet);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ed_BATHTR_CoolantTempInlet(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempInlet = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempInlet = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_CoolantTempOutlet(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempOutlet);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ed_BATHTR_CoolantTempOutlet(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempOutlet = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempOutlet = in;
	return 0;
}

int decode_can_0x3ed_CRC_3EDh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.CRC_3EDh);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_CRC_3EDh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.CRC_3EDh = in;
	return 0;
}

int decode_can_0x3ed_MC_3EDh(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.MC_3EDh);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_MC_3EDh(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.MC_3EDh = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_Status(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_Status);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_Status(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_Status = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_WarnCommFlt(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnCommFlt);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_WarnCommFlt(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnCommFlt = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_ServiceMemErr(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceMemErr);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_ServiceMemErr(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceMemErr = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_CoolantOutletSnsrFlt(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantOutletSnsrFlt);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_CoolantOutletSnsrFlt(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantOutletSnsrFlt = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_HCSensorFlt(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_HCSensorFlt);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_HCSensorFlt(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_HCSensorFlt = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_CoolantInletSnsrFlt(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantInletSnsrFlt);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_CoolantInletSnsrFlt(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantInletSnsrFlt = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_WARNCoolantTempOOR(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WARNCoolantTempOOR);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_WARNCoolantTempOOR(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WARNCoolantTempOOR = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_WarnLV_OOR(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnLV_OOR);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_WarnLV_OOR(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnLV_OOR = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_WarnHV_OOR(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnHV_OOR);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_WarnHV_OOR(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnHV_OOR = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_SelfProtectHW(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectHW);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_SelfProtectHW(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectHW = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_SelfProtectOvrHeat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectOvrHeat);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_SelfProtectOvrHeat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectOvrHeat = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_ServiceRqrd(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceRqrd);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_ServiceRqrd(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceRqrd = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_ServiceCurrOutofRng(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceCurrOutofRng);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_ServiceCurrOutofRng(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceCurrOutofRng = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_ServiceDrvrCirc(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceDrvrCirc);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_ServiceDrvrCirc(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceDrvrCirc = in;
	return 0;
}

int decode_can_0x3ed_BCH_LOC_Fault(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BCH_LOC_Fault);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BCH_LOC_Fault(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BCH_LOC_Fault = in;
	return 0;
}

int decode_can_0x3ed_BATHTR_RespErr(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_RespErr);
	*out = rval;
	return 0;
}

int encode_can_0x3ed_BATHTR_RespErr(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ed_BPCM_BattHtr2.BATHTR_RespErr = in;
	return 0;
}

int print_can_0x3ed_BPCM_BattHtr2(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "BATHTR_CoolantTempInlet = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempInlet)));
	r = print_helper(r, fprintf(output, "BATHTR_CoolantTempOutlet = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantTempOutlet)));
	r = print_helper(r, fprintf(output, "CRC_3EDh = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.CRC_3EDh)));
	r = print_helper(r, fprintf(output, "MC_3EDh = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.MC_3EDh)));
	r = print_helper(r, fprintf(output, "BATHTR_Status = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_Status)));
	r = print_helper(r, fprintf(output, "BATHTR_WarnCommFlt = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnCommFlt)));
	r = print_helper(r, fprintf(output, "BATHTR_ServiceMemErr = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceMemErr)));
	r = print_helper(r, fprintf(output, "BATHTR_CoolantOutletSnsrFlt = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantOutletSnsrFlt)));
	r = print_helper(r, fprintf(output, "BATHTR_HCSensorFlt = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_HCSensorFlt)));
	r = print_helper(r, fprintf(output, "BATHTR_CoolantInletSnsrFlt = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_CoolantInletSnsrFlt)));
	r = print_helper(r, fprintf(output, "BATHTR_WARNCoolantTempOOR = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WARNCoolantTempOOR)));
	r = print_helper(r, fprintf(output, "BATHTR_WarnLV_OOR = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnLV_OOR)));
	r = print_helper(r, fprintf(output, "BATHTR_WarnHV_OOR = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_WarnHV_OOR)));
	r = print_helper(r, fprintf(output, "BATHTR_SelfProtectHW = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectHW)));
	r = print_helper(r, fprintf(output, "BATHTR_SelfProtectOvrHeat = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_SelfProtectOvrHeat)));
	r = print_helper(r, fprintf(output, "BATHTR_ServiceRqrd = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceRqrd)));
	r = print_helper(r, fprintf(output, "BATHTR_ServiceCurrOutofRng = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceCurrOutofRng)));
	r = print_helper(r, fprintf(output, "BATHTR_ServiceDrvrCirc = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_ServiceDrvrCirc)));
	r = print_helper(r, fprintf(output, "BCH_LOC_Fault = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BCH_LOC_Fault)));
	r = print_helper(r, fprintf(output, "BATHTR_RespErr = (wire: %.0f)\n", (double)(o->can_0x3ed_BPCM_BattHtr2.BATHTR_RespErr)));
	return r;
}

static int pack_can_0x3ee_Thermal_Command(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* LTAP_Cmd: start-bit 0, length 8, endianess intel, scaling 0.3937, offset 0 */
	x = ((uint8_t)(o->can_0x3ee_Thermal_Command.LTAP_Cmd)) & 0xff;
	i |= x;
	/* BATHTR_PwrCnsAllwd: start-bit 8, length 8, endianess intel, scaling 40, offset 0 */
	x = ((uint8_t)(o->can_0x3ee_Thermal_Command.BATHTR_PwrCnsAllwd)) & 0xff;
	x <<= 8; 
	i |= x;
	/* BATHTR_WtrTempDes: start-bit 16, length 8, endianess intel, scaling 1, offset -40 */
	x = ((uint8_t)(o->can_0x3ee_Thermal_Command.BATHTR_WtrTempDes)) & 0xff;
	x <<= 16; 
	i |= x;
	/* LTAP_PostRunCom: start-bit 56, length 3, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ee_Thermal_Command.LTAP_PostRunCom)) & 0x7;
	x <<= 56; 
	i |= x;
	/* LTAP_Failsafe_ACT: start-bit 59, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ee_Thermal_Command.LTAP_Failsafe_ACT)) & 0x3;
	x <<= 59; 
	i |= x;
	/* Thermal_System_Relay_Status: start-bit 62, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ee_Thermal_Command.Thermal_System_Relay_Status)) & 0x3;
	x <<= 62; 
	i |= x;
	/* BATHTR_Enbl: start-bit 61, length 1, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3ee_Thermal_Command.BATHTR_Enbl)) & 0x1;
	x <<= 61; 
	i |= x;
	*data = (i);
	o->can_0x3ee_Thermal_Command_tx = 1;
	return 8;
}

static int unpack_can_0x3ee_Thermal_Command(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* LTAP_Cmd: start-bit 0, length 8, endianess intel, scaling 0.3937, offset 0 */
	x = i & 0xff;
	o->can_0x3ee_Thermal_Command.LTAP_Cmd = x;
	/* BATHTR_PwrCnsAllwd: start-bit 8, length 8, endianess intel, scaling 40, offset 0 */
	x = (i >> 8) & 0xff;
	o->can_0x3ee_Thermal_Command.BATHTR_PwrCnsAllwd = x;
	/* BATHTR_WtrTempDes: start-bit 16, length 8, endianess intel, scaling 1, offset -40 */
	x = (i >> 16) & 0xff;
	o->can_0x3ee_Thermal_Command.BATHTR_WtrTempDes = x;
	/* LTAP_PostRunCom: start-bit 56, length 3, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0x7;
	o->can_0x3ee_Thermal_Command.LTAP_PostRunCom = x;
	/* LTAP_Failsafe_ACT: start-bit 59, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 59) & 0x3;
	o->can_0x3ee_Thermal_Command.LTAP_Failsafe_ACT = x;
	/* Thermal_System_Relay_Status: start-bit 62, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 62) & 0x3;
	o->can_0x3ee_Thermal_Command.Thermal_System_Relay_Status = x;
	/* BATHTR_Enbl: start-bit 61, length 1, endianess intel, scaling 1, offset 0 */
	x = (i >> 61) & 0x1;
	o->can_0x3ee_Thermal_Command.BATHTR_Enbl = x;
	o->can_0x3ee_Thermal_Command_rx = 1;
	o->can_0x3ee_Thermal_Command_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3ee_LTAP_Cmd(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ee_Thermal_Command.LTAP_Cmd);
	rval *= 0.3937;
	if (rval <= 99.998) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ee_LTAP_Cmd(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ee_Thermal_Command.LTAP_Cmd = 0;
	if (in > 99.998)
		return -1;
	in *= 2.54001;
	o->can_0x3ee_Thermal_Command.LTAP_Cmd = in;
	return 0;
}

int decode_can_0x3ee_BATHTR_PwrCnsAllwd(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ee_Thermal_Command.BATHTR_PwrCnsAllwd);
	rval *= 40;
	*out = rval;
	return 0;
}

int encode_can_0x3ee_BATHTR_PwrCnsAllwd(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	in *= 0.025;
	o->can_0x3ee_Thermal_Command.BATHTR_PwrCnsAllwd = in;
	return 0;
}

int decode_can_0x3ee_BATHTR_WtrTempDes(const can_obj_can_c5_h_t *o, dbcc_double_t *out) {
	assert(o);
	assert(out);
	dbcc_double_t rval = (dbcc_double_t)(o->can_0x3ee_Thermal_Command.BATHTR_WtrTempDes);
	rval += -40;
	if (rval <= 214) {
		*out = rval;
		return 0;
	} else {
		*out = (dbcc_double_t)0;
		return -1;
	}
}

int encode_can_0x3ee_BATHTR_WtrTempDes(can_obj_can_c5_h_t *o, dbcc_double_t in) {
	assert(o);
	o->can_0x3ee_Thermal_Command.BATHTR_WtrTempDes = 0;
	if (in > 214)
		return -1;
	in += 40;
	o->can_0x3ee_Thermal_Command.BATHTR_WtrTempDes = in;
	return 0;
}

int decode_can_0x3ee_LTAP_PostRunCom(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ee_Thermal_Command.LTAP_PostRunCom);
	*out = rval;
	return 0;
}

int encode_can_0x3ee_LTAP_PostRunCom(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ee_Thermal_Command.LTAP_PostRunCom = in;
	return 0;
}

int decode_can_0x3ee_LTAP_Failsafe_ACT(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ee_Thermal_Command.LTAP_Failsafe_ACT);
	*out = rval;
	return 0;
}

int encode_can_0x3ee_LTAP_Failsafe_ACT(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ee_Thermal_Command.LTAP_Failsafe_ACT = in;
	return 0;
}

int decode_can_0x3ee_Thermal_System_Relay_Status(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ee_Thermal_Command.Thermal_System_Relay_Status);
	*out = rval;
	return 0;
}

int encode_can_0x3ee_Thermal_System_Relay_Status(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ee_Thermal_Command.Thermal_System_Relay_Status = in;
	return 0;
}

int decode_can_0x3ee_BATHTR_Enbl(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3ee_Thermal_Command.BATHTR_Enbl);
	*out = rval;
	return 0;
}

int encode_can_0x3ee_BATHTR_Enbl(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3ee_Thermal_Command.BATHTR_Enbl = in;
	return 0;
}

int print_can_0x3ee_Thermal_Command(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "LTAP_Cmd = (wire: %.0f)\n", (double)(o->can_0x3ee_Thermal_Command.LTAP_Cmd)));
	r = print_helper(r, fprintf(output, "BATHTR_PwrCnsAllwd = (wire: %.0f)\n", (double)(o->can_0x3ee_Thermal_Command.BATHTR_PwrCnsAllwd)));
	r = print_helper(r, fprintf(output, "BATHTR_WtrTempDes = (wire: %.0f)\n", (double)(o->can_0x3ee_Thermal_Command.BATHTR_WtrTempDes)));
	r = print_helper(r, fprintf(output, "LTAP_PostRunCom = (wire: %.0f)\n", (double)(o->can_0x3ee_Thermal_Command.LTAP_PostRunCom)));
	r = print_helper(r, fprintf(output, "LTAP_Failsafe_ACT = (wire: %.0f)\n", (double)(o->can_0x3ee_Thermal_Command.LTAP_Failsafe_ACT)));
	r = print_helper(r, fprintf(output, "Thermal_System_Relay_Status = (wire: %.0f)\n", (double)(o->can_0x3ee_Thermal_Command.Thermal_System_Relay_Status)));
	r = print_helper(r, fprintf(output, "BATHTR_Enbl = (wire: %.0f)\n", (double)(o->can_0x3ee_Thermal_Command.BATHTR_Enbl)));
	return r;
}

static int pack_can_0x3fd_Proxi_Cfg(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* Country_Code: start-bit 0, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3fd_Proxi_Cfg.Country_Code)) & 0xff;
	i |= x;
	/* Model_Year: start-bit 8, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3fd_Proxi_Cfg.Model_Year)) & 0xff;
	x <<= 8; 
	i |= x;
	/* Vehicle_Line_Configuration: start-bit 16, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3fd_Proxi_Cfg.Vehicle_Line_Configuration)) & 0xff;
	x <<= 16; 
	i |= x;
	/* Car_Shape_Configuration: start-bit 24, length 5, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3fd_Proxi_Cfg.Car_Shape_Configuration)) & 0x1f;
	x <<= 24; 
	i |= x;
	/* Proxi_Cfg_Stat: start-bit 29, length 2, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x3fd_Proxi_Cfg.Proxi_Cfg_Stat)) & 0x3;
	x <<= 29; 
	i |= x;
	*data = (i);
	o->can_0x3fd_Proxi_Cfg_tx = 1;
	return 8;
}

static int unpack_can_0x3fd_Proxi_Cfg(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* Country_Code: start-bit 0, length 8, endianess intel, scaling 1, offset 0 */
	x = i & 0xff;
	o->can_0x3fd_Proxi_Cfg.Country_Code = x;
	/* Model_Year: start-bit 8, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 8) & 0xff;
	o->can_0x3fd_Proxi_Cfg.Model_Year = x;
	/* Vehicle_Line_Configuration: start-bit 16, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 16) & 0xff;
	o->can_0x3fd_Proxi_Cfg.Vehicle_Line_Configuration = x;
	/* Car_Shape_Configuration: start-bit 24, length 5, endianess intel, scaling 1, offset 0 */
	x = (i >> 24) & 0x1f;
	o->can_0x3fd_Proxi_Cfg.Car_Shape_Configuration = x;
	/* Proxi_Cfg_Stat: start-bit 29, length 2, endianess intel, scaling 1, offset 0 */
	x = (i >> 29) & 0x3;
	o->can_0x3fd_Proxi_Cfg.Proxi_Cfg_Stat = x;
	o->can_0x3fd_Proxi_Cfg_rx = 1;
	o->can_0x3fd_Proxi_Cfg_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x3fd_Country_Code(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3fd_Proxi_Cfg.Country_Code);
	*out = rval;
	return 0;
}

int encode_can_0x3fd_Country_Code(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3fd_Proxi_Cfg.Country_Code = in;
	return 0;
}

int decode_can_0x3fd_Model_Year(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3fd_Proxi_Cfg.Model_Year);
	*out = rval;
	return 0;
}

int encode_can_0x3fd_Model_Year(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3fd_Proxi_Cfg.Model_Year = in;
	return 0;
}

int decode_can_0x3fd_Vehicle_Line_Configuration(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3fd_Proxi_Cfg.Vehicle_Line_Configuration);
	*out = rval;
	return 0;
}

int encode_can_0x3fd_Vehicle_Line_Configuration(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3fd_Proxi_Cfg.Vehicle_Line_Configuration = in;
	return 0;
}

int decode_can_0x3fd_Car_Shape_Configuration(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3fd_Proxi_Cfg.Car_Shape_Configuration);
	*out = rval;
	return 0;
}

int encode_can_0x3fd_Car_Shape_Configuration(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3fd_Proxi_Cfg.Car_Shape_Configuration = in;
	return 0;
}

int decode_can_0x3fd_Proxi_Cfg_Stat(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x3fd_Proxi_Cfg.Proxi_Cfg_Stat);
	*out = rval;
	return 0;
}

int encode_can_0x3fd_Proxi_Cfg_Stat(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x3fd_Proxi_Cfg.Proxi_Cfg_Stat = in;
	return 0;
}

int print_can_0x3fd_Proxi_Cfg(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "Country_Code = (wire: %.0f)\n", (double)(o->can_0x3fd_Proxi_Cfg.Country_Code)));
	r = print_helper(r, fprintf(output, "Model_Year = (wire: %.0f)\n", (double)(o->can_0x3fd_Proxi_Cfg.Model_Year)));
	r = print_helper(r, fprintf(output, "Vehicle_Line_Configuration = (wire: %.0f)\n", (double)(o->can_0x3fd_Proxi_Cfg.Vehicle_Line_Configuration)));
	r = print_helper(r, fprintf(output, "Car_Shape_Configuration = (wire: %.0f)\n", (double)(o->can_0x3fd_Proxi_Cfg.Car_Shape_Configuration)));
	r = print_helper(r, fprintf(output, "Proxi_Cfg_Stat = (wire: %.0f)\n", (double)(o->can_0x3fd_Proxi_Cfg.Proxi_Cfg_Stat)));
	return r;
}

static int pack_can_0x441_DG_RQ_GLOBAL_UDS(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* DG_RQ_GLOBAL_UDS: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x441_DG_RQ_GLOBAL_UDS.DG_RQ_GLOBAL_UDS)) & 0xffffffffffffffff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x441_DG_RQ_GLOBAL_UDS_tx = 1;
	return 8;
}

static int unpack_can_0x441_DG_RQ_GLOBAL_UDS(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* DG_RQ_GLOBAL_UDS: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffffff;
	o->can_0x441_DG_RQ_GLOBAL_UDS.DG_RQ_GLOBAL_UDS = x;
	o->can_0x441_DG_RQ_GLOBAL_UDS_rx = 1;
	o->can_0x441_DG_RQ_GLOBAL_UDS_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x441_DG_RQ_GLOBAL_UDS(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x441_DG_RQ_GLOBAL_UDS.DG_RQ_GLOBAL_UDS);
	*out = rval;
	return 0;
}

int encode_can_0x441_DG_RQ_GLOBAL_UDS(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x441_DG_RQ_GLOBAL_UDS.DG_RQ_GLOBAL_UDS = in;
	return 0;
}

int print_can_0x441_DG_RQ_GLOBAL_UDS(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "DG_RQ_GLOBAL_UDS = (wire: %.0f)\n", (double)(o->can_0x441_DG_RQ_GLOBAL_UDS.DG_RQ_GLOBAL_UDS)));
	return r;
}

static int pack_can_0x5a8_TRANSM2(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t i = 0;
	/* CRC_T2: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x5a8_TRANSM2.CRC_T2)) & 0xff;
	x <<= 56; 
	i |= x;
	/* ShiftLeverPosition: start-bit 30, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x5a8_TRANSM2.ShiftLeverPosition)) & 0xf;
	x <<= 30; 
	i |= x;
	/* MessageCounter_T2: start-bit 48, length 4, endianess intel, scaling 1, offset 0 */
	x = ((uint8_t)(o->can_0x5a8_TRANSM2.MessageCounter_T2)) & 0xf;
	x <<= 48; 
	i |= x;
	*data = (i);
	o->can_0x5a8_TRANSM2_tx = 1;
	return 8;
}

static int unpack_can_0x5a8_TRANSM2(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t i = (data);
	if (dlc < 8)
		return -1;
	/* CRC_T2: start-bit 56, length 8, endianess intel, scaling 1, offset 0 */
	x = (i >> 56) & 0xff;
	o->can_0x5a8_TRANSM2.CRC_T2 = x;
	/* ShiftLeverPosition: start-bit 30, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 30) & 0xf;
	o->can_0x5a8_TRANSM2.ShiftLeverPosition = x;
	/* MessageCounter_T2: start-bit 48, length 4, endianess intel, scaling 1, offset 0 */
	x = (i >> 48) & 0xf;
	o->can_0x5a8_TRANSM2.MessageCounter_T2 = x;
	o->can_0x5a8_TRANSM2_rx = 1;
	o->can_0x5a8_TRANSM2_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x5a8_CRC_T2(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x5a8_TRANSM2.CRC_T2);
	*out = rval;
	return 0;
}

int encode_can_0x5a8_CRC_T2(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x5a8_TRANSM2.CRC_T2 = in;
	return 0;
}

int decode_can_0x5a8_ShiftLeverPosition(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x5a8_TRANSM2.ShiftLeverPosition);
	*out = rval;
	return 0;
}

int encode_can_0x5a8_ShiftLeverPosition(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x5a8_TRANSM2.ShiftLeverPosition = in;
	return 0;
}

int decode_can_0x5a8_MessageCounter_T2(const can_obj_can_c5_h_t *o, uint8_t *out) {
	assert(o);
	assert(out);
	uint8_t rval = (uint8_t)(o->can_0x5a8_TRANSM2.MessageCounter_T2);
	*out = rval;
	return 0;
}

int encode_can_0x5a8_MessageCounter_T2(can_obj_can_c5_h_t *o, uint8_t in) {
	assert(o);
	o->can_0x5a8_TRANSM2.MessageCounter_T2 = in;
	return 0;
}

int print_can_0x5a8_TRANSM2(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "CRC_T2 = (wire: %.0f)\n", (double)(o->can_0x5a8_TRANSM2.CRC_T2)));
	r = print_helper(r, fprintf(output, "ShiftLeverPosition = (wire: %.0f)\n", (double)(o->can_0x5a8_TRANSM2.ShiftLeverPosition)));
	r = print_helper(r, fprintf(output, "MessageCounter_T2 = (wire: %.0f)\n", (double)(o->can_0x5a8_TRANSM2.MessageCounter_T2)));
	return r;
}

static int pack_can_0x5bf_ECU_APPL_BPCM(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* ECU_APPL_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x5bf_ECU_APPL_BPCM.ECU_APPL_BPCM)) & 0xffffffffffffffff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x5bf_ECU_APPL_BPCM_tx = 1;
	return 8;
}

static int unpack_can_0x5bf_ECU_APPL_BPCM(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* ECU_APPL_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffffff;
	o->can_0x5bf_ECU_APPL_BPCM.ECU_APPL_BPCM = x;
	o->can_0x5bf_ECU_APPL_BPCM_rx = 1;
	o->can_0x5bf_ECU_APPL_BPCM_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x5bf_ECU_APPL_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x5bf_ECU_APPL_BPCM.ECU_APPL_BPCM);
	*out = rval;
	return 0;
}

int encode_can_0x5bf_ECU_APPL_BPCM(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x5bf_ECU_APPL_BPCM.ECU_APPL_BPCM = in;
	return 0;
}

int print_can_0x5bf_ECU_APPL_BPCM(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "ECU_APPL_BPCM = (wire: %.0f)\n", (double)(o->can_0x5bf_ECU_APPL_BPCM.ECU_APPL_BPCM)));
	return r;
}

static int pack_can_0x63f_SD_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* SD_RS_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x63f_SD_RS_BPCM.SD_RS_BPCM)) & 0xffffffffffffffff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x63f_SD_RS_BPCM_tx = 1;
	return 8;
}

static int unpack_can_0x63f_SD_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* SD_RS_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffffff;
	o->can_0x63f_SD_RS_BPCM.SD_RS_BPCM = x;
	o->can_0x63f_SD_RS_BPCM_rx = 1;
	o->can_0x63f_SD_RS_BPCM_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x63f_SD_RS_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x63f_SD_RS_BPCM.SD_RS_BPCM);
	*out = rval;
	return 0;
}

int encode_can_0x63f_SD_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x63f_SD_RS_BPCM.SD_RS_BPCM = in;
	return 0;
}

int print_can_0x63f_SD_RS_BPCM(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "SD_RS_BPCM = (wire: %.0f)\n", (double)(o->can_0x63f_SD_RS_BPCM.SD_RS_BPCM)));
	return r;
}

static int pack_can_0x6ff_APPL_ECU_BPCM(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* APPL_ECU_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x6ff_APPL_ECU_BPCM.APPL_ECU_BPCM)) & 0xffffffffffffffff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x6ff_APPL_ECU_BPCM_tx = 1;
	return 8;
}

static int unpack_can_0x6ff_APPL_ECU_BPCM(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* APPL_ECU_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffffff;
	o->can_0x6ff_APPL_ECU_BPCM.APPL_ECU_BPCM = x;
	o->can_0x6ff_APPL_ECU_BPCM_rx = 1;
	o->can_0x6ff_APPL_ECU_BPCM_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x6ff_APPL_ECU_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x6ff_APPL_ECU_BPCM.APPL_ECU_BPCM);
	*out = rval;
	return 0;
}

int encode_can_0x6ff_APPL_ECU_BPCM(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x6ff_APPL_ECU_BPCM.APPL_ECU_BPCM = in;
	return 0;
}

int print_can_0x6ff_APPL_ECU_BPCM(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "APPL_ECU_BPCM = (wire: %.0f)\n", (double)(o->can_0x6ff_APPL_ECU_BPCM.APPL_ECU_BPCM)));
	return r;
}

static int pack_can_0x7df_DG_RQ_GLOBAL(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* DG_RQ_GLOBAL: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x7df_DG_RQ_GLOBAL.DG_RQ_GLOBAL)) & 0xffffffffffffffff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x7df_DG_RQ_GLOBAL_tx = 1;
	return 8;
}

static int unpack_can_0x7df_DG_RQ_GLOBAL(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* DG_RQ_GLOBAL: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffffff;
	o->can_0x7df_DG_RQ_GLOBAL.DG_RQ_GLOBAL = x;
	o->can_0x7df_DG_RQ_GLOBAL_rx = 1;
	o->can_0x7df_DG_RQ_GLOBAL_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x7df_DG_RQ_GLOBAL(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x7df_DG_RQ_GLOBAL.DG_RQ_GLOBAL);
	*out = rval;
	return 0;
}

int encode_can_0x7df_DG_RQ_GLOBAL(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x7df_DG_RQ_GLOBAL.DG_RQ_GLOBAL = in;
	return 0;
}

int print_can_0x7df_DG_RQ_GLOBAL(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "DG_RQ_GLOBAL = (wire: %.0f)\n", (double)(o->can_0x7df_DG_RQ_GLOBAL.DG_RQ_GLOBAL)));
	return r;
}

static int pack_can_0x7e7_D_RQ_BPCM(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* D_RQ_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x7e7_D_RQ_BPCM.D_RQ_BPCM)) & 0xffffffffffffffff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x7e7_D_RQ_BPCM_tx = 1;
	return 8;
}

static int unpack_can_0x7e7_D_RQ_BPCM(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* D_RQ_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffffff;
	o->can_0x7e7_D_RQ_BPCM.D_RQ_BPCM = x;
	o->can_0x7e7_D_RQ_BPCM_rx = 1;
	o->can_0x7e7_D_RQ_BPCM_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x7e7_D_RQ_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x7e7_D_RQ_BPCM.D_RQ_BPCM);
	*out = rval;
	return 0;
}

int encode_can_0x7e7_D_RQ_BPCM(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x7e7_D_RQ_BPCM.D_RQ_BPCM = in;
	return 0;
}

int print_can_0x7e7_D_RQ_BPCM(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "D_RQ_BPCM = (wire: %.0f)\n", (double)(o->can_0x7e7_D_RQ_BPCM.D_RQ_BPCM)));
	return r;
}

static int pack_can_0x7ef_D_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t *data) {
	assert(o);
	assert(data);
	register uint64_t x;
	register uint64_t m = 0;
	/* D_RS_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = ((uint64_t)(o->can_0x7ef_D_RS_BPCM.D_RS_BPCM)) & 0xffffffffffffffff;
	m |= x;
	*data = reverse_byte_order(m);
	o->can_0x7ef_D_RS_BPCM_tx = 1;
	return 8;
}

static int unpack_can_0x7ef_D_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(dlc <= 8);
	register uint64_t x;
	register uint64_t m = reverse_byte_order(data);
	if (dlc < 8)
		return -1;
	/* D_RS_BPCM: start-bit 7, length 64, endianess motorola, scaling 1, offset 0 */
	x = m & 0xffffffffffffffff;
	o->can_0x7ef_D_RS_BPCM.D_RS_BPCM = x;
	o->can_0x7ef_D_RS_BPCM_rx = 1;
	o->can_0x7ef_D_RS_BPCM_time_stamp_rx = time_stamp;
	return 8;
}

int decode_can_0x7ef_D_RS_BPCM(const can_obj_can_c5_h_t *o, uint64_t *out) {
	assert(o);
	assert(out);
	uint64_t rval = (uint64_t)(o->can_0x7ef_D_RS_BPCM.D_RS_BPCM);
	*out = rval;
	return 0;
}

int encode_can_0x7ef_D_RS_BPCM(can_obj_can_c5_h_t *o, uint64_t in) {
	assert(o);
	o->can_0x7ef_D_RS_BPCM.D_RS_BPCM = in;
	return 0;
}

int print_can_0x7ef_D_RS_BPCM(const can_obj_can_c5_h_t *o, FILE *output) {
	assert(o);
	assert(output);
	int r = 0;
	r = print_helper(r, fprintf(output, "D_RS_BPCM = (wire: %.0f)\n", (double)(o->can_0x7ef_D_RS_BPCM.D_RS_BPCM)));
	return r;
}

int unpack_message(can_obj_can_c5_h_t *o, const unsigned long id, uint64_t data, uint8_t dlc, dbcc_time_stamp_t time_stamp) {
	assert(o);
	assert(id < (1ul << 29)); /* 29-bit CAN ID is largest possible */
	assert(dlc <= 8);         /* Maximum of 8 bytes in a CAN packet */
	switch (id) {
	case 0x095: return unpack_can_0x095_BPCM_Status1_BEV(o, data, dlc, time_stamp);
	case 0x0b4: return unpack_can_0x0b4_Hybrid_Status1(o, data, dlc, time_stamp);
	case 0x0e0: return unpack_can_0x0e0_BPCM_IMPACT(o, data, dlc, time_stamp);
	case 0x107: return unpack_can_0x107_BPCM_DC_Status(o, data, dlc, time_stamp);
	case 0x108: return unpack_can_0x108_DC_Charging_Command(o, data, dlc, time_stamp);
	case 0x150: return unpack_can_0x150_BPCM_MSG_01(o, data, dlc, time_stamp);
	case 0x151: return unpack_can_0x151_BPCM_PHEV_2(o, data, dlc, time_stamp);
	case 0x15a: return unpack_can_0x15a_IMPACT_INFO(o, data, dlc, time_stamp);
	case 0x1d0: return unpack_can_0x1d0_BPCM_HV_Modules1(o, data, dlc, time_stamp);
	case 0x1d7: return unpack_can_0x1d7_Hybrid_Status2(o, data, dlc, time_stamp);
	case 0x1d8: return unpack_can_0x1d8_Hybrid_Command_BPCM(o, data, dlc, time_stamp);
	case 0x210: return unpack_can_0x210_SBW_ROT1_DPT(o, data, dlc, time_stamp);
	case 0x212: return unpack_can_0x212_HCP_GW_20(o, data, dlc, time_stamp);
	case 0x220: return unpack_can_0x220_BPCM_MSG_02(o, data, dlc, time_stamp);
	case 0x281: return unpack_can_0x281_BPCM_DischargePowerLimits_BEV(o, data, dlc, time_stamp);
	case 0x285: return unpack_can_0x285_BPCM_ChargePowerLimits_BEV(o, data, dlc, time_stamp);
	case 0x2c6: return unpack_can_0x2c6_BPCM_HV_Impedance(o, data, dlc, time_stamp);
	case 0x306: return unpack_can_0x306_BPCM_HV_SOC(o, data, dlc, time_stamp);
	case 0x307: return unpack_can_0x307_BPCM_HV_Temperature(o, data, dlc, time_stamp);
	case 0x312: return unpack_can_0x312_BP_CNC_CO(o, data, dlc, time_stamp);
	case 0x322: return unpack_can_0x322_DC_Charging_Status1(o, data, dlc, time_stamp);
	case 0x354: return unpack_can_0x354_BPCM_MSG_04(o, data, dlc, time_stamp);
	case 0x356: return unpack_can_0x356_BPCM_HV_VoltLimits(o, data, dlc, time_stamp);
	case 0x358: return unpack_can_0x358_HybridRMS_Safety(o, data, dlc, time_stamp);
	case 0x359: return unpack_can_0x359_BPCM_Status2_BEV(o, data, dlc, time_stamp);
	case 0x38c: return unpack_can_0x38c_GPS_POS3(o, data, dlc, time_stamp);
	case 0x39e: return unpack_can_0x39e_NET_CFG_EPT(o, data, dlc, time_stamp);
	case 0x3d1: return unpack_can_0x3d1_HCP_Charging_Stat2(o, data, dlc, time_stamp);
	case 0x3d2: return unpack_can_0x3d2_HCP_GW_1000(o, data, dlc, time_stamp);
	case 0x3e0: return unpack_can_0x3e0_VIN(o, data, dlc, time_stamp);
	case 0x3e8: return unpack_can_0x3e8_BPCM_MSG_05(o, data, dlc, time_stamp);
	case 0x3ea: return unpack_can_0x3ea_BPCM_LTRActPump1(o, data, dlc, time_stamp);
	case 0x3eb: return unpack_can_0x3eb_BPCM_LTRActPump2(o, data, dlc, time_stamp);
	case 0x3ec: return unpack_can_0x3ec_BPCM_BattHtr1(o, data, dlc, time_stamp);
	case 0x3ed: return unpack_can_0x3ed_BPCM_BattHtr2(o, data, dlc, time_stamp);
	case 0x3ee: return unpack_can_0x3ee_Thermal_Command(o, data, dlc, time_stamp);
	case 0x3fd: return unpack_can_0x3fd_Proxi_Cfg(o, data, dlc, time_stamp);
	case 0x441: return unpack_can_0x441_DG_RQ_GLOBAL_UDS(o, data, dlc, time_stamp);
	case 0x5a8: return unpack_can_0x5a8_TRANSM2(o, data, dlc, time_stamp);
	case 0x5bf: return unpack_can_0x5bf_ECU_APPL_BPCM(o, data, dlc, time_stamp);
	case 0x63f: return unpack_can_0x63f_SD_RS_BPCM(o, data, dlc, time_stamp);
	case 0x6ff: return unpack_can_0x6ff_APPL_ECU_BPCM(o, data, dlc, time_stamp);
	case 0x7df: return unpack_can_0x7df_DG_RQ_GLOBAL(o, data, dlc, time_stamp);
	case 0x7e7: return unpack_can_0x7e7_D_RQ_BPCM(o, data, dlc, time_stamp);
	case 0x7ef: return unpack_can_0x7ef_D_RS_BPCM(o, data, dlc, time_stamp);
	default: break; 
	}
	return -1; 
}

int pack_message(can_obj_can_c5_h_t *o, const unsigned long id, uint64_t *data) {
	assert(o);
	assert(id < (1ul << 29)); /* 29-bit CAN ID is largest possible */
	switch (id) {
	case 0x095: return pack_can_0x095_BPCM_Status1_BEV(o, data);
	case 0x0b4: return pack_can_0x0b4_Hybrid_Status1(o, data);
	case 0x0e0: return pack_can_0x0e0_BPCM_IMPACT(o, data);
	case 0x107: return pack_can_0x107_BPCM_DC_Status(o, data);
	case 0x108: return pack_can_0x108_DC_Charging_Command(o, data);
	case 0x150: return pack_can_0x150_BPCM_MSG_01(o, data);
	case 0x151: return pack_can_0x151_BPCM_PHEV_2(o, data);
	case 0x15a: return pack_can_0x15a_IMPACT_INFO(o, data);
	case 0x1d0: return pack_can_0x1d0_BPCM_HV_Modules1(o, data);
	case 0x1d7: return pack_can_0x1d7_Hybrid_Status2(o, data);
	case 0x1d8: return pack_can_0x1d8_Hybrid_Command_BPCM(o, data);
	case 0x210: return pack_can_0x210_SBW_ROT1_DPT(o, data);
	case 0x212: return pack_can_0x212_HCP_GW_20(o, data);
	case 0x220: return pack_can_0x220_BPCM_MSG_02(o, data);
	case 0x281: return pack_can_0x281_BPCM_DischargePowerLimits_BEV(o, data);
	case 0x285: return pack_can_0x285_BPCM_ChargePowerLimits_BEV(o, data);
	case 0x2c6: return pack_can_0x2c6_BPCM_HV_Impedance(o, data);
	case 0x306: return pack_can_0x306_BPCM_HV_SOC(o, data);
	case 0x307: return pack_can_0x307_BPCM_HV_Temperature(o, data);
	case 0x312: return pack_can_0x312_BP_CNC_CO(o, data);
	case 0x322: return pack_can_0x322_DC_Charging_Status1(o, data);
	case 0x354: return pack_can_0x354_BPCM_MSG_04(o, data);
	case 0x356: return pack_can_0x356_BPCM_HV_VoltLimits(o, data);
	case 0x358: return pack_can_0x358_HybridRMS_Safety(o, data);
	case 0x359: return pack_can_0x359_BPCM_Status2_BEV(o, data);
	case 0x38c: return pack_can_0x38c_GPS_POS3(o, data);
	case 0x39e: return pack_can_0x39e_NET_CFG_EPT(o, data);
	case 0x3d1: return pack_can_0x3d1_HCP_Charging_Stat2(o, data);
	case 0x3d2: return pack_can_0x3d2_HCP_GW_1000(o, data);
	case 0x3e0: return pack_can_0x3e0_VIN(o, data);
	case 0x3e8: return pack_can_0x3e8_BPCM_MSG_05(o, data);
	case 0x3ea: return pack_can_0x3ea_BPCM_LTRActPump1(o, data);
	case 0x3eb: return pack_can_0x3eb_BPCM_LTRActPump2(o, data);
	case 0x3ec: return pack_can_0x3ec_BPCM_BattHtr1(o, data);
	case 0x3ed: return pack_can_0x3ed_BPCM_BattHtr2(o, data);
	case 0x3ee: return pack_can_0x3ee_Thermal_Command(o, data);
	case 0x3fd: return pack_can_0x3fd_Proxi_Cfg(o, data);
	case 0x441: return pack_can_0x441_DG_RQ_GLOBAL_UDS(o, data);
	case 0x5a8: return pack_can_0x5a8_TRANSM2(o, data);
	case 0x5bf: return pack_can_0x5bf_ECU_APPL_BPCM(o, data);
	case 0x63f: return pack_can_0x63f_SD_RS_BPCM(o, data);
	case 0x6ff: return pack_can_0x6ff_APPL_ECU_BPCM(o, data);
	case 0x7df: return pack_can_0x7df_DG_RQ_GLOBAL(o, data);
	case 0x7e7: return pack_can_0x7e7_D_RQ_BPCM(o, data);
	case 0x7ef: return pack_can_0x7ef_D_RS_BPCM(o, data);
	default: break; 
	}
	return -1; 
}

int message_dlc(const unsigned long id) {
	assert(id < (1ul << 29)); /* 29-bit CAN ID is largest possible */
	switch (id) {
	case 0x095: return 8;
	case 0x0b4: return 7;
	case 0x0e0: return 8;
	case 0x107: return 8;
	case 0x108: return 8;
	case 0x150: return 8;
	case 0x151: return 8;
	case 0x15a: return 4;
	case 0x1d0: return 8;
	case 0x1d7: return 8;
	case 0x1d8: return 8;
	case 0x210: return 5;
	case 0x212: return 8;
	case 0x220: return 8;
	case 0x281: return 8;
	case 0x285: return 8;
	case 0x2c6: return 8;
	case 0x306: return 8;
	case 0x307: return 8;
	case 0x312: return 8;
	case 0x322: return 8;
	case 0x354: return 8;
	case 0x356: return 8;
	case 0x358: return 8;
	case 0x359: return 8;
	case 0x38c: return 8;
	case 0x39e: return 3;
	case 0x3d1: return 8;
	case 0x3d2: return 8;
	case 0x3e0: return 8;
	case 0x3e8: return 8;
	case 0x3ea: return 8;
	case 0x3eb: return 8;
	case 0x3ec: return 8;
	case 0x3ed: return 8;
	case 0x3ee: return 8;
	case 0x3fd: return 8;
	case 0x441: return 8;
	case 0x5a8: return 8;
	case 0x5bf: return 8;
	case 0x63f: return 8;
	case 0x6ff: return 8;
	case 0x7df: return 8;
	case 0x7e7: return 8;
	case 0x7ef: return 8;
	default: break; 
	}
	return -1; 
}

int print_message(const can_obj_can_c5_h_t *o, const unsigned long id, FILE *output) {
	assert(o);
	assert(id < (1ul << 29)); /* 29-bit CAN ID is largest possible */
	assert(output);
	switch (id) {
	case 0x095: return print_can_0x095_BPCM_Status1_BEV(o, output);
	case 0x0b4: return print_can_0x0b4_Hybrid_Status1(o, output);
	case 0x0e0: return print_can_0x0e0_BPCM_IMPACT(o, output);
	case 0x107: return print_can_0x107_BPCM_DC_Status(o, output);
	case 0x108: return print_can_0x108_DC_Charging_Command(o, output);
	case 0x150: return print_can_0x150_BPCM_MSG_01(o, output);
	case 0x151: return print_can_0x151_BPCM_PHEV_2(o, output);
	case 0x15a: return print_can_0x15a_IMPACT_INFO(o, output);
	case 0x1d0: return print_can_0x1d0_BPCM_HV_Modules1(o, output);
	case 0x1d7: return print_can_0x1d7_Hybrid_Status2(o, output);
	case 0x1d8: return print_can_0x1d8_Hybrid_Command_BPCM(o, output);
	case 0x210: return print_can_0x210_SBW_ROT1_DPT(o, output);
	case 0x212: return print_can_0x212_HCP_GW_20(o, output);
	case 0x220: return print_can_0x220_BPCM_MSG_02(o, output);
	case 0x281: return print_can_0x281_BPCM_DischargePowerLimits_BEV(o, output);
	case 0x285: return print_can_0x285_BPCM_ChargePowerLimits_BEV(o, output);
	case 0x2c6: return print_can_0x2c6_BPCM_HV_Impedance(o, output);
	case 0x306: return print_can_0x306_BPCM_HV_SOC(o, output);
	case 0x307: return print_can_0x307_BPCM_HV_Temperature(o, output);
	case 0x312: return print_can_0x312_BP_CNC_CO(o, output);
	case 0x322: return print_can_0x322_DC_Charging_Status1(o, output);
	case 0x354: return print_can_0x354_BPCM_MSG_04(o, output);
	case 0x356: return print_can_0x356_BPCM_HV_VoltLimits(o, output);
	case 0x358: return print_can_0x358_HybridRMS_Safety(o, output);
	case 0x359: return print_can_0x359_BPCM_Status2_BEV(o, output);
	case 0x38c: return print_can_0x38c_GPS_POS3(o, output);
	case 0x39e: return print_can_0x39e_NET_CFG_EPT(o, output);
	case 0x3d1: return print_can_0x3d1_HCP_Charging_Stat2(o, output);
	case 0x3d2: return print_can_0x3d2_HCP_GW_1000(o, output);
	case 0x3e0: return print_can_0x3e0_VIN(o, output);
	case 0x3e8: return print_can_0x3e8_BPCM_MSG_05(o, output);
	case 0x3ea: return print_can_0x3ea_BPCM_LTRActPump1(o, output);
	case 0x3eb: return print_can_0x3eb_BPCM_LTRActPump2(o, output);
	case 0x3ec: return print_can_0x3ec_BPCM_BattHtr1(o, output);
	case 0x3ed: return print_can_0x3ed_BPCM_BattHtr2(o, output);
	case 0x3ee: return print_can_0x3ee_Thermal_Command(o, output);
	case 0x3fd: return print_can_0x3fd_Proxi_Cfg(o, output);
	case 0x441: return print_can_0x441_DG_RQ_GLOBAL_UDS(o, output);
	case 0x5a8: return print_can_0x5a8_TRANSM2(o, output);
	case 0x5bf: return print_can_0x5bf_ECU_APPL_BPCM(o, output);
	case 0x63f: return print_can_0x63f_SD_RS_BPCM(o, output);
	case 0x6ff: return print_can_0x6ff_APPL_ECU_BPCM(o, output);
	case 0x7df: return print_can_0x7df_DG_RQ_GLOBAL(o, output);
	case 0x7e7: return print_can_0x7e7_D_RQ_BPCM(o, output);
	case 0x7ef: return print_can_0x7ef_D_RS_BPCM(o, output);
	default: break; 
	}
	return -1; 
}

