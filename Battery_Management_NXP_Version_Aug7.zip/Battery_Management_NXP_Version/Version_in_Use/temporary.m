model = 'test';
subsys = 'Subsystem9/Subsystem8';
busCreatorPath = [model '/' subsys '/Bus Creator'];

% Ensure model is loaded
load_system(model);

% Get Bus Creator port handles
busCreatorPorts = get_param(busCreatorPath, 'PortHandles');
busOutports = busCreatorPorts.Outport;

for i = 1:105
    % Construct target block name
    if i <= 14
        dsBlockName = sprintf('Data Store Write%d', i);
    else
        dsBlockName = sprintf('DSWrite_HVBatCell_Voltage%03d', i);
    end

    dsBlockPath = [model '/' subsys '/' dsBlockName];

    try
        % Check if block exists and get its port handles
        dsPorts = get_param(dsBlockPath, 'PortHandles');
        % Connect output i of Bus Creator to Data Store Write input
        add_line(model, busOutports(i), dsPorts.Inport, 'autorouting', 'on');
    catch ME
        warning("Could not connect output %d to %s: %s", i, dsBlockPath, ME.message);
    end
end
