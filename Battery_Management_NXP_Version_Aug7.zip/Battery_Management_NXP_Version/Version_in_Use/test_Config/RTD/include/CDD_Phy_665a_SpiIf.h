/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_SPIIF_H
#define CDD_PHY_665A_SPIIF_H

/**
*   @file CDD_Phy_665a_SpiIf.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Std_Types.h"
#include "CDD_Phy_665a_Cfg.h"
#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
#include "Spi.h"
#if (PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED == STD_ON)
#include "Icu.h"
#endif
#endif

/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_SPIIF_VENDOR_ID                    43
#define PHY_665A_SPIIF_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_SPIIF_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_SPIIF_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_SPIIF_SW_MAJOR_VERSION             1
#define PHY_665A_SPIIF_SW_MINOR_VERSION             0
#define PHY_665A_SPIIF_SW_PATCH_VERSION             2

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((PHY_665A_SPIIF_AR_RELEASE_MAJOR_VERSION != STD_AR_RELEASE_MAJOR_VERSION) || \
         (PHY_665A_SPIIF_AR_RELEASE_MINOR_VERSION != STD_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_SpiIf.h and StandardTypes.h are different"
    #endif
#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((PHY_665A_SPIIF_AR_RELEASE_MAJOR_VERSION != SPI_AR_RELEASE_MAJOR_VERSION) || \
         (PHY_665A_SPIIF_AR_RELEASE_MINOR_VERSION != SPI_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_SpiIf.h and Spi.h are different"
    #endif
#if (PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED == STD_ON)
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((PHY_665A_SPIIF_AR_RELEASE_MAJOR_VERSION != ICU_AR_RELEASE_MAJOR_VERSION) || \
         (PHY_665A_SPIIF_AR_RELEASE_MINOR_VERSION != ICU_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_SpiIf.h and Icu.h are different"
    #endif
#endif /*(PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED == STD_ON)*/
#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/
#endif /*DISABLE_MCAL_INTERMODULE_ASR_CHECK*/

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same vendor */
#if (PHY_665A_SPIIF_VENDOR_ID != PHY_665A_VENDOR_ID_CFG)
#error "CDD_Phy_665a_SpiIf.h and CDD_Phy_665a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Autosar version */
#if ((PHY_665A_SPIIF_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (PHY_665A_SPIIF_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (PHY_665A_SPIIF_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of CDD_Phy_665a_SpiIf.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Software version */
#if ((PHY_665A_SPIIF_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_CFG) || \
     (PHY_665A_SPIIF_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_CFG) || \
     (PHY_665A_SPIIF_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of CDD_Phy_665a_SpiIf.h and CDD_Phy_665a_Cfg.h are different"
#endif
/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/
#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
#define PHY_665A_START_SEC_VAR_CLEARED_32
#include "Phy_665a_MemMap.h"
/**
 * A global variable to store the Previous sequence that was being transmitted by SPI driver.
*/
extern volatile Spi_SequenceType Phy_665a_GlblPrevSpiSeq;
#define PHY_665A_STOP_SEC_VAR_CLEARED_32
#include "Phy_665a_MemMap.h"
#endif
/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/
#define PHY_665A_START_SEC_CODE
#include "Phy_665a_MemMap.h"

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)

void Phy_665a_SpiStartTimer(uint32 TimerValue);
void Phy_665a_SpiStopTimer(void);

#if (STD_ON == PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED)
void Phy_665a_SpiIfEnableRequestSideband(void);
void Phy_665a_SpiIfDisableRequestSideband(void);
void Phy_665a_SpiIfEnableResponseSideband(void);
void Phy_665a_SpiIfDisableResponseSideband(void);
#endif /*(STD_ON == PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED)*/

/*!
 * @brief Implementation to provide the transmission status of Sequence.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Autosar Spi: This Function contains the implementation to provide the transmission status of a Sequence for which the Transmission has been started.
 *  This function is applicable for Single Spi Single CS variant only.
 *
 * @param[in]   Sequence    Sequence ID whose transmission status has to be checked.
 *
 * @return Spi_SeqResultType
 * @retval SPI_SEQ_OK           The last transmission of the Sequence has been finished successfully.
 * @retval SPI_SEQ_PENDING      The SPI handler/Driver is performing a SPI Sequence.
 * @retval SPI_SEQ_FAILED       The last transmission of the Sequence has failed.
 * @retval SPI_SEQ_CANCELLED    The last transmission of the Sequence has been cancelled by the user.
 *
 */
Spi_SeqResultType Phy_665a_SpiIfCheckSequence
(
    Spi_SequenceType Sequence
);

/*!
 * @brief Implementation to setup the external buffer.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]    RequestMsg         Starting location of request message to be transmitted.
 * @param[in]    RequestMsgLength   Length in 16 bit words of request message to be transmitted.
 *
 * @return Std_ReturnType
 * @retval E_OK             External buffer was set successfully.
 * @retval E_NOT_OK         Setting of external buffer failed.
 *
 */
Std_ReturnType Phy_665a_SpiIfWrite
(
    const uint16* RequestMsg,
    uint8 RequestMsgLength
);

/*!
 * @brief Implementation to wait for the finishing of the specified SPI sequence.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]    Sequence  Sequence whose state has to be checked.
 *
 * @return void
 *
 */
Std_ReturnType Phy_665a_SpiIfWaitSequence
(
    Spi_SequenceType Sequence
);

/*!
 * @brief Implementation to start the transmission of the SPI sequence.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Autosar Spi: This Function contains the implementation to start the Transmission of SPI sequence. This function is used to start
 *  asynchronous transmission for the Spi requests and selecting the sequence that will be correspond to the number of
 *  frames that has to be transmitted. This Api will be used to Transmit request messages(via MTSR) in  case of Dual Spi Master Slave
 *  variant and will not send any message to MRST. In case of Single SPI variant it will be used to send requests via MTSR and receive Responses
 *  via MRST.
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return Std_ReturnType
 * @retval E_OK             Spi async transmission started successfully.
 * @retval E_NOT_OK         Spi async transmission failed.
 *
 */
Std_ReturnType Phy_665a_SpiIfStartTransmit
(
    void
);

/*!
 * @brief Implementation to reset the Spi channel counter
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Slave SPI: This Function contains the implementation to reset the gobal counter which holds the last Spi channel used.
 *
  * @param[in]      void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 *
 */
void Phy_665a_SpiIfResetSpi
(
    void
);

#if (PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE)
/*!
 * @brief Implementation to setup the status external buffer of SpiSlave for the Dual SPI Master Slave Variant.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]    ResponseMsg        Starting location of response message to be received.
 * @param[in]    ResponseMsgLength  Length in 16 bit words of response message expected to be received.
 *
 * @return Std_ReturnType
 * @retval E_OK             External buffer was set successfully.
 * @retval E_NOT_OK         Setting of external buffer failed.
 *
 */
Std_ReturnType  Phy_665a_SpiIfRead
(
    uint16 *ResponseMsg,
    uint16 ResponseMsgLength
);

/*!
 * @brief Implementation to check the status of SPI Slave for the Dual SPI Master Slave Variant.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 *
 */
Std_ReturnType Phy_665a_SpiIfReadWait
(
    void
);

/*!
 * @brief Implementation to count the number of hextets that are received for a transaction descriptor.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Slave SPI: This Function contains the implementation to count the number of Hextets that are received for a transaction descriptor.
 *  This function calculates the number of uint16 words that are remaining for the DMA to be moved, then the difference of Number of Hextets that
 *  was loaded for DMA to be transmitted and DMA Remaning count is provided.
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return uint16
 * @retval E_OK     Number of uint16 words received so far by the SPI Slave.
 *
 */
uint16 Phy_665a_SpiIfReadRecCnt
(
    void
);

/*!
 * @brief Implementation to provide the transfer status.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Slave SPI: This Function contains the implementation to provide the transfer status of Spi Slave Driver.
 *  This function is applicable for Dual Spi Master Slave Variant only.
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return boolean
 * @retval TRUE     Transfer status is in progress.
 * @retval FALSE    Transfer status is finished.
 *
 */
boolean Phy_665a_SpiIfGetTransferStatus
(
    void
);

/*!
 * @brief Implementation to forcefully stop the transfer of SPI Slave driver.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Autosar Spi: This Function contains the implementation to stop the Transfer of Spi Slave driver.
 *  This function is applicable for Dual Spi Master Slave Variant only. It Changes the transfer status
 *  of Spi Slave driver to false based on the user call. The function is invoked by
 *  Phy_665a_IOSendMessageTpl3Variable Api to stop the Spi Slave Driver Transfer in case the
 *  number of received hextets is less than expected number of hextets for a TD. It is used
 *  in the scenario of reporting a TD timeout.
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 *
 */
void Phy_665a_SpiIfForceComplete
(
    void
);

/*!
 * @brief Implementation to forcefully stop the transfer of SPI Slave driver.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Slave Spi: This Function resets the value of number of hextets to be copied by Slave driver
 *  during read for Dual spi Master Slave variant, when there are no hextets to copy.
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 *
 */
void Phy_665a_SpiIfRevertWrite
(
    void
);
#endif /*(PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE)*/

#if (PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)
/*!
 * @brief Implementation to setup the external buffer for full duplex read during PHY Initialization
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Autosar Spi: This Function contains the implementation for User Code function to setup the external buffer of SPI driver
 *  to Transmit messages a "No message"(Message with Prefix but no header and data) and read responses from
 *  PHY_665a driver during the PHY Initialization in full duplex mode and start the Async Transmission.
 *  The function is called to receive Response messages and updates the external buffer with Source pointer location as NOP message location,
 *  Destination pointer with location where response has to be stored and Length as length of Response message for each SPI channel. This function is applicable
 *  for Single Spi Variant only.
 *
 * @param[out]   pResponseMsg       Starting location of response message to be received.
 * @param[in]    NumberOfResponses  Number of response message expected to be received.
 * @param[in]    ResponseMsgLength  Length in 16 bit words of each expected response.
 *
 * @return Std_ReturnType
 * @retval E_OK             External buffer was set successfully.
 * @retval E_NOT_OK         Setting of external buffer failed.
 *
 */
Std_ReturnType Phy_665a_SpiIfSynchronousReadSSpi
(
    uint16* pResponseMsg,
    uint8 NumberOfResponses,
    uint8 ResponseMsgLength
);

/*!
 * @brief Implementation to setup the external buffer for full duplex read and write during Phy_IO_SendMessage.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Autosar Spi: This Function contains the implementation for User Code function to setup the external buffer of SPI driver
 *  to Transmit messages a Request Messages and read responses from
 *  PHY_665a driver during the Phy_665a_IO_SendMessage in full duplex mode simultaneously and start the Async Transmission.
 *  The function is called to receive Response messages and updates the external buffer with Source pointer location as location of Request Message,
 *  Destination pointer with location where response has to be stored and Length as length of Response/Request message for each SPI channel. This function is applicable
 *  for Single Spi Variant only. Length of Request and Responses should be equal.
 *
 * @param[in]    RequestMsg     Starting location of request message to be transmitted.
 * @param[in]    ResponseMsg    Starting location of response message to be received.
 * @param[in]    MsgLength      Length in 16 bit words of request/response messages.
 *
 * @return Std_ReturnType
 * @retval E_OK             External buffer was set successfully.
 * @retval E_NOT_OK         Setting of external buffer failed.
 *
 */
Std_ReturnType Phy_665a_SpiIfReadWriteFullDuplexAsynch
(
    const uint16* RequestMsg,
    uint16* ResponseMsg,
    uint8 MsgLength
);

/*!
 * @brief Implementation to setup the external buffer full duplex read and write during Phy_IO_SendMessage.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *  Wrapper function for Autosar Spi: This Function contains the implementation for User Code function to setup the external buffer of SPI driver
 *  to Transmit messages a "No message" (Message with Prefix but no header and data) and read responses from
 *  PHY_665a driver during the Transaction descriptor communication after initialization in full duplex mode and start the Async Transmission.
 *  The function is called to receive Response messages and updates the external buffer with Source pointer location as NOP message location,
 *  Destination pointer with location where response has to be stored and Length as length of Response message for each SPI channel. This functions is applicable
 *  for Single Spi Variant only. This function is invoked from High response Interrupt.
 *
 * @param[out]   pResponseMsg       Starting location of response message to be received.
 * @param[in]    NumberOfResponses  Number of response message expected to be received.
 * @param[in]    ResponseMsgLength  Length in 16 bit words of each response message expected to be received.
 *
 * @return Std_ReturnType
 * @retval E_OK             External buffer was set successfully.
 * @retval E_NOT_OK         Setting of external buffer failed.
 *
 */
Std_ReturnType Phy_665a_SpiIfAsynchronousReadSSpi
(
    uint16* pResponseMsg,
    uint8 NumberOfResponses,
    uint8 ResponseMsgLength
);

#endif /*(PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)*/

#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/

#define PHY_665A_STOP_SEC_CODE
#include "Phy_665a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_SPIIF_H */
