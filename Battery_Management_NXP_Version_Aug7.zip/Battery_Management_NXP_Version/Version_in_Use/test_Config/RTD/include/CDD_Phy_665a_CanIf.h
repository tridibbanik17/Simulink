/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_CANIF_H
#define CDD_PHY_665A_CANIF_H

/**
*   @file CDD_Phy_665a_CanIf.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#if (PHY_665A_CAN_SUPPORT_ENABLED == STD_ON)
#include "CanIf.h"
#endif
#include "CDD_Phy_665a_Types.h"

/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_CANIF_VENDOR_ID                    43
#define PHY_665A_CANIF_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_CANIF_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_CANIF_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_CANIF_SW_MAJOR_VERSION             1
#define PHY_665A_CANIF_SW_MINOR_VERSION             0
#define PHY_665A_CANIF_SW_PATCH_VERSION             2

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_CANIF_VENDOR_ID != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_CanIf.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_CANIF_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_CANIF_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_CANIF_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_CanIf.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_CANIF_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_CANIF_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_CANIF_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_CanIf.h and CDD_Phy_665a_Types.h are different"
#endif

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/
#define PHY_665A_START_SEC_CODE
#include "Phy_665a_MemMap.h"

#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
/*!
 * @brief Function used in CanIf driver interfacing for PDU transmission
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]   RequestMsg
 * @param[in]   DeviceIdx
 * @param[in]   Phy_665a_TplCanMsgInfo
 */
Std_ReturnType Phy_665a_CanSendRequest
(
    const uint16* RequestMsg,
    uint8 DeviceIdx,
    Phy_665a_TplCanMsgInfoType Phy_665a_TplCanMsgInfo
);
#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)*/

#define PHY_665A_STOP_SEC_CODE
#include "Phy_665a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_CANIF_H */
