/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHYIF_H
#define CDD_PHYIF_H

/**
*   @file CDD_PhyIf.h
*
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_PhyIf_Cfg.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHYIF_VENDOR_ID                        43
#define PHYIF_AR_RELEASE_MAJOR_VERSION         4
#define PHYIF_AR_RELEASE_MINOR_VERSION         7
#define PHYIF_AR_RELEASE_REVISION_VERSION      0
#define PHYIF_SW_MAJOR_VERSION                 1
#define PHYIF_SW_MINOR_VERSION                 0
#define PHYIF_SW_PATCH_VERSION                 2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if this header file and CDD_PhyIf_Types.h are of the same vendor */
#if (PHYIF_VENDOR_ID != PHYIF_CFG_VENDOR_ID)
#error "CDD_PhyIf.h and CDD_PhyIf_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_PhyIf_Types.h are of the same Autosar version */
#if ((PHYIF_AR_RELEASE_MAJOR_VERSION != PHYIF_CFG_AR_RELEASE_MAJOR_VERSION) || \
    (PHYIF_AR_RELEASE_MINOR_VERSION != PHYIF_CFG_AR_RELEASE_MINOR_VERSION) || \
    (PHYIF_AR_RELEASE_REVISION_VERSION != PHYIF_CFG_AR_RELEASE_REVISION_VERSION) \
    )
#error "AutoSar Version Numbers of CDD_PhyIf.h and CDD_PhyIf_Types.h are different"
#endif

/* Check if this header file and CDD_PhyIf_Types.h are of the same Software version */
#if ((PHYIF_SW_MAJOR_VERSION != PHYIF_CFG_SW_MAJOR_VERSION) || \
    (PHYIF_SW_MINOR_VERSION != PHYIF_CFG_SW_MINOR_VERSION) || \
    (PHYIF_SW_PATCH_VERSION != PHYIF_CFG_SW_PATCH_VERSION)  \
    )
     
#error "Software Version Numbers of CDD_PhyIf.h and CDD_PhyIf_Types.h are different"
#endif


/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

Std_ReturnType Phy_IO_SendMessage(Phy_TDType* TransactionDescriptor, Phy_ErrorStatusType* ErrorStatus);
uint8 Phy_SchedMessage(Phy_DeviceIdxType DeviceIdx, Phy_TplProtocolType TplType, Phy_EventType Event, uint16 Operand, uint16* RequestPtr);
uint8 Phy_Sched_EventMessage(Phy_DeviceIdxType DeviceIdx,Phy_TplProtocolType TplType, uint16* RequestPtr);
uint8 Phy_SyncHoldMessage (Phy_DeviceIdxType DeviceIdx, Phy_TplProtocolType TplType, uint32 TimeOprnd, uint16* RequestPtr);
uint8 Phy_SyncGpioMessage(Phy_DeviceIdxType DeviceIdx, Phy_TplProtocolType TplType,uint8 GpioLevel,uint16* RequestPtr);
Std_ReturnType Phy_CancelTd(Phy_TDType* TransactionDescriptor);
void Phy_CancelAllTds(void);
/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOCFG
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHYIF_H */
