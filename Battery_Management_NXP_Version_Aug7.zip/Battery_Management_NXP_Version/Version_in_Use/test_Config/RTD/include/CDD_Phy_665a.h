/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_H
#define CDD_PHY_665A_H

/**
*   @file CDD_Phy_665a.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Phy_665a_Cfg.h"
#include "CDD_Phy_665a_Types.h"
#include "CDD_Phy_665a_Common.h"
#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
#include "CDD_Phy_665a_IntSpi.h"
#endif
#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
#include "CDD_Phy_665a_IntCan.h"
#endif
#include "SchM_Phy_665a.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_MODULE_ID                    255
#define PHY_665A_VENDOR_ID                    43
#define PHY_665A_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_SW_MAJOR_VERSION             1
#define PHY_665A_SW_MINOR_VERSION             0
#define PHY_665A_SW_PATCH_VERSION             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if this header file and SchM_Phy_665a.h are of the same Autosar version */
    #if ((PHY_665A_AR_RELEASE_MAJOR_VERSION != SCHM_PHY_665A_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_AR_RELEASE_MINOR_VERSION != SCHM_PHY_665A_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a.h and SchM_Phy_665a.h are different"
    #endif
#endif /*DISABLE_MCAL_INTERMODULE_ASR_CHECK*/

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same vendor */
#if (PHY_665A_VENDOR_ID != PHY_665A_VENDOR_ID_CFG)
#error "CDD_Phy_665a.h and CDD_Phy_665a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_CFG) || \
     (PHY_665A_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_CFG) || \
     (PHY_665A_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_VENDOR_ID != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Common.h are of the same vendor */
#if (PHY_665A_VENDOR_ID != PHY_665A_COMMON_VENDOR_ID)
#error "CDD_Phy_665a.h and CDD_Phy_665a_Common.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Common.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION != PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION != PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION != PHY_665A_COMMON_AR_RELEASE_REVISION_VERSION))
#error "AutoSar Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_Common.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Common.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION != PHY_665A_COMMON_SW_MAJOR_VERSION) || \
     (PHY_665A_SW_MINOR_VERSION != PHY_665A_COMMON_SW_MINOR_VERSION) || \
     (PHY_665A_SW_PATCH_VERSION != PHY_665A_COMMON_SW_PATCH_VERSION))
#error "Software Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_Common.h are different"
#endif

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
/* Check if this header file and CDD_Phy_665a_IntSpi.h are of the same vendor */
#if (PHY_665A_VENDOR_ID != PHY_665A_INTSPI_VENDOR_ID)
#error "CDD_Phy_665a.h and CDD_Phy_665a_IntSpi.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_IntSpi.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION != PHY_665A_INTSPI_AR_RELEASE_MAJOR_VERSION) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION != PHY_665A_INTSPI_AR_RELEASE_MINOR_VERSION) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION != PHY_665A_INTSPI_AR_RELEASE_REVISION_VERSION))
#error "AutoSar Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_IntSpi.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_IntSpi.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION != PHY_665A_INTSPI_SW_MAJOR_VERSION) || \
     (PHY_665A_SW_MINOR_VERSION != PHY_665A_INTSPI_SW_MINOR_VERSION) || \
     (PHY_665A_SW_PATCH_VERSION != PHY_665A_INTSPI_SW_PATCH_VERSION))
#error "Software Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_IntSpi.h are different"
#endif
#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/

#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
/* Check if this header file and CDD_Phy_665a_IntCan.h are of the same vendor */
#if (PHY_665A_VENDOR_ID != PHY_665A_INTCAN_VENDOR_ID)
#error "CDD_Phy_665a.h and CDD_Phy_665a_IntCan.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_IntCan.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION != PHY_665A_INTCAN_AR_RELEASE_MAJOR_VERSION) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION != PHY_665A_INTCAN_AR_RELEASE_MINOR_VERSION) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION != PHY_665A_INTCAN_AR_RELEASE_REVISION_VERSION))
#error "AutoSar Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_IntCan.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_IntCan.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION != PHY_665A_INTCAN_SW_MAJOR_VERSION) || \
     (PHY_665A_SW_MINOR_VERSION != PHY_665A_INTCAN_SW_MINOR_VERSION) || \
     (PHY_665A_SW_PATCH_VERSION != PHY_665A_INTCAN_SW_PATCH_VERSION))
#error "Software Version Numbers of CDD_Phy_665a.h and CDD_Phy_665a_IntCan.h are different"
#endif
#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)*/

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/*
 * Macro used for defining  DET function used for locking errors.
*/
#if (PHY_665A_DEV_ERROR_DETECT == STD_ON)
/*
 * Macro used for defining  argument in DET function used for locking errors.
*/
#if (defined PHY_665A_INSTANCE_ID)
#error PHY_665A_INSTANCE_ID is already defined
#endif
#define PHY_665A_INSTANCE_ID 0U
/*Error Id*/
/*
 * Macro used for defining invalid command code error.
*/
#if (defined PHY_665A_E_INVALID_CMD_CODE)
#error PHY_665A_E_INVALID_CMD_CODE is already defined
#endif
#define PHY_665A_E_INVALID_CMD_CODE 0x01U
/*
 * Macro used for defining invalid pointer error.
*/
#if (defined PHY_665A_E_INVALID_POINTER)
#error PHY_665A_E_INVALID_POINTER is already defined
#endif
#define PHY_665A_E_INVALID_POINTER 0x02U
/*
 * Macro used for defining invalid request length .
*/
#if (defined PHY_665A_E_INVALID_REQ_LEN)
#error PHY_665A_E_INVALID_REQ_LEN is already defined
#endif
#define PHY_665A_E_INVALID_REQ_LEN 0x03U
/*
 * Macro used for defining invalid NRT error.
*/
#if (defined PHY_665A_E_INVALID_NRT)
#error PHY_665A_E_INVALID_NRT is already defined
#endif
#define PHY_665A_E_INVALID_NRT 0x04U
/*
 * Macro used for defining SPI EB setup buffer error.
*/
#if (defined PHY_665A_E_SPI_SETUP_EB)
#error PHY_665A_E_SPI_SETUP_EB is already defined
#endif
#define PHY_665A_E_SPI_SETUP_EB 0x05U
/*
 * Macro used for defining SPI transmit error .
*/
#if (defined PHY_665A_E_SPI_TRANSMIT)
#error PHY_665A_E_SPI_TRANSMIT is already defined
#endif
#define PHY_665A_E_SPI_TRANSMIT 0x06U
/*
 * Macro used for defining pack message error .
*/
#if (defined PHY_665A_E_PCK_MSG)
#error PHY_665A_E_PCK_MSG is already defined
#endif
#define PHY_665A_E_PCK_MSG 0x07U
/*
 * Macro used for defining invalid communication crc error.
*/
#if (defined PHY_665A_E_INVALID_COM_CRC)
#error PHY_665A_E_INVALID_COM_CRC is already defined
#endif
#define PHY_665A_E_INVALID_COM_CRC 0x08U
/*
 * Macro used for defining invalid response length array size error .
*/
#if (defined PHY_665A_E_INVALID_RSP_LEN_ARR_SIZE)
#error PHY_665A_E_INVALID_RSP_LEN_ARR_SIZE is already defined
#endif
#define PHY_665A_E_INVALID_RSP_LEN_ARR_SIZE 0x09U
/*
 * Macro used for defining invalid unpack message error.
*/
#if (defined PHY_665A_E_INVALID_UNPCK_MSG)
#error PHY_665A_E_INVALID_UNPCK_MSG is already defined
#endif
#define PHY_665A_E_INVALID_UNPCK_MSG 0x0AU
/*
 * Macro used for defining invalid read response length error .
*/
#if (defined PHY_665A_E_INVALID_INT_READ_RSP_LEN)
#error PHY_665A_E_INVALID_INT_READ_RSP_LEN is already defined
#endif
#define PHY_665A_E_INVALID_INT_READ_RSP_LEN 0x0BU
/*
 * Macro used for defining invalid System Configuration CRC..
*/
#if (defined PHY_665A_E_INVALID_SYS_CRC)
#error PHY_665A_E_INVALID_SYS_CRC is already defined
#endif
#define PHY_665A_E_INVALID_SYS_CRC 0x0CU
/*
 * Macro used for defining I2C configuration init error .
*/
#if (defined PHY_665A_E_I2C_CFG_INIT)
#error PHY_665A_E_I2C_CFG_INIT is already defined
#endif
#define PHY_665A_E_I2C_CFG_INIT 0x0DU
/*
 * Macro used for defining GPIO configuration init error.
*/
#if (defined PHY_665A_E_GPIO_CFG_INIT)
#error PHY_665A_E_GPIO_CFG_INIT is already defined
#endif
#define PHY_665A_E_GPIO_CFG_INIT 0x0EU
/*
 * Macro used for defining  invalid event handler Crc.
*/
#if (defined PHY_665A_E_INVALID_EVH_CRC)
#error PHY_665A_E_INVALID_EVH_CRC is already defined
#endif
#define PHY_665A_E_INVALID_EVH_CRC 0x0FU
/*
 * Macro used for defining invalid read event handler Crc error .
*/
#if (defined PHY_665A_E_READ_EVH_CRC)
#error PHY_665A_E_READ_EVH_CRC is already defined
#endif
#define PHY_665A_E_READ_EVH_CRC 0x10U
/*
 * Macro used for defining invalid event handler wakeup configuration.
*/
#if (defined PHY_665A_E_EVH_WAKEUP_CFG)
#error PHY_665A_E_EVH_WAKEUP_CFG is already defined
#endif
#define PHY_665A_E_EVH_WAKEUP_CFG 0x11U
/*
 * Macro used for defining invalid number of interrupt events.
*/
#if (defined PHY_665A_E_INVALID_NUM_OF_EVENTS)
#error PHY_665A_E_INVALID_NUM_OF_EVENTS is already defined
#endif
#define PHY_665A_E_INVALID_NUM_OF_EVENTS 0x12U
/*
 * Macro used for defining invalid event handler interrupt configuration  .
*/
#if (defined PHY_665A_E_EVH_INT_CFG)
#error PHY_665A_E_EVH_INT_CFG is already defined
#endif
#define PHY_665A_E_EVH_INT_CFG 0x13U
/*
 * Macro used for defining invalid selection of source for  event handler interrupt.
*/
#if (defined PHY_665A_E_EVH_INT_SEL)
#error PHY_665A_E_EVH_INT_SEL is already defined
#endif
#define PHY_665A_E_EVH_INT_SEL 0x14U
/*
 * Macro used for defining check system crc error.
*/
#if (defined PHY_665A_E_CHCK_SYS_CRC)
#error PHY_665A_E_CHCK_SYS_CRC is already defined
#endif
#define PHY_665A_E_CHCK_SYS_CRC 0x15U
/*
 * Macro used for defining read system crc error.
*/
#if (defined PHY_665A_E_READ_SYS_CRC)
#error PHY_665A_E_READ_SYS_CRC is already defined
#endif
#define PHY_665A_E_READ_SYS_CRC 0x16U
/*
 * Macro used for defining queue init error.
*/
#if (defined PHY_665A_E_QUEUE_INIT)
#error PHY_665A_E_QUEUE_INIT is already defined
#endif
#define PHY_665A_E_QUEUE_INIT 0x17U
/*
 * Macro used for defining filter init error.
*/
#if (defined PHY_665A_E_FILTER_INIT)
#error PHY_665A_E_FILTER_INIT is already defined
#endif
#define PHY_665A_E_FILTER_INIT 0x18U
/*
 * Macro used for defining tpl port init error.
*/
#if (defined PHY_665A_E_TPL_PORT_INIT)
#error PHY_665A_E_TPL_PORT_INIT is already defined
#endif
#define PHY_665A_E_TPL_PORT_INIT 0x19U
/*
 * Macro used for defining error due to wrong read of uid.
*/
#if (defined PHY_665A_E_READ_UID)
#error PHY_665A_E_READ_UID is already defined
#endif
#define PHY_665A_E_READ_UID 0x1AU
/*
 * Macro used for defining Spi init error .
*/
#if (defined PHY_665A_E_SPI_INIT)
#error PHY_665A_E_SPI_INIT is already defined
#endif
#define PHY_665A_E_SPI_INIT 0x1BU
/*
 * Macro used for defining system init error.
*/
#if (defined PHY_665A_E_SYS_INIT)
#error PHY_665A_E_SYS_INIT is already defined
#endif
#define PHY_665A_E_SYS_INIT 0x1CU
/*
 * Macro used for defining host com init error.
*/
#if (defined PHY_665A_E_HOST_COM_INIT)
#error PHY_665A_E_HOST_COM_INIT is already defined
#endif
#define PHY_665A_E_HOST_COM_INIT 0x1DU
/*
 * Macro used for defining Phy init error .
*/
#if (defined PHY_665A_E_INIT)
#error PHY_665A_E_INIT is already defined
#endif
#define PHY_665A_E_INIT 0x1EU
/*
 * Macro used for defining  error due to response boundary overflow.
*/
#if (defined PHY_665A_E_RSP_BOUNDARY_OVFLW)
#error PHY_665A_E_RSP_BOUNDARY_OVFLW is already defined
#endif
#define PHY_665A_E_RSP_BOUNDARY_OVFLW 0x1FU
/*
 * Macro used for defining error due to invalid transaction descriptor request message count  .
*/
#if (defined PHY_665A_E_INVALID_TD_REQ_MSG_CNT)
#error defined PHY_665A_E_INVALID_TD_REQ_MSG_CNT is already defined
#endif
#define PHY_665A_E_INVALID_TD_REQ_MSG_CNT 0x20U
/*
 * Macro used for defining error in  phy initialization .
*/
#if (defined PHY_665A_E_UNINIT)
#error defined PHY_665A_E_UNINIT is already defined
#endif
#define PHY_665A_E_UNINIT 0x21U
/*
 * Macro used for defining invalid schedule event.
*/
#if (defined PHY_665A_E_INVALID_SCHED_EVENT)
#error defined PHY_665A_E_INVALID_SCHED_EVENT is already defined
#endif
#define PHY_665A_E_INVALID_SCHED_EVENT 0x22U
/*
 * Macro used for defining invalid schedule timer operand.
*/
#if (defined PHY_665A_E_INVALID_SCHED_TIMER_OPERAND)
#error defined PHY_665A_E_INVALID_SCHED_TIMER_OPERAND is already defined
#endif
#define PHY_665A_E_INVALID_SCHED_TIMER_OPERAND 0x23U
/*
 * Macro used for defining  error due to invalid schedule sync operand  .
*/
#if (defined PHY_665A_E_INVALID_SCHED_SYNC_OPERAND)
#error defined PHY_665A_E_INVALID_SCHED_SYNC_OPERAND is already defined
#endif
#define PHY_665A_E_INVALID_SCHED_SYNC_OPERAND 0x24U
/*
 * Macro used for defining error due to invalid schedule response queue free operand .
*/
#if (defined PHY_665A_E_INVALID_SCHED_RSP_QUEUE_FREE_OPERAND)
#error defined PHY_665A_E_INVALID_SCHED_RSP_QUEUE_FREE_OPERAND is already defined
#endif
#define PHY_665A_E_INVALID_SCHED_RSP_QUEUE_FREE_OPERAND 0x25U
/*
 * Macro used for defining error due to invalid channel id.
*/
#if (defined PHY_665A_E_INVALID_CHANNEL_ID)
#error defined PHY_665A_E_INVALID_CHANNEL_ID is already defined
#endif
#define PHY_665A_E_INVALID_CHANNEL_ID 0x26U
/*
 * Macro used for defining error due to invalid interrupt  value.
*/
#if (defined PHY_665A_E_INVALID_INTERRUPT_VALUE)
#error defined PHY_665A_E_INVALID_INTERRUPT_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_INTERRUPT_VALUE 0x27U
/*
 * Macro used for defining error due to invalid start byte.
*/
#if (defined PHY_665A_E_INVALID_START_BYTE)
#error defined PHY_665A_E_INVALID_START_BYTE is already defined
#endif
#define PHY_665A_E_INVALID_START_BYTE 0x28U
/*
 * Macro used for defining error due to invalid read byte.
*/
#if (defined PHY_665A_E_INVALID_READ_BYTE)
#error defined PHY_665A_E_INVALID_READ_BYTE is already defined
#endif
#define PHY_665A_E_INVALID_READ_BYTE 0x29U
/*
 * Macro used for defining error due to invalid stop byte.
*/
#if (defined PHY_665A_E_INVALID_STOP_BYTE)
#error defined PHY_665A_E_INVALID_STOP_BYTE is already defined
#endif
#define PHY_665A_E_INVALID_STOP_BYTE 0x2AU
/*
 * Macro used for defining error during spi read operation.
*/
#if (defined PHY_665A_E_SPI_READ_ERROR)
#error defined PHY_665A_E_SPI_READ_ERROR is already defined
#endif
#define PHY_665A_E_SPI_READ_ERROR 0x2BU
/*
 * Macro used for defining invalid request buffer length.
*/
#if (defined PHY_665A_E_INVALID_REQ_BUFFER_LEN)
#error defined PHY_665A_E_INVALID_REQ_BUFFER_LEN is already defined
#endif
#define PHY_665A_E_INVALID_REQ_BUFFER_LEN 0x2CU
/*
 * Macro used for defining invalid chain address.
*/
#if (defined PHY_665A_E_INVALID_CHAIN_ADD)
#error defined PHY_665A_E_INVALID_CHAIN_ADD is already defined
#endif
#define PHY_665A_E_INVALID_CHAIN_ADD 0x2DU
/*
 * Macro used for defining  invalid data size.
*/
#if (defined PHY_665A_E_INVALID_DATA_SIZE)
#error defined PHY_665A_E_INVALID_DATA_SIZE is already defined
#endif
#define PHY_665A_E_INVALID_DATA_SIZE 0x2FU
/*
 * Macro used for defining invalid message length.
*/
#if (defined PHY_665A_E_INVALID_MSG_LEN)
#error defined PHY_665A_E_INVALID_MSG_LEN is already defined
#endif
#define PHY_665A_E_INVALID_MSG_LEN 0x30U
/*
 * Macro used for defining error due to wrong spi reception .
*/
#if (defined PHY_665A_E_SPI_PREFIX_RSP_ERROR)
#error defined PHY_665A_E_SPI_PREFIX_RSP_ERROR is already defined
#endif
#define PHY_665A_E_SPI_PREFIX_RSP_ERROR 0x31U
/*
 * Macro used for defining error due to invalid parity.
*/
#if (defined PHY_665A_E_INVALID_PARITY)
#error defined PHY_665A_E_INVALID_PARITY is already defined
#endif
#define PHY_665A_E_INVALID_PARITY 0x32U
/*
 * Macro used for defining error due to invalid prefix type.
*/
#if (defined PHY_665A_E_INVALID_PREFIX_TYPE)
#error defined PHY_665A_E_INVALID_PREFIX_TYPE is already defined
#endif
#define PHY_665A_E_INVALID_PREFIX_TYPE 0x33U
/*
 * Macro used for defining error due to invalid target mode type.
*/
#if (defined PHY_665A_E_INVALID_TARGET_MODE_TYPE)
#error defined PHY_665A_E_INVALID_TARGET_MODE_TYPE is already defined
#endif
#define PHY_665A_E_INVALID_TARGET_MODE_TYPE 0x34U
/*
 * Macro used for defining error due to invalid EN value.
*/
#if (defined PHY_665A_E_INVALID_EN_VALUE)
#error defined PHY_665A_E_INVALID_EN_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_EN_VALUE 0x35U
/*
 * Macro used for defining error due to invalid RX value.
*/
#if (defined PHY_665A_E_INVALID_RX_VALUE)
#error defined PHY_665A_E_INVALID_RX_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_RX_VALUE 0x36U
/*
 * Macro used for defining error due to invalid All chains value.
*/
#if (defined PHY_665A_E_INVALID_ALLCHAINS_VALUE)
#error defined PHY_665A_E_INVALID_ALLCHAINS_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_ALLCHAINS_VALUE 0x37U
/*
 * Macro used for defining error due to invalid chain address value.
*/
#if (defined PHY_665A_E_INVALID_CADD_VALUE)
#error defined PHY_665A_E_INVALID_CADD_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_CADD_VALUE 0x38U
/*
 * Macro used for defining error due to invalid master address value.
*/
#if (defined PHY_665A_E_INVALID_MADD_VALUE)
#error defined PHY_665A_E_INVALID_MADD_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_MADD_VALUE 0x39U
/*
 * Macro used for defining error due to invalid number of responses.
*/
#if (defined PHY_665A_E_INVALID_NUM_RESP)
#error defined PHY_665A_E_INVALID_NUM_RESP is already defined
#endif
#define PHY_665A_E_INVALID_NUM_RESP 0x3AU
/*
 * Macro used for defining error due to starting the transmission of TD which is in non idle state.
*/
#if (defined PHY_665A_E_TD_NOT_IDLE)
#error defined PHY_665A_E_TD_NOT_IDLE is already defined
#endif
#define PHY_665A_E_TD_NOT_IDLE 0x3BU
/*
 * Macro used for defining error due to the count of Request Messages that has been transmitted is non zero.
*/
#if (defined PHY_665A_E_INVALID_REQ_MSG_CNT)
#error defined PHY_665A_E_INVALID_REQ_MSG_CNT is already defined
#endif
#define PHY_665A_E_INVALID_REQ_MSG_CNT 0x3CU
/*
 * Macro used for defining Wrong Chain Address Error .
*/
#if (defined PHY_665A_E_WRONG_CADD)
#error PHY_665A_E_WRONG_CADD is already defined
#endif
#define PHY_665A_E_WRONG_CADD 0x3DU
/*
 * Macro used for defining Wrong Register Address Error .
*/
#if (defined PHY_665A_E_WRONG_RADD)
#error PHY_665A_E_WRONG_RADD is already defined
#endif
#define PHY_665A_E_WRONG_RADD 0x3EU

/*
 * Macro used for defining Prefixing Failure Error .
*/
#if (defined PHY_665A_E_PREFIX_FAILED)
#error PHY_665A_E_PREFIX_FAILED is already defined
#endif
#define PHY_665A_E_PREFIX_FAILED 0x3FU
/*
 * Macro used for defining  error due to request boundary overflow.
*/
#if (defined PHY_665A_E_REQ_BOUNDARY_OVFLW)
#error PHY_665A_E_REQ_BOUNDARY_OVFLW is already defined
#endif
#define PHY_665A_E_REQ_BOUNDARY_OVFLW 0x40U
/*
 * Macro used for defining  error due to invalid number of Responses expected.
*/
#if (defined PHY_665A_E_INVALID_NUM_RESP_EXPECTED)
#error PHY_665A_E_INVALID_NUM_RESP_EXPECTED is already defined
#endif
#define PHY_665A_E_INVALID_NUM_RESP_EXPECTED 0x41U
/*
 * Macro used for defining  error due to more responses to be received than the number of Responses expected.
*/
#if (defined PHY_665A_E_NUM_RESP_OVFLW)
#error PHY_665A_E_NUM_RESP_OVFLW is already defined
#endif
#define PHY_665A_E_NUM_RESP_OVFLW 0x42U
/*
 * Macro used for defining  error due to the TD is in IDLE state.
*/
#if (defined PHY_665A_E_TD_NOT_STARTED)
#error PHY_665A_E_TD_NOT_STARTED is already defined
#endif
#define PHY_665A_E_TD_NOT_STARTED 0x43U
/*
 * Macro used for defining error due to invalid pointer location.
*/
#if (defined PHY_665A_E_INVALID_POINTER_LOCATION)
#error defined PHY_665A_E_INVALID_POINTER_LOCATION is already defined
#endif
#define PHY_665A_E_INVALID_POINTER_LOCATION 0x44U
/*
 * Macro used for defining error due to Error status not equal to PHY_NO_ERROR.
*/
#if (defined PHY_665A_E_NOT_PHY_NO_ERROR)
#error defined PHY_665A_E_NOT_PHY_NO_ERROR is already defined
#endif
#define PHY_665A_E_NOT_PHY_NO_ERROR 0x45U
/*
 * Macro used for defining error due to invalid event type for event handler interrupt.
*/
#if (defined PHY_665A_E_INVALID_EVENT_TYPE)
#error defined PHY_665A_E_INVALID_EVENT_TYPE is already defined
#endif
#define PHY_665A_E_INVALID_EVENT_TYPE 0x46U
/*
 * Macro used for defining error due to invalid event type for event handler interrupt.
*/
#if (defined PHY_665A_E_NOT_INTERNAL_TD)
#error defined PHY_665A_E_NOT_INTERNAL_TD is already defined
#endif
#define PHY_665A_E_NOT_INTERNAL_TD 0x47U
/*
 * Macro used for defining error due to failure to wakeup the 665 device.
*/
#if (defined PHY_665A_E_WAKEUP_FAIL)
#error defined PHY_665A_E_WAKEUP_FAIL is already defined
#endif
#define PHY_665A_E_WAKEUP_FAIL 0x48U
/*
 * Macro used for defining error due to wrong I2C Data Register Count Input from Application to 665 device.
*/
#if (defined PHY_665A_E_INVALID_I2C_REGCNT)
#error defined PHY_665A_E_INVALID_I2C_REGCNT is already defined
#endif
#define PHY_665A_E_INVALID_I2C_REGCNT 0x49U

/*
 * Macro used for defining error due to invalid Transaction Descriptor Scope.
*/
#if (defined PHY_665A_E_INVALID_TD_SCOPE)
#error defined PHY_665A_E_INVALID_TD_SCOPE is already defined
#endif
#define PHY_665A_E_INVALID_TD_SCOPE 0x50U

/*
 * Macro used for defining error due to invalid Device Idx.
*/
#if (defined PHY_665A_E_INVALID_DEVICE_IDX)
#error defined PHY_665A_E_INVALID_DEVICE_IDX is already defined
#endif
#define PHY_665A_E_INVALID_DEVICE_IDX 0x51U

/*
 * Macro used for defining error due to CanIF Tx Failed.
*/
#if (defined PHY_665A_E_CANIF_TX_FAILED)
#error defined PHY_665A_E_CANIF_TX_FAILED is already defined
#endif
#define PHY_665A_E_CANIF_TX_FAILED 0x52U

/*
 * Macro used for defining error due to Devices are already WUP.
*/
#if (defined PHY_665A_E_DEVICES_ALREADY_WUP)
#error defined PHY_665A_E_DEVICES_ALREADY_WUP is already defined
#endif
#define PHY_665A_E_DEVICES_ALREADY_WUP 0x53U

/*
 * Macro used for defining error due to Devices are already WUP.
*/
#if (defined PHY_665A_E_INVALID_INIT_STATE)
#error defined PHY_665A_E_INVALID_INIT_STATE is already defined
#endif
#define PHY_665A_E_INVALID_INIT_STATE 0x54U

/*
 * Macro used for defining error due to invalid Can Frame Type.
*/
#if (defined PHY_665A_E_INVALID_CAN_FRAME_TYPE)
#error defined PHY_665A_E_INVALID_CAN_FRAME_TYPE is already defined
#endif
#define PHY_665A_E_INVALID_CAN_FRAME_TYPE 0x55U
/*
 * Macro used for defining error due to odd sdu length
*/
#if (defined PHY_665A_E_ODD_SDU_LENGTH)
#error PHY_665A_E_ODD_SDU_LENGTH is already defined
#endif
#define PHY_665A_E_ODD_SDU_LENGTH 0x056U
/*
 * Macro used for defining error due to invalid Tpl type received from PduId
*/
#if (defined PHY_665A_E_INVALID_PDU_ID_TPL_TYPE)
#error PHY_665A_E_INVALID_PDU_ID_TPL_TYPE is already defined
#endif
#define PHY_665A_E_INVALID_PDU_ID_TPL_TYPE 0x057U
/*
 * Macro used for defining error due to invalid Sdu Length
*/
#if (defined PHY_665A_E_INVALID_SU_LENGTH)
#error PHY_665A_E_INVALID_SU_LENGTH is already defined
#endif
#define PHY_665A_E_INVALID_SU_LENGTH 0x058U

/*
 * Macro used for defining error due to Can response common response buffer overflow
*/
#if (defined PHY_665A_E_CAN_RESP_COMMON_BUFFER_OVFLW)
#error PHY_665A_E_CAN_RESP_COMMON_BUFFER_OVFLW is already defined
#endif
#define PHY_665A_E_CAN_RESP_COMMON_BUFFER_OVFLW 0x59U

/*
 * Macro used for defining error due to invalid TD Encoding
*/
#if (defined PHY_665A_E_TD_NOT_CLEARED)
#error defined PHY_665A_E_TD_NOT_CLEARED is already defined
#endif
#define PHY_665A_E_TD_NOT_CLEARED 0x5AU

/*
 * Macro used for defining error due to invalid DADD in Request Message
*/
#if (defined PHY_665A_E_INVALID_DADD)
#error PHY_665A_E_INVALID_DADD is already defined
#endif
#define PHY_665A_E_INVALID_DADD 0x5BU

/*
 * Macro used for defining error due to sending request has been done before TD processing started
*/
#if (defined PHY_665A_E_REQ_ALREADY_SENT)
#error PHY_665A_E_REQ_ALREADY_SENT is already defined
#endif
#define PHY_665A_E_REQ_ALREADY_SENT 0x5CU

/*
 * Macro used for defining error due to processing request has been done before TD processing started
*/
#if (defined PHY_665A_E_REQ_ALREADY_PROCESSED)
#error PHY_665A_E_REQ_ALREADY_PROCESSED is already defined
#endif
#define PHY_665A_E_REQ_ALREADY_PROCESSED 0x5DU

/*
 * Macro used for defining error due to Invalid request in the TD
*/
#if (defined PHY_665A_E_INVALID_REQ)
#error PHY_665A_E_INVALID_REQ is already defined
#endif
#define PHY_665A_E_INVALID_REQ 0x5EU

/*
 * Macro used for defining error due to Invalid Event for the Schedule command for request in the TD
*/
#if (defined PHY_665A_E_INVALID_EVENT_SCHED_CMD_REQ)
#error PHY_665A_E_INVALID_EVENT_SCHED_CMD_REQ is already defined
#endif
#define PHY_665A_E_INVALID_EVENT_SCHED_CMD_REQ 0x5FU

/*
 * Macro used for defining error due to Invalid operand for the Schedule command for TIMING Event for request in the TD
*/
#if (defined PHY_665A_E_INVALID_TIMING_EVENT_OPERAND_SCHED_CMD_REQ)
#error PHY_665A_E_INVALID_TIMING_EVENT_OPERAND_SCHED_CMD_REQ is already defined
#endif
#define PHY_665A_E_INVALID_TIMING_EVENT_OPERAND_SCHED_CMD_REQ 0x60U

/*
 * Macro used for defining error due to Batch Information
*/
#if (defined PHY_665A_E_INVALID_BATCH_REQ_PROCESSED_CNT)
#error PHY_665A_E_INVALID_BATCH_REQ_PROCESSED_CNT is already defined
#endif
#define PHY_665A_E_INVALID_BATCH_REQ_PROCESSED_CNT 0x61U

/*
 * Macro used for defining error due to Batch Information, invalid Request Size Array Index
*/
#if (defined PHY_665A_E_INVALID_REQ_QUEUE_SIZE_ARR_IDX)
#error PHY_665A_E_INVALID_REQ_QUEUE_SIZE_ARR_IDX is already defined
#endif
#define PHY_665A_E_INVALID_REQ_QUEUE_SIZE_ARR_IDX 0x62U

/*
 * Macro used for defining  error due to invlaid Data Length of request.
*/
#if (defined PHY_665A_E_INVALID_DATA_LEN_WRITE_REQ)
#error defined PHY_665A_E_INVALID_DATA_LEN_WRITE_REQ is already defined
#endif
#define PHY_665A_E_INVALID_DATA_LEN_WRITE_REQ 0x63U

/*
 * Macro used for defining  error due to invlaid Expected Resp Count.
*/
#if (defined PHY_665A_E_INVALID_EXPECTED_RSP_CNT)
#error defined PHY_665A_E_INVALID_EXPECTED_RSP_CNT is already defined
#endif
#define PHY_665A_E_INVALID_EXPECTED_RSP_CNT 0x64U

/*
 * Macro used for defining  error due to invlaid Expected Resp Hextet Count.
*/
#if (defined PHY_665A_E_INVALID_EXPECTED_RSP_HEX_CNT)
#error defined PHY_665A_E_INVALID_EXPECTED_RSP_HEX_CNT is already defined
#endif
#define PHY_665A_E_INVALID_EXPECTED_RSP_HEX_CNT 0x65U

/*
 * Macro used for defining  error due to invlaid Batch Status.
*/
#if (defined PHY_665A_E_INVALID_BATCH_STATUS)
#error defined PHY_665A_E_INVALID_BATCH_STATUS is already defined
#endif
#define PHY_665A_E_INVALID_BATCH_STATUS 0x66U

/*
 * Macro used for defining error due to invlaid Last Read Crc Message Flag Status.
*/
#if (defined PHY_665A_E_INVALID_LAST_MSG_RD_CRC_FLG_STATUS)
#error defined PHY_665A_E_INVALID_LAST_MSG_RD_CRC_FLG_STATUS is already defined
#endif
#define PHY_665A_E_INVALID_LAST_MSG_RD_CRC_FLG_STATUS 0x67U

/*
 * Macro used for defining error due to invlaid Sleep Flag Status.
*/
#if (defined PHY_665A_E_INVALID_SLEEP_FLG_STATUS)
#error defined PHY_665A_E_INVALID_SLEEP_FLG_STATUS is already defined
#endif
#define PHY_665A_E_INVALID_SLEEP_FLG_STATUS 0x68U

/*
 * Macro used for defining error due to invalid Protocol value.
*/
#if (defined PHY_665A_E_INVALID_PROTOCOL_VALUE)
#error defined PHY_665A_E_INVALID_PROTOCOL_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_PROTOCOL_VALUE 0x6BU

/*
 * Macro used for defining error due to invalid Timeout value.
*/
#if (defined PHY_665A_E_INVALID_TIMEOUT_VALUE)
#error defined PHY_665A_E_INVALID_TIMEOUT_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_TIMEOUT_VALUE 0x6CU
/*
 * Macro used for defining error due to invalid Port Count value.
*/
#if (defined PHY_665A_E_INVALID_SYS_PORT_CNT)
#error defined PHY_665A_E_INVALID_SYS_PORT_CNT is already defined
#endif
#define PHY_665A_E_INVALID_SYS_PORT_CNT 0x6DU
/*
 * Macro used for defining error due to invalid Port Prama Count value.
*/
#if (defined PHY_665A_E_INVALID_SYS_NUM_OF_PARAMS)
#error defined PHY_665A_E_INVALID_SYS_NUM_OF_PARAMS is already defined
#endif
#define PHY_665A_E_INVALID_SYS_NUM_OF_PARAMS 0x6EU
/*
 * Macro used for defining error due to invalid PortId value.
*/
#if (defined PHY_665A_E_INVALID_SYS_PORT_ID_VALUE)
#error defined PHY_665A_E_INVALID_SYS_PORT_ID_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_SYS_PORT_ID_VALUE 0x6FU
/*
 * Macro used for defining error due to invalid PortId value.
*/
#if (defined PHY_665A_E_INVALID_SYS_PORT_SEQUENCE)
#error defined PHY_665A_E_INVALID_SYS_PORT_SEQUENCE is already defined
#endif
#define PHY_665A_E_INVALID_SYS_PORT_SEQUENCE 0x70U
/*
 * Macro used for defining Invalid DeviceIdx
*/
#if (defined PHY_665A_E_INVALID_DEVICE_INDEX)
#error defined PHY_665A_E_INVALID_DEVICE_INDEX is already defined
#endif
#define PHY_665A_E_INVALID_DEVICE_INDEX 0x71U

/*
 * Macro used for defining Invalid GPIO Number of Channels
*/
#if (defined PHY_665A_E_INVALID_GPIO_NUM_CHANNELS)
#error defined PHY_665A_E_INVALID_GPIO_NUM_CHANNELS is already defined
#endif
#define PHY_665A_E_INVALID_GPIO_NUM_CHANNELS 0x72U
/*
 * Macro used for defining Invalid GPIO Config Param
*/
#if (defined PHY_665A_E_INVALID_GPIO_CONFIG_PARAM)
#error defined PHY_665A_E_INVALID_GPIO_CONFIG_PARAM is already defined
#endif
#define PHY_665A_E_INVALID_GPIO_CONFIG_PARAM 0x73U
/*
 * Macro used for defining Invalid number of GPIO Config Reg Param
*/
#if (defined PHY_665A_E_INVALID_GPIO_PARAM_NUM)
#error defined PHY_665A_E_INVALID_GPIO_PARAM_NUM is already defined
#endif
#define PHY_665A_E_INVALID_GPIO_PARAM_NUM 0x75U
/*
 * Macro used for defining Invalid GPIO Config Reg Param
*/
#if (defined PHY_665A_E_GPIO_CHANNEL_ALREADY_CONFIGURED)
#error defined PHY_665A_E_GPIO_CHANNEL_ALREADY_CONFIGURED is already defined
#endif
#define PHY_665A_E_GPIO_CHANNEL_ALREADY_CONFIGURED 0x77U
/*
 * Macro used for defining Invalid Sys QueueCtrl Clear Value
*/
#if (defined PHY_665A_E_INVALID_CLEAR_VALUE)
#error defined PHY_665A_E_INVALID_CLEAR_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_CLEAR_VALUE 0x78U

/*
 * Macro used for defining Invalid Sys QueueCtrl Hold Value
*/
#if (defined PHY_665A_E_INVALID_HOLD_VALUE)
#error defined PHY_665A_E_INVALID_HOLD_VALUE is already defined
#endif
#define PHY_665A_E_INVALID_HOLD_VALUE 0x79U

/*
 * Macro used for defining Invalid Device Index Value
*/
#if (defined PHY_665A_E_DEV_IDX_VALUE)
#error defined PHY_665A_E_DEV_IDX_VALUE is already defined
#endif
#define PHY_665A_E_DEV_IDX_VALUE 0x7AU

/*
 * Macro used for defining Invalid Can Speed
*/
#if (defined PHY_665A_E_INVALID_CAN_SPEED)
#error defined PHY_665A_E_INVALID_CAN_SPEED is already defined
#endif
#define PHY_665A_E_INVALID_CAN_SPEED 0x7BU

/*
 * Macro used for defining Invalid TPL Port Configuration
*/
#if (defined PHY_665A_E_INVALID_TPL_PORT_CFG)
#error defined PHY_665A_E_INVALID_TPL_PORT_CFG is already defined
#endif
#define PHY_665A_E_INVALID_TPL_PORT_CFG 0x7CU

/*
 * Macro used for defining Invalid Read request Parameters
*/
#if (defined PHY_665A_E_INVALID_READ_PARAM)
#error defined PHY_665A_E_INVALID_READ_PARAM is already defined
#endif
#define PHY_665A_E_INVALID_READ_PARAM 0x7DU

/*
 * Macro used for defining Queue Overflow
*/
#if (defined PHY_665A_E_QUEUE_OVERFLOW)
#error defined PHY_665A_E_QUEUE_OVERFLOW is already defined
#endif
#define PHY_665A_E_QUEUE_OVERFLOW 0x7EU

/*
 * Macro used for defining TD is present inside Queue
*/
#if (defined PHY_665A_E_TD_EXIST_ALREADY_IN_QUEUE)
#error defined PHY_665A_E_TD_EXIST_ALREADY_IN_QUEUE is already defined
#endif
#define PHY_665A_E_TD_EXIST_ALREADY_IN_QUEUE 0x7FU

/*
 * Macro used for defining TD is  not present inside Queue
*/
#if (defined PHY_665A_E_TD_NOT_IN_QUEUE)
#error defined PHY_665A_E_TD_NOT_IN_QUEUE is already defined
#endif
#define PHY_665A_E_TD_NOT_IN_QUEUE 0x80U

/*
 * Macro used for defining  Queue Underflow
*/
#if (defined PHY_665A_E_QUEUE_UNDERFLOW)
#error defined PHY_665A_E_QUEUE_UNDERFLOW is already defined
#endif
#define PHY_665A_E_QUEUE_UNDERFLOW 0x81U

/*
 * Macro used for defining error due to no Can devices
*/
#if (defined PHY_665A_E_NO_CAN_DEVICES)
#error defined PHY_665A_E_NO_CAN_DEVICES is already defined
#endif
#define PHY_665A_E_NO_CAN_DEVICES 0x82U

/*
 * Macro used for defining error due to no Spi devices
*/
#if (defined PHY_665A_E_NO_SPI_DEVICES)
#error defined PHY_665A_E_NO_SPI_DEVICES is already defined
#endif
#define PHY_665A_E_NO_SPI_DEVICES 0x83U

/*
 * Macro used for defining error due to last message of the TD as Schedule command
*/
#if (defined PHY_665A_E_LAST_TD_MSG_SCHED_CMD)
#error defined PHY_665A_E_LAST_TD_MSG_SCHED_CMD is already defined
#endif
#define PHY_665A_E_LAST_TD_MSG_SCHED_CMD 0x84U

/*
 * Macro used for defining error due to invalid device index
*/
#if (defined PHY_665A_E_INVALID_DEV_ID)
#error defined PHY_665A_E_INVALID_DEV_ID is already defined
#endif
#define PHY_665A_E_INVALID_DEV_ID 0x85U

/*
 * Macro used for defining error due to invalid device internal state
*/
#if (defined PHY_665A_E_INVALID_DEV_INTERNAL_STATE)
#error defined PHY_665A_E_INVALID_DEV_INTERNAL_STATE is already defined
#endif
#define PHY_665A_E_INVALID_DEV_INTERNAL_STATE 0x86U

/*
 * Macro used for defining error due to invalid num of registers to be read per response
*/
#if (defined PHY_665A_E_INVALID_NUM_REG_PER_RESP)
#error defined PHY_665A_E_INVALID_NUM_REG_PER_RESP is already defined
#endif
#define PHY_665A_E_INVALID_NUM_REG_PER_RESP 0x87U

/*
 * Macro used for defining error due to invalid num of registers to be read
*/
#if (defined PHY_665A_E_INVALID_NUM_REG)
#error defined PHY_665A_E_INVALID_NUM_REG is already defined
#endif
#define PHY_665A_E_INVALID_NUM_REG 0x88U

/*
 * Macro used for defining error due to invalid Data Length
*/
#if (defined PHY_665A_E_INVALID_DATA_LEN)
#error defined PHY_665A_E_INVALID_DATA_LEN is already defined
#endif
#define PHY_665A_E_INVALID_DATA_LEN 0x8AU

/*
 * Macro used for defining error due to invalid McuIf Protocol
*/
#if (defined PHY_665A_E_INVALID_MCUIF_PROTOCOL)
#error defined PHY_665A_E_INVALID_MCUIF_PROTOCOL is already defined
#endif
#define PHY_665A_E_INVALID_MCUIF_PROTOCOL 0x8BU

/*
 * Macro used for defining error due to invalid SYNC trigger
*/
#if (defined PHY_665A_E_INVALID_SYNC_TRIGG)
#error defined PHY_665A_E_INVALID_SYNC_TRIGG is already defined
#endif
#define PHY_665A_E_INVALID_SYNC_TRIGG 0x8CU

/*
 * Macro used for defining error due to invalid Queue Flush Message
*/
#if (defined PHY_665A_E_INVALID_QUEUE_FLUSH)
#error defined PHY_665A_E_INVALID_QUEUE_FLUSH is already defined
#endif
#define PHY_665A_E_INVALID_QUEUE_FLUSH 0x8DU

/*
 * Macro used for defining error due to invalid Message Position
*/
#if (defined PHY_665A_E_INVALID_MESSAGE_POSITION)
#error defined PHY_665A_E_INVALID_MESSAGE_POSITION is already defined
#endif
#define PHY_665A_E_INVALID_MESSAGE_POSITION 0x8EU

/*
 * Macro used for defining error due to invalid Sync Mode
*/
#if (defined PHY_665A_E_INVALID_SYNC_MODE)
#error defined PHY_665A_E_INVALID_SYNC_MODE is already defined
#endif
#define PHY_665A_E_INVALID_SYNC_MODE 0x8FU

/*
 * Macro used for defining error due to invalid Sync State
*/
#if (defined PHY_665A_E_INVALID_SYNC_STATE)
#error defined PHY_665A_E_INVALID_SYNC_STATE is already defined
#endif
#define PHY_665A_E_INVALID_SYNC_STATE 0x90U

/*
 * Macro used for defining error due to invalid Parity Valid Bit of Prefix.
*/
#if (defined PHY_665A_E_INVALID_PREFIX_VALIDITY_BIT)
#error defined PHY_665A_E_INVALID_PREFIX_VALIDITY_BIT is already defined
#endif
#define PHY_665A_E_INVALID_PREFIX_VALIDITY_BIT 0x91U

/*
* Macro used for defining error due to invalid Device Address
*/
#if (defined PHY_665A_E_INVALID_DEVICE_ADDRESS)
#error defined PHY_665A_E_INVALID_DEVICE_ADDRESS is already defined
#endif
#define PHY_665A_E_INVALID_DEVICE_ADDRESS 0x92U

/*
* Macro used for defining error due to invalid Register Address
*/
#if (defined PHY_665A_E_INVALID_REGISTER_ADDRESS)
#error defined PHY_665A_E_INVALID_REGISTER_ADDRESS is already defined
#endif
#define PHY_665A_E_INVALID_REGISTER_ADDRESS 0x93U

/*
* Macro used for defining error due to invalid Hold Operand
*/
#if (defined PHY_665A_E_INVALID_TIME_OPERAND)
#error defined PHY_665A_E_INVALID_TIME_OPERAND is already defined
#endif
#define PHY_665A_E_INVALID_TIME_OPERAND 0x95U

/*
* Macro used for defining error due to Communication timeout of Phy_665a device
*/
#if (defined PHY_665A_E_COMMUNICATION_TIMEOUT)
#error defined PHY_665A_E_COMMUNICATION_TIMEOUT is already defined
#endif
#define PHY_665A_E_COMMUNICATION_TIMEOUT 0x95U

/*
* Macro used for defining error due to Communication timeout of Phy_665a device
*/
#if (defined PHY_665A_E_INVALID_SYNC_QUEUE_FLUSH_FLG_STATUS)
#error defined PHY_665A_E_INVALID_SYNC_QUEUE_FLUSH_FLG_STATUS is already defined
#endif
#define PHY_665A_E_INVALID_SYNC_QUEUE_FLUSH_FLG_STATUS 0x96U

/*
* Macro used for defining error due to Communication timeout of Phy_665a device
*/
#if (defined PHY_665A_E_SYNC_GPIO_SIGNAL_NOT_CONFIGURED)
#error defined PHY_665A_E_SYNC_GPIO_SIGNAL_NOT_CONFIGURED is already defined
#endif
#define PHY_665A_E_SYNC_GPIO_SIGNAL_NOT_CONFIGURED 0x97U

/*
* Macro used for defining error due to invalid CRC
*/
#if (defined PHY_665A_E_INVALID_CRC)
#error defined PHY_665A_E_INVALID_CRC is already defined
#endif
#define PHY_665A_E_INVALID_CRC 0x98U

/*
 * Macro used for defining SPI receive error .
*/
#if (defined PHY_665A_E_SPI_RECEIVE)
#error PHY_665A_E_SPI_RECEIVE is already defined
#endif
#define PHY_665A_E_SPI_RECEIVE 0x99U

/*
 * Macro used for defining TPL2 CAN initialization count down error.
*/
#if (defined PHY_665A_E_CAN_TPL2_COUNT_DOWN)
#error PHY_665A_E_CAN_TPL2_COUNT_DOWN is already defined
#endif
#define PHY_665A_E_CAN_TPL2_COUNT_DOWN 0x9AU

/*Service Id*/
/*
 * Macro used for defining in  which function(Phy_665a_PckInternalTpl3Msg) the DET error has occurred.
*/
#if (defined PHY_665A_PCK_INTERNAL_TPL3_MSG_SVCID)
#error PHY_665A_PCK_INTERNAL_TPL3_MSG_SVCID is already defined
#endif
#define PHY_665A_PCK_INTERNAL_TPL3_MSG_SVCID 0x01U
/*
 * Macro used for defining in  which function(Phy_665a_SpiSendRequest) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_SEND_REQUEST_SVCID)
#error PHY_665A_SPI_SEND_REQUEST_SVCID is already defined
#endif
#define PHY_665A_SPI_SEND_REQUEST_SVCID 0x02U
/*
 * Macro used for defining in  which function(Phy_665a_DeInit) the DET error has occurred.
*/
#if (defined PHY_665A_DEINIT_SVCID)
#error PHY_665A_DEINIT_SVCID is already defined
#endif
#define PHY_665A_DEINIT_SVCID 0x03U
/*
 * Macro used for defining in  which function(Phy_665a_CalcTpl3RespLen) the DET error has occurred.
*/
#if (defined PHY_665A_CALC_TPL3_RESP_LEN_SVCID)
#error PHY_665A_CALC_TPL3_RESP_LEN_SVCID is already defined
#endif
#define PHY_665A_CALC_TPL3_RESP_LEN_SVCID 0x04U
/*
 * Macro used for defining in  which function(Phy_665a_UnPckInternalTpl3RespMsg) the DET error has occurred.
*/
#if (defined PHY_665A_UNPCK_INTERNAL_TPL3_RSP_MSG_SVCID)
#error PHY_665A_UNPCK_INTERNAL_TPL3_RSP_MSG_SVCID is already defined
#endif
#define PHY_665A_UNPCK_INTERNAL_TPL3_RSP_MSG_SVCID 0x05U
/*
 * Macro used for defining in  which function(Phy_665a_ReadInternalCRC) the DET error has occurred.
*/
#if (defined PHY_665A_READ_INTERNAL_CRC_SVCID)
#error PHY_665A_READ_INTERNAL_CRC_SVCID is already defined
#endif
#define PHY_665A_READ_INTERNAL_CRC_SVCID 0x06U
/*
 * Macro used for defining in  which function(Phy_665a_SysInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_INIT_SVCID)
#error PHY_665A_SYS_INIT_SVCID is already defined
#endif
#define PHY_665A_SYS_INIT_SVCID 0x07U
/*
 * Macro used for defining in  which function(Phy_665a_HostComInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_HOST_COM_INIT_SVCID)
#error PHY_665A_HOST_COM_INIT_SVCID is already defined
#endif
#define PHY_665A_HOST_COM_INIT_SVCID 0x08U
/*
 * Macro used for defining in  which function(Phy_665a_SpiInit) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_INIT_SVCID)
#error PHY_665A_SPI_INIT_SVCID is already defined
#endif
#define PHY_665A_SPI_INIT_SVCID 0x09U
/*
 * Macro used for defining in  which function(Phy_665a_ReadUid) the DET error has occurred.
*/
#if (defined PHY_665A_READ_UID_SVCID)
#error PHY_665A_READ_UID_SVCID is already defined
#endif
#define PHY_665A_READ_UID_SVCID 0x0AU
/*
 * Macro used for defining in  which function(Phy_665a_TplPortInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_TPL_PORT_INIT_SVCID)
#error PHY_665A_TPL_PORT_INIT_SVCID is already defined
#endif
#define PHY_665A_TPL_PORT_INIT_SVCID 0x0BU
/*
 * Macro used for defining in  which function(Phy_665a_FilterInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_FILTER_INIT_SVCID)
#error PHY_665A_FILTER_INIT_SVCID is already defined
#endif
#define PHY_665A_FILTER_INIT_SVCID 0x0CU
/*
 * Macro used for defining in  which function(Phy_665a_QueueInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_QUEUE_INIT_SVCID)
#error PHY_665A_QUEUE_INIT_SVCID is already defined
#endif
#define PHY_665A_QUEUE_INIT_SVCID 0x0DU
/*
 * Macro used for defining in  which function(Phy_665a_ReadSysCrcReqSend) the DET error has occurred.
*/
#if (defined PHY_665A_READ_SYS_CRC_SVCID)
#error PHY_665A_READ_SYS_CRC_SVCID is already defined
#endif
#define PHY_665A_READ_SYS_CRC_SVCID 0x0EU
/*
 * Macro used for defining in  which function(Phy_665a_CheckTpl3Crc) the DET error has occurred.
*/
#if (defined PHY_665A_CHECK_TPL3_CRC_SVCID)
#error PHY_665A_CHECK_TPL3_CRC_SVCID is already defined
#endif
#define PHY_665A_CHECK_TPL3_CRC_SVCID 0x0FU
/*
 * Macro used for defining in  which function(Phy_665a_EvhIntSelInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_SEL_INIT_SVCID)
#error PHY_665A_EVH_INT_SEL_INIT_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_SEL_INIT_SVCID 0x10U
/*
 * Macro used for defining in  which function(Phy_665a_EvhIntCfgInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_CFG_INIT_SVCID)
#error PHY_665A_EVH_INT_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_CFG_INIT_SVCID 0x11U
/*
 * Macro used for defining in  which function(Phy_665a_EvhWakeupCfgInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_WAKEUP_CFG_INIT_SVCID)
#error PHY_665A_EVH_WAKEUP_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_EVH_WAKEUP_CFG_INIT_SVCID 0x12U
/*
 * Macro used for defining in  which function(Phy_665a_ReadEvhCrcReqSend) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_CRC_SVCID)
#error PHY_665A_EVH_READ_CRC_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_CRC_SVCID 0x13U
/*
 * Macro used for defining in  which function(Phy_665a_GpioCfgInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_GPIO_CFG_INIT_SVCID)
#error PHY_665A_GPIO_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_GPIO_CFG_INIT_SVCID 0x14U
/*
 * Macro used for defining in  which function(Phy_665a_I2cCfgInitCanVariant) the DET error has occurred.
*/
#if (defined PHY_665A_I2C_CFG_INIT_SVCID)
#error PHY_665A_I2C_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_I2C_CFG_INIT_SVCID 0x15U
/*
 * Macro used for defining in  which function(Phy_665a_Init) the DET error has occurred.
*/
#if (defined PHY_665A_INIT_SVCID)
#error PHY_665A_INIT_SVCID is already defined
#endif
#define PHY_665A_INIT_SVCID 0x16U
/*
 * Macro used for defining in  which function(Phy_665a_SpiSlotFillTpl3Read) the DET error has occurred.
*/
#if (defined PHY_665A_SLOT_FILL_READ_SVCID)
#error PHY_665A_SLOT_FILL_READ_SVCID is already defined
#endif
#define PHY_665A_SLOT_FILL_READ_SVCID 0x17U

/*
 * Macro used for defining in  which function(Phy_665a_SpiSlotFillTpl3Write) the DET error has occurred.
*/
#if (defined PHY_665A_SLOT_FILL_WRITE_SVCID)
#error PHY_665A_SLOT_FILL_WRITE_SVCID is already defined
#endif
#define PHY_665A_SLOT_FILL_WRITE_SVCID 0x18U

/*
 * Macro used for defining in  which function(Phy_665a_SpiSlotFillTpl3Wup) the DET error has occurred.
*/
#if (defined PHY_665A_SLOT_FILL_WUP_SVCID)
#error PHY_665A_SLOT_FILL_WUP_SVCID is already defined
#endif
#define PHY_665A_SLOT_FILL_WUP_SVCID 0x19U

/*
 * Macro used for defining in  which function(Phy_665a_IO_SendMessage) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_MSG_SVCID)
#error PHY_665A_IO_SEND_MSG_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_MSG_SVCID 0x1AU
/*
 * Macro used for defining in  which function(Phy_665a_SchedMessage) the DET error has occurred.
*/
#if (defined PHY_665A_SCHED_MSG_SVCID)
#error PHY_665A_SCHED_MSG_SVCID is already defined
#endif
#define PHY_665A_SCHED_MSG_SVCID 0x1BU
/*
 * Macro used for defining in  which function(Phy_665a_GpioConfig) the DET error has occurred.
*/
#if (defined PHY_665A_GPIO_CONFIG_SVCID)
#error PHY_665A_GPIO_CONFIG_SVCID is already defined
#endif
#define PHY_665A_GPIO_CONFIG_SVCID 0x1CU
/*
 * Macro used for defining in  which function(Phy_665a_GpioInReadMessage) the DET error has occurred.
*/
#if (defined PHY_665A_GPIO_READ_INPUT_REG_SVCID)
#error PHY_665A_GPIO_READ_INPUT_REG_SVCID is already defined
#endif
#define PHY_665A_GPIO_READ_INPUT_REG_SVCID 0x1DU
/*
 * Macro used for defining in  which function(Phy_665a_GpioOutConfig) the DET error has occurred.
*/

#if (defined PHY_665A_GPIO_WRITE_OUTPUT_SVCID)
#error PHY_665A_GPIO_WRITE_OUTPUT_SVCID is already defined
#endif
#define PHY_665A_GPIO_WRITE_OUTPUT_SVCID 0x1EU

/*
 * Macro used for defining in  which function(Phy_665a_SCHED_ReadStatus) the DET error has occurred.
*/
#if (defined PHY_665A_READ_SCHED_STAT_SVCID)
#error PHY_665A_READ_SCHED_STAT_SVCID is already defined
#endif
#define PHY_665A_READ_SCHED_STAT_SVCID 0x1FU

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ConfigIntSource) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_CONFIG_SVCID)
#error PHY_665A_EVH_CONFIG_SVCID is already defined
#endif
#define PHY_665A_EVH_CONFIG_SVCID 0x20U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadWakeUpReason) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_WAKE_UP_REASON_SVCID)
#error PHY_665A_EVH_READ_WAKE_UP_REASON_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_WAKE_UP_REASON_SVCID 0x21U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadResetReason) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_RESET_REASON_SVCID)
#error PHY_665A_EVH_READ_RESET_REASON_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_RESET_REASON_SVCID 0x22U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadQueueStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_QUEUE_STAT_SVCID)
#error PHY_665A_EVH_READ_QUEUE_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_QUEUE_STAT_SVCID 0x23U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadGroupErrStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_GRP_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_GRP_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_GRP_ERR_STAT_SVCID 0x24U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadGeneralErrStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_GENERAL_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_GENERAL_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_GENERAL_ERR_STAT_SVCID 0x25U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadMcuIfErrStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_MCU_IF_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_MCU_IF_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_MCU_IF_ERR_STAT_SVCID 0x26U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadTpl0ErrStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_TPL0_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_TPL0_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_TPL0_ERR_STAT_SVCID 0x27U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadTpl1ErrStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_TPL1_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_TPL1_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_TPL1_ERR_STAT_SVCID 0x28U

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadTpl2ErrStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_TPL2_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_TPL2_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_TPL2_ERR_STAT_SVCID 0x29U
/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadTpl3ErrStatus) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_TPL3_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_TPL3_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_TPL3_ERR_STAT_SVCID 0x2AU

/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadAccErrReg) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_ACC_ERR_STAT_SVCID)
#error PHY_665A_EVH_READ_ACC_ERR_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_ACC_ERR_STAT_SVCID 0x2BU

/*
 * Macro used for defining in  which function(Phy_665a_SYNC_SwTrigMessage) the DET error has occurred.
*/
#if (defined PHY_665A_SCHED_EVENT_MESSAGE_SVCID)
#error PHY_665A_SCHED_EVENT_MESSAGE_SVCID is already defined
#endif
#define PHY_665A_SCHED_EVENT_MESSAGE_SVCID 0x2CU

/*
 * Macro used for defining in  which function(Phy_665a_I2C_ReadStatus) the DET error has occurred.
*/
#if (defined PHY_665A_I2C_READ_I2C_STAT_REG_SVCID)
#error PHY_665A_I2C_READ_I2C_STAT_REG_SVCID is already defined
#endif
#define PHY_665A_I2C_READ_I2C_STAT_REG_SVCID 0x2DU

/*
 * Macro used for defining in  which function(Phy_665a_I2cConfigDataReg) the DET error has occurred.
*/
#if (defined PHY_665A_I2C_WRITE_DATA_REG_SVCID)
#error PHY_665A_I2C_WRITE_DATA_REG_SVCID is already defined
#endif
#define PHY_665A_I2C_WRITE_DATA_REG_SVCID 0x2EU

/*
 * Macro used for defining in  which function(Phy_665a_I2C_ReadDataReg) the DET error has occurred.
*/
#if (defined PHY_665A_I2C_READ_I2C_DATA_REG_SVCID)
#error PHY_665A_I2C_READ_I2C_DATA_REG_SVCID is already defined
#endif
#define PHY_665A_I2C_READ_I2C_DATA_REG_SVCID 0x2FU

/*
 * Macro used for defining in  which function(Phy_665a_I2cConfigCtrlReg) the DET error has occurred.
*/
#if (defined PHY_665A_I2C_WRITE_CTRL_REG_SVCID)
#error PHY_665A_I2C_WRITE_CTRL_REG_SVCID is already defined
#endif
#define PHY_665A_I2C_WRITE_CTRL_REG_SVCID 0x30U
/*
 * Macro used for defining in  which function(Phy_665a_VerifyTdRequest) the DET error has occurred.
*/
#if (defined PHY_665A_VERIFY_TD_REQUEST_SVCID)
#error PHY_665A_VERIFY_TD_REQUEST_SVCID is already defined
#endif
#define PHY_665A_VERIFY_TD_REQUEST_SVCID 0x31U
/*
 * Macro used for defining in  which function(Phy_665a_TimingCalcAlgo) the DET error has occurred.
*/
#if (defined PHY_665A_TIMING_CALC_ALGO_SVCID)
#error PHY_665A_TIMING_CALC_ALGO_SVCID is already defined
#endif
#define PHY_665A_TIMING_CALC_ALGO_SVCID 0x32U
/*
 * Macro used for defining in  which function() the DET error has occurred.
*/
#if (defined PHY_665A_CALCINTERFRAMEDELAY_SVCID)
#error PHY_665A_CALCINTERFRAMEDELAY_SVCID is already defined
#endif
#define PHY_665A_CALCINTERFRAMEDELAY_SVCID 0x32U
/*
 * Macro used for defining in  which function() the DET error has occurred.
*/
#if (defined PHY_665A_UPDATE_SLOT_TIME_SVCID)
#error PHY_665A_UPDATE_SLOT_TIME_SVCID is already defined
#endif
#define PHY_665A_UPDATE_SLOT_TIME_SVCID 0x33U
/*
 * Macro used for defining in  which function() the DET error has occurred.
*/
#if (defined PHY_665A_GET_GLBL_TIMER_SVCID)
#error PHY_665A_GET_GLBL_TIMER_SVCID is already defined
#endif
#define PHY_665A_GET_GLBL_TIMER_SVCID 0x34U
/*
 * Macro used for defining in  which function(Phy_665a_IOSendMessageTpl3InterruptContext) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_MESSAGE_TPL3_VARIABLE_LOOP_SVCID)
#error PHY_665A_IO_SEND_MESSAGE_TPL3_VARIABLE_LOOP_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_MESSAGE_TPL3_VARIABLE_LOOP_SVCID 0x35U
/*
 * Macro used for defining in  which function(Phy_665a_ErrorDiagnostic) the DET error has occurred.
*/
#if (defined PHY_665A_ERROR_DIAGNOSTIC_SVCID)
#error PHY_665A_ERROR_DIAGNOSTIC_SVCID is already defined
#endif
#define PHY_665A_ERROR_DIAGNOSTIC_SVCID 0x36U
/*
 * Macro used for defining in  which function(Phy_665a_DetermineDiagnosticErrSrc) the DET error has occurred.
*/
#if (defined PHY_665A_DETERMINE_DIAGNOSTIC_ERR_SRC_SVCID)
#error PHY_665A_DETERMINE_DIAGNOSTIC_ERR_SRC_SVCID is already defined
#endif
#define PHY_665A_DETERMINE_DIAGNOSTIC_ERR_SRC_SVCID 0x37U
/*
 * Macro used for defining in  which function(Phy_665a_PckInternalTpl2Msg) the DET error has occurred.
*/
#if (defined PHY_665A_PCK_INTERNAL_TPL2_MSG_SVCID)
#error PHY_665A_PCK_INTERNAL_TPL2_MSG_SVCID is already defined
#endif
#define PHY_665A_PCK_INTERNAL_TPL2_MSG_SVCID 0x3AU

/*
 * Macro used for defining in  which function(Phy_665a_UpdatePrefix) the DET error has occurred.
*/
#if (defined PHY_665A_UPDATE_PREFIX_SVCID)
#error PHY_665A_UPDATE_PREFIX_SVCID is already defined
#endif
#define PHY_665A_UPDATE_PREFIX_SVCID 0x3CU
/*
 * Macro used for defining in  which function(Phy_665a_SpiReceivePrefixedResponse) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_RECEIVE_PREFIXED_RESPONSE_SVCID)
#error PHY_665A_SPI_RECEIVE_PREFIXED_RESPONSE_SVCID is already defined
#endif
#define PHY_665A_SPI_RECEIVE_PREFIXED_RESPONSE_SVCID 0x3EU
/*
 * Macro used for defining in  which function(Phy_665a_SpiUnPckTpl3PrefixedResponse) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_UNPCK_TPL3_PREFIX_RSP_SVCID)
#error PHY_665A_SPI_UNPCK_TPL3_PREFIX_RSP_SVCID is already defined
#endif
#define PHY_665A_SPI_UNPCK_TPL3_PREFIX_RSP_SVCID 0x3FU
/*
 * Macro used for defining in  which function(Phy_665a_SpiPreprocessTpl3PrefixedResponse) the DET error has occurred.
*/
#if (defined PHY_665A_VALIDATE_PREFIX_SVCID)
#error PHY_665A_VALIDATE_PREFIX_SVCID is already defined
#endif
#define PHY_665A_VALIDATE_PREFIX_SVCID 0x40U

/*
 * Macro used for defining in  which function(Phy_665a_ValidateTpl3Crc) the DET error has occurred.
*/
#if (defined PHY_665A_VALIDATE_TPL3_CRC_SVCID)
#error PHY_665A_VALIDATE_TPL3_CRC_SVCID is already defined
#endif
#define PHY_665A_VALIDATE_TPL3_CRC_SVCID 0x42U
/*
 * Macro used for defining in  which function(Phy_665a_IOSendMessageTpl2InterruptContext) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_MESSAGE_TPL2_VARIABLE_LOOP_SVCID)
#error defined PHY_665A_IO_SEND_MESSAGE_TPL2_VARIABLE_LOOP_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_MESSAGE_TPL2_VARIABLE_LOOP_SVCID 0x43U

/*
 * Macro used for defining in  which function(Phy_665a_SYS_ReadCrcReg) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_READ_CRC_SVCID)
#error defined PHY_665A_SYS_READ_CRC_SVCID is already defined
#endif
#define PHY_665A_SYS_READ_CRC_SVCID 0x45U
/*
 * Macro used for defining in  which function(Phy_665a_SYS_ReadComCfg) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_READ_COM_CFG_SVCID)
#error defined PHY_665A_SYS_READ_COM_CFG_SVCID is already defined
#endif
#define PHY_665A_SYS_READ_COM_CFG_SVCID 0x46U
/*
 * Macro used for defining in  which function(Phy_665a_SysModeWriteStatusReg) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_MODE_WRITE_STATUS_SVCID)
#error defined PHY_665A_SYS_MODE_WRITE_STATUS_SVCID is already defined
#endif
#define PHY_665A_SYS_MODE_WRITE_STATUS_SVCID 0x47U
/*
 * Macro used for defining in  which function(Phy_665a_SYS_ReadQueueStatus) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_READ_QUEUE_CTRL_SVCID)
#error defined PHY_665A_SYS_READ_QUEUE_CTRL_SVCID is already defined
#endif
#define PHY_665A_SYS_READ_QUEUE_CTRL_SVCID 0x48U
/*
 * Macro used for defining in  which function(Phy_665a_SysQueueCtrlReadStatusReg) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_READ_QUEUE_STATUS_SVCID)
#error defined PHY_665A_SYS_READ_QUEUE_STATUS_SVCID is already defined
#endif
#define PHY_665A_SYS_READ_QUEUE_STATUS_SVCID 0x49U
/*
 * Macro used for defining in  which function(Phy_665a_SYS_WriteQueueCtrlReg) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_WRITE_QUEUE_CTRL_SVCID)
#error defined PHY_665A_SYS_WRITE_QUEUE_CTRL_SVCID is already defined
#endif
#define PHY_665A_SYS_WRITE_QUEUE_CTRL_SVCID 0x4AU

/*
 * Macro used for defining in  which function the DET error has occurred.
*/
#if (defined PHY_665A_SYS_TPL_PORT_WRITE_SINGLE_REG_SVCID)
#error defined PHY_665A_SYS_TPL_PORT_WRITE_SINGLE_REG_SVCID is already defined
#endif
#define PHY_665A_SYS_TPL_PORT_WRITE_SINGLE_REG_SVCID 0x4CU
/*
 * Macro used for defining in  which function the DET error has occurred.
*/
#if (defined PHY_665A_SYS_PORT2_CFG_WRITE_STATUS_SVCID)
#error defined PHY_665A_SYS_PORT2_CFG_WRITE_STATUS_SVCID is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_WRITE_STATUS_SVCID 0x4DU
/*
 * Macro used for defining in  which function the DET error has occurred.
*/
#if (defined PHY_665A_SYS_PORT3_CFG_WRITE_STATUS_SVCID)
#error defined PHY_665A_SYS_PORT3_CFG_WRITE_STATUS_SVCID is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_WRITE_STATUS_SVCID 0x4EU
/*
 * Macro used for defining in  which function(Phy_665a_IOSendMessageTpl3InterruptContext) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_MESSAGE_TPL3_VARIABLE_INTERRUPT_CONTEXT_SVCID)
#error defined PHY_665A_IO_SEND_MESSAGE_TPL3_VARIABLE_INTERRUPT_CONTEXT_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_MESSAGE_TPL3_VARIABLE_INTERRUPT_CONTEXT_SVCID 0x4F
/*
 * Macro used for defining in  which function(Phy_665a_IOSendMessageTpl2InterruptContext) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_MESSAGE_TPL2_VARIABLE_INTERRUPT_CONTEXT_SVCID)
#error defined PHY_665A_IO_SEND_MESSAGE_TPL2_VARIABLE_INTERRUPT_CONTEXT_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_MESSAGE_TPL2_VARIABLE_INTERRUPT_CONTEXT_SVCID 0x50
/*
 * Macro used for defining in  which function(Phy_665a_SpiSlotFillTpl2Read) the DET error has occurred.
*/
#if (defined PHY_665A_PRE_SLOT_TPL2_FILL_READ_SVCID)
#error defined PHY_665A_PRE_SLOT_TPL2_FILL_READ_SVCID is already defined
#endif
#define PHY_665A_PRE_SLOT_TPL2_FILL_READ_SVCID 0x51
/*
 * Macro used for defining in  which function(Phy_665a_ExpectedTime) the DET error has occurred.
*/
#if (defined PHY_665A_EXPECTED_TIME_SVCID)
#error defined PHY_665A_EXPECTED_TIME_SVCID is already defined
#endif
#define PHY_665A_EXPECTED_TIME_SVCID 0x52

/*
 * Macro used for defining in which function(Phy_665a_IOSendInternalFirstTpl3Message) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_INTERNAL_FIRST_TPL3_MESSAGE_SVCID)
#error defined PHY_665A_IO_SEND_INTERNAL_FIRST_TPL3_MESSAGE_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_INTERNAL_FIRST_TPL3_MESSAGE_SVCID 0x53

/*
 * Macro used for defining in which function(Phy_665a_SpiInternalTpl3Write) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_INTERNAL_WRITE_SVCID)
#error defined PHY_665A_SPI_INTERNAL_WRITE_SVCID is already defined
#endif
#define PHY_665A_SPI_INTERNAL_WRITE_SVCID 0x54

/*
 * Macro used for defining in which function(Phy_665a_SpiInternalTpl3Read) the DET error has occurred.
*/
#if (defined PHY_665A_INTERNAL_READ_SVCID)
#error defined PHY_665A_INTERNAL_READ_SVCID is already defined
#endif
#define PHY_665A_INTERNAL_READ_SVCID 0x56

/*
 * Macro used for defining in which function(Phy_665a_UpdateInternalTpl3TdGptCntext) the DET error has occurred.
*/
#if (defined PHY_665A_UPDATE_INTERNAL_TPL3_TD_GPT_CNTEXT_SVCID)
#error defined PHY_665A_UPDATE_INTERNAL_TPL3_TD_GPT_CNTEXT_SVCID is already defined
#endif
#define PHY_665A_UPDATE_INTERNAL_TPL3_TD_GPT_CNTEXT_SVCID 0x58

/*
 * Macro used for defining in which function(Phy_665a_SpiInternalTpl2Write) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_INTERNAL_TPL2_WRITE_SVCID)
#error defined PHY_665A_SPI_INTERNAL_TPL2_WRITE_SVCID is already defined
#endif
#define PHY_665A_SPI_INTERNAL_TPL2_WRITE_SVCID 0x5A

/*
 * Macro used for defining in which function(Phy_665a_SpiInternalTpl2Read) the DET error has occurred.
*/
#if (defined PHY_665A_INTERNAL_READ_TPL2_SVCID)
#error defined PHY_665A_INTERNAL_READ_TPL2_SVCID is already defined
#endif
#define PHY_665A_INTERNAL_READ_TPL2_SVCID 0x5C
/*
 * Macro used for defining in which function(Phy_665a_IOSendInternalOtherTpl2Message) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_INTERNAL_OTHER_TPL2_MESSAGE_SVCID)
#error defined PHY_665A_IO_SEND_INTERNAL_OTHER_TPL2_MESSAGE_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_INTERNAL_OTHER_TPL2_MESSAGE_SVCID 0x5D
/*
 * Macro used for defining in which function(Phy_665a_UpdateInternalTpl2TdGptCntext) the DET error has occurred.
*/
#if (defined PHY_665A_UPDATE_INTERNAL_TD_GPT_CNTEXT_SVCID_TPL2)
#error defined PHY_665A_UPDATE_INTERNAL_TD_GPT_CNTEXT_SVCID_TPL2 is already defined
#endif
#define PHY_665A_UPDATE_INTERNAL_TD_GPT_CNTEXT_SVCID_TPL2 0x5E
/*
 * Macro used for defining in  which function(Phy_665a_EVH_ReadCrcReg) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_CRC_STAT_SVCID)
#error defined PHY_665A_EVH_READ_CRC_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_CRC_STAT_SVCID 0x5F
/*
 * Macro used for defining in  which function(Phy_665a_SYS_WriteTargetMode) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_MODE_WRITE_SVCID)
#error defined PHY_665A_SYS_MODE_WRITE_SVCID is already defined
#endif
#define PHY_665A_SYS_MODE_WRITE_SVCID 0x60
/*
 * Macro used for defining in which function the DET error has occurred.
*/
#if (defined PHY_665A_EVH_CONFIG_INTX_SVCID)
#error defined PHY_665A_EVH_CONFIG_INTX_SVCID is already defined
#endif
#define PHY_665A_EVH_CONFIG_INTX_SVCID 0x61

/*
 * Macro used for defining in  which function(Phy_665a_EvhReadErrRegStat) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_READ_ERR_REG_STAT_SVCID)
#error defined PHY_665A_EVH_READ_ERR_REG_STAT_SVCID is already defined
#endif
#define PHY_665A_EVH_READ_ERR_REG_STAT_SVCID 0x64

/*
 * Macro used for defining in  which function(Phy_665a_WakeupDevice) the DET error has occurred.
*/
#if (defined PHY_665A_WAKEUP_DEVICE_SVCID)
#error defined PHY_665A_WAKEUP_DEVICE_SVCID is already defined
#endif
#define PHY_665A_WAKEUP_DEVICE_SVCID 0x65

/*
 * Macro used for defining in  which function(Phy_665a_I2C_ReadCtrl) the DET error has occurred.
*/
#if (defined PHY_665A_I2C_READ_I2C_CTRL_REG_SVCID)
#error PHY_665A_I2C_READ_I2C_CTRL_REG_SVCID is already defined
#endif
#define PHY_665A_I2C_READ_I2C_CTRL_REG_SVCID 0x66

/*
 * Macro used for defining in  which function(Phy_665a_I2C_WriteConfigReg) the DET error has occurred.
*/
#if (defined PHY_665A_I2C_WRITE_CFG_REG_SVCID)
#error PHY_665A_I2C_WRITE_CFG_REG_SVCID is already defined
#endif
#define PHY_665A_I2C_WRITE_CFG_REG_SVCID 0x67

/*
 * Macro used for defining in  which function(Phy_665a_ClearInternalTD) the DET error has occurred.
*/
#if (defined PHY_665A_CLEAR_INTERNAL_TD_SVCID)
#error PHY_665A_CLEAR_INTERNAL_TD_SVCID is already defined
#endif
#define PHY_665A_CLEAR_INTERNAL_TD_SVCID 0x68

/*
 * Macro used for defining in which function(Phy_665a_VerifyTdMessageBoundary) the DET error has occurred.
*/
#if (defined PHY_665A_VERIFY_TD_MESSAGE_BOUNDARY_SVCID)
#error PHY_665A_VERIFY_TD_MESSAGE_BOUNDARY_SVCID is already defined
#endif
#define PHY_665A_VERIFY_TD_MESSAGE_BOUNDARY_SVCID 0x69

/*
 * Macro used for defining in which function(Phy_665a_PackCanMsgToPdu) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_PACK_MSG_TO_PDU_SVCID)
#error PHY_665A_CAN_PACK_MSG_TO_PDU_SVCID is already defined
#endif
#define PHY_665A_CAN_PACK_MSG_TO_PDU_SVCID 0x70U

/*
 * Macro used for defining in  which function(Phy_665a_CanSendRequest) the DET error has occurred.
*/
#if (defined PHY_665A_SEND_INTERNAL_REQUEST_CAN_SVCID)
#error defined PHY_665A_SEND_INTERNAL_REQUEST_CAN_SVCID is already defined
#endif
#define PHY_665A_SEND_INTERNAL_REQUEST_CAN_SVCID 0x71

/*
 * Macro used for defining in  which function(Phy_665a_ReadUidReqSend) the DET error has occurred.
*/
#if (defined PHY_665A_READ_UID_REQ_CAN_SEND_SVCID)
#error defined PHY_665A_READ_UID_REQ_CAN_SEND_SVCID is already defined
#endif
#define PHY_665A_READ_UID_REQ_CAN_SEND_SVCID 0x74

/*
 * Macro used for defining in  which function(Phy_665a_RxIndication) the DET error has occurred.
*/
#if (defined PHY_665A_RX_INDICATION_SVCID)
#error defined PHY_665A_RX_INDICATION_SVCID is already defined
#endif
#define PHY_665A_RX_INDICATION_SVCID 0x75

/*
 * Macro used for defining in  which function(Phy_665a_CanUnPckUid) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_UNPCK_UID_SVCID)
#error defined PHY_665A_CAN_UNPCK_UID_SVCID is already defined
#endif
#define PHY_665A_CAN_UNPCK_SVCID 0x76

/*
 * Macro used for defining in  which function(Phy_665a_UpdateInternalTDIndex) the DET error has occurred.
*/
#if (defined PHY_665A_UPDATE_INTERNAL_TD_INDEX_SVCID)
#error defined PHY_665A_UPDATE_INTERNAL_TD_INDEX_SVCID is already defined
#endif
#define PHY_665A_UPDATE_INTERNAL_TD_INDEX_SVCID 0x79

/*
 * Macro used for defining in  which function(Phy_665a_CanPackFirstBatch) the DET error has occurred.
*/
#if (defined PHY_665A_PACK_MESSAGE_BATCH_CAN_SVCID)
#error defined PHY_665A_PACK_MESSAGE_BATCH_CAN_SVCID is already defined
#endif
#define PHY_665A_PACK_MESSAGE_BATCH_CAN_SVCID 0x7C

/*
 * Macro used for defining in  which function(Phy_665a_CanSlotFillTpl3Wup) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_SLOT_FILL_WUP_SVCID)
#error defined PHY_665A_CAN_SLOT_FILL_WUP_SVCID is already defined
#endif
#define PHY_665A_CAN_SLOT_FILL_WUP_SVCID 0x7E

/*
 * Macro used for defining in  which function(Phy_665a_CanSlotFillTpl3Write) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_SLOT_FILL_WRITE_SVCID)
#error defined PHY_665A_CAN_SLOT_FILL_WRITE_SVCID is already defined
#endif
#define PHY_665A_CAN_SLOT_FILL_WRITE_SVCID 0x7F


/*
 * Macro used for defining in  which function(Phy_665a_CanSlotFillTpl3Read) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_SLOT_FILL_READ_SVCID)
#error defined PHY_665A_CAN_SLOT_FILL_READ_SVCID is already defined
#endif
#define PHY_665A_CAN_SLOT_FILL_READ_SVCID 0x80

/*
 * Macro used for defining in  which function(Phy_665a_CanSlotFillTpl2Wup) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_SLOT_FILL_TPL2_WUP_SVCID)
#error defined PHY_665A_CAN_SLOT_FILL_TPL2_WUP_SVCID is already defined
#endif
#define PHY_665A_CAN_SLOT_FILL_TPL2_WUP_SVCID 0x82

/*
 * Macro used for defining in  which function(Phy_665a_CanSlotFillTpl2Write) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_SLOT_FILL_TPL2_WRITE_SVCID)
#error defined PHY_665A_CAN_SLOT_FILL_TPL2_WRITE_SVCID is already defined
#endif
#define PHY_665A_CAN_SLOT_FILL_TPL2_WRITE_SVCID 0x83

/*
 * Macro used for defining in  which function(Phy_665a_CanSlotFillTpl2Read) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_SLOT_FILL_TPL2_READ_SVCID)
#error defined PHY_665A_CAN_SLOT_FILL_TPL2_READ_SVCID is already defined
#endif
#define PHY_665A_CAN_SLOT_FILL_TPL2_READ_SVCID 0x84

/*
 * Macro used for defining in  which function(Phy_665a_SendFirstInternalMessage) the DET error has occurred.
*/
#if (defined PHY_665A_SEND_INTERNAL_FIRST_MESSAGE_SVCID)
#error defined PHY_665A_SEND_INTERNAL_FIRST_MESSAGE_SVCID is already defined
#endif
#define PHY_665A_SEND_INTERNAL_FIRST_MESSAGE_SVCID 0x86

/*
 * Macro used for defining in  which function(Phy_665a_CanInternalTpl3Write) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_INTERNAL_WRITE_TPL3_SVCID)
#error defined PHY_665A_CAN_INTERNAL_WRITE_TPL3_SVCID is already defined
#endif
#define PHY_665A_CAN_INTERNAL_WRITE_TPL3_SVCID 0x87

/*
 * Macro used for defining in  which function(Phy_665a_CanInternalTpl3Read) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_INTERNAL_READ_TPL3_SVCID)
#error defined PHY_665A_CAN_INTERNAL_READ_TPL3_SVCID is already defined
#endif
#define PHY_665A_CAN_INTERNAL_READ_TPL3_SVCID 0x88

/*
 * Macro used for defining in  which function(Phy_665a_CanInternalWriteTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_INTERNAL_WRITE_TPL2_SVCID)
#error defined PHY_665A_CAN_INTERNAL_WRITE_TPL2_SVCID is already defined
#endif
#define PHY_665A_CAN_INTERNAL_WRITE_TPL2_SVCID 0x8D

/*
 * Macro used for defining in  which function(Phy_665a_CanInternalReadTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_INTERNAL_READ_TPL2_SVCID)
#error defined PHY_665A_CAN_INTERNAL_READ_TPL2_SVCID is already defined
#endif
#define PHY_665A_CAN_INTERNAL_READ_TPL2_SVCID 0x8E

/*
 * Macro used for defining in  which function(Phy_665a_SendInternalOtherMessageCanGpt) the DET error has occurred.
*/
#if (defined PHY_665A_SEND_INTERNAL_OTHER_MESSAGE_GPT_SVCID)
#error defined PHY_665A_SEND_INTERNAL_OTHER_MESSAGE_GPT_SVCID is already defined
#endif
#define PHY_665A_SEND_INTERNAL_OTHER_MESSAGE_GPT_SVCID 0x90

/*
 * Macro used for defining in  which function(Phy_665a_SYS_WriteTplPortCfg) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_WRITE_TPL_PORT_CFG_SVCID)
#error defined PHY_665A_SYS_WRITE_TPL_PORT_CFG_SVCID is already defined
#endif
#define PHY_665A_SYS_WRITE_TPL_PORT_CFG_SVCID 0x91

/*
 * Macro used for defining in which function (Phy_665a_SYS_GetHardwareVersion) the DET error has occurred.
*/
#if (defined PHY_665A_SYS_GET_HARDWARE_VERSION_SVCID)
#error defined PHY_665A_SYS_GET_HARDWARE_VERSION_SVCID is already defined
#endif
#define PHY_665A_SYS_GET_HARDWARE_VERSION_SVCID 0x92

/*
 * Macro used for defining in  which function(Phy_665a_SingleChainAnalyzeReqPortCfg) the DET error has occurred.
*/
#if (defined PHY_665A_SINGLE_CHAIN_ANALYZE_REQ_PORT_CFG_TPL3_SVCID)
#error defined PHY_665A_SINGLE_CHAIN_ANALYZE_REQ_PORT_CFG_TPL3_SVCID is already defined
#endif
#define PHY_665A_SINGLE_CHAIN_ANALYZE_REQ_PORT_CFG_TPL3_SVCID 0x96

/*
 * Macro used for defining in  which function(Phy_665a_NonGlobalReqAnalyze) the DET error has occurred.
*/
#if (defined PHY_665A_NON_GLOBAL_REQ_ANALYZE_TPL3_SVCID)
#error defined PHY_665A_NON_GLOBAL_REQ_ANALYZE_TPL3_SVCID is already defined
#endif
#define PHY_665A_NON_GLOBAL_REQ_ANALYZE_TPL3_SVCID 0x97

/*
 * Macro used for defining in  which function(Phy_665a_NonGlobalReqNonLoopBckPortAnalyze) the DET error has occurred.
*/
#if (defined PHY_665A_NON_GLOBAL_REQ_NON_LOOP_BCK_PORT_ANALYZE_TPL3_SVCID)
#error defined PHY_665A_NON_GLOBAL_REQ_NON_LOOP_BCK_PORT_ANALYZE_TPL3_SVCID is already defined
#endif
#define PHY_665A_NON_GLOBAL_REQ_NON_LOOP_BCK_PORT_ANALYZE_TPL3_SVCID 0x98

/*
 * Macro used for defining in  which function(Phy_665a_NonGlobalReqLoopBckPortAnalyzeTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_NON_GLOBAL_REQ_LOOP_BCK_PORT_ANALYZE_TPL3_SVCID)
#error defined PHY_665A_NON_GLOBAL_REQ_LOOP_BCK_PORT_ANALYZE_TPL3_SVCID is already defined
#endif
#define PHY_665A_NON_GLOBAL_REQ_LOOP_BCK_PORT_ANALYZE_TPL3_SVCID 0x99

/*
 * Macro used for defining in  which function(Phy_665a_GlbAnalyzePortCfgTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_GLB_ANALYZE_PORT_CFG_TPL3_SVCID)
#error defined PHY_665A_GLB_ANALYZE_PORT_CFG_TPL3_SVCID is already defined
#endif
#define PHY_665A_GLB_ANALYZE_PORT_CFG_TPL3_SVCID 0x9A

/*
 * Macro used for defining in  which function(Phy_665a_Tpl2GlobalWrite) the DET error has occurred.
*/
#if (defined PHY_665A_TPL2_GLOBAL_WRITE_SVCID)
#error defined PHY_665A_TPL2_GLOBAL_WRITE_SVCID is already defined
#endif
#define PHY_665A_TPL2_GLOBAL_WRITE_SVCID 0x9C

/*
 * Macro used for defining in  which function(Phy_665a_TdEnQueue) the DET error has occurred.
*/
#if (defined PHY_665A_TD_EN_QUEUE_SVCID)
#error defined PHY_665A_TD_EN_QUEUE_SVCID is already defined
#endif
#define PHY_665A_TD_EN_QUEUE_SVCID 0x9D

/*
 * Macro used for defining in  which function(Phy_665a_CancelTd) the DET error has occurred.
*/
#if (defined PHY_665A_CANCEL_TD_SVCID)
#error defined PHY_665A_CANCEL_TD_SVCID is already defined
#endif
#define PHY_665A_CANCEL_TD_SVCID 0x9E

#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
#if (STD_ON == PHY_665A_CAN_SW_QUEUE_SUPPORT_ENABLED)
/*
 * Macro used for defining in  which function(Phy_665a_DeQueueCan) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_MESSAGE_CAN_DEQUEUE_SVCID)
#error defined PHY_665A_IO_SEND_MESSAGE_CAN_DEQUEUE_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_MESSAGE_CAN_DEQUEUE_SVCID 0x9F
#endif /*(STD_ON == PHY_665A_CAN_SW_QUEUE_SUPPORT_ENABLED)*/
#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)*/

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
#if (STD_ON == PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED)
/*
 * Macro used for defining in  which function(Phy_665a_DeQueueSpi) the DET error has occurred.
*/
#if (defined PHY_665A_IO_SEND_MESSAGE_SPI_DEQUEUE_SVCID)
#error defined PHY_665A_IO_SEND_MESSAGE_SPI_DEQUEUE_SVCID is already defined
#endif
#define PHY_665A_IO_SEND_MESSAGE_SPI_DEQUEUE_SVCID 0xA0
#endif /*(STD_ON == PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED)*/
#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/

/*
 * Macro used for defining in  which function(Phy_665a_CanTrcvLowInit) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_TRCV_LOW_INIT_SVCID)
#error defined PHY_665A_CAN_TRCV_LOW_INIT_SVCID is already defined
#endif
#define PHY_665A_CAN_TRCV_LOW_INIT_SVCID 0xA1

/*
 * Macro used for defining in  which function(Phy_665a_CanTrcvHighInit) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_TRCV_HIGH_INIT_SVCID)
#error defined PHY_665A_CAN_TRCV_HIGH_INIT_SVCID is already defined
#endif
#define PHY_665A_CAN_TRCV_HIGH_INIT_SVCID 0xA2

/*
 * Macro used for defining in  which function(Phy_665a_AnalyzeReqPortCfgTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_ANALYZE_REQ_PORTCFG_TPL2_SVCID)
#error defined PHY_665A_ANALYZE_REQ_PORTCFG_TPL2_SVCID is already defined
#endif
#define PHY_665A_ANALYZE_REQ_PORTCFG_TPL2_SVCID 0xA3

/*
 * Macro used for defining in  which function(Phy_665a_SingleChainAnalyzeReqPortCfgTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_SINGLE_CHAIN_ANALYZE_REQ_PORT_CFG_TPL2_SVCID)
#error defined PHY_665A_SINGLE_CHAIN_ANALYZE_REQ_PORT_CFG_TPL2_SVCID is already defined
#endif
#define PHY_665A_SINGLE_CHAIN_ANALYZE_REQ_PORT_CFG_TPL2_SVCID 0xA4

/*
 * Macro used for defining in  which function(Phy_665a_NonGlobalReqAnalyzeTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_NON_GLOBAL_REQ_ANALYZE_TPL2_SVCID)
#error defined PHY_665A_NON_GLOBAL_REQ_ANALYZE_TPL2_SVCID is already defined
#endif
#define PHY_665A_NON_GLOBAL_REQ_ANALYZE_TPL2_SVCID 0xA5

/*
 * Macro used for defining in  which function(Phy_665a_NonGlobalReqNonLoopBckPortAnalyzeTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_NON_GLOBAL_REQ_NON_LOOP_BCK_PORT_ANALYZE_TPL2_SVCID)
#error defined PHY_665A_NON_GLOBAL_REQ_NON_LOOP_BCK_PORT_ANALYZE_TPL2_SVCID is already defined
#endif
#define PHY_665A_NON_GLOBAL_REQ_NON_LOOP_BCK_PORT_ANALYZE_TPL2_SVCID 0xA6

/*
 * Macro used for defining in  which function(Phy_665a_NonGlobalReqLoopBckPortAnalyzeTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_NON_GLOBAL_REQ_LOOP_BCK_PORT_ANALYZE_TPL2_SVCID)
#error defined PHY_665A_NON_GLOBAL_REQ_LOOP_BCK_PORT_ANALYZE_TPL2_SVCID is already defined
#endif
#define PHY_665A_NON_GLOBAL_REQ_LOOP_BCK_PORT_ANALYZE_TPL2_SVCID 0xA7

/*
 * Macro used for defining in  which function(Phy_665a_GlbAnalyzePortCfgTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_GLB_ANALYZE_PORT_CFG_TPL2_SVCID)
#error defined PHY_665A_GLB_ANALYZE_PORT_CFG_TPL2_SVCID is already defined
#endif
#define PHY_665A_GLB_ANALYZE_PORT_CFG_TPL2_SVCID 0xA8

/*
 * Macro used for defining in  which function(Phy_665a_GlbAnalyzeEachPortCfgTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_GLB_ANALYZE_EACH_PORT_CFG_TPL2_SVCID)
#error defined PHY_665A_GLB_ANALYZE_EACH_PORT_CFG_TPL2_SVCID is already defined
#endif
#define PHY_665A_GLB_ANALYZE_EACH_PORT_CFG_TPL2_SVCID 0xA9

/*
 * Macro used for defining in  which function(Phy_665a_SpiSlotFillTpl2Write) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_SLOT_FILL_TPL2_WRITE_SVCID)
#error defined PHY_665A_SPI_SLOT_FILL_TPL2_WRITE_SVCID is already defined
#endif
#define PHY_665A_SPI_SLOT_FILL_TPL2_WRITE_SVCID 0xAA

/*
 * Macro used for defining in  which function(Phy_665a_PackNextBatchInterruptContext) the DET error has occurred.
*/
#if (defined PHY_665A_PACK_BATCH_INTERRUPT_CONTEXT_SVCID)
#error defined PHY_665A_PACK_BATCH_INTERRUPT_CONTEXT_SVCID is already defined
#endif
#define PHY_665A_PACK_BATCH_INTERRUPT_CONTEXT_SVCID 0xAB

/*
 * Macro used for defining in  which function(Phy_665a_Spi_Init) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_DEV_INIT_SVCID)
#error defined PHY_665A_SPI_DEV_INIT_SVCID is already defined
#endif
#define PHY_665A_SPI_DEV_INIT_SVCID 0xAC

/*
 * Macro used for defining in  which function(Phy_665a_Can_Init) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_DEV_INIT_SVCID)
#error defined PHY_665A_CAN_DEV_INIT_SVCID is already defined
#endif
#define PHY_665A_CAN_DEV_INIT_SVCID 0xAD

/*
 * Macro used for defining in  which function(Phy_665a_GetDevInitProgressStatus) the DET error has occurred.
*/
#if (defined PHY_665A_GET_DEV_INIT_PROGRESS_STATUS_SVCID)
#error defined PHY_665A_GET_DEV_INIT_PROGRESS_STATUS_SVCID is already defined
#endif
#define PHY_665A_GET_DEV_INIT_PROGRESS_STATUS_SVCID 0xAE

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt0SelInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_0_SEL_SVCID)
#error defined PHY_665A_EVH_INT_0_SEL_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_0_SEL_SVCID 0xB3

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt1SelInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_1_SEL_SVCID)
#error defined PHY_665A_EVH_INT_1_SEL_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_1_SEL_SVCID 0xB4

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt2SelInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_2_SEL_SVCID)
#error defined PHY_665A_EVH_INT_2_SEL_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_2_SEL_SVCID 0xB5

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt3SelInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_3_SEL_SVCID)
#error defined PHY_665A_EVH_INT_3_SEL_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_3_SEL_SVCID 0xB6

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt0CfgInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_0_CFG_INIT_SVCID)
#error defined PHY_665A_EVH_INT_0_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_0_CFG_INIT_SVCID 0xB7

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt1CfgInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_1_CFG_INIT_SVCID)
#error defined PHY_665A_EVH_INT_1_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_1_CFG_INIT_SVCID 0xB8

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt2CfgInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_2_CFG_INIT_SVCID)
#error defined PHY_665A_EVH_INT_2_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_2_CFG_INIT_SVCID 0xB9

/*
 * Macro used for defining in  which function(Phy_665a_EvhInt3CfgInit) the DET error has occurred.
*/
#if (defined PHY_665A_EVH_INT_3_CFG_INIT_SVCID)
#error defined PHY_665A_EVH_INT_3_CFG_INIT_SVCID is already defined
#endif
#define PHY_665A_EVH_INT_3_CFG_INIT_SVCID 0xBA

/*
 * Macro used for defining in which function(Phy_665a_GpioCfg0Init) the DET error has occurred.
*/
#if (defined PHY_665A_GPIO_CFG_0_INIT_SVCID)
#error defined PHY_665A_GPIO_CFG_0_INIT_SVCID is already defined
#endif
#define PHY_665A_GPIO_CFG_0_INIT_SVCID 0xBB

/*
 * Macro used for defining in which function(Phy_665a_GpioCfg1Init) the DET error has occurred.
*/
#if (defined PHY_665A_GPIO_CFG_1_INIT_SVCID)
#error defined PHY_665A_GPIO_CFG_1_INIT_SVCID is already defined
#endif
#define PHY_665A_GPIO_CFG_1_INIT_SVCID 0xBC

/*
 * Macro used for defining in  which function(Phy_665a_SpiWriteMsgSendFuncSyncStartEncounteredState) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID)
#error PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID is already defined
#endif
#define PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID 0xBFU

/*
 * Macro used for defining in  which function(Phy_665a_SpiWriteMsgSendFuncSyncNotStartedState) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID)
#error PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID is already defined
#endif
#define PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID 0xC0U

/*
 * Macro used for defining in  which function(Phy_665a_SpiWriteMsgSendFuncSyncPendingState) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID)
#error PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID is already defined
#endif
#define PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID 0xC1U

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSwTriggCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_VERIFY_SYNC_SW_TRIGG_CMD_TPL3_SVCID)
#error PHY_665A_SPI_VERIFY_SYNC_SW_TRIGG_CMD_TPL3_SVCID is already defined
#endif
#define PHY_665A_SPI_VERIFY_SYNC_SW_TRIGG_CMD_TPL3_SVCID 0xC2U

/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSchedCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_VERIFY_SYNC_SCHED_CMD_TPL3_SVCID)
#error PHY_665A_SPI_VERIFY_SYNC_SCHED_CMD_TPL3_SVCID is already defined
#endif
#define PHY_665A_SPI_VERIFY_SYNC_SCHED_CMD_TPL3_SVCID 0xC3U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/
/*
 * Macro used for defining in  which function(Phy_665a_SpiReadMsgSendFuncSyncNotStartedState) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_READ_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID)
#error PHY_665A_SPI_READ_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID is already defined
#endif
#define PHY_665A_SPI_READ_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID 0xC4U

/*
 * Macro used for defining in  which function(Phy_665a_SpiWriteMsgSendFuncSyncHaltState) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_HALT_STATE_SVCID)
#error PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_HALT_STATE_SVCID is already defined
#endif
#define PHY_665A_SPI_WRITE_MSG_SEND_FUNC_SYNC_HALT_STATE_SVCID 0xC6U

/*
 * Macro used for defining in  which function(Phy_665a_SpiSyncMsgSendFunc) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_SYNC_MSG_SEND_FUNC_SVCID)
#error PHY_665A_SPI_SYNC_MSG_SEND_FUNC_SVCID is already defined
#endif
#define PHY_665A_SPI_SYNC_MSG_SEND_FUNC_SVCID 0xC7U

/*
 * Macro used for defining in  which function the DET error has occurred.
*/
#if (defined PHY_665A_SPI_SYNC_MSG_SEND_ERR_SVCID)
#error PHY_665A_SPI_SYNC_MSG_SEND_ERR_SVCID is already defined
#endif
#define PHY_665A_SPI_SYNC_MSG_SEND_ERR_SVCID 0xC9U

/*
 * Macro used for defining in  which function(Phy_665a_SpiMsgSendFuncSyncStartEncounteredState) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID)
#error PHY_665A_SPI_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID is already defined
#endif
#define PHY_665A_SPI_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID 0xCAU

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
* Macro used for defining in which function(Phy_665a_GetRegAddInTpl3Format) the DET error has occurred.
*/
#if (defined PHY_665A_GET_REG_ADD_IN_TPL3_FORMAT_SVCID)
#error defined PHY_665A_GET_REG_ADD_IN_TPL3_FORMAT_SVCID is already defined
#endif
#define PHY_665A_GET_REG_ADD_IN_TPL3_FORMAT_SVCID 0xCB
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
* Macro used for defining in which function(Phy_665a_GetRegAddInTpl2Format) the DET error has occurred.
*/
#if (defined PHY_665A_GET_REG_ADD_IN_TPL2_FORMAT_SVCID)
#error defined PHY_665A_GET_REG_ADD_IN_TPL2_FORMAT_SVCID is already defined
#endif
#define PHY_665A_GET_REG_ADD_IN_TPL2_FORMAT_SVCID 0xCC
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

/*
 * Macro used for defining in which function(Phy_665a_GetRamtTblMember) the DET error has occurred.
*/
#if (defined PHY_665A_GET_RAM_TABLE_MEMBER_SVCID)
#error defined PHY_665A_GET_RAM_TABLE_MEMBER_SVCID is already defined
#endif
#define PHY_665A_GET_RAM_TABLE_MEMBER_SVCID 0xCD

/*
 * Macro used for defining in which function(Phy_665a_CanSyncMsgSendFunc) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_SYNC_MSG_SEND_FUNC_SVCID)
#error defined PHY_665A_CAN_SYNC_MSG_SEND_FUNC_SVCID is already defined
#endif
#define PHY_665A_CAN_SYNC_MSG_SEND_FUNC_SVCID 0xCE

/*
 * Macro used for defining in which function(Phy_665a_CanMsgSendFuncInactiveMode) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_MSG_SEND_FUNC_INACTIVE_MODE_SVCID)
#error defined PHY_665A_CAN_MSG_SEND_FUNC_INACTIVE_MODE_SVCID is already defined
#endif
#define PHY_665A_CAN_MSG_SEND_FUNC_INACTIVE_MODE_SVCID 0xCF

/*
 * Macro used for defining in which function(Phy_665a_CanMsgSendFuncSyncNotStartedState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID)
#error defined PHY_665A_CAN_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID 0xD0

/*
 * Macro used for defining in which function(Phy_665a_CanWriteMsgSendFuncSyncNotStartedState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID)
#error defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID 0xD1

/*
 * Macro used for defining in which function(Phy_665a_CanReadMsgSendFuncSyncNotStartedState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_READ_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID)
#error defined PHY_665A_CAN_READ_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_READ_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID 0xD2

/*
 * Macro used for defining in which function(Phy_665a_CanMsgSendFuncSwActiveMode) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_MSG_SEND_FUNC_SW_ACTIVE_MODE_SVCID)
#error defined PHY_665A_CAN_MSG_SEND_FUNC_SW_ACTIVE_MODE_SVCID is already defined
#endif
#define PHY_665A_CAN_MSG_SEND_FUNC_SW_ACTIVE_MODE_SVCID 0xD3

/*
 * Macro used for defining in which function(Phy_665a_CanMsgSendFuncSyncStartEncounteredState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID)
#error defined PHY_665A_CAN_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID 0xD4

/*
 * Macro used for defining in which function(Phy_665a_CanWriteMsgSendFuncSyncStartEncounteredState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID)
#error defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_START_ENCOUNTERED_STATE_SVCID 0xD5

/*
 * Macro used for defining in which function(Phy_665a_CanWriteMsgSendFuncSyncPendingState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID)
#error defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID 0xD6

/*
 * Macro used for defining in which function(Phy_665a_CanReadMsgSendFuncSyncPendingState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_READ_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID)
#error defined PHY_665A_CAN_READ_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_READ_MSG_SEND_FUNC_SYNC_PENDING_STATE_SVCID 0xD7

/*
 * Macro used for defining in which function(Phy_665a_CanWriteMsgSendFuncSyncHaltState) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_HALT_STATE_SVCID)
#error defined PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_HALT_STATE_SVCID is already defined
#endif
#define PHY_665A_CAN_WRITE_MSG_SEND_FUNC_SYNC_HALT_STATE_SVCID 0xD8

/*
 * Macro used for defining in which function(Phy_665a_SYNC_HoldMessage) the DET error has occurred.
*/
#if (defined PHY_665A_SYNC_HOLD_MSG_SVCID)
#error defined PHY_665A_SYNC_HOLD_MSG_SVCID is already defined
#endif
#define PHY_665A_SYNC_HOLD_MSG_SVCID 0xD9

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining in which function(Phy_665a_VerifySyncHwTriggCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_VERIFY_SYNC_HW_TRIGG_CMD_TPL3_SVCID)
#error defined PHY_665A_SPI_VERIFY_SYNC_HW_TRIGG_CMD_TPL3_SVCID is already defined
#endif
#define PHY_665A_SPI_VERIFY_SYNC_HW_TRIGG_CMD_TPL3_SVCID 0xDA

/*
 * Macro used for defining in which function(Phy_665a_VerifyExtQueueFlushCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_VERIFY_EXT_QUEUE_FLUSH_CMD_TPL3_SVCID)
#error defined PHY_665A_VERIFY_EXT_QUEUE_FLUSH_CMD_TPL3_SVCID is already defined
#endif
#define PHY_665A_VERIFY_EXT_QUEUE_FLUSH_CMD_TPL3_SVCID 0xDB
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
 * Macro used for defining in which function(Phy_665a_VerifQueueFlushCmdTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_VERIFY_QUEUE_FLUSH_CMD_TPL2_SVCID)
#error defined PHY_665A_VERIFY_QUEUE_FLUSH_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_VERIFY_QUEUE_FLUSH_CMD_TPL2_SVCID 0xDC
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

/*
 * Macro used for defining in which function(Phy_665a_SpiMsgSendFuncSyncNotStartedState) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID)
#error defined PHY_665A_SPI_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID is already defined
#endif
#define PHY_665A_SPI_MSG_SEND_FUNC_SYNC_NOT_STARTED_STATE_SVCID 0xDD

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
 * Macro used for defining in which function(Phy_665a_VerifySyncSchedCmdTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_VERIFY_SYNC_SCHED_CMD_TPL2_SVCID)
#error defined PHY_665A_SPI_VERIFY_SYNC_SCHED_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_SPI_VERIFY_SYNC_SCHED_CMD_TPL2_SVCID 0xDE

/*
 * Macro used for defining in which function(Phy_665a_VerifySyncSwTriggCmdTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_VERIFY_SYNC_SW_TRIGG_CMD_TPL2_SVCID)
#error defined PHY_665A_SPI_VERIFY_SYNC_SW_TRIGG_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_SPI_VERIFY_SYNC_SW_TRIGG_CMD_TPL2_SVCID 0xDF

/**
 * Macro used for defining in which function(Phy_665a_VerifySyncHwTriggCmdTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_VERIFY_SYNC_HW_TRIGG_CMD_TPL2_SVCID)
#error defined PHY_665A_SPI_VERIFY_SYNC_HW_TRIGG_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_SPI_VERIFY_SYNC_HW_TRIGG_CMD_TPL2_SVCID 0xE0

/**
 * Macro used for defining in which function(Phy_665a_VerifyWriteGpioOutputCmdTpl2) the DET error has occurred.
*/
#if (defined PHY_665A_VERIFY_WRITE_GPIO_OUTPUT_CMD_TPL2_SVCID)
#error defined PHY_665A_VERIFY_WRITE_GPIO_OUTPUT_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_VERIFY_WRITE_GPIO_OUTPUT_CMD_TPL2_SVCID 0xE2
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

/*
 * Macro used for defining in  which function(Phy_665a_SYNC_GpioMessage) the DET error has occurred.
*/

#if (defined PHY_665A_SYNC_GPIO_MESSAGE_SVCID)
#error PHY_665A_SYNC_GPIO_MESSAGE_SVCID is already defined
#endif
#define PHY_665A_SYNC_GPIO_MESSAGE_SVCID 0xE3U

/*
 * Macro used for defining in  which function(Phy_665a_WriteSingleReg) the DET error has occurred.
*/
#if (defined PHY_665A_WRITE_SINGLE_REG_SVCID)
#error PHY_665A_WRITE_SINGLE_REG_SVCID is already defined
#endif
#define PHY_665A_WRITE_SINGLE_REG_SVCID 0xE4U

/*
 * Macro used for defining in  which function(Phy_665a_WriteSingleReg) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_SEND_WRITE_INIT_MSG_SVCID)
#error PHY_665A_SPI_SEND_WRITE_INIT_MSG_SVCID is already defined
#endif
#define PHY_665A_SPI_SEND_WRITE_INIT_MSG_SVCID 0xE5U

/*
 * Macro used for defining in  which function(Phy_665a_WriteSingleReg) the DET error has occurred.
*/
#if (defined PHY_665A_SPI_SEND_READ_INIT_MSG_SVCID)
#error PHY_665A_SPI_SEND_READ_INIT_MSG_SVCID is already defined
#endif
#define PHY_665A_SPI_SEND_READ_INIT_MSG_SVCID 0xE6U

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSwTriggCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_VERIFY_SYNC_SW_TRIGG_CMD_TPL3_SVCID)
#error PHY_665A_CAN_VERIFY_SYNC_SW_TRIGG_CMD_TPL3_SVCID is already defined
#endif
#define PHY_665A_CAN_VERIFY_SYNC_SW_TRIGG_CMD_TPL3_SVCID 0xE5U

/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSchedCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_VERIFY_SYNC_SCHED_CMD_TPL3_SVCID)
#error PHY_665A_CAN_VERIFY_SYNC_SCHED_CMD_TPL3_SVCID is already defined
#endif
#define PHY_665A_CAN_VERIFY_SYNC_SCHED_CMD_TPL3_SVCID 0xE6U

/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSchedCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_VERIFY_SYNC_HW_TRIGG_CMD_TPL3_SVCID)
#error PHY_665A_CAN_VERIFY_SYNC_HW_TRIGG_CMD_TPL3_SVCID is already defined
#endif
#define PHY_665A_CAN_VERIFY_SYNC_HW_TRIGG_CMD_TPL3_SVCID 0xE7U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSwTriggCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_VERIFY_SYNC_SW_TRIGG_CMD_TPL2_SVCID)
#error PHY_665A_CAN_VERIFY_SYNC_SW_TRIGG_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_CAN_VERIFY_SYNC_SW_TRIGG_CMD_TPL2_SVCID 0xE8U

/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSchedCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_VERIFY_SYNC_SCHED_CMD_TPL2_SVCID)
#error PHY_665A_CAN_VERIFY_SYNC_SCHED_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_CAN_VERIFY_SYNC_SCHED_CMD_TPL2_SVCID 0xE9U

/*
 * Macro used for defining in  which function(Phy_665a_VerifySyncSchedCmdTpl3) the DET error has occurred.
*/
#if (defined PHY_665A_CAN_VERIFY_SYNC_HW_TRIGG_CMD_TPL2_SVCID)
#error PHY_665A_CAN_VERIFY_SYNC_HW_TRIGG_CMD_TPL2_SVCID is already defined
#endif
#define PHY_665A_CAN_VERIFY_SYNC_HW_TRIGG_CMD_TPL2_SVCID 0xEAU
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

/*
 * Macro used for defining in  which function(Phy_665a_InternalTdHandlerGpt) the DET error has occurred.
*/
#if (defined PHY_665A_INTERNAL_TD_HANDLER_GPT_SVCID)
#error PHY_665A_INTERNAL_TD_HANDLER_GPT_SVCID is already defined
#endif
#define PHY_665A_INTERNAL_TD_HANDLER_GPT_SVCID 0xEBU

/*
 * Macro used for defining in  which function(Phy_665a_COM_ReadRegisters) the DET error has occurred.
*/
#if (defined PHY_665A_COM_READREGISTERS_SVCID)
#error PHY_665A_COM_READREGISTERS_SVCID is already defined
#endif
#define PHY_665A_COM_READREGISTERS_SVCID 0xECU

/*
 * Macro used for defining in  which function(Phy_665a_COM_WriteRegisters) the DET error has occurred.
*/
#if (defined PHY_665A_COM_WRITEREGISTERS_SVCID)
#error PHY_665A_COM_WRITEREGISTERS_SVCID is already defined
#endif
#define PHY_665A_COM_WRITEREGISTERS_SVCID 0xEDU

/*
 * Macro used for defining that the DET error has occurred due to calculate request timeout API.
*/
#if (defined PHY_665A_CALCULATE_REQUEST_TIMEOUT_SVCID)
#error defined PHY_665A_CALCULATE_REQUEST_TIMEOUT_SVCID is already defined
#endif
#define PHY_665A_CALCULATE_REQUEST_TIMEOUT_SVCID 0xEEU

/*
 * Macro used for defining that the DET error has occurred due to failing of Spi_SetupEB API.
*/
#if (defined PHY_665A_SPIIF_WRITE_SVCID)
#error defined PHY_665A_SPIIF_WRITE_SVCID is already defined
#endif
#define PHY_665A_SPIIF_WRITE_SVCID 0xEFU

/*
 * Macro used for defining that the DET error has occurred due to failing of Spi_SetupEB API.
*/
#if (defined PHY_665A_SPIIF_READ_WRITE_FULL_DUPLEX_ASYNCH_SVCID)
#error defined PHY_665A_SPIIF_READ_WRITE_FULL_DUPLEX_ASYNCH_SVCID is already defined
#endif
#define PHY_665A_SPIIF_READ_WRITE_FULL_DUPLEX_ASYNCH_SVCID 0xF0U

#endif/*(PHY_665A_DEV_ERROR_DETECT == STD_ON)*/

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

#define PHY_665A_START_SEC_VAR_INIT_16
#include "Phy_665a_MemMap.h"
#if (PHY_665A_CAN_SUPPORT_ENABLED == STD_ON)
extern uint16 Phy_665a_CanPreTxBuff[];
#endif
#define PHY_665A_STOP_SEC_VAR_INIT_16
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"
extern uint16 Phy_665a_GlblDestArrSize;
extern uint16* Phy_665aGlbRespBuffPtr;
#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
extern uint16* Phy_665aGlbRespBuffPtr;
#endif
#define PHY_665A_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Phy_665a_MemMap.h"
extern Phy_665a_InitializationStateType Phy_665a_DeviceState[PHY_665A_NUMBER_OF_665A_DEVICES];
#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
extern Phy_665a_InternalStatesType Phy_665a_CanInternalDeviceState[PHY_665A_NUMBER_OF_665A_DEVICES];
extern Phy_665a_InitializationStateType Phy_665a_InitProcessingFlg;
#endif
#define PHY_665A_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Phy_665a_MemMap.h"
#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
/*
 * An instance of global structure GlobalInfo_t to hold the information about the  Transaction Descriptor Error status and Slot index..
 */
extern Phy_665a_GlobalInfoType Phy_665a_GlobalSpiInfo;
#endif
#define PHY_665A_STOP_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Phy_665a_MemMap.h"
/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/

#define PHY_665A_START_SEC_CODE
#include "Phy_665a_MemMap.h"

/*!
 * @brief Phy_665a driver initialization
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       McuIfProtocol
 * @param[out]      void
 * @param[inout]    void
 *
 * @return Std_ReturnType
 * @retval E_OK             Phy_665a initialization completed successfully.
 * @retval E_NOT_OK         Phy_665a initialization failed.
 */
Std_ReturnType Phy_665a_Init(Phy_665aMcuIfProtcol_Type McuIfProtocol);

/*!
 * @brief Phy_665a driver deinitialization
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       McuIfProtocol
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_DeInit(Phy_665aMcuIfProtcol_Type McuIfProtocol);

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
#if (STD_ON == PHY_665A_SPI_ASYNC_INIT_SUPPORT_ENABLED)
/*!
 * @brief Phy_665a device wake-up
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       McuIfProtocol
 * @param[out]      void
 * @param[inout]    void
 *
 * @return Std_ReturnType
 * @retval E_OK             Phy_665a device wake-up completed successfully.
 * @retval E_NOT_OK         Phy_665a device wake-up failed.
 */
Std_ReturnType Phy_665a_WakeUp(Phy_665aMcuIfProtcol_Type McuIfProtocol);
#endif /*(STD_ON == PHY_665A_SPI_ASYNC_INIT_SUPPORT_ENABLED)*/
#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/

/*!
 * @brief Phy_665a device initialization state reading
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       DeviceIdx
 * @param[out]      void
 * @param[inout]    void
 *
 * @return Phy_665a_InitializationStateType
 * @retval PHY_665A_DEVICE_UNINITIALIZED        Device is not initialized
 * @retval PHY_665A_INITIALIZATION_IN_PROGRESS  Device initilazation in progress
 * @retval PHY_665A_INITIALIZATION_FINISHED     Device initilazation is finished on all devices
 * @retval PHY_665A_INITIALIZATION_FAILED       Reported if any MC33665SA device on failed to initialize
 * @retval PHY_665A_INITIALIZATION_TIMED_OUT    Reported in case of communication timeout
 * @retval PHY_665A_INVALID_DEVICE              Device configuration index is not valid
 * @retval PHY_665A_DEVICE_WAKEUP               Device is awake
 */
Phy_665a_InitializationStateType Phy_665a_GetDevInitProgressStatus(Phy_DeviceIdxType DeviceIdx);

/*!
 * @brief Starts transferring the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      ErrorStatus
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Transactino Descriptor was accepted for transfer.
 * @retval E_NOT_OK         Transactino Descriptor was rejected.
 */
Std_ReturnType Phy_665a_IO_SendMessage(Phy_TDType* TransactionDescriptor, Phy_ErrorStatusType* ErrorStatus);

/*!
 * @brief Cancels the provided TD if present in SPI or CAN software queues
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 * 
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Transactino Descriptor transfer was cancelled.
 * @retval E_NOT_OK         Transactino Descriptor transfer failed to cancel.
 */
Std_ReturnType Phy_665a_CancelTd(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Cancels all the queued TDs present in SPI and CAN software queues
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 * 
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_CancelAllTds(void);

/*!
 * @brief Updates the targeted PhyDeviceIndex in the provided TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       PhyIndex
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Transactino Descriptor device index updated successfully.
 * @retval E_NOT_OK         Transactino Descriptor device index failed to update.
 */
Std_ReturnType Phy_665a_UpdateInternalTDIndex(Phy_TDType* TransactionDescriptor, Phy_DeviceIdxType PhyIndex);

/*!
 * @brief Cleares content in the provided TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Internal Transactino Descriptor was cleared successfully.
 * @retval E_NOT_OK         Internal Transactino Descriptor failed to get cleared.
 */
Std_ReturnType Phy_665a_ClearInternalTD(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a SCHED_CMD write message at the RequestPtr location
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       DeviceIdx, TplType, Event, Operand
 * @param[out]      RequestPtr
 * @param[inout]    void
 *
 * @return Std_ReturnType
 * @retval E_OK             SCHED_CMD write message packed successfully.
 * @retval E_NOT_OK         SCHED_CMD write message failed to pack.
 */
uint8 Phy_665a_SchedMessage(Phy_DeviceIdxType DeviceIdx, Phy_TplProtocolType TplType, Phy_EventType Event, uint16 Operand, uint16* RequestPtr);

/*!
 * @brief Packs a read message for SYS_CFG_CRC register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_CFG_CRC read message was packed successfully.
 * @retval E_NOT_OK         SYS_CFG_CRC read message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_ReadCrcReg(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a read message for SYS_QUEUE_STAT register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_QUEUE_STAT read message was packed successfully.
 * @retval E_NOT_OK         SYS_QUEUE_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_ReadQueueStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a read message for HW version registers in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Following registers will be read with this API
 *            SYS_VERSION
 *            SYS_UID_LOW
 *            SYS_UID_MID
 *            SYS_UID_HIGH
 *            SYS_PROD_VER
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             HW version registers read message was packed successfully.
 * @retval E_NOT_OK         HW version registers read message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_GetHardwareVersion(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a read message for SYS_QUEUE_CTRL register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_QUEUE_CTRL read message was packed successfully.
 * @retval E_NOT_OK         SYS_QUEUE_CTRL read message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_ReadQueueCtrlReg(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a write message for SYS_QUEUE_CTRL register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ClearMsg
 * @param[in]       HoldMsg
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_QUEUE_CTRL write message was packed successfully.
 * @retval E_NOT_OK         SYS_QUEUE_CTRL write message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_WriteQueueCtrlReg(Phy_TDType* TransactionDescriptor, Phy_665a_ClearMessageType ClearMsg, Phy_665a_HoldMessageType HoldMsg);

/*!
 * @brief Wrapper function which packs a clear message for SYS_QUEUE_CTRL register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ClearMsg
 * @param[in]       HoldMsg
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_QUEUE_CTRL clear message was packed successfully.
 * @retval E_NOT_OK         SYS_QUEUE_CTRL clear message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_ClearQueue(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a write message for SYS_PORTx_CFG (x=0:3) register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Following registers can be written with this API
 *            SYS_PORT0_CFG
 *            SYS_PORT1_CFG
 *            SYS_PORT2_CFG
 *            SYS_PORT3_CFG
 *
 * @param[in]       TplNumPort_CfgPtr
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_PORTx_CFG write message was packed successfully.
 * @retval E_NOT_OK         SYS_PORTx_CFG write message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_WriteTplPortCfg(Phy_TDType* TransactionDescriptor, Phy_665a_TplNumPortConfigType* TplNumPort_CfgPtr);

/*!
 * @brief Packs a read message for SYS_COM_CFG register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_COM_CFG read message was packed successfully.
 * @retval E_NOT_OK         SYS_COM_CFG read message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_ReadComCfg(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a write message for SYS_MODE register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       SysTargetMode
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SYS_MODE write message was packed successfully.
 * @retval E_NOT_OK         SYS_MODE write message failed to get packed.
 */
Std_ReturnType Phy_665a_SYS_WriteTargetMode(Phy_TDType* TransactionDescriptor, Phy_665a_TargetModeType SysTargetMode);

/*!
 * @brief Packs a write message for EVH_INTx_SEL (x=0:3) register in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Following registers can be written with this API
 *            EVH_INT0_SEL
 *            EVH_INT1_SEL
 *            EVH_INT2_SEL
 *            EVH_INT3_SEL
 *
 * @param[in]       Event_Config_Ptr
 * @param[in]       NumOfEvents
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_INTx_SEL write message was packed successfully.
 * @retval E_NOT_OK         EVH_INTx_SEL write message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ConfigIntSource(Phy_665a_Event_Config_TblType* Event_Config_Ptr, uint8 NumOfEvents, Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a multi error status register read messages in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Following registers are read with this API
 *            EVH_GRP_ERR_STAT
 *            EVH_GENERAL_ERR_STAT
 *            EVH_MCUIF_ERR_STAT
 *            EVH_TPL0_ERR_STAT
 *            EVH_TPL1_ERR_STAT
 *            EVH_TPL2_ERR_STAT
 *            EVH_TPL3_ERR_STAT
 *            EVH_ACC_ERR
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Registers read messages was packed successfully.
 * @retval E_NOT_OK         Registers read messages failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadAllErrReg(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_WAKEUP_REASON register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_WAKEUP_REASON read message was packed successfully.
 * @retval E_NOT_OK         EVH_WAKEUP_REASON read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadWakeUpReason(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_RST_REASON register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_RST_REASON read message was packed successfully.
 * @retval E_NOT_OK         EVH_RST_REASON read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadResetReason(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_QUEUE_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_QUEUE_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_QUEUE_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadQueueStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_GRP_ERR_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_GRP_ERR_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_GRP_ERR_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadGroupErrStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_GENERAL_ERR_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_GENERAL_ERR_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_GENERAL_ERR_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadGeneralErrStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_MCUIF_ERR_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_MCUIF_ERR_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_MCUIF_ERR_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadMcuIfErrStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_TPL0_ERR_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_TPL0_ERR_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_TPL0_ERR_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadTpl0ErrStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_TPL1_ERR_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_TPL1_ERR_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_TPL1_ERR_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadTpl1ErrStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_TPL2_ERR_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_TPL2_ERR_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_TPL2_ERR_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadTpl2ErrStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_TPL3_ERR_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_TPL3_ERR_STAT read message was packed successfully.
 * @retval E_NOT_OK         EVH_TPL3_ERR_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadTpl3ErrStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_ACC_ERR register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_ACC_ERR read message was packed successfully.
 * @retval E_NOT_OK         EVH_ACC_ERR read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadAccErrReg(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a EVH_CFG_CRC register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             EVH_CFG_CRC read message was packed successfully.
 * @retval E_NOT_OK         EVH_CFG_CRC read message failed to get packed.
 */
Std_ReturnType Phy_665a_EVH_ReadCrcReg(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a SCHED_STAT register read command in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             SCHED_STAT read message was packed successfully.
 * @retval E_NOT_OK         SCHED_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_SCHED_ReadStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a SCHED_EVENT write message at the RequestPtr location
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       DeviceIdx, TplType
 * @param[out]      RequestPtr
 * @param[inout]    void
 *
 * @return Std_ReturnType
 * @retval E_OK             SCHED_EVENT write message packed successfully.
 * @retval E_NOT_OK         SCHED_EVENT write message failed to pack.
 */
uint8 Phy_665a_SYNC_SwTrigMessage(Phy_DeviceIdxType DeviceIdx, Phy_TplProtocolType TplType, uint16* RequestPtr);

/*!
 * @brief Packs a GPIO_OUT register write message at the RequestPtr location
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          Toggles HW GPIO output used as signaling in HW SYNC scenario
 * 
 * @param[in]       DeviceIdx
 * @param[in]       TplType
 * @param[in]       GpioLevel
 * @param[out]      RequestPtr
 * @param[inout]    void
 *
 * @return Std_ReturnType
 * @retval E_OK             GPIO_OUT write message packed successfully.
 * @retval E_NOT_OK         GPIO_OUT write message failed to pack.
 */
uint8 Phy_665a_SYNC_GpioMessage(Phy_DeviceIdxType DeviceIdx, Phy_TplProtocolType TplType, uint8 GpioLevel, uint16* RequestPtr);

/*!
 * @brief Packs a SYNC HOLD time message at the RequestPtr location
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          SYNC HOLD user input used in HW SYNC scenario represents the amount of time
 *          which is required from the HW trigger until all the data in the SYNC scenario
 *          is completely transferred (all requests and responses)
 * 
 * @param[in]       DeviceIdx
 * @param[in]       TplType
 * @param[in]       TimeOprnd
 * @param[out]      RequestPtr
 * @param[inout]    void
 *
 * @return Std_ReturnType
 * @retval E_OK             SYNC HOLD time message packed successfully.
 * @retval E_NOT_OK         SYNC HOLD time message failed to pack.
 */
uint8 Phy_665a_SYNC_HoldMessage(Phy_DeviceIdxType DeviceIdx, Phy_TplProtocolType TplType, uint32 TimeOprnd, uint16* RequestPtr);

/*!
 * @brief Packs general register read commands in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       RegAddr
 * @param[in]       RegCnt
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             general read messages were packed successfully.
 * @retval E_NOT_OK         general read messages failed to get packed.
 */
Std_ReturnType Phy_665a_COM_ReadRegisters(Phy_TDType* TransactionDescriptor, uint16 RegAddr, uint8 RegCnt);

/*!
 * @brief Packs general register write commands in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       Data
 * @param[in]       RegAddr
 * @param[in]       RegCnt
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             general write messages were packed successfully.
 * @retval E_NOT_OK         general write messages failed to get packed.
 */
Std_ReturnType Phy_665a_COM_WriteRegisters(Phy_TDType* TransactionDescriptor, uint16* Data, uint16 RegAddr, uint8 RegCnt);

#if (STD_ON == PHY_665A_GPIO_CHANNEL_CONFIG_SUPPORT_ENABLED)
/*!
 * @brief Packs a GPIO_CFGx (x=0:1) registers write messages in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Following registers are written with this API
 *            GPIO_CFG0
 *            GPIO_CFG1
 *
 * @param[in]       Gpio_Config_Ptr
 * @param[in]       NumChannels
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Registers write messages was packed successfully.
 * @retval E_NOT_OK         Registers write messages failed to get packed.
 */
Std_ReturnType Phy_665a_GPIO_WriteConfigReg(Phy_TDType* TransactionDescriptor, Phy_665a_Gpio_Config_TblType* Gpio_Config_Ptr, uint8 NumChannels);

/*!
 * @brief Packs a GPIO_IN register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             GPIO_IN read message was packed successfully.
 * @retval E_NOT_OK         GPIO_IN read message failed to get packed.
 */
Std_ReturnType Phy_665a_GPIO_ReadInputReg(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a GPIO_OUT register write message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       GpioList
 * @param[in]       NumberOfGpios
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             GPIO_OUT write message was packed successfully.
 * @retval E_NOT_OK         GPIO_OUT write message failed to get packed.
 */
Std_ReturnType Phy_665a_GPIO_WriteOutput(Phy_TDType* TransactionDescriptor, Phy_665a_Gpio_SetOutputType* GpioList, uint8 NumberOfGpios);
#endif /* (STD_ON == PHY_665A_GPIO_CHANNEL_CONFIG_SUPPORT_ENABLED) */

#if (STD_ON == PHY_665A_I2C_SUPPORT_ENABLED)
/*!
 * @brief Packs a I2C_STAT register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             I2C_STAT read message was packed successfully.
 * @retval E_NOT_OK         I2C_STAT read message failed to get packed.
 */
Std_ReturnType Phy_665a_I2C_ReadStatus(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a I2C_CTRL register read message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             I2C_CTRL read message was packed successfully.
 * @retval E_NOT_OK         I2C_CTRL read message failed to get packed.
 */
Std_ReturnType Phy_665a_I2C_ReadCtrl(Phy_TDType* TransactionDescriptor);

/*!
 * @brief Packs a I2C_DATAx (x=0:6) registers write messages in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Following registers are read with this API
 *            I2C_DATA0
 *            I2C_DATA1
 *            I2C_DATA2
 *            I2C_DATA3
 *            I2C_DATA4
 *            I2C_DATA5
 *            I2C_DATA6
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Registers write messages was packed successfully.
 * @retval E_NOT_OK         Registers write messages failed to get packed.
 */
Std_ReturnType Phy_665a_I2C_WriteDataReg(Phy_TDType* TransactionDescriptor, uint16* I2cDataBuffer, uint8 RegCnt);

/*!
 * @brief Packs a I2C_DATAx (x=0:6) registers read messages in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Following registers are read with this API
 *            I2C_DATA0
 *            I2C_DATA1
 *            I2C_DATA2
 *            I2C_DATA3
 *            I2C_DATA4
 *            I2C_DATA5
 *            I2C_DATA6
 *
 * @param[in]       RegCnt
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             Registers read messages was packed successfully.
 * @retval E_NOT_OK         Registers read messages failed to get packed.
 */
Std_ReturnType Phy_665a_I2C_ReadDataReg(Phy_TDType* TransactionDescriptor, uint8 RegCnt);

/*!
 * @brief Packs a I2C_CTRL register write message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             I2C_CTRL write message was packed successfully.
 * @retval E_NOT_OK         I2C_CTRL write message failed to get packed.
 */
Std_ReturnType Phy_665a_I2C_WriteControlReg(Phy_TDType* TransactionDescriptor, I2cConfigCtrlReg_Type* I2cConfigCtrl);

/*!
 * @brief Packs a I2C_CFG register write message in the TransactionDescriptor
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    TransactionDescriptor
 *
 * @return Std_ReturnType
 * @retval E_OK             I2C_CFG write message was packed successfully.
 * @retval E_NOT_OK         I2C_CFG write message failed to get packed.
 */
Std_ReturnType Phy_665a_I2C_WriteConfigReg(Phy_TDType* TransactionDescriptor, boolean I2cEnable);
#endif /*(STD_ON == PHY_665A_I2C_SUPPORT_ENABLED)*/

#define PHY_665A_STOP_SEC_CODE
#include "Phy_665a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_H */
