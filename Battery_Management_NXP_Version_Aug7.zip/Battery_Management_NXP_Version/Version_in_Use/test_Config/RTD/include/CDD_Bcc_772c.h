/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_BCC_772C_H
#define CDD_BCC_772C_H

/**
*   @file CDD_Bcc_772c.h
*
*   @addtogroup  CDD_BCC_772C
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
 *                                        INCLUDE FILES
 * 1) system and project includes
 * 2) needed interfaces from external units
 * 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bcc_772c_Cfg.h"
#include "SchM_Bcc_772c.h"

/*==================================================================================================
 *                              SOURCE FILE VERSION INFORMATION
 ==================================================================================================*/
#define BCC_772C_VENDOR_ID                    43
#define BCC_772C_MODULE_ID                    255
#define BCC_772C_AR_RELEASE_MAJOR_VERSION     4
#define BCC_772C_AR_RELEASE_MINOR_VERSION     7
#define BCC_772C_AR_RELEASE_REVISION_VERSION  0
#define BCC_772C_SW_MAJOR_VERSION             1
#define BCC_772C_SW_MINOR_VERSION             0
#define BCC_772C_SW_PATCH_VERSION             2

/*==================================================================================================
 *                                     FILE VERSION CHECKS
 ==================================================================================================*/

/* Check if this header file and Bcc_772c_Cfg.h are of the same vendor */
#if (BCC_772C_VENDOR_ID != BCC_772C_VENDOR_ID_CFG)
    #error "CDD_Bcc_772c.h and Bcc_772c_Cfg.h have different vendor ids"
#endif

/* Check if source file and Bcc_772c header file are of the same Autosar version */
#if ((BCC_772C_AR_RELEASE_MAJOR_VERSION != BCC_772C_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (BCC_772C_AR_RELEASE_MINOR_VERSION != BCC_772C_AR_RELEASE_MINOR_VERSION_CFG) || \
     (BCC_772C_AR_RELEASE_REVISION_VERSION != BCC_772C_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of CDD_Bcc_772c.h and Bcc_772c_Cfg.h are different"
#endif

/* Check if current file and Bcc_772c_Cfg header file are of the same Software version */
#if ((BCC_772C_SW_MAJOR_VERSION != BCC_772C_SW_MAJOR_VERSION_CFG) || \
     (BCC_772C_SW_MINOR_VERSION != BCC_772C_SW_MINOR_VERSION_CFG) || \
     (BCC_772C_SW_PATCH_VERSION != BCC_772C_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of CDD_Bcc_772c.h and Bcc_772c_Cfg.h are different"
#endif

/*==================================================================================================
 *                                          CONSTANTS
 ==================================================================================================*/

/*==================================================================================================
 *                                      DEFINES AND MACROS
 ==================================================================================================*/

/* Error Values */
#if (BCC_772C_DEV_ERROR_DETECT == STD_ON)
/**
 * @brief API service called with wrong parameter.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Parameter shall not be a NULL pointer.
 */
#define BCC_772C_E_PARAM_POINTER_U8 ((uint8)0x00u)
/**
 * @brief Invalid configuration options.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Configuration options for SYS.
 */
#define BCC_772C_E_INVALID_SYS_CONFIG_U8 ((uint8)0x01u)
/**
 * @brief Invalid MC33772C mode.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Mode option shall respect struct Bcc_772c_SysDeviceModeType.
 */
#define BCC_772C_E_INVALID_MODE_U8 ((uint8)0x02u)
/**
 * @brief MC33772C not yet initialized.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates MC33772C has to be initialized before certain operations.
 */
#define BCC_772C_E_UNINIT_U8 ((uint8)0x03u)
/**
 * @brief Device driver already initialized.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Init function shall only be called if driver is uninitialized.
 */
#define BCC_772C_E_ALREADY_INIT_U8 ((uint8)0x05u)

#if (BCC_772C_GPIO_SUPPORT == STD_ON)
/**
 * @brief GPIO configuration invalid.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates GpioDirection and OpenDrainEn configuration options.
 */

#define BCC_772C_E_INVALID_GPIO_CONFIG_U8 ((uint8)0x06u)
#endif /* (BCC_772C_GPIO_SUPPORT == STD_ON) */

/**
 * @brief BCC device address invalid.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates ChainAddr and DevAddr addresses are not configuration-compliant.
 */
#define BCC_772C_E_INVALID_ADDR_U8 ((uint8)0x07u)

/**
 * @brief BCC device address not unique.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates DevAddr address is already used.
 */
#define BCC_772C_E_DUPLICATED_ADDR_U8 ((uint8)0x08u)
/**
 * @brief Maximum number of devices in a chain was reached.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Maximum number of devices in a chain.
 */
#define BCC_772C_E_NR_MAX_OF_DEVICES_U8 ((uint8)0x09u)

#if (BCC_772C_FEH_SUPPORT == STD_ON)
/**
 * @brief Invalid configuration options.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Configuration options for FEH.
 */
#define BCC_772C_E_INVALID_FEH_CONFIG_U8 ((uint8)0x11u)
#endif /* (BCC_772C_FEH_SUPPORT == STD_ON) */

/**
 * @brief Invalid configuration options.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Configuration options for MSR.
 */
#define BCC_772C_E_INVALID_MSR_CONFIG_U8 ((uint8)0x12u)

#if (BCC_772C_I2C_SUPPORT == STD_ON)
/**
 * @brief Invalid configuration options.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Configuration options for I2C.
 */
#define BCC_772C_E_INVALID_I2C_CONFIG_U8 ((uint8)0x13u)
#endif /* (BCC_772C_I2C_SUPPORT == STD_ON) */

#if (BCC_772C_BAL_SUPPORT == STD_ON)
/**
 * @brief Invalid configuration options.
 *
 * @implements Bcc_772c_ErrorCodes_define
 *
 * @violates Configuration options for BAL.
 */
#define BCC_772C_E_INVALID_BAL_CONFIG_U8 ((uint8)0x14u)
#endif /* (BCC_772C_BAL_SUPPORT == STD_ON) */

/**
* @brief Invalid measurement option.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Measurement options.
*/
#define BCC_772C_E_INVALID_MEAS_U8          ((uint8)0x15u)
/**
* @brief The TD was not cleared after the previous transaction.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates TD append operation.
*/
#define BCC_772C_E_TD_NOT_CLEARED_U8        ((uint8)0x16u)
/**
* @brief The TD append operation failed due to overflow.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates TD append operation.
*/
#define BCC_772C_E_TD_OVERFLOW_U8           ((uint8)0x17u)
/**
* @brief The RegCnt value is invalid.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Maximum number of registers to be read/written in one command.
*/
#define BCC_772C_E_INVALID_SIZE_U8          ((uint8)0x18u)
/**
* @brief The AdcAvg value is invalid for Bcc_772c_MSR_StartConversion.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Parameter allowed value.
*/
#define BCC_772C_E_INVALID_AVG_U8           ((uint8)0x19u)
/**
* @brief The Channel value is invalid for Bcc_772c_MSR_SetThresholds.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Parameter allowed value.
*/
#define BCC_772C_E_INVALID_TH_CH_U8         ((uint8)0x20u)
/**
* @brief The Threshold value is invalid for Bcc_772c_MSR_SetThresholds.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Parameter allowed value.
*/
#define BCC_772C_E_INVALID_TH_VAL_U8        ((uint8)0x21u)
/**
 * @brief Invalid configuration options.
 *
 * @implements Bcc_772C_ErrorCodes_define
 *
 * @violates Configuration options for CC.
 */
#define BCC_772C_E_INVALID_CC_CONFIG_U8    ((uint8)0x22u)
/**
 * @brief Invalid action selection for Bcc_772c_CC_ControlMeasurements.
 *
 * @implements Bcc_772C_ErrorCodes_define
 *
 * @violates Action option shall respect struct Bcc_772c_CcActionType.
 */
#define BCC_772C_E_INVALID_ACTION_U8       ((uint8)0x23u)
/**
* @brief Transaction operation was not finished or the TD was cleared.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Parameter allowed value.
*/
#define BCC_772C_E_TD_NOT_FINISHED_U8       ((uint8)0x1Au)
/**
* @brief RShunt value provided for Bcc_772c_CC_ExtractISense is invalid.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Parameter allowed value.
*/
#define BCC_772C_E_INVALID_RSHUNT_U8        ((uint8)0x24u)
/**
* @brief Register address is not in the allowed range.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Register address is not in the allowed range
*/
#define BCC_772C_E_INVALID_REGISTER_ADDR_U8    ((uint8)0x25u)
/**
* @brief Register is not part of memory map mirror.
*
* @implements Bcc_772c_ErrorCodes_define
*/
/*
* @violates Register is not part of memory map mirror.
*/
#define BCC_772C_E_INVALID_MEM_MAP_REGISTER_U8    ((uint8)0x26u)

/* Service IDs */
/**
 * @brief API service ID for Bcc_772c_Init function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_INIT_ID_U8                         ((uint8)0x1u)
/**
 * @brief API service ID for Bcc_772c_SYS_SetMode function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_SYS_SETMODE_ID_U8                  ((uint8)0x2u)
/**
 * @brief API service ID for Bcc_772c_SYS_GetPreviousMode function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_SYS_GETPREVIOUSMODE_ID_U8          ((uint8)0x3u)
/**
 * @brief API service ID for Bcc_772c_SYS_Configure function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_SYS_CONFIGURE_ID_U8                ((uint8)0x4u)
/**
 * @brief API service ID for Bcc_772c_SYS_GetVersion function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_SYS_GETVERSION_ID_U8               ((uint8)0x5u)
/**
 * @brief API service ID for Bcc_772c_SYS_GetHardwareVersion function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_SYS_GETHARDWAREVERSION_ID_U8       ((uint8)0x6u)

#if (BCC_772C_GPIO_SUPPORT == STD_ON)
/**
 * @brief API service ID for Bcc_772c_GPIO_Configure function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_GPIO_CONFIGURE_ID_U8               ((uint8)0x7u)
/**
 * @brief API service ID for Bcc_772c_GPIO_GetInput function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_GPIO_GETINPUT_ID_U8                ((uint8)0x8u)
/**
 * @brief API service ID for Bcc_772c_GPIO_SetOutput function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_GPIO_SETOUTPUT_ID_U8               ((uint8)0x9u)
/**
 * @brief API service ID for BCC_772C_GPIO_GETFAULTSTATUS_ID_U8 function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_GPIO_GETFAULTSTATUS_ID_U8          ((uint8)0xAu)
#endif /* (BCC_772C_GPIO_SUPPORT == STD_ON) */

#if (BCC_772C_I2C_SUPPORT == STD_ON)
/**
 * @brief API service ID for Bcc_772c_I2C_CommandEEPROM function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_I2C_COMMANDEEPROM_ID_U8            ((uint8)0x10u)
/**
 * @brief API service ID for Bcc_772c_I2C_ReadResult function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_I2C_READRESULT_ID_U8               ((uint8)0x11u)
#endif /* (BCC_772C_I2C_SUPPORT == STD_ON) */

#if (BCC_772C_FEH_SUPPORT == STD_ON)
/**
 * @brief API service ID for Bcc_772c_FEH_Configure function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_FEH_CONFIGURE_ID_U8                ((uint8)0x13u)
/**
 * @brief API service ID for Bcc_772c_FEH_GetFaultStatus function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_FEH_GETFAULTSTATUS_ID_U8           ((uint8)0x15u)
#endif/* (BCC_772C_FEH_SUPPORT == STD_ON) */

#if ((BCC_772C_GPIO_SUPPORT == STD_ON) || (BCC_772C_FEH_SUPPORT == STD_ON) || (BCC_772C_BAL_SUPPORT == STD_ON))
/**
 * @brief API service ID for Bcc_772c_FEH_ClearFaultStatus function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_FEH_CLEARFAULTSTATUS_ID_U8         ((uint8)0x14u)
#endif/* ((BCC_772C_GPIO_SUPPORT == STD_ON) || (BCC_772C_FEH_SUPPORT == STD_ON) || (BCC_772C_BAL_SUPPORT == STD_ON)) */

#if (BCC_772C_BAL_SUPPORT == STD_ON)
/**
 * @brief API service ID for Bcc_772c_SetChannelConfiguration function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_BAL_SETCHANNELCONFIGURATION_ID_U8  ((uint8)0x17u)
/**
 * @brief API service ID for Bcc_772c_BAL_GetStatus function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_BAL_GETSTATUS_ID_U8                ((uint8)0x18u)
#endif /* (BCC_772C_BAL_SUPPORT == STD_ON)*/

/**
* @brief API service ID for Bcc_772c_MSR_StartConversion function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_MSR_STARTCONVERSION_ID_U8        ((uint8)0x20u)
/**
* @brief API service ID for Bcc_772c_MSR_Configure function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_MSR_CONFIGURE_ID_U8                ((uint8)0x21u)
/**
* @brief API service ID for Bcc_772c_MSR_GetData function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_MSR_GETDATA_ID_U8                  ((uint8)0x22u)
/**
* @brief API service ID for Bcc_772c_MSR_SetThresholds function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_MSR_SETTHRESHOLDS_ID_U8            ((uint8)0x25u)
/**
 * @brief API service ID for Bcc_772c_MSR_GetFaultStatus function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_MSR_GETFAULTSTATUS_ID_U8           ((uint8)0x16u)
/**
* @brief API service ID for Bcc_772c_CC_Configure function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_CC_CONFIGURE_ID_U8                 ((uint8)0x23u)
/**
* @brief API service ID for Bcc_772c_CC_GetData function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_CC_GETDATA_ID_U8                   ((uint8)0x24u)
/**
* @brief API service ID for Bcc_772c_CC_ControlMeasurements function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_CC_CONTROLMEASUREMENTS_ID_U8       ((uint8)0x26u)
/**
* @brief API service ID for Bcc_772c_COM_WriteRegister function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_COM_WRITEREG_ID_U8                 ((uint8)0x40u)
/**
* @brief API service ID for Bcc_772c_COM_ReadRegisters function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_COM_READREG_ID_U8                  ((uint8)0x41u)
/**
* @brief API service ID for Bcc_772c_Enumerate function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_ENUMERATE_ID_U8                    ((uint8)0x42u)
/**
* @brief API service ID for Bcc_772c_COM_InsertNop function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_COM_INSERTNOP_ID_U8                ((uint8)0x47u)
/**
 * @brief API service ID for Bcc_772c_Deinit function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_DEINIT_ID_U8                        ((uint8)0x48u)
/**
 * @brief API service ID for Bcc_772c_CC_ExtractCoulombCnt function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_CC_EXTRACTCOULOMBCNT_ID_U8               ((uint8)0x49u)
/**
 * @brief API service ID for Bcc_772c_CC_ExtractISense function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_CC_EXTRACTISENSE_ID_U8             ((uint8)0x4Au)
/**
 * @brief API service ID for Bcc_772c_MEM_ReadRegister function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_772C_MEM_READ_ID_U8             ((uint8)0x4Bu)
#if (BCC_772C_SPI_SUPPORT == STD_OFF)
/**
* @brief API service ID for Bcc_772c_WakeupDevice function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_WAKEUPDEVICE_ID_U8                    ((uint8)0x4Du)
/**
* @brief API service ID for Bcc_772c_WakeupChain function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_WAKEUPCHAIN_ID_U8                  ((uint8)0x43u)
#else
/**
* @brief API service ID for Bcc_772c_SPIWakeupDevice function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_SPI_WAKEUPDEVICE_ID_U8                    ((uint8)0x4Eu)
#endif /* BCC_772C_SPI_SUPPORT == STD_OFF */
#endif /* BCC_772C_DEV_ERROR_DETECT == STD_ON */
/**
* @brief API service ID for Bcc_772c_MEM_ResetToDefault function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_772C_MEM_RESET_ID_U8                 ((uint8)0x4FU)
/**
* @brief Instance ID of this bcc_772c driver.
*
*/
#define BCC_772C_INSTANCE_ID 0U

/*==================================================================================================
 *                                            ENUMS
 ==================================================================================================*/
/**
 * @brief This type defines a range of specific status for Bcc_772c Driver.
 *
 * @implements Bcc_772c_DriverStatusType_enum
 */
typedef enum
{
    BCC_772C_UNINITIALIZED = 0U, /**< @brief Driver internal data not initialized or not usable. */
    BCC_772C_INIT         /**< @brief Driver internal data initialized. */
} Bcc_772c_DriverStatusType;

/**
 * @brief Describes the operating mode of a BCC device.
 *
 * @implements Bcc_772c_SysDeviceModeType_enum
 */
typedef enum
{
    BCC_772C_SYS_MODE_NORMAL = 0x2U,    /**< @brief MC33772C in NORMAL mode. */
    BCC_772C_SYS_MODE_SLEEP = 0x7U,     /**< @brief MC33772C in SLEEP mode. */
    BCC_772C_SYS_MODE_DIAG = 0x3U,      /**< @brief MC33772C in DIAG mode. */
} Bcc_772c_SysDeviceModeType;

/**
 * @brief Defines the measurement type to perform specific operations on.
 *
 * @implements Bcc_772c_MsrMeasurementType_enum
 */
typedef enum
{
    BCC_772C_MSR_TYPE_ALL = 0U,              /**< @brief Read all values MEAS_CELL(1..6), MEAS_AN(0..6), MEAS_STACK, MEAS_ISENSE1, MEAS_ISENSE2 */
    BCC_772C_MSR_TYPE_CELL_VOLTAGE,          /**< @brief Read 6 values MEAS_CELL(1..6) */
    BCC_772C_MSR_TYPE_AINX,                  /**< @brief Read 7 values MEAS_AN(0..6) */
    BCC_772C_MSR_TYPE_STACK_VOLTAGE,         /**< @brief Read MEAS_STACK */
    BCC_772C_MSR_TYPE_STACK_CELL_VOLTAGE ,   /**< @brief Read MEAS_STACK, MEAS_CELL(1..6) */
    BCC_772C_MSR_TYPE_DIAG_BANDGAP,          /**< @brief MEAS_VBG_DIAG_ADC1A, MEAS_VBG_ADC1B */
    BCC_772C_MSR_TYPE_IC_TEMPERATURE         /**< @brief Read MEAS_IC_TEMP */
} Bcc_772c_MsrMeasurementType;

/**
 * @brief Defines the measurement channel to update the thresholds for.
 *
 * @implements Bcc_772c_MsrThresholdChannelType_enum
 */
typedef enum
{
    BCC_772C_MSR_TH_TYPE_CT_ALL = 0U,   /**< @brief Configure all cell terminals */
    BCC_772C_MSR_TH_TYPE_CT6 = 1U,      /**< @brief Configure cell terminal 6 */
    BCC_772C_MSR_TH_TYPE_CT5 = 2U,      /**< @brief Configure cell terminal 5 */
    BCC_772C_MSR_TH_TYPE_CT4 = 3U,      /**< @brief Configure cell terminal 4 */
    BCC_772C_MSR_TH_TYPE_CT3 = 4U,      /**< @brief Configure cell terminal 3 */
    BCC_772C_MSR_TH_TYPE_CT2 = 5U,      /**< @brief Configure cell terminal 2 */
    BCC_772C_MSR_TH_TYPE_CT1 = 6U,      /**< @brief Configure cell terminal 1 */
    BCC_772C_MSR_TH_TYPE_AN6 = 7U,      /**< @brief Configure analog input 6 */
    BCC_772C_MSR_TH_TYPE_AN5 = 8U,      /**< @brief Configure analog input 5 */
    BCC_772C_MSR_TH_TYPE_AN4 = 9U,      /**< @brief Configure analog input 4 */
    BCC_772C_MSR_TH_TYPE_AN3 = 10U,     /**< @brief Configure analog input 3 */
    BCC_772C_MSR_TH_TYPE_AN2 = 11U,     /**< @brief Configure analog input 2 */
    BCC_772C_MSR_TH_TYPE_AN1 = 12U,     /**< @brief Configure analog input 1 */
    BCC_772C_MSR_TH_TYPE_AN0 = 13U      /**< @brief Configure analog input 0 */
} Bcc_772c_MsrThresholdChannelType;

#if (BCC_772C_CC_SUPPORT == STD_ON)
/**
 * @brief Defines the action type for current measurement.
 *
 * @implements Bcc_772c_CcActionType_enum
 */
typedef enum
{
    BCC_772C_CC_START = 0,      /**< @brief Read all values MEAS_CELL(1..6), MEAS_AN(0..6), MEAS_STACK, MEAS_ISENSE1, MEAS_ISENSE2 */
    BCC_772C_CC_STOP,           /**< @brief Read 6 values MEAS_CELL(1..6) */
    BCC_772C_CC_RESTART         /**< @brief Read 7 values MEAS_AN(0..6) */
} Bcc_772c_CcActionType;
#endif /* (BCC_772C_CC_SUPPORT == STD_ON) */

#if (BCC_772C_BAL_SUPPORT == STD_ON)
/**
 * @brief Defines the balancing channel to be configured.
 *
 * @implements Bcc_772c_ChannelNoType_enum
 */
typedef enum
{
    BCC_772C_CHANNEL_1 = 0U,        /**< @brief Configure balancing on channel 1 */
    BCC_772C_CHANNEL_2,             /**< @brief Configure balancing on channel 2 */
    BCC_772C_CHANNEL_3,             /**< @brief Configure balancing on channel 3 */
    BCC_772C_CHANNEL_4,             /**< @brief Configure balancing on channel 4 */
#if ((BCC_772C_SILICON_A1 == STD_ON) || (BCC_772C_SILICON_P1 == STD_ON))
    BCC_772C_CHANNEL_5,             /**< @brief Configure balancing on channel 5 */
    BCC_772C_CHANNEL_6,             /**< @brief Configure balancing on channel 6 */
#endif
    BCC_772C_CHANNEL_ALL            /**< @brief Configure balancing on all channels */
} Bcc_772c_ChannelNoType;
#endif /* (BCC_772C_BAL_SUPPORT == STD_ON) */
/*==================================================================================================
 *                                STRUCTURES AND OTHER TYPEDEFS
 ==================================================================================================*/

#if (BCC_772C_BAL_SUPPORT == STD_ON)
/**
 * @brief    Operating parameters of the cell balance output drivers.
 *
 * @implements Bcc_772c_BalChannelConfigurationType_struct
 */
typedef struct
{
    boolean BalEn;                         /**< @brief General enable or disable for all cell balance drivers. */
    Bcc_772c_ChannelNoType ChannelNo;      /**< @brief ID of channel to be configured */
    boolean BalChannelEn;                  /**< @brief Cell balance enable */
    uint16  Timer;                         /**< @brief Cell balance timer value in minutes */
} Bcc_772c_BalChannelConfigurationType;
#endif /* (BCC_772C_BAL_SUPPORT == STD_ON) */

#if (BCC_772C_I2C_SUPPORT == STD_ON)
/**
 * @brief    Operating parameters for I2C functionality
 *
 * @implements Bcc_772c_I2CParamsType_struct
 */
typedef struct
{
    uint8 Operation;            /**< @brief 0 - Write Command, 1 - Read Command */
    uint8 EEPROMAddr;           /**< @brief EEPROM address to read/write */
    uint8 Data;                 /**< @brief Data to write */
} Bcc_772c_I2CParamsType;
#endif /* (BCC_772C_I2C_SUPPORT == STD_ON) */

#if (BCC_772C_CC_SUPPORT == STD_ON)
/**
 * @brief    Extracted values for VSENSE and ISENSE and selected RSHUNT value.
 *
 * @implements Bcc_772c_CcISenseValueType_struct
 */
typedef struct
{
    uint16 RShunt;          /**< @brief Resistance parameter with typical range of (0, 204.7] microOHM, resolution: 0.1 microOHM/LSB, Ex: RShunt = 100 => 10 microOHM resistance */
    sint32 VSense;          /**< @brief VSENSE value expressed in nanoVolt */
    sint32 ISense;          /**< @brief ISENSE value expressed in miliAmper */
} Bcc_772c_CcISenseValueType;
#endif /* (BCC_772C_CC_SUPPORT == STD_ON) */

/**
 * @brief Bcc_772c Driver Configuration Main Structure
 *
 * This is the top level structure containing all the needed parameters for the Bcc_772c Handler Driver.
 *
 * @implements Bcc_772c_DriverConfigType_struct
 */
typedef struct
{
    const Bcc_772c_DeviceConfigType *DeviceConfigSets;
    const BmsTpl2ChainConfigType *BmsCommonChainsConfig;
} Bcc_772c_DriverConfigType;

/**
 * @brief   Information needed for reading/writing registers
 *
 */
typedef struct
{
    uint8         RegAddr;            /**< @brief 7 bit Memory Address field of the BCC */
    uint8         RegCnt;             /**< @brief Number of consecutive registers to be addressed (1 WRITE, 1-127 for READ) */
    const uint16  *Data;              /**< @brief 16 bit frame Pointer to an data array in data field */
} Bcc_772c_RWRegistersType;

/**
 * @brief   Information needed by the packing function to determine the command and the specific device.
 *
 */
typedef struct
{
    Bcc_772c_BccCommandType CmdCode;    /**< @brief  2 bit frame type: 00 NOP, 01 READ, 02 WRITE, 03 GLOBAL WRITE */
    uint8 ChainAddr;                    /**< @brief  Chain Address (part of CID) */
    uint8 DevAddr;                      /**< @brief  Device Address (part of CID) */
} Bcc_772c_PackMsgParamsType;

/**
 * @brief   Information needed for writing a register
 *
 * @implements Bcc_772c_RegisterContentType_struct
 */
typedef struct
{
    uint8  RegAddr;            /**< @brief 7 bit Memory Address field of the BCC */
    uint16 RegData;            /**< @brief Register content which will be written */
    uint16 RegMask;            /**< @brief  Mask that will be applied to register content */
} Bcc_772c_RegisterContentType;


/**
 * @brief   Under- and over-voltage threshold for a specific channel.
 *
 * @implements Bcc_772c_MsrThresholdValueType_struct
 */
typedef struct
{
    uint16 Overvoltage;   /**< @brief Overvoltage or overtemperature threshold value */
    uint16 Undervoltage;  /**< @brief Undervoltage or undertemperature threshold value */
} Bcc_772c_MsrThresholdValueType;

/**
 * @brief   MemMapMirror structure.
 *
 * @implements Bcc_772c_MemMapMirrorType_struct
 */
typedef struct
{
    uint16* RegMirrorAddress;   /**< @brief Pointer to an array containing addresses of registers to be written in memory map mirror */
    uint16* RegMirrorValues;    /**< @brief Pointer to an array containing values of registers to be written in memory map mirror */
    uint8 Size;                 /**< @brief Number of register to be updated in memory map mirror */
} Bcc_772c_MemMapMirrorType;



/*==================================================================================================
 *                                GLOBAL VARIABLE DECLARATIONS
 ==================================================================================================*/
#if (BCC_772C_PRECOMPILE_SUPPORT == STD_OFF)
/**
* @brief   Export Post-Build configurations.
*/

#define BCC_772C_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

/** @cond */
BCC_772C_CONFIG_EXT
/*! @endcond */

#define BCC_772C_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

#endif /* (BCC_772C_PRECOMPILE_SUPPORT == STD_OFF) */

#define BCC_772C_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

#if (BCC_772C_PRECOMPILE_SUPPORT == STD_ON)
extern const Bcc_772c_DriverConfigType Bcc_772c_PBCfgVariantPredefined;
#endif /* (BCC_772C_PRECOMPILE_SUPPORT == STD_ON) */

#define BCC_772C_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

#define BCC_772C_START_SEC_VAR_INIT_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

/**
 * @brief Keeps track of Bcc_772c driver state.
 */
extern Bcc_772c_DriverStatusType Bcc_772c_eDriverState;

#define BCC_772C_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

/*==================================================================================================
 *                                    FUNCTION PROTOTYPES
 ==================================================================================================*/
#define BCC_772C_START_SEC_CODE
#include "Bcc_772c_MemMap.h"

/*!
 * @brief   This function is used to enumerate a device
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *            List of used registers: INIT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Device was successfully enumerated.
 * @retval      E_NOT_OK            Device was not successfully enumerated.
 *
 */
Std_ReturnType Bcc_772c_Enumerate
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

#if (BCC_772C_SPI_SUPPORT == STD_OFF)
/*!
 * @brief   This function appends in the transaction descriptor the messages needed for waking up a device
 * @details This function appends in the transaction descriptor: a write message for the first wakeup pulse, a PHY timer
 *          scheduling event to insert a delay of tWAKE_DELAY, another write messsage for the second wakeup pulse
 *          - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Messages were successfully appended in the transaction descriptor
 * @retval      E_NOT_OK            Messages were not successfully appended in the transaction descriptor
 *
 */
Std_ReturnType Bcc_772c_WakeupDevice
    (
        uint8 ChainAddr,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   This function appends in the transaction descriptor the messages needed for waking up the devices
 * @details This function appends in the transaction descriptor: a write message for the first wakeup pulse, a PHY timer
 *          scheduling event to insert a delay of tWAKE_DELAY, another write messsage for the second wakeup pulse and another PHY
 *          timer scheduling event to insert a delay of tWU_WAIT * number of nodes in daisy chain
 *          - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Messages were successfully appended in the transaction descriptor
 * @retval      E_NOT_OK            Messages were not successfully appended in the transaction descriptor
 *
 */
Std_ReturnType Bcc_772c_WakeupChain
    (
        uint8 ChainAddr,
        const Bms_TDType* MessageTD
    );

#endif /* (BCC_772C_SPI_SUPPORT == STD_OFF) */

#if (BCC_772C_SPI_SUPPORT == STD_ON)
/*!
 * @brief   This function appends in the transaction descriptor the messages needed for waking up a device in SPI mode
 * @details This function appends in the transaction descriptor: a write message and a PHY timer
 *          - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Messages were successfully appended in the transaction descriptor
 * @retval      E_NOT_OK            Messages were not successfully appended in the transaction descriptor
 *
 */
Std_ReturnType Bcc_772c_SPIWakeupDevice
    (
        uint8 ChainAddr,
        const Bms_TDType* MessageTD
    );
#endif /* (BCC_772C_SPI_SUPPORT == STD_ON) */

/*!
 * @brief   Initialization of Battery Cell Controller (BCC) device(s).
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Side effect:   Sets Bcc_772c_eDriverState to INIT.
 *
 * @param[in] DriverConfig Driver configuration, used only if the pre-compile support is off.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The initialization of the Battery Cell Controller (BCC) device(s) was successful.
 * @retval      E_NOT_OK        The initialization of the Battery Cell Controller (BCC) device(s) was not successful.
 *
 */
Std_ReturnType Bcc_772c_Init
    (
        const Bcc_772c_DriverConfigType *DriverConfig
    );

/*!
 * @brief   Configures the selected Battery Cell Controller device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *            List of used registers: SYS_CFG1, SYS_CFG2
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The configuration of the selected Battery Cell Controller device was successful.
 * @retval      E_NOT_OK            The configuration of the selected Battery Cell Controller device was not successful.
 *
 */
Std_ReturnType Bcc_772c_SYS_Configure
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint16 ConfigIdx,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Sets the operating mode for all Battery Cell Controller devices.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *            List of used registers: SYS_CFG1, SYS_CFG_GLOBAL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       Mode            MC33772 mode to set as of Bcc_772c_SysDeviceModeType.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The operating mode for all Battery Cell Controller devices was set successfully.
 * @retval      E_NOT_OK            The operating mode for all Battery Cell Controller devices was not set successfully.
 *
 */
Std_ReturnType Bcc_772c_SYS_SetMode
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        Bcc_772c_SysDeviceModeType Mode,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Retrieves last known operating mode from a Battery Cell Controller device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *            List of used registers: SYS_CFG2
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Last known operating mode from a Battery Cell Controller device was retrieved successfully.
 * @retval      E_NOT_OK            Last known operating mode from a Battery Cell Controller device was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_SYS_GetPreviousMode
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Returns the version information of this module.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 * @param[out]      VersionInfo    Pointer to user-allocated structure to be filled in.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Version information of this module was returned successfully.
 * @retval      E_NOT_OK            Version information of this module was not returned successfully.
 *
 */
void Bcc_772c_SYS_GetVersion
    (
        Std_VersionInfoType *VersionInfo
    );

/*!
 * @brief   Retrieves hardware version and unique identifier from a Battery Cell Controller device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *            List of used registers: SILICON_REV
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Hardware version and unique identifier from a Battery Cell Controller device were retrieved successfully.
 * @retval      E_NOT_OK            Hardware version and unique identifier from a Battery Cell Controller device were not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_SYS_GetHardwareVersion
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

#if (BCC_772C_GPIO_SUPPORT == STD_ON)
/*!
 * @brief   Configures the GPIO pins direction of a Battery Cell Controller device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *            List of used registers: GPIO_CFG1, GPIO_CFG2
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Configuration of the GPIO pins direction of a Battery Cell Controller device was successful.
 * @retval      E_NOT_OK            Configuration of the GPIO pins direction of a Battery Cell Controller device was not successful.
 *
 */
Std_ReturnType Bcc_772c_GPIO_Configure
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint8 ConfigIdx,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Reads the input values of GPIO pins for a Battery Cell Controller device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          Reads input values (low/high) of GPIO pins + whether a low to high level transition was present.
 *
 *          List of used registers: GPIO_STS
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The input values of GPIO pins for a Battery Cell Controller device were read successfully.
 * @retval      E_NOT_OK            The input values of GPIO pins for a Battery Cell Controller device were not read successfully.
 *
 */
Std_ReturnType Bcc_772c_GPIO_GetInput
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Sets the output values of GPIO pins for a Battery Cell Controller device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: GPIO_CFG2
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       OutputValue     Value to write GPIO pins with.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The output values of GPIO pins for a Battery Cell Controller device were set successfully.
 * @retval      E_NOT_OK            The output values of GPIO pins for a Battery Cell Controller device were not set successfully.
 *
 */
Std_ReturnType Bcc_772c_GPIO_SetOutput
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint8 OutputValue,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Retrieves the short register GPIO_SHORT_ANX_OPEN_STS for the selected BCC device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: GPIO_SHORT_ANx_OPEN_STS
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The fault status registers were retrieved successfully.
 * @retval      E_NOT_OK            The fault status registers were not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_GPIO_GetFaultStatus
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

#endif /* (BCC_772C_GPIO_SUPPORT == STD_ON) */

/*!
 * @brief       Sets the measurement configuration parameters for selected BCC device.
 * @details     - Sync or Async:    Synchronous
 *              - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *              List of used registers: ADC_CFG, OV_UV_EN
 *
 * @param[in]     ChainAddr     Chain address for specific BCC device.
 * @param[in]     DevAddr       Address of specific BCC device.
 * @param[in]     ConfigIdx     Index of chosen static configuration.
 * @param[inout]  MessageTD     Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The measurement configuration parameters were set successfully.
 * @retval      E_NOT_OK        The measurement configuration parameters were not set successfully.
 *
 */
Std_ReturnType Bcc_772c_MSR_Configure
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint8 ConfigIdx,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief       Dynamically sets the threshold value for CT or AN terminals for selected BCC device.
 * @details     - Sync or Async:    Synchronous
 *              - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *              List of used registers: OV_UV_EN, TH_ALL_CT, TH_CT6, TH_CT5, TH_CT4, TH_CT3, TH_CT2, TH_CT1,
 *              TH_AN6, TH_AN5, TH_AN4, TH_AN3, TH_AN2, TH_AN1, TH_AN0
 *              This method will configure both the overvoltage (or overtemperature) and
 *              undervoltage (or undertemperature) for a specific CT or AN terminal.
 *              The method can also configure the same threshold values for all CT terminals.
 *
 * @param[in]     ChainAddr     Chain address for specific BCC device.
 * @param[in]     DevAddr       Address of specific BCC device.
 * @param[in]     Channel       The channel for which the threshold will be configured.
 * @param[in]     Threshold     The threshdold values which will be configured.
 * @param[inout]  MessageTD     Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The measurement process for the selected BCC device started successfully.
 * @retval      E_NOT_OK        The measurement process for the selected BCC device did not start successfully.
 *
 */
Std_ReturnType Bcc_772c_MSR_SetThresholds
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        Bcc_772c_MsrThresholdChannelType Channel,
        Bcc_772c_MsrThresholdValueType Threshold,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief       Starts on-demand measurement process for selected BCC device.
 * @details     - Sync or Async:    Synchronous
 *              - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *              List of used registers: ADC_CFG
 *
 * @param[in]     ChainAddr     Chain address for specific BCC device.
 * @param[in]     DevAddr       Address of specific BCC device.
 * @param[in]     AdcAvg        The number of samples to be averaged.
 * @param[inout]  MessageTD     Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The measurement process for the selected BCC device started successfully.
 * @retval      E_NOT_OK        The measurement process for the selected BCC device did not start successfully.
 *
 */
Std_ReturnType Bcc_772c_MSR_StartConversion
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint8 AdcAvg,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Retrieves measurement data from specified BCC device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: MEAS_CELL6, MEAS_CELL5, MEAS_CELL4, MEAS_CELL3, MEAS_CELL2, MEAS_CELL1
 *                                  MEAS_AN6, MEAS_AN5, MEAS_AN4, MEAS_AN3, MEAS_AN2, MEAS_AN1, MEAS_AN0, MEAS_STACK
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       MeasType        Measurement data type to read.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The measurement data was retrieved successfully.
 * @retval      E_NOT_OK            The measurement data was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_MSR_GetData
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        Bcc_772c_MsrMeasurementType MeasType,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Retrieves the measurement fault status registers for the selected BCC device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: CELL_OV_FLT, CELL_UV_FLT, AN_OT_UT_FLT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The fault status registers were retrieved successfully.
 * @retval      E_NOT_OK            The fault status registers were not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_MSR_GetFaultStatus
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

#if (BCC_772C_CC_SUPPORT == STD_ON)
/*!
 * @brief       Selects the coulomb counting method.
 * @details     - Sync or Async:    Synchronous
 *              - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *              List of used registers: ADC2_OFFSET_COMP, TH_ISENSE_OC, TH_COULOMB_CNT_MSB, TH_COULOMB_CNT_LSB
 *
 * @param[in]     ChainAddr     Chain address for specific BCC device.
 * @param[in]     DevAddr       Address of specific BCC device.
 * @param[in]     ConfigIdx     Index of chosen static configuration.
 * @param[inout]  MessageTD     Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The coulomb counting configuration parameters were set successfully.
 * @retval      E_NOT_OK        The coulomb counting configuration parameters were not set successfully.
 *
 */
Std_ReturnType Bcc_772c_CC_Configure
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint8 ConfigIdx,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief       Controls current measurement process for selected BCC device.
 * @details     - Sync or Async:    Synchronous
 *              - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *              List of used registers: SYS_CFG1, ADC_CFG
 *
 * @param[in]     ChainAddr         Chain address for specific BCC device.
 * @param[in]     DevAddr           Address of specific BCC device.
 * @param[in]     Action            Command for current measurement process.
 * @param[inout]  MessageTD         Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The current measurement process for the selected BCC device was started/stopped successfully.
 * @retval      E_NOT_OK        The current measurement process for the selected BCC device was not started/stopped successfully.
 *
 */
Std_ReturnType Bcc_772c_CC_ControlMeasurements
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        Bcc_772c_CcActionType Action,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief      Retrieves current measurement data from specified BCC device.
 * @details    - Sync or Async:    Synchronous
 *             - Reentrancy:       Reentrant
 *               Usage of reentrant capability is only allowed if the callers take care
 *               that there is no simultaneous usage of the same MessageTD parameter.
 *
 *              List of used registers: CC_NB_SAMPLES, COULOMB_CNT1, COULOMB_CNT2, MEAS_ISENSE1, MEAS_ISENSE2
 *
 * @param[in]     ChainAddr         Chain address for specific BCC device.
 * @param[in]     DevAddr           Address of specific BCC device.
 * @param[inout]  MessageTD         Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The current measurement data for the selected BCC device was retrieved successfully.
 * @retval      E_NOT_OK        The current measurement data for the selected BCC device was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_CC_GetData
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

#endif /* (BCC_772C_CC_SUPPORT == STD_ON) */

#if (BCC_772C_BAL_SUPPORT == STD_ON)
/*!
 * @brief   Configures the discharge time and enable flag for the controlled discharge of the cells.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *          Maximum memory needed in the transaction descriptor:
 *          List of used registers: SYS_CFG1, CB1_CFG, CB2_CFG, CB3_CFG, CB4_CFG, CB5_CFG, CB6_CFG
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ChannelConfig   User-specified channel configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The discharge time and enable flag were configured successfully.
 * @retval      E_NOT_OK            The discharge time and enable flag were not configured successfully.
 *
 */
Std_ReturnType Bcc_772c_BAL_SetChannelConfiguration
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bcc_772c_BalChannelConfigurationType *ChannelConfig,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Retrieves the status of the balancing activity.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          Memory needed in the request buffer:
 *          Memory needed in the response buffer:
 *          List of used registers: SYS_CFG1, CB_DRV_STS, CB_SHORT_FLT, CB_OPEN_FLT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Status of the balancing activity was retrieved successfully.
 * @retval      E_NOT_OK            Status of the balancing activity was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_BAL_GetStatus
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

#endif /* (BCC_772C_BAL_SUPPORT == STD_ON) */

#if (BCC_772C_FEH_SUPPORT == STD_ON)
/*!
 * @brief   Configures the wakeup source and FAULT bin behaviour for the selected BCC device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: FAULT_MASK1, FAULT_MASK2, FAULT_MASK3, WAKEUP_MASK1, WAKEUP_MASK2, WAKEUP_MASK3
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The FEH configuration parameters were set successfully.
 * @retval      E_NOT_OK            The FEH configuration parameters were not set successfully.
 *
 */
Std_ReturnType Bcc_772c_FEH_Configure
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint16 ConfigIdx,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Retrieves the fault status registers for the selected BCC device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: FAULT1_STATUS, FAULT2_STATUS, FAULT3_STATUS
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The fault status registers were retrieved successfully.
 * @retval      E_NOT_OK            The fault status registers were not retrieved successfully.
 *
 */
Std_ReturnType Bcc_772c_FEH_GetFaultStatus
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Clears the fault status registers for the selected BCC device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: FAULT1_STATUS, FAULT2_STATUS, FAULT3_STATUS, AN_OT_UT_FLT, CELL_OV_FLT, CELL_UV_FLT,
 *                                  GPIO_SHORT_ANX_OPEN_STS, CELL_OV_FLT, CELL_UV_FLT, ADC2_OFFSET_COMP
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The fault status registers were cleared successfully.
 * @retval      E_NOT_OK            The fault status registers were not cleared successfully.
 *
 */
Std_ReturnType Bcc_772c_FEH_ClearFaultStatus
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );
#endif /* (BCC_772C_FEH_SUPPORT == STD_ON) */

#if (BCC_772C_I2C_SUPPORT == STD_ON)
/*!
 * @brief   Writes data into the I2C Data register.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: EEPROM_CTRL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       I2CParams       Address to structure containig operation, EEPROM address and data to write.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Data was written successfully into the I2C Data register.
 * @retval      E_NOT_OK            Data was not written successfully into the I2C Data register.
 *
 */
Std_ReturnType Bcc_772c_I2C_CommandEEPROM
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bcc_772c_I2CParamsType* I2CParams,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief   Reads from the I2C Data register.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          List of used registers: EEPROM_CTRL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Data was read successfully from the I2C Data register.
 * @retval      E_NOT_OK            Data was not read successfully from the I2C Data register.
 *
 */
Std_ReturnType Bcc_772c_I2C_ReadResult
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType* MessageTD
    );
#endif /* (BCC_772C_I2C_SUPPORT == STD_ON) */

/*!
 * @brief Read multiple datas from a specific registers in a specific device.
 *
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 * @param[in]     ChainAddr   3 bit Chain Address
 * @param[in]     DevAddr     6 bit Physical Address field of the BCC device
 * @param[in]     RegAddr     7 bit Memory Address field of the BCC
 * @param[in]     RegCnt      Number of consecutive registers to read. Maximal value is 127.
 * @param[inout]  MessageTD   Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The values were read successfully from the specified registers.
 * @retval      E_NOT_OK            The values were not read successfully from the specified registers.
 *
 */
Std_ReturnType Bcc_772c_COM_ReadRegisters
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint8 RegAddr,
        uint8 RegCnt,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief Write a masked value into a specific register in a specific device.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ChainAddr       3 bit Chain Address.
 * @param[in]       DevAddr         6 bit Physical Address field of the BCC device.
 * @param[in]       MaskedData      Address to the information needed for writing register.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Value was written successfully into the specified register.
 * @retval      E_NOT_OK            Value was not written successfully into the specified register.
 *
 */
Std_ReturnType Bcc_772c_COM_WriteRegister
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bcc_772c_RegisterContentType* MaskedData,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief Read data from memory map.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ChainAddr       3 bit Chain Address
 * @param[in]       DevAddr         6 bit Physical Address field of the BCC device
 * @param[in]       RegAddr         Device memory address where the register will be read.
 * @param[inout]    RegData         Data read from memory map

 *
 * @return      Std_ReturnType
 * @retval      E_OK                The value was read successfully from the memory map.
 * @retval      E_NOT_OK            The value was not read successfully from the memory map.
 *
 */
Std_ReturnType Bcc_772c_MEM_ReadRegister
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        uint8 RegAddr,
        uint16 *RegData
    );

/*!
 * @brief This function is used to add a NOP message in MessageTD.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The NOP message was added successfully to MessageTD.
 * @retval      E_NOT_OK            The NOP message was not added successfully to MessageTD.
 *
 */
Std_ReturnType Bcc_772c_COM_InsertNop
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        const Bms_TDType *MessageTD
    );

/*!
 * @brief   Deinitialization of all Battery Cell Controller (BCC) device(s).
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Side effect:   Sets Bcc_772c_eDriverState to UNINIT.
 *
 */
void Bcc_772c_Deinit
    (
        void
    );

#if (BCC_772C_CC_SUPPORT == STD_ON)
/*!
 * @brief Helper service that computes the coulomb counter value from the available measurement data.
 *
 * @details - Sync or Async: Asynchronous
 *          - Reentrancy:    Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same MessageTD parameter.
 *
 *            List of used registers: COULOM_CNT1, COULOMB_CNT2
 *
 * @param[in]     ChainAddr   3 bit Chain Address
 * @param[in]     DevAddr     6 bit Physical Address field of the BCC device
 * @param[inout]  Value       32 bit concatenated coulomb count result value
 * @param[inout]  MessageTD   Address to the transaction descriptor in which the operation was appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The coulomb counter value was computed successfully.
 * @retval      E_NOT_OK            The coulomg count register addresses were not found in the transaction descriptor response buffer.
 *
 */
Std_ReturnType Bcc_772c_CC_ExtractCoulombCnt
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        sint32* Value,
        const Bms_TDType* MessageTD
    );

/*!
 * @brief Helper service that computes the the VSENSE and ISENSE values from the available measurement data.
 *
 * @details - Sync or Async: Asynchronous
 *          - Reentrancy:    Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 * @param[in]     ChainAddr   3 bit Chain Address
 * @param[in]     DevAddr     6 bit Physical Address field of the BCC device
 * @param[inout]  Value       Address to RSHUNT, VSENSE and ISENSE values.
 * @param[inout]  MessageTD   Address to the transaction descriptor in which the operation was appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The VSENSE and ISENSE values from the available measurement data were computed successfully.
 * @retval      E_NOT_OK            The registers needed for VSENSE and ISENSE computation were not found in the given transaction descriptor.
 *
 */
Std_ReturnType Bcc_772c_CC_ExtractISense
    (
        uint8 ChainAddr,
        uint8 DevAddr,
        Bcc_772c_CcISenseValueType* Value,
        const Bms_TDType* MessageTD
    );

#endif /* (BCC_772C_CC_SUPPORT == STD_ON) */

/*!
 * @brief   Resets the Memory Map Mirror for a specific device.
 * @details
 *
 * @param[in]       ChainAddr       Chain address for specific BJB device.
 * @param[in]       DevAddr         Address of specific BJB device.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Memory Map Mirror was reset successfully.
 * @retval      E_NOT_OK            Memory Map Mirror was not reset successfully.
 *
 */
Std_ReturnType Bcc_772c_MEM_ResetToDefault
    (
        uint8 ChainAddr,
        uint8 DevAddr
    );

#define BCC_772C_STOP_SEC_CODE
#include "Bcc_772c_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_BCC_772C_H */
