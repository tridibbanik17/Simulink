/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef BCC_774A_H
#define BCC_774A_H

/**
*   @file    CDD_Bcc_774a.h
*
*   @addtogroup CDD_BCC_774A
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bcc_774a_Cfg.h"
#include "SchM_Bcc_774a.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define BCC_774A_MODULE_ID                    255
#define BCC_774A_VENDOR_ID                    43
#define BCC_774A_AR_RELEASE_MAJOR_VERSION     4
#define BCC_774A_AR_RELEASE_MINOR_VERSION     7
#define BCC_774A_AR_RELEASE_REVISION_VERSION  0
#define BCC_774A_SW_MAJOR_VERSION             1
#define BCC_774A_SW_MINOR_VERSION             0
#define BCC_774A_SW_PATCH_VERSION             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if this header file and CDD_Bcc_774a_Cfg.h are of the same vendor */
#if (BCC_774A_VENDOR_ID != BCC_774A_VENDOR_ID_CFG)
#error "CDD_Bcc_774a.h and CDD_Bcc_774a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Bcc_774a_Cfg.h are of the same Autosar version */
#if ((BCC_774A_AR_RELEASE_MAJOR_VERSION != BCC_774A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (BCC_774A_AR_RELEASE_MINOR_VERSION != BCC_774A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (BCC_774A_AR_RELEASE_REVISION_VERSION != BCC_774A_AR_RELEASE_REVISION_VERSION_CFG) \
    )
#error "AutoSar Version Numbers of CDD_Bcc_774a.h and CDD_Bcc_774a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Bcc_774a_Cfg.h are of the same Software version */
#if ((BCC_774A_SW_MAJOR_VERSION != BCC_774A_SW_MAJOR_VERSION_CFG) || \
     (BCC_774A_SW_MINOR_VERSION != BCC_774A_SW_MINOR_VERSION_CFG) || \
     (BCC_774A_SW_PATCH_VERSION != BCC_774A_SW_PATCH_VERSION_CFG) \
    )
#error "Software Version Numbers of CDD_Bcc_774a.h and CDD_Bcc_774a_Cfg.h are different"
#endif

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/

    /* Error Values */
#if (BCC_774A_DEV_ERROR_DETECT == STD_ON)
/**
* @brief API service called with wrong parameter.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Parameter shall not be a NULL pointer.
*/
#define BCC_774A_E_PARAM_POINTER_U8         ((uint8)0x00u)
/**
* @brief Invalid configuration options.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Configuration options for SYS.
*/
#define BCC_774A_E_INVALID_SYS_CONFIG_U8    ((uint8)0x01u)
/**
* @brief Invalid MC33774 mode.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Mode option shall respect struct Bcc_774a_SysDriverModeType.
*/
#define BCC_774A_E_INVALID_MODE_U8          ((uint8)0x02u)
/**
* @brief MC33774 not yet initialized.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates MC33774 has to be initialized before certain operations.
*/
#define BCC_774A_E_UNINIT_U8                ((uint8)0x03u)
/**
* @brief Deep Sleep surviving register parameter invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Deep Sleep surviving register shall respect enum Bcc_774a_SysDSStorageType.
*/
#define BCC_774A_E_INVALID_DS_REG_U8        ((uint8)0x04u)
/**
* @brief Device driver already initialized.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Init function shall only be called if driver is uninitialized.
*/
#define BCC_774A_E_ALREADY_INIT_U8          ((uint8)0x05u)

#if (BCC_774A_GPIO_SUPPORT == STD_ON)
/**
* @brief GPIO configuration invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates GpioDirection and OpenDrainEn configuration options.
*/
#define BCC_774A_E_INVALID_GPIO_CONFIG_U8   ((uint8)0x06u)

#endif /* BCC_774A_GPIO_SUPPORT == STD_ON */

/**
* @brief BCC device address invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates ChainAddr and DevAddr addresses are not configuration-compliant.
*/
#define BCC_774A_E_INVALID_ADDR_U8          ((uint8)0x07u)

#if (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON)
/**
* @brief Event type specification invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Event type should comply to enum Bcc_774a_FehEventType.
*/
#define BCC_774A_E_INVALID_EVENTS_U8        ((uint8)0x09u)
#endif /* BCC_774A_FEH_EVENTS_SUPPORT == STD_ON  */

#if ((BCC_774A_FEH_EVENTS_SUPPORT == STD_ON) || (BCC_774A_FEH_ALARM_SUPPORT == STD_ON) || (BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON))
/**
* @brief FEH module configuration is invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Configuration options for FEH.
*/
#define BCC_774A_E_INVALID_FEH_CONFIG_U8    ((uint8)0x11u)
#endif /* BCC_774A_FEH_EVENTS_SUPPORT == STD_ON || BCC_774A_FEH_ALARM_SUPPORT == STD_ON || BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON */

/**
* @brief Invalid configuration options.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Configuration options for MSR.
*/
#define BCC_774A_E_INVALID_MSR_CONFIG_U8    ((uint8)0x12u)

#if (BCC_774A_I2C_SUPPORT == STD_ON)
/**
* @brief Invalid configuration options.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Configuration options for I2C.
*/
#define BCC_774A_E_INVALID_I2C_CONFIG_U8    ((uint8)0x13u)

#endif/* BCC_774A_I2C_SUPPORT == STD_ON */

#if (BCC_774A_BAL_SUPPORT == STD_ON)
/**
* @brief Invalid configuration options.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Configuration options for BAL.
*/
#define BCC_774A_E_INVALID_BAL_CONFIG_U8    ((uint8)0x14u)

#endif /* BCC_774A_BAL_SUPPORT == STD_ON */

/**
* @brief Invalid measurement option.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Measurement options.
*/
#define BCC_774A_E_INVALID_MEAS_U8          ((uint8)0x15u)
/**
* @brief The TD was not cleared after the previous transaction.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates TD append operation.
*/
#define BCC_774A_E_TD_NOT_CLEARED_U8        ((uint8)0x16u)
/**
* @brief The TD append operation failed due to overflow.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates TD append operation.
*/
#define BCC_774A_E_TD_OVERFLOW_U8           ((uint8)0x17u)
/**
* @brief The RegCnt value is invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Maximum number of registers to be read/written in one command.
*/
#define BCC_774A_E_INVALID_SIZE_U8          ((uint8)0x18u)
/**
* @brief Loopback method selected is invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Loopback method selection.
*/
#define BCC_774A_E_INVALID_LOOPBACK_METHOD_U8  ((uint8)0x19u)
/**
* @brief Number of nodes in a chain is invalid.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Number of nodes in a chain selection.
*/
#define BCC_774A_E_INVALID_NUMNODES_U8         ((uint8)0x1Au)
/**
* @brief Register is not part of memory map mirror.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Register is not part of memory map mirror.
*/
#define BCC_774A_E_INVALID_MEM_MAP_REGISTER_U8      ((uint8)0x1Bu)
/*
* @brief Invalid MemMap size selection.
*
* @implements Bcc_774a_ErrorCodes_define
*/
/*
* @violates Number of registers to update in MemMap exceeds range.
*/
#define BCC_774A_E_MEM_SIZE_U8              ((uint8)0x1CU)

    /* Service IDs */
/**
* @brief API service ID for Bcc_774a_Init function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_INIT_ID_U8                         ((uint8)0x00u)
/**
* @brief API service ID for Bcc_774a_Deinit function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_DEINIT_ID_U8                       ((uint8)0x01u)
/**
* @brief API service ID for Bcc_774a_SYS_SetMode function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SYS_SETMODE_ID_U8                  ((uint8)0x02u)
/**
* @brief API service ID for Bcc_774a_SYS_GetPreviousMode function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SYS_GETPREVIOUSMODE_ID_U8          ((uint8)0x03u)
/**
* @brief API service ID for Bcc_774a_SYS_GetVersion function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SYS_GETVERSION_ID_U8               ((uint8)0x04u)
/**
* @brief API service ID for Bcc_774a_SYS_GetHardwareVersion function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SYS_GETHARDWAREVERSION_ID_U8       ((uint8)0x05u)
/**
* @brief API service ID for Bcc_774a_SYS_WriteDSStorage function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SYS_WRITEDSSTORAGE_ID_U8           ((uint8)0x06u)
/**
* @brief API service ID for Bcc_774a_SYS_ReadDSStorage function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SYS_READDSSTORAGE_ID_U8            ((uint8)0x07u)

#if (BCC_774A_GPIO_SUPPORT == STD_ON)
/**
* @brief API service ID for Bcc_774a_GPIO_Configure function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_GPIO_CONFIGURE_ID_U8               ((uint8)0x08u)
/**
* @brief API service ID for Bcc_774a_GPIO_GetInput function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_GPIO_GETINPUT_ID_U8                ((uint8)0x09u)
/**
* @brief API service ID for Bcc_774a_GPIO_SetOutput function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_GPIO_SETOUTPUT_ID_U8               ((uint8)0x10u)
#endif /* BCC_774A_GPIO_SUPPORT == STD_ON */

#if (BCC_774A_I2C_SUPPORT == STD_ON)
/**
* @brief API service ID for Bcc_774a_I2C_Configure function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_I2C_CONFIGURE_ID_U8                ((uint8)0x11u)
/**
* @brief API service ID for Bcc_774a_I2C_GetStatus function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_I2C_GETSTATUS_ID_U8                ((uint8)0x12u)
/**
* @brief API service ID for Bcc_774a_I2C_SetData function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_I2C_SETDATA_ID_U8                  ((uint8)0x13u)
/**
* @brief API service ID for Bcc_774a_I2C_GetData function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_I2C_GETDATA_ID_U8                  ((uint8)0x14u)

#endif /* BCC_774A_I2C_SUPPORT == STD_ON */

#if (BCC_774A_FEH_ALARM_SUPPORT == STD_ON)
/**
* @brief API service ID for Bcc_774a_FEH_ConfigureAlarm function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_CONFIGUREALARM_ID_U8           ((uint8)0x15u)
/**
* @brief API service ID for Bcc_774a_FEH_GetAlarmReason function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_GETALARMREASON_ID_U8           ((uint8)0x16u)
#endif /* BCC_774A_FEH_ALARM_SUPPORT == STD_ON */

#if (BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON)
/**
* @brief API service ID for Bcc_774a_FEH_ConfigureWakeup function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_CONFIGUREWAKEUP_ID_U8                ((uint8)0x17u)
/**
* @brief API service ID for Bcc_774a_FEH_GetWakeupReason function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_GETWAKEUPREASON_ID_U8          ((uint8)0x18u)
#endif /* BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON */

/**
* @brief API service ID for Bcc_774a_FEH_RunBIST function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_RUNBIST_ID_U8                  ((uint8)0x19u)
/**
* @brief API service ID for Bcc_774a_FEH_ReadBISTResult function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_READBISTRESULT_ID_U8           ((uint8)0x20u)

#if (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON)
/**
* @brief API service ID for Bcc_774a_FEH_GetFaultStatus function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_GETFAULTSTATUS_ID_U8           ((uint8)0x21u)
/**
* @brief API service ID for Bcc_774a_FEH_ConfigureEvents function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_CONFIGUREEVENTS_ID_U8                ((uint8)0x22u)
/**
* @brief API service ID for Bcc_774a_FEH_GetResetReason function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_FEH_GETRESETREASON_ID_U8           ((uint8)0x23u)
#endif /* BCC_774A_FEH_EVENTS_SUPPORT == STD_ON */

/**
* @brief API service ID for Bcc_774a_SYS_Configure function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SYS_CONFIGURE_ID_U8                ((uint8)0x24u)

#if (BCC_774A_BAL_SUPPORT == STD_ON)
/**
* @brief API service ID for Bcc_774a_BAL_SetGlobalConfiguration function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_BAL_SETGLOBALCONFIGURATION_ID_U8   ((uint8)0x25u)
/**
* @brief API service ID for Bcc_774a_BAL_GetStatus function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_BAL_GETSTATUS_ID_U8                ((uint8)0x26u)
/**
* @brief API service ID for Bcc_774a_BAL_SetChannelConfiguration function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_BAL_SETCHANNELCONFIGURATION_ID_U8  ((uint8)0x27u)
/**
* @brief API service ID for Bcc_774a_BAL_EmergencyDischarge function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_BAL_EMERGENCYDISCHARGE_ID_U8       ((uint8)0x28u)
#endif /* BCC_774A_BAL_SUPPORT == STD_ON */

/**
* @brief API service ID for Bcc_774a_MSR_StartMeasurements function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_MSR_STARTMEASUREMENTS_ID_U8        ((uint8)0x29u)
/**
* @brief API service ID for Bcc_774a_MSR_StopMeasurements function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_MSR_STOPMEASUREMENTS_ID_U8         ((uint8)0x30u)
/**
* @brief API service ID for Bcc_774a_MSR_SetMode function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_MSR_SETMODE_ID_U8                  ((uint8)0x31u)
/**
* @brief API service ID for Bcc_774a_MSR_Configure function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_MSR_CONFIGURE_ID_U8                ((uint8)0x34u)
/**
* @brief API service ID for Bcc_774a_MSR_GetData function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_MSR_GETDATA_ID_U8                  ((uint8)0x36u)
/**
* @brief API service ID for Bcc_774a_MSR_GetStatus function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_MSR_GETSTATUS_ID_U8                ((uint8)0x37u)
/**
* @brief API service ID for Bcc_774a_MSR_GetFaults function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_MSR_GETFAULTS_ID_U8                ((uint8)0x38u)
/**
* @brief API service ID for Bcc_774a_COM_WriteRegisters function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_COM_WRITEREG_ID_U8                 ((uint8)0x40u)
/**
* @brief API service ID for Bcc_774a_COM_ReadRegisters function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_COM_READREG_ID_U8                  ((uint8)0x41u)
/**
* @brief API service ID for Bcc_774a_Enumerate function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_ENUMERATE_ID_U8                    ((uint8)0x42u)
/**
* @brief API service ID for Bcc_774a_COM_WakeupChain function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_COM_WAKEUPCHAIN_ID_U8                  ((uint8)0x43u)
/**
* @brief API service ID for Bcc_774a_COM_InsertNop function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_COM_INSERTNOP_ID_U8                  ((uint8)0x47u)
/**
* @brief API service ID for Bcc_774a_SetMADD function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SETMADD_ID_U8                      ((uint8)0x48u)
/**
* @brief API service ID for Bcc_774a_LoopbackConfigure function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_LOOPBACKCONFIGURE_ID_U8            ((uint8)0x49u)
/**
* @brief API service ID for Bcc_774a_SetNumNodes function.
* @details Parameters used when raising an error or exception.
*
*/
#define BCC_774A_SETNUMNODES_ID_U8                  ((uint8)0x4Au)
/**
 * @brief API service ID for Bcc_774a_MEM_ReadRegister function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_774A_MEM_READ_ID_U8          ((uint8)0x4Bu)
/**
 * @brief API service ID for Bcc_774a_MEM_Update function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_774A_MEM_UPDATE_ID_U8               ((uint8)0x4Cu)
/**
 * @brief API service ID for Bcc_774a_MEM_ResetToDefault function.
 * @details Parameters used when raising an error or exception.
 *
 */
#define BCC_774A_MEM_RESET_ID_U8               ((uint8)0x4Du)


#endif /* BCC_774A_DEV_ERROR_DETECT == STD_ON */

/*==================================================================================================
*                                            ENUMS
==================================================================================================*/
/**
* @brief   This type defines a range of specific status for Bcc_774a Driver.
*
* @implements Bcc_774a_DriverStatusType_enum
*/
typedef enum
{
    BCC_774A_UNINITIALIZED = 0U,          /**< @brief Driver internal data not initialized or not usable. */
    BCC_774A_INITIALIZED                  /**< @brief Driver internal data initialized. */
} Bcc_774a_DriverStatusType;

/**
* @brief   Describes the operating mode of a BCC device.
*
* @implements Bcc_774a_SysDriverModeType_enum
*/
typedef enum
{
    BCC_774A_SYS_MODE_ACTIVE     = 0x01u,            /**< @brief MC33774 in ACTIVE mode. */
    BCC_774A_SYS_MODE_SLEEP      = 0x0Au,            /**< @brief MC33774 in SLEEP mode. */
    BCC_774A_SYS_MODE_DEEPSLEEP  = 0x14u,            /**< @brief MC33774 in DEEP SLEEP mode. */
    BCC_774A_SYS_MODE_CYCLIC     = 0x1Fu             /**< @brief MC33774 in CYCLIC mode. */
} Bcc_774a_SysDriverModeType;

/**
 * @brief Specifies the Deep Sleep surviving registers to be addressed.
 *
 * @implements Bcc_774a_SysDSStorageType_enum
 */
typedef enum
{
    BCC_774A_SYS_DS_STORAGE_0 = 0U,      /**< @brief SYS_DS_STORAGE0 */
    BCC_774A_SYS_DS_STORAGE_1,           /**< @brief SYS_DS_STORAGE1 */
    BCC_774A_SYS_DS_STORAGE_BOTH         /**< @brief Both SYS_DS_STORAGE0 and SYS_DS_STORAGE1 */
} Bcc_774a_SysDSStorageType;

#if (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON)
/**
 * @brief Defines event types that are used by the device to trigger fault events.
 *
 * @implements Bcc_774a_FehEventType_enum
 */
typedef enum
{
    BCC_774A_FEH_EVT_SUPPLY_0  = 0U,       /**< @brief Supply voltages event/fault (register 0) */
    BCC_774A_FEH_EVT_SUPPLY_1,             /**< @brief Supply voltages event/fault (register 1) */
    BCC_774A_FEH_EVT_ANALOG,               /**< @brief Analog event/fault */
    BCC_774A_FEH_EVT_COMM,                 /**< @brief Communication-related event/fault */
    BCC_774A_FEH_EVT_MEAS,                 /**< @brief Measurement-related event/fault */
    BCC_774A_FEH_EVT_ALL_EVENTS            /**< @brief All events/faults */
} Bcc_774a_FehEventType;
#endif /* (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON) */

#if (BCC_774A_BAL_SUPPORT == STD_ON)
/**
 * @brief Specifies source channel for temperature measurement.
 *
 * @implements Bcc_774a_BalTempSourceType_enum
 */
typedef enum
{
    BCC_774A_BAL_TMP_SOURCE_AIN0 = 0U,   /**< @brief AIN0 as source */
    BCC_774A_BAL_TMP_SOURCE_AIN1,        /**< @brief AIN1 as source */
    BCC_774A_BAL_TMP_SOURCE_AIN2,        /**< @brief AIN2 as source */
    BCC_774A_BAL_TMP_SOURCE_AIN3,        /**< @brief AIN3 as source */
    BCC_774A_BAL_TMP_SOURCE_AINA         /**< @brief AINA as source */
} Bcc_774a_BalTempSourceType;
#endif /* (BCC_774A_BAL_SUPPORT == STD_ON) */

/**
 * @brief Defines the measurement chain to perform specific operations on.
 *
 * BCC_774A_MSR_CHAIN_SYNCHRONOUS specifies that both the PRIMARY and SECONDARY chains will be used.
 *
 * @implements Bcc_774a_MsrChainType_enum
 */
typedef enum
{
    BCC_774A_MSR_CHAIN_PRIMARY = 0U,   /**< @brief Primary measurement chain to be used */
    BCC_774A_MSR_CHAIN_SECONDARY,      /**< @brief Secondary measurement chain to be used */
    BCC_774A_MSR_CHAIN_SYNCHRONOUS     /**< @brief Both Primary and Secondary measurement chains to be used */
} Bcc_774a_MsrChainType;

/**
 * @brief Defines the measurement type to perform specific operations on.
 *
 * @implements Bcc_774a_MsrMeasurementType_enum
 */
typedef enum
{
    BCC_774A_MSR_TYPE_PERIODIC = 0U,                /**< @brief Periodic measurement */
    BCC_774A_MSR_TYPE_APPLICATION,                  /**< @brief Application timed continuous measurements */
    BCC_774A_MSR_TYPE_SYNCHRONOUS,                  /**< @brief Synchronized measurement */
    BCC_774A_MSR_TYPE_FASTVB,                       /**< @brief FastVB measurement */
    BCC_774A_MSR_TYPE_PERIODIC_VCx,                 /**< @brief Periodic measurement for VCx */
    BCC_774A_MSR_TYPE_PERIODIC_AINx,                /**< @brief Periodic measurement for AINx */
    BCC_774A_MSR_TYPE_PERIODIC_PRMTEMP,             /**< @brief Periodic measurement for PRMTEMP */
    BCC_774A_MSR_TYPE_PERIODIC_SECVREF,             /**< @brief Periodic measurement for SECVREF */
    BCC_774A_MSR_TYPE_PERIODIC_VAUX,                /**< @brief Periodic measurement for VAUX */
    BCC_774A_MSR_TYPE_PERIODIC_VBAT,                /**< @brief Periodic measurement for VBAT */
    BCC_774A_MSR_TYPE_PERIODIC_VDDA,                /**< @brief Periodic measurement for VDDA */
    BCC_774A_MSR_TYPE_PERIODIC_VDDC,                /**< @brief Periodic measurement for VDDC */
    BCC_774A_MSR_TYPE_PERIODIC_SECTEMP,             /**< @brief Periodic measurement for SECTEMP */
    BCC_774A_MSR_TYPE_PERIODIC_PRMVREF,             /**< @brief Periodic measurement for PRMVREF */
    BCC_774A_MSR_TYPE_PERIODIC_NPNISENSE,           /**< @brief Periodic measurement for NPNISENSE */
    BCC_774A_MSR_TYPE_APPLICATION_VCx,              /**< @brief Application timed continuous measurements for VCx */
    BCC_774A_MSR_TYPE_APPLICATION_AINx,             /**< @brief Application timed continuous measurements for AINx */
    BCC_774A_MSR_TYPE_PERIODIC_INTERNAL_VOLTAGES    /**< @brief Periodic measurement for internal voltages */
} Bcc_774a_MsrMeasurementType;

/*==================================================================================================
*                                STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*---------------------------------------------------------------------------
*                 Bcc_774a Driver AUTOSAR Related Type Definitions
-----------------------------------------------------------------------------*/
#if (BCC_774A_BAL_SUPPORT == STD_ON)
/**
 * @brief   All information needed for balancing configuration.
 *
 * @implements Bcc_774a_BalConfigurationType_struct
 */
typedef struct
{
    boolean                     CCMBal;             /**< @brief Constant current balancing enable */
    boolean                     GlobalUvBal;        /**< @brief Stop balancing for all cells once the global undervoltage threshold is reached by any cell */
    boolean                     CellUvBal;          /**< @brief Stop balancing once each individual channel reaches the under-voltage threshold. */
    boolean                     TimerBasedBal;      /**< @brief Stop balancing for all cells when cell balancing timer expires */
    boolean                     TmpBalEn;           /**< @brief Temperature-based balancing enable */
    Bcc_774a_BalTempSourceType  TmpSrc;             /**< @brief Source channel for temperature measurement */
    uint16                      PreBalTimer;        /**< @brief Pre-balancing timer */
    uint16                      GlobalBalTimer;     /**< @brief Global balancing timer */
    uint16                      BalChannels0En;     /**< @brief Mask to enable balancing channels from 0 to 15 */
    uint16                      BalChannels1En;     /**< @brief Mask to enable balancing channels 16 and 17 */
    uint16                      BalSwitchMon0En;    /**< @brief Mask to enable balancing switch monitoring for channels 0 to 15 */
    uint16                      BalSwitchMon1En;    /**< @brief Mask to enable balancing switch monitoring for channels 16 and 17 */
    uint16                      PWMCycleVoltage;    /**< @brief FULL PWM cycle voltage to set the cell voltage on which the balancing is operating at maximum current */
} Bcc_774a_BalConfigurationType;

/**
 * @brief   All information needed for channel balancing.
 *
 * @implements Bcc_774a_BalChannelConfigurationType_struct
 */
typedef struct
{
    uint8                           ChannelNo;      /**< @brief ID of channel to be configured */
    uint8                           PWM;            /**< @brief Sets balancing PWM for ChannelNo. DutyCycle = PWM*100/255% */
    uint16                          Timer;          /**< @brief 14-bit timer value */
} Bcc_774a_BalChannelConfigurationType;
#endif /* (BCC_774A_BAL_SUPPORT == STD_ON) */

/**
 * @brief   Balance pause configuration.
 *
 * @implements Bcc_774a_MsrBalPauseType_struct
 */
typedef struct
{
    uint16  BalancingPauseTimer;    /**< @brief 14-bit timer before MSR cycle is executed */
    boolean BalancingAutopauseEn;   /**< @brief Balancing autopause to delay start of MSR in CYC mode */
} Bcc_774a_MsrBalPauseType;

/**
 * @brief   Information needed for balancing pausing and open load detection.
 *
 * @implements Bcc_774a_MsrSetModeParamsType_struct
 */
typedef struct
{
    boolean PauseBalancing;       /**< @brief Pause balancing process during the measurement cycle */
    uint8   OpenLoadNum;          /**< @brief VC/VB to configure open load detection for */
} Bcc_774a_MsrSetModeParamsType;

/**
 * @brief   Information needed for reading/writing registers
 *
 * @implements Bcc_774a_RWRegistersType_struct
 */
typedef struct
{
    uint16        RegAddr;            /**< @brief 14 bit Memory Address field of the BCC */
    uint16         RegCnt;             /**< @brief Number of consecutive registers to be addressed (1 - 4 for WRITE, 1-256 for READ) */
    const uint16  *Data;              /**< @brief 16 bit frame Pointer to an data array in data field */
} Bcc_774a_RWRegistersType;

/**
 * @brief   Information needed by the packing function to determine the command and the specific device.
 *
 */
typedef struct
{
    uint8 CmdCode;          /**< @brief 2bit frame type: 00 wake-up, 01 read request, 02 write 03 response */
    uint8 ChainAddr;        /**< @brief 4 bit diasychain Address */
    uint8 DevAddr;          /**< @brief 6 bit Physical Address field of the BCC, 0 Unenumerated device, 1-62 device address, 63 all device */
} Bcc_774a_PackMsgParamsType;


/*---------------------------------------------------------------------------
*     Bcc_774a Driver Low Level Implementation Specific Type Definitions
-----------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------
*     Bcc_774a Driver Configuration Main Structure
-----------------------------------------------------------------------------*/
/**
* @brief   This is the top level structure containing all the
*          needed parameters for the Bcc_774a Handler Driver.
*
* @implements Bcc_774a_DriverConfigType_struct
*/
typedef struct
{
    const Bcc_774a_DeviceConfigType *DeviceConfigSets;
    const BmsTpl3ChainConfigType *BmsCommonChainsConfig;
} Bcc_774a_DriverConfigType;

/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/**
* brief   Export Post-Build configurations.
*/
#if (BCC_774A_PRECOMPILE_SUPPORT == STD_OFF)

#define BCC_774A_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_774a_MemMap.h"

/** @cond */
BCC_774A_CONFIG_EXT
/*! @endcond */

#define BCC_774A_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_774a_MemMap.h"

#endif /* (BCC_774A_PRECOMPILE_SUPPORT == STD_OFF) */

#define BCC_774A_START_SEC_VAR_INIT_UNSPECIFIED
#include "Bcc_774a_MemMap.h"

/**
 * @brief   Keeps track of Bcc_774a internal state.
 *
 * @implements Bcc_774a_eDriverState_datastore
 */
extern Bcc_774a_DriverStatusType Bcc_774a_eDriverState;

#define BCC_774A_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Bcc_774a_MemMap.h"



#define BCC_774A_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Bcc_774a_MemMap.h"

extern Bcc_774a_CheckChainStateType Bcc_774a_aArrChains[BCC_774A_CHAIN_CNT_MAX_TPL];

/**
 * @brief   Keeps track of Bcc_774a devices' state.
 *
 * @implements Bcc_774a_DeviceStateMap_datastore
 */
extern Bcc_774a_HashMapType Bcc_774a_xDeviceStateMap;

#define BCC_774A_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Bcc_774a_MemMap.h"

/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/

#define BCC_774A_START_SEC_CODE
#include "Bcc_774a_MemMap.h"

/*!
 * @brief   Initialization of Battery Cell Controller (BCC) device(s).
 * @details
 *          - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Side effect:   Sets Bcc_774a_eDriverState to INIT.
 *
 * @param[in]   DriverConfig    Internal driver data to be initialized.
 *
 * @return      Std_ReturnType
 * @retval      E_OK            The initialization of the Battery Cell Controller (BCC) device(s) was successful.
 * @retval      E_NOT_OK        The initialization of the Battery Cell Controller (BCC) device(s) was not successful.
 *
 */
Std_ReturnType Bcc_774a_Init(const Bcc_774a_DriverConfigType *DriverConfig);

/*!
 * @brief   This function is used to enumerate a device
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          -  Memory needed in the request buffer: 8 words
 *          -  Memory needed in the response buffer: 4 words
 *          -  List of used registers: SYS_COM_CFG
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Device was successfully enumerated.
 * @retval      E_NOT_OK            Device was not successfully enumerated.
 *
 */
Std_ReturnType Bcc_774a_Enumerate(uint8 ChainAddr,
                                  uint8 DevAddr,
                                  const Bms_TDType* MessageTD
                                 );

/*!
 * @brief   Deinitialization of all Battery Cell Controller (BCC) device(s).
 * @details
 *           - Sync or Async: Synchronous
 *           - Reentrancy:    Non-Reentrant
 *           - Side effect:   Sets Bcc_774a_eDriverState to UNINIT.
 *
 */
void Bcc_774a_Deinit(void);

    /*** SYS module API ***/

/*!
 * @brief   Configures the selected Battery Cell Controller device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer:
 *              - 17 words - TPL encoding = Variable
 *              - 20 words - TPL encoding = Fixed 64
 *          - List of used registers: SYS_COM_CFG, SYS_COM_TO_CFG, SYS_TPL_CFG, SYS_CLK_SYNC_CTRL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The configuration of the selected Battery Cell Controller device was successful.
 * @retval      E_NOT_OK            The configuration of the selected Battery Cell Controller device was not successful.
 *
 */
Std_ReturnType Bcc_774a_SYS_Configure(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      uint16 ConfigIdx,
                                      const Bms_TDType* MessageTD
                                     );

/*!
 * @brief   Sets the operating mode for all Battery Cell Controller devices.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - BCC_774A_SYS_MODE_CYCLIC shall be configured with non-zero CyclicTimer.
 *          - Setting the devices into DEEPSLEEP mode will require the driver to
 *            re-enumerate the devices by calling Bcc_774a_Init again.
 *
 *          - May report BCC_774A_E_INVALID_MODE_U8 on invalid mode parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *            - 5 words - TPL encoding = Variable
 *            - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: SYS_MODE, SYS_CYC_WAKEUP_CFG
 *
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       Mode            MC33774 mode to set as of Bcc_774a_SysDriverModeType.
 * @param[in]       CyclicTimer     Timer used only for Cyclic mode (ignored else).
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The operating mode for all Battery Cell Controller devices was set successfully.
 * @retval      E_NOT_OK            The operating mode for all Battery Cell Controller devices was not set successfully.
 * 
 */
Std_ReturnType Bcc_774a_SYS_SetMode(uint8 ChainAddr,
                                    uint8 DevAddr,
                                    Bcc_774a_SysDriverModeType Mode,
                                    uint16 CyclicTimer,
                                    const Bms_TDType* MessageTD
                                   );

/*!
 * @brief   Retrieves last known operating mode from a Battery Cell Controller device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer: 4 words
 *          - List of used registers: SYS_MODE
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Last known operating mode from a Battery Cell Controller device was retrieved successfully.
 * @retval      E_NOT_OK            Last known operating mode from a Battery Cell Controller device was not retrieved successfully.
 * 
 */
Std_ReturnType Bcc_774a_SYS_GetPreviousMode(uint8 ChainAddr,
                                            uint8 DevAddr,
                                            const Bms_TDType* MessageTD
                                           );

/*!
 * @brief   Returns the version information of this module.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 * @param[out]      VersionInfo    Pointer to user-allocated structure to be filled in.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Version information of this module was returned successfully.
 * @retval      E_NOT_OK            Version information of this module was not returned successfully.
 * 
 */
void Bcc_774a_SYS_GetVersion(Std_VersionInfoType *VersionInfo);

/*!
 * @brief   Retrieves hardware version and unique identifier from a Battery Cell Controller device.
 * @details - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer:
 *            - 11 words - TPL encoding = Variable
 *            - 20 words - TPL encoding = Fixed 64
 *          - List of used registers: SYS_VERSION, SYS_UID_LOW, SYS_UID_MID, SYS_UID_HIGH, SYS_PROD_VER
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Hardware version and unique identifier from a Battery Cell Controller device were retrieved successfully.
 * @retval      E_NOT_OK            Hardware version and unique identifier from a Battery Cell Controller device were not retrieved successfully.
 * 
 */
Std_ReturnType Bcc_774a_SYS_GetHardwareVersion(uint8 ChainAddr,
                                               uint8 DevAddr,
                                               const Bms_TDType* MessageTD
                                              );

/*!
 * @brief   Writes Deep Sleep surviving registers of  a Battery Cell Controller device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Writes SYS_DS_STORAGE1 with DSRegisterData[31:16].
 *          - Writes SYS_DS_STORAGE0 with DSRegisterData[15:0].
 *
 *          - Maximum memory needed in the transaction descriptor:
 *            - 5 words - TPL encoding = Variable
 *            - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: SYS_DS_STORAGE0, SYS_DS_STORAGE1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       DSRegisterNum   Specifies Deep Sleep surviving register(s) to write.
 * @param[in]       DSRegisterData  Pointer to an array with the register data
 *                                  A single element is needed when writing a single register
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Deep Sleep surviving registers of the Battery Cell Controller device were successfully written.
 * @retval      E_NOT_OK            Deep Sleep surviving registers of the Battery Cell Controller device were not successfully written.
 * 
 */
Std_ReturnType Bcc_774a_SYS_WriteDSStorage(uint8 ChainAddr,
                                           uint8 DevAddr,
                                           Bcc_774a_SysDSStorageType DSRegisterNum,
                                           const uint16 *DSRegisterData,
                                           const Bms_TDType* MessageTD
                                          );

/*!
 * @brief   Reads Deep Sleep surviving registers of a Battery Cell Controller device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Reads SYS_DS_STORAGE1 into DSRegisterData[31:16].
 *          - Reads SYS_DS_STORAGE0 into DSRegisterData[15:0].
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer:
 *             - 5 words - TPL encoding = Variable
 *             - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: SYS_DS_STORAGE0, SYS_DS_STORAGE1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       DSRegisterNum   Specifies Deep Sleep surviving register(s) to write.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Deep Sleep surviving registers of the Battery Cell Controller device were successfully read.
 * @retval      E_NOT_OK            Deep Sleep surviving registers of the Battery Cell Controller device were not successfully read.
 * 
 */
Std_ReturnType Bcc_774a_SYS_ReadDSStorage(uint8 ChainAddr,
                                          uint8 DevAddr,
                                          Bcc_774a_SysDSStorageType DSRegisterNum,
                                          const Bms_TDType* MessageTD
                                         );

#if (BCC_774A_GPIO_SUPPORT == STD_ON)
    /*** GPIO module API ***/

/*!
 * @brief   Configures the GPIO pins direction of a Battery Cell Controller device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - If direction for a pin is set as output, the open drain shall be configured.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *             - 5 words - TPL encoding = Variable
 *             - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: GPIO_CFG0, GPIO_CFG1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Configuration of the GPIO pins direction of a Battery Cell Controller device was successful.
 * @retval      E_NOT_OK            Configuration of the GPIO pins direction of a Battery Cell Controller device was not successful.
 * 
 */
Std_ReturnType Bcc_774a_GPIO_Configure(uint8 ChainAddr,
                                       uint8 DevAddr,
                                       uint16 ConfigIdx,
                                       const Bms_TDType* MessageTD
                                      );

/*!
 * @brief   Reads the input values of GPIO pins for a Battery Cell Controller device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Reads input values (low/high) of GPIO pins + whether a high level was present
 *          since the last read command.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer: 4 words
 *          - List of used registers: GPIO_IN
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The input values of GPIO pins for a Battery Cell Controller device were read successfully.
 * @retval      E_NOT_OK            The input values of GPIO pins for a Battery Cell Controller device were not read successfully.
 * 
 */
Std_ReturnType Bcc_774a_GPIO_GetInput(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      const Bms_TDType* MessageTD
                                     );

/*!
 * @brief   Sets the output values of GPIO pins for a Battery Cell Controller device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - If direction for a pin is set as output, the open drain shall be configured.
 *
 *          - Maximum memory needed in the transaction descriptor: 4 words
 *          - List of used registers: GPIO_OUT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       OutputValue     Value to write GPIO pins with.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The output values of GPIO pins for a Battery Cell Controller device were set successfully.
 * @retval      E_NOT_OK            The output values of GPIO pins for a Battery Cell Controller device were not set successfully.
 *
 */
Std_ReturnType Bcc_774a_GPIO_SetOutput(uint8 ChainAddr,
                                       uint8 DevAddr,
                                       uint8 OutputValue,
                                       const Bms_TDType* MessageTD
                                      );
#endif /* (BCC_774A_GPIO_SUPPORT == STD_ON) */

    /*** I2C module API ***/

#if (BCC_774A_I2C_SUPPORT == STD_ON)
/*!
 * @brief   Enables and configures I2C communication for the specified BCC device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *              - 5 words - TPL encoding = Variable
 *              - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: I2C_CFG, I2C_CTRL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                I2C communication for the specified BCC device was enabled and configured successfully.
 * @retval      E_NOT_OK            I2C communication for the specified BCC device was not enabled and configured successfully.
 *
 */
Std_ReturnType Bcc_774a_I2C_Configure(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      uint16 ConfigIdx,
                                      const Bms_TDType* MessageTD
                                     );

/*!
 * @brief   Provides the I2C Master status by reading the corresponding register.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer: 4 words
 *          - List of used registers: I2C_STAT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                I2C Master status was provided successfully.
 * @retval      E_NOT_OK            I2C Master status was not provided successfully.
 *
 */
Std_ReturnType Bcc_774a_I2C_GetStatus(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      const Bms_TDType* MessageTD
                                     );

/*!
 * @brief   Writes data into the I2C Data registers.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *              - 33 words - TPL encoding = Variable
 *              - 72 words - TPL encoding = Fixed 64
 *          - List of used registers: I2C_DATA0, I2C_DATA1, I2C_DATA2, I2C_DATA3, I2C_DATA4, I2C_DATA5, I2C_DATA6,
 *                                    I2C_DATA7, I2C_DATA8, I2C_DATA9, I2C_DATA10, I2C_DATA11, I2C_DATA12, I2C_DATA13,
 *                                    I2C_DATA14, I2C_DATA15, I2C_DATA16, I2C_DATA17
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       Data            Pointer to buffer containing data to be written.
 * @param[in]       RegCnt          Number of data registers to be written.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Data was written successfully into the I2C Data registers.
 * @retval      E_NOT_OK            Data was not written successfully into the I2C Data registers.
 *
 */
Std_ReturnType Bcc_774a_I2C_SetData(uint8 ChainAddr,
                                    uint8 DevAddr,
                                    const uint16 *Data,
                                    uint8 RegCnt,
                                    const Bms_TDType* MessageTD
                                   );

/*!
 * @brief   Reads data from the I2C Data registers.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer:
 *              - 33 words - TPL encoding = Variable
 *              - 72 words - TPL encoding = Fixed 64
 *          - List of used registers: I2C_DATA0, I2C_DATA1, I2C_DATA2, I2C_DATA3, I2C_DATA4, I2C_DATA5, I2C_DATA6,
 *                                    I2C_DATA7, I2C_DATA8, I2C_DATA9, I2C_DATA10, I2C_DATA11, I2C_DATA12, I2C_DATA13,
 *                                    I2C_DATA14, I2C_DATA15, I2C_DATA16, I2C_DATA17
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       RegCnt          Number of data registers to be read.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Data was read successfully from the I2C Data registers.
 * @retval      E_NOT_OK            Data was not read successfully from the I2C Data registers.
 *
 */
Std_ReturnType Bcc_774a_I2C_GetData(uint8 ChainAddr,
                                    uint8 DevAddr,
                                    uint8 RegCnt,
                                    const Bms_TDType* MessageTD
                                   );
#endif /* (BCC_774A_I2C_SUPPORT == STD_ON) */

    /*** FEH module API ***/
#if (BCC_774A_FEH_ALARM_SUPPORT == STD_ON)
/*!
 * @brief   Configures the behaviour and sources for alarm(s) on a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *              - 6 words - TPL encoding = Variable
 *              - 12 words - TPL encoding = Fixed 64
 *          - List of used registers: FEH_ALARM_CFG, FEH_ALARM_OUT_CFG0, FEH_ALARM_OUT_CFG1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The behaviour and sources for alarm(s) on a specific device were configured successfully.
 * @retval      E_NOT_OK            The behaviour and sources for alarm(s) on a specific device were not configured successfully.
 *
 */
Std_ReturnType Bcc_774a_FEH_ConfigureAlarm(uint8 ChainAddr,
                                           uint8 DevAddr,
                                           uint16 ConfigIdx,
                                           const Bms_TDType* MessageTD
                                          );

/*!
 * @brief   Retrieves the reason for alarm triggering from a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer:
 *              - 5 words - TPL encoding = Variable
 *              - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: FEH_ALARM_OUT_REASON0, FEH_ALARM_OUT_REASON1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The reason for alarm triggering from a specific device was retrieved successfully.
 * @retval      E_NOT_OK            The reason for alarm triggering from a specific device was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_774a_FEH_GetAlarmReason(uint8 ChainAddr,
                                           uint8 DevAddr,
                                           const Bms_TDType* MessageTD
                                          );
#endif /* (BCC_774A_FEH_ALARM_SUPPORT == STD_ON) */

#if (BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON)
/*!
 * @brief   Configures the wakeup source for a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *              - 5 words - TPL encoding = Variable
 *              - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: FEH_WAKEUP_CFG0, FEH_WAKEUP_CFG1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The wakeup source for a specific device was configured successfully.
 * @retval      E_NOT_OK            The wakeup source for a specific device was not configured successfully.
 *
 */
Std_ReturnType Bcc_774a_FEH_ConfigureWakeup(uint8 ChainAddr,
                                            uint8 DevAddr,
                                            uint16 ConfigIdx,
                                            const Bms_TDType* MessageTD
                                           );

/*!
 * @brief   Retrieves the reason for wakeup event from a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer:
 *              - 5 words - TPL encoding = Variable
 *              - 8 words - TPL encoding = Fixed 64
 *          - List of used registers: FEH_WAKEUP_REASON0, FEH_WAKEUP_REASON1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The reason for wakeup event from a specific device was retrieved successfully.
 * @retval      E_NOT_OK            The reason for wakeup event from a specific device was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_774a_FEH_GetWakeupReason(uint8 ChainAddr,
                                            uint8 DevAddr,
                                            const Bms_TDType* MessageTD
                                           );
#endif /* (BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON) */

/*!
 * @brief   Starts a manual Built-in Self Test (BIST) for a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor: 4 words
 *          - List of used registers: FEH_MON_BIST_CTRL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The manual Built-in Self Test (BIST) for a specific device started successfully.
 * @retval      E_NOT_OK            The manual Built-in Self Test (BIST) for a specific device did not start successfully.
 *
 */
Std_ReturnType Bcc_774a_FEH_RunBIST(uint8 ChainAddr,
                                    uint8 DevAddr,
                                    const Bms_TDType* MessageTD
                                   );

/*!
 * @brief   Retrieves the BIST result from a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer: 4 words
 *          - List of used registers: FEH_MON_BIST_RES
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The BIST result from a specific device was successfully retrieved.
 * @retval      E_NOT_OK            The BIST result from a specific device was not successfully retrieved.
 *
 */
Std_ReturnType Bcc_774a_FEH_ReadBISTResult(uint8 ChainAddr,
                                           uint8 DevAddr,
                                           const Bms_TDType* MessageTD
                                          );

#if (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON)
/*!
 * @brief   Retrieves fault event status from a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Using BCC_774A_FEH_EVT_ALL_EVENTS also appends the content of FEH_ACC_ERR and FEH_GRP_FLT_STAT registers to Events parameter.
 *
 *          - Memory needed in the request buffer:
 *              - 15 words - TPL encoding = Variable
 *              - 24 words - TPL encoding = Fixed 64
 *          - Memory needed in the response buffer:
 *              - 13 words - TPL encoding = Variable
 *              - 28 words - TPL encoding = Fixed 64
 *          - List of used registers: FEH_SUPPLY_FLT_STAT0, FEH_SUPPLY_FLT_STAT1, FEH_ANA_FLT_STAT, FEH_COM_FLT_STAT,
 *                                    FEH_MEAS_FLT_STAT, FEH_ACC_ERR, FEH_GRP_FLT_STAT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       EventType       Event category specified for status retrieval.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Fault event status from the specific device was successfully retrieved.
 * @retval      E_NOT_OK            Fault event status from the specific device was not successfully retrieved.
 *
 */
Std_ReturnType Bcc_774a_FEH_GetFaultStatus(uint8 ChainAddr,
                                           uint8 DevAddr,
                                           Bcc_774a_FehEventType EventType,
                                           const Bms_TDType* MessageTD
                                          );

/*!
 * @brief   Configures the sources which trigger a POR or fault events.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *              - 20 words - TPL encoding = Variable
 *              - 32 words - TPL encoding = Fixed 64
 *          - List of used registers: FEH_SUPPLY_FLT_POR_CFG0, FEH_SUPPLY_FLT_POR_CFG1, FEH_COM_FLT_POR_CFG,
 *                                    FEH_SUPPLY_FLT_EVT_CFG0, FEH_SUPPLY_FLT_EVT_CFG1, FEH_ANA_FLT_EVT_CFG,
 *                                    FEH_COM_FLT_EVT_CFG, FEH_MEAS_FLT_EVT_CFG
 *

 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The sources which trigger a POR or fault events were successfully configured.
 * @retval      E_NOT_OK            The sources which trigger a POR or fault events were not successfully configured.
 *
 */
Std_ReturnType Bcc_774a_FEH_ConfigureEvents(uint8 ChainAddr,
                                            uint8 DevAddr,
                                            uint16 ConfigIdx,
                                            const Bms_TDType* MessageTD
                                           );

/*!
 * @brief   Retrieves reason of the last Power-On Reset (POR).
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer: 4 words
 *          - List of used registers: FEH_POR_REASON
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Reason of the last Power-On Reset (POR) was successfully retrieved.
 * @retval      E_NOT_OK            Reason of the last Power-On Reset (POR) was not successfully retrieved.
 *
 */
Std_ReturnType Bcc_774a_FEH_GetResetReason(uint8 ChainAddr,
                                           uint8 DevAddr,
                                           const Bms_TDType* MessageTD
                                          );
#endif /* (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON) */

    /*** BAL module API ***/
#if (BCC_774A_BAL_SUPPORT == STD_ON)
/*!
 * @brief   Sets the global balancing configuration and enables balancing activity.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *              - 14 words - TPL encoding = Variable
 *              - 32 words - TPL encoding = Fixed 64
 *          - List of used registers: BAL_GLOB_CFG, BAL_GLOB_TO_TMR, BAL_CH_CFG0, BAL_CH_CFG1, BAL_PRE_TMR,
 *                                    BAL_SWITCH_MON_CFG0, BAL_SWITCH_MON_CFG1, FULL_PWM_CYCLE_VOLTAGE
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       BalConfig       User-specified balancing configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Balancing activity was enabled and the global balancing configuration was set successfully.
 * @retval      E_NOT_OK            Balancing activity was not enabled and the global balancing configuration was not set successfully.
 *
 */
Std_ReturnType Bcc_774a_BAL_SetGlobalConfiguration(uint8 ChainAddr,
                                                   uint8 DevAddr,
                                                   const Bcc_774a_BalConfigurationType *BalConfig,
                                                   const Bms_TDType* MessageTD
                                                  );

/*!
 * @brief   Retrieves the status of the balancing activity.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer:
 *              - 20 words - TPL encoding = Variable
 *              - 44 words - TPL encoding = Fixed 64
 *          - List of used registers: BAL_CH_UV0_STAT0, BAL_CH_UV0_STAT1, BAL_GLOB_UV1_STAT0, BAL_GLOB_UV1_STAT1,
 *                                    BAL_STAT0, BAL_STAT1, BAL_STAT2, BAL_SWITCH_STAT0, BAL_SWITCH_STA1,
 *                                    BAL_SWITCH_FLT_STAT0, BAL_SWITCH_FLT_STAT1
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Status of the balancing activity was retrieved successfully.
 * @retval      E_NOT_OK            Status of the balancing activity was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_774a_BAL_GetStatus(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      const Bms_TDType* MessageTD
                                     );

/*!
 * @brief   Configures the PWM and timer for controlled discharge of selected cells.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor: 8 words
 *          - List of used registers: BAL_TMR_CH_ALL, BAL_TMR_CH0, BAL_TMR_CH1, BAL_TMR_CH2, BAL_TMR_CH3, BAL_TMR_CH4,
 *                                    BAL_TMR_CH5, BAL_TMR_CH6, BAL_TMR_CH7, BAL_TMR_CH8, BAL_TMR_CH9, BAL_TMR_CH10,
 *                                    BAL_TMR_CH11, BAL_TMR_CH12, BAL_TMR_CH13, BAL_TMR_CH14, BAL_TMR_CH15, BAL_TMR_CH16,
 *                                    BAL_TMR_CH17, BAL_PWM_CH_ALL, BAL_PWM_CH0, BAL_PWM_CH1, BAL_PWM_CH2, BAL_PWM_CH3,
 *                                    BAL_PWM_CH4, BAL_PWM_CH5, BAL_PWM_CH6, BAL_PWM_CH7, BAL_PWM_CH8, BAL_PWM_CH9,
 *                                    BAL_PWM_CH10, BAL_PWM_CH11, BAL_PWM_CH12, BAL_PWM_CH13, BAL_PWM_CH14, BAL_PWM_CH15,
 *                                    BAL_PWM_CH16, BAL_PWM_CH17
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ChannelConfig   User-specified channel configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The selected PWM and timer were configured successfully.
 * @retval      E_NOT_OK            The selected PWM and timer were not configured successfully.
 *
 */
Std_ReturnType Bcc_774a_BAL_SetChannelConfiguration(uint8 ChainAddr,
                                                    uint8 DevAddr,
                                                    const Bcc_774a_BalChannelConfigurationType *ChannelConfig,
                                                    const Bms_TDType* MessageTD
                                                   );
#endif /* (BCC_774A_BAL_SUPPORT == STD_ON) */

/*!
 * @brief   Configures automatic discharge functionality & emergency discharge of cells
 *          for all BCC devices from the topology.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor: 4 words
 *          - List of used registers: BAL_AUTO_DISCHRG_CTRL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       Start       Start/stop the emergency discharge process.
 * @param[inout]    MessageTD   Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Automatic discharge functionality & emergency discharge of cells were configured successfully.
 * @retval      E_NOT_OK            Automatic discharge functionality & emergency discharge of cells were not configured successfully.
 *
 */
Std_ReturnType Bcc_774a_BAL_EmergencyDischarge(uint8 ChainAddr,
                                               uint8 DevAddr,
                                               boolean Start,
                                               const Bms_TDType* MessageTD
                                              );

    /*** MSR module API ***/

/*!
 * @brief   Starts the measurement process for selected BCC device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor: 4 words
 *          - List of used registers: PRMM_CFG, SECM_CFG, ALLM_CFG
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       MeasChain       Measurement chain to start.
 * @param[in]       BalancePause    Balance pause configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The measurement process for the selected BCC device started successfully.
 * @retval      E_NOT_OK            The measurement process for the selected BCC device did not start successfully.
 *
 */
Std_ReturnType Bcc_774a_MSR_StartMeasurements(uint8 ChainAddr,
                                              uint8 DevAddr,
                                              Bcc_774a_MsrChainType MeasChain,
                                              Bcc_774a_MsrBalPauseType BalancePause,
                                              const Bms_TDType* MessageTD
                                             );

/*!
 * @brief   Stops the measurement process for selected BCC device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor: 4 words
 *          - List of used registers: PRMM_CFG, SECM_CFG, ALLM_CFG
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       MeasChain       Measurement chain to stop.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The measurement process for the selected BCC device was stopped successfully.
 * @retval      E_NOT_OK            The measurement process for the selected BCC device did not stop successfully.
 *
 */
Std_ReturnType Bcc_774a_MSR_StopMeasurements(uint8 ChainAddr,
                                             uint8 DevAddr,
                                             Bcc_774a_MsrChainType MeasChain,
                                             const Bms_TDType* MessageTD
                                            );

/*!
 * @brief   Triggers the results capture for application measurements
 *          or the start of synchronous or FastFB measurements based
 *          on the MeasType parameter.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor: 4 words
 *          - List of used registers: ALLM_APP_CTRL, ALLM_SYNC_CTRL, SECM_SYNC_CTRL
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       MeasType        Measurement type to start.
 * @param[in]       SetModeParams   Address to the information needed for balancing pausing and open load detection configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The results capture was triggered successfully.
 * @retval      E_NOT_OK            The results capture was not triggered successfully.
 *
 */
Std_ReturnType Bcc_774a_MSR_SetMode(uint8 ChainAddr,
                                    uint8 DevAddr,
                                    Bcc_774a_MsrMeasurementType MeasType,
                                    const Bcc_774a_MsrSetModeParamsType* SetModeParams,
                                    const Bms_TDType* MessageTD
                                   );

/*!
 * @brief   Sets the measurement configuration parameters for selected BCC device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Maximum memory needed in the transaction descriptor:
 *              - 58 words - TPL encoding = Variable
 *              - 88 words - TPL encoding = Fixed 64
 *          - List of used registers: ALLM_PER_CTRL, ALLM_VCVB_CFG0, ALLM_VCVB_CFG1, PRMM_AIN_CFG, PRMM_VBUF_CFG,
 *                                    PRMM_VC_OV_UV_CFG0, PRMM_VC_OV_UV_CFG1, PRMM_VC_OV_TH_CFG, PRMM_VC_UV0_TH_CFG, PRMM_VC_UV1_TH_CFG,
 *                                    PRMM_AIN0_OV_TH_CFG, PRMM_AIN1_OV_TH_CFG, PRMM_AIN2_OV_TH_CFG, PRMM_AIN3_OV_TH_CFG, PRMM_AINA_OV_TH_CFG
 *                                    PRMM_AIN0_UV_TH_CFG, PRMM_AIN1_UV_TH_CFG, PRMM_AIN2_UV_TH_CFG, PRMM_AIN3_UV_TH_CFG, PRMM_AINA_UV_TH_CFG
 *                                    SECM_AIN_CFG, SECM_VBUF_CFG
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       ConfigIdx       Index of chosen static configuration.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The measurement configuration parameters were set successfully.
 * @retval      E_NOT_OK            The measurement configuration parameters were not set successfully.
 *
 */
Std_ReturnType Bcc_774a_MSR_Configure(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      uint16 ConfigIdx,
                                      const Bms_TDType* MessageTD
                                     );

/*!
 * @brief   Retrieves measurement data from specified BCC device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 8 words
 *          - Memory needed in the response buffer:
 *              - 53 words - TPL encoding = Variable
 *              - 116 words - TPL encoding = Fixed 64
 *          - List of used registers: PRMM_PER_NUM, PRMM_PER_VC0, PRMM_PER_VC1, PRMM_PER_VC2, PRMM_PER_VC3,
 *                                    PRMM_PER_VC4, PRMM_PER_VC5, PRMM_PER_VC6, PRMM_PER_VC7, PRMM_PER_VC8,
 *                                    PRMM_PER_VC9, PRMM_PER_VC10, PRMM_PER_VC11, PRMM_PER_VC12, PRMM_PER_VC13,
 *                                    PRMM_PER_VC14, PRMM_PER_VC15, PRMM_PER_VC16, PRMM_PER_VC17,
 *                                    PRMM_PER_AINA, PRMM_PER_AIN0, PRMM_PER_AIN1, PRMM_PER_AIN2, PRMM_PER_AIN3,
 *                                    PRMM_PER_PRMTEMP, PRMM_PER_SECVREF, PRMM_PER_VAUX, PRMM_PER_VDDC,
 *                                    SECM_PER_AIN4, SECM_PER_AIN5, SECM_PER_AIN6, SECM_PER_AIN7,
 *                                    SECM_PER_SECTEMP, SECM_PER_PRMVREF, SECM_PER_VAUX, SECM_PER_VBAT,
 *                                    SECM_PER_VDDA, SECM_PER_VDDC, SECM_PER_NPNISENSE,
 *                                    PRMM_APP_VC_CNT, PRMM_APP_VC0, PRMM_APP_VC1, PRMM_APP_VC2, PRMM_APP_VC3,
 *                                    PRMM_APP_VC4, PRMM_APP_VC5, PRMM_APP_VC6, PRMM_APP_VC7, PRMM_APP_VC8,
 *                                    PRMM_APP_VC9, PRMM_APP_VC10, PRMM_APP_VC11, PRMM_APP_VC12, PRMM_APP_VC13,
 *                                    PRMM_APP_VC134 PRMM_APP_VC15, PRMM_APP_VC16, PRMM_APP_VC17,
 *                                    PRMM_APP_AIN0, PRMM_APP_AIN1, PRMM_APP_AIN2, PRMM_APP_AIN3,
 *                                    SECM_APP_AIN4, SECM_APP_AIN5, SECM_APP_AIN6, SECM_APP_AIN7,
 *                                    PRMM_SYNC_NUM, PRMM_SYNC_VC0, PRMM_SYNC_VC1, PRMM_SYNC_VC2, PRMM_SYNC_VC3,
 *                                    PRMM_SYNC_VC4, PRMM_SYNC_VC5, PRMM_SYNC_VC6, PRMM_SYNC_VC7, PRMM_SYNC_VC8,
 *                                    PRMM_SYNC_VC9, PRMM_SYNC_VC10, PRMM_SYNC_VC11, PRMM_SYNC_VC12, PRMM_SYNC_VC13,
 *                                    PRMM_SYNC_VC14, PRMM_SYNC_VC15, PRMM_SYNC_VC16, PRMM_SYNC_VC17,
 *                                    SECM_SYNC_NUM, SECM_SYNC_VB0, SECM_SYNC_VB1, SECM_SYNC_VB2, SECM_SYNC_VB3,
 *                                    SECM_SYNC_VB4, SECM_SYNC_VB5, SECM_SYNC_VB6, SECM_SYNC_VB7, SECM_SYNC_VB8,
 *                                    SECM_SYNC_VB9, SECM_SYNC_VB10, SECM_SYNC_VB11, SECM_SYNC_VB12, SECM_SYNC_VB13,
 *                                    SECM_SYNC_VB14, SECM_SYNC_VB15, SECM_SYNC_VB16, SECM_SYNC_VB17
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       MeasChain       Measurement chain to read from.
 * @param[in]       MeasType        Measurement data type to read.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The measurement data was retrieved successfully.
 * @retval      E_NOT_OK            The measurement data was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_774a_MSR_GetData(uint8 ChainAddr,
                                    uint8 DevAddr,
                                    Bcc_774a_MsrChainType MeasChain,
                                    Bcc_774a_MsrMeasurementType MeasType,
                                    const Bms_TDType* MessageTD
                                   );

/*!
 * @brief   Retrieves measurement status information from specified BCC device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer: 4 words
 *          - List of used registers: PRMM_MEAS_STAT, SECM_MEAS_STAT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       MeasChain       Measurement chain to retrieve status from.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Measurement status information was retrieved successfully.
 * @retval      E_NOT_OK            Measurement status information was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_774a_MSR_GetStatus(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      Bcc_774a_MsrChainType MeasChain,
                                      const Bms_TDType* MessageTD
                                     );

/*!
 * @brief   Retrieves measurement faults information from specified BCC device's
 *          Primary measurement chain.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - Memory needed in the response buffer:
 *              - 14 words - TPL encoding = Variable
 *              - 32 words - TPL encoding = Fixed 64
 *          - List of used registers: PRMM_VC_OV_FLT_STAT0, PRMM_VC_OV_FLT_STAT1, PRMM_VC_UV0_FLT_STAT0, PRMM_VC_UV0_FLT_STAT1,
 *                                    PRMM_VC_UV1_FLT_STAT0, PRMM_VC_UV1_FLT_STAT1, PRMM_AIN_OV_FLT_STAT, PRMM_AIN_UV_FLT_STAT
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Measurement faults information was retrieved successfully.
 * @retval      E_NOT_OK            Measurement faults information was not retrieved successfully.
 *
 */
Std_ReturnType Bcc_774a_MSR_GetFaults(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      const Bms_TDType* MessageTD
                                     );

    /*** COM module API ***/

/*!
 * @brief Write a value into a specific register in a specific device
 * @details
 *          - Sync or Async: Synchronous
 *          - Reentrancy:    Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 * @param[in]     ChainAddr         4 bit diasychain Address
 * @param[in]     DevAddr           6 bit Physical Address field of the BCC, 0 Unenumerated device, 1-62 device address, 63 all device
 * @param[in]     RegistersData     Address to the structure in which information about RegCnt, Data and RegAddr is stored.
 * @param[inout]  MessageTD         Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Value was written successfully into the specified register.
 * @retval      E_NOT_OK            Value was not written successfully into the specified register.
 *
 */
Std_ReturnType Bcc_774a_COM_WriteRegisters(uint8 ChainAddr,
                                           uint8 DevAddr,
                                           const Bcc_774a_RWRegistersType* RegistersData,
                                           const Bms_TDType* MessageTD
                                          );

/*!
 * @brief Read data from memory map.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       ChainAddr       Chain Address
 * @param[in]       DevAddr         Physical Address field of the BCC device
 * @param[in]       RegAddr         Device memory address where the register will be read.
 * @param[inout]    RegData         Data read from memory map

 *
 * @return      Std_ReturnType
 * @retval      E_OK                The value was read successfully from the memory map.
 * @retval      E_NOT_OK            The value was not read successfully from the memory map.
 *
 */
Std_ReturnType Bcc_774a_MEM_ReadRegister(uint8 ChainAddr,
                                         uint8 DevAddr,
                                         uint16 RegAddr,
                                         uint16 *RegData
                                        );

/*!
 * @brief Read multiple datas from a specific registers in a specific device.
 *        Padding is not used in response frames (Force PAD bit 0).
 * @details
 *          - Sync or Async: Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 * @param[in]     ChainAddr   4 bit diasychain Address
 * @param[in]     DevAddr     6 bit Physical Address field of the BCC, 0 Unenumerated device, 1-62 device address, 63 all device
 * @param[in]     RegAddr     14 bit Memory Address field of the BCC
 * @param[in]     RegCnt      16 bit Number of consecutive registers to read. Maximal value is 256.
 * @param[inout]  MessageTD   Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The values were read successfully from the specified registers.
 * @retval      E_NOT_OK            The values were not read successfully from the specified registers.
 *
 */
Std_ReturnType Bcc_774a_COM_ReadRegisters(uint8 ChainAddr,
                                          uint8 DevAddr,
                                          uint16 RegAddr,
                                          uint16 RegCnt,
                                          const Bms_TDType* MessageTD
                                         );

/*!
 * @brief This function is used to append a wakeup message for the entire chain
 *        to the transaction descriptor.
 * @details
 *          - Sync or Async: Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *
 * @param[in]       ChainAddr       Chain address to wakeup.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The wakeup message was appended successfully to the transaction descriptor.
 * @retval      E_NOT_OK            The wakeup message was not appended successfully to the transaction descriptor.
 *
 */
Std_ReturnType Bcc_774a_COM_WakeupChain(uint8 ChainAddr,
                                        const Bms_TDType *MessageTD
                                       );

/*!
 * @brief This function is used to add a NOP message in MessageTD.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The NOP message was added successfully to MessageTD.
 * @retval      E_NOT_OK            The NOP message was not added successfully to MessageTD.
 *
 */
Std_ReturnType Bcc_774a_COM_InsertNop(uint8 ChainAddr,
                                      uint8 DevAddr,
                                      const Bms_TDType *MessageTD
                                     );

/*!
 * @brief   This service configures the MADD bit of a specific device in the internal state structure.
 * @details
 *          - Sync or Async:        Synchronous
 *          - Reentrancy:           Reentrant
 *
 *          - Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same ChainAddr and DevAddr parameter.
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       EnableMADD      Value of the MADD bit for the specific device in the internal state structure.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The MADD bit of the specific device in the internal state structure was configured successfully.
 * @retval      E_NOT_OK            The MADD bit of the specific device in the internal state structure was not configured successfully.
 *
 */
Std_ReturnType Bcc_774a_SetMADD(uint8 ChainAddr,
                                uint8 DevAddr,
                                boolean EnableMADD
                               );

/*!
 * @brief   This service configures the loopback method selected for a specific chain in the internal state structure.
 * @details
 *          - Sync or Async:        Synchronous
 *          - Reentrancy:           Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care that
 *            there is no simultaneous usage of the same ChainAddr and DevAddr parameter.
 *
 * @param[in]       ChainAddr           Chain address of the specific chain selected.
 * @param[in]       LoopbackMethod      Loopback method selected for the specific chain.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The loopback method of the specific chain in the internal state structure was configured successfully.
 * @retval      E_NOT_OK            The loopback method of the specific chain in the internal state structure was not configured successfully.
 *
 */
Std_ReturnType Bcc_774a_LoopbackConfigure(uint8 ChainAddr,
                                          uint8 LoopbackMethod
                                         );

/*!
 * @brief   This function is used to set the number of nodes in the chain.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *          - Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same MessageTD parameter.
 *
 *          - Memory needed in the request buffer: 4 words
 *          - List of used registers: SYS_COM_CFG
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       NumNodes        Number of nodes in the chain.
 * @param[inout]    MessageTD       Address to the transaction descriptor in which this operation will be appended.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The number of nodes was set successfully.
 * @retval      E_NOT_OK            The number of nodes was not set successfully.
 *
 */
Std_ReturnType Bcc_774a_SetNumNodes(uint8 ChainAddr,
                                    uint8 DevAddr,
                                    uint8 NumNodes,
                                    const Bms_TDType* MessageTD
                                   );

/*!
 * @brief   This function is used to update the Memory Map Mirror for a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 * @param[in]       MemMapData      Address to MemMap information to be updated (register address, data and number of registers to be updated)
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The Memory Map was updated successfully.
 * @retval      E_NOT_OK            The Memory Map was not updated successfully.
 *
 */
Std_ReturnType Bcc_774a_MEM_Update(uint8 ChainAddr,
                                   uint8 DevAddr,
                                   const Bms_MemMapMirrorType* MemMapData
                                  );
/*!
 * @brief   This function is used to reset the Memory Map Mirror for a specific device.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 *
 *
 * @param[in]       ChainAddr       Chain address for specific BCC device.
 * @param[in]       DevAddr         Address of specific BCC device.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The Memory Map was reseted successfully.
 * @retval      E_NOT_OK            The Memory Map was not reseted successfully.
 *
 */
Std_ReturnType Bcc_774a_MEM_ResetToDefault(uint8 ChainAddr,
                                           uint8 DevAddr
                                          );

#define BCC_774A_STOP_SEC_CODE
#include "Bcc_774a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* BCC_774A_H */
