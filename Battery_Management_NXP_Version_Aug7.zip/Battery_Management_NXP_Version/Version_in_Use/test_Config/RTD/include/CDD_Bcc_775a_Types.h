/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_BCC_775A_TYPES_H
#define CDD_BCC_775A_TYPES_H

/**
*   @file    CDD_Bcc_775a_Types.h
*
*   @addtogroup CDD_BCC_775A
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bms_common.h"
#include "StandardTypes.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define BCC_775A_MODULE_ID_COM                    255
#define BCC_775A_VENDOR_ID_COM                    43
#define BCC_775A_AR_RELEASE_MAJOR_VERSION_COM     4
#define BCC_775A_AR_RELEASE_MINOR_VERSION_COM     7
#define BCC_775A_AR_RELEASE_REVISION_VERSION_COM  0
#define BCC_775A_SW_MAJOR_VERSION_COM             1
#define BCC_775A_SW_MINOR_VERSION_COM             0
#define BCC_775A_SW_PATCH_VERSION_COM             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Bms_common header file are of the same Autosar version */
    #if ((BCC_775A_AR_RELEASE_MAJOR_VERSION_COM != BMS_COMMON_AR_RELEASE_MAJOR_VERSION) || \
         (BCC_775A_AR_RELEASE_MINOR_VERSION_COM != BMS_COMMON_AR_RELEASE_MINOR_VERSION) \
        )
    #error "AutoSar Version Numbers of CDD_Bcc_775a_Types.h and CDD_Bms_common.h are different"
    #endif
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((BCC_775A_AR_RELEASE_MAJOR_VERSION_COM != STD_AR_RELEASE_MAJOR_VERSION) || \
         (BCC_775A_AR_RELEASE_MINOR_VERSION_COM != STD_AR_RELEASE_MINOR_VERSION) \
        )
    #error "AutoSar Version Numbers of CDD_Bcc_775a_Types.h and StandardTypes.h are different"
    #endif
#endif

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/
/*! @brief Maximal number of daisy-chain in TPL mode. */
#define BCC_775A_CHAIN_CNT_MAX_TPL     6U
/*! @brief All daisy-chain in TPL mode. */
#define BCC_775A_ALL_CHAIN_TPL     7U

/*! @brief Maximal number of Battery Cell Controller devices in TPL mode. */
#define BCC_775A_DEVICE_CNT_MAX_TPL    62U
/*! @brief All Battery Cell Controller devices in TPL mode. */
#define BCC_775A_ALL_DEVICE_TPL    63U

/** BCC Commands. */
/*! @brief Wake-up request / NOP */
#define BCC_775A_CMD_WAKEUP            0x00U
/*! @brief Read command. */
#define BCC_775A_CMD_READ              0x01U
/*! @brief Write command. */
#define BCC_775A_CMD_WRITE             0x02U
/*! @brief Response */
#define BCC_775A_CMD_RESPONSE          0x03U

/* Represents CMD field shift in FRAME first 16bit */
#define BCC_775A_CMD_FIELD_SHIFT       0xEU
/* Represents CMD filed mask in FRAME first 16bit */
#define BCC_775A_CMD_FIELD_MASK        0xC000U

/* Represents MADD field shift in FRAME first 16bit */
#define BCC_775A_MADD_FIELD_SHIFT       0xDU
/* Represents MADD filed mask in FRAME first 16bit */
#define BCC_775A_MADD_FIELD_MASK        0x2000U

/* Represents CADD field shift in FRAME first 16bit */
#define BCC_775A_CADD_FIELD_SHIFT       0xAU
/* Represents CADD filed mask in FRAME first 16bit */
#define BCC_775A_CADD_FIELD_MASK        0x1C00U

/* Represents DEVADD field shift in FRAME first 16bit */
#define BCC_775A_DEVADD_FIELD_SHIFT       0x4U
/* Represents DEVADD filed mask in FRAME first 16bit */
#define BCC_775A_DEVADD_FIELD_MASK        0x03F0U

/* Represents MSGCNT field shift in FRAME first 16bit */
#define BCC_775A_MSGCNT_FIELD_SHIFT       0x0U
/* Represents MSGCNT filed mask in FRAME first 16bit */
#define BCC_775A_MSGCNT_FIELD_MASK        0x000FU

/* Represents DATLEN field shift in FRAME second 16bit */
#define BCC_775A_DATLEN_FIELD_SHIFT       0xEU
/*represents DATLEN filed mask in FRAME second 16bit */
#define BCC_775A_DATLEN_FIELD_MASK        0xC000U

/* Represents REGADD field shift in FRAME second 16bit */
#define BCC_775A_REGADD_FIELD_SHIFT       0x0U
/* Represents REGADD filed mask in FRAME second 16bit */
#define BCC_775A_REGADD_FIELD_MASK        0x3FFFU

/* Represents PAD field shift in FRAME third 16bit for read command */
#define BCC_775A_PAD_FIELD_SHIFT       0xAU
/* Represents PAD filed mask in FRAME second 16bit */
#define BCC_775A_PAD_FIELD_MASK        0x0400U
/* Padding is used in response frame */
#define BCC_775A_PAD_ENABLE            1U
/* Padding is not used in response frame */
#define BCC_775A_PAD_DISABLE           0U

/* Represents RESPLEN field shift in FRAME third 16bit for read command */
#define BCC_775A_RESPLEN_FIELD_SHIFT       0x8U
/* Represents NUMREG filed mask in FRAME second 16bit */
#define BCC_775A_RESPLEN_FIELD_MASK        0x0300U

/* Represents NUMREG field shift in FRAME third 16bit for read command */
#define BCC_775A_NUMREG_FIELD_SHIFT       0x0U
/* Represents NUMREG filed mask in FRAME second 16bit */
#define BCC_775A_NUMREG_FIELD_MASK        0x00FFU
/************************************************/

/* 33775 communication frame minimum length is 4 * 16bit data (64bit),
 * maximum length is 7 * 16bit data (112 bit)*/
#define BCC_775A_FRAME_BASE_LENGTH        4U
#define BCC_775A_FRAME_MAX_LENGTH         7U

/*! @brief This is the maximum number of registers in a response frame */
#define BCC_775A_COM_MAX_RESP_LENGTH   4U

/*! @brief Maximum register address */
#define BCC_775A_MAX_REG_ADDR          16384U
/*! @brief Maximum number of registers that can be requested in one command */
#define BCC_775A_RX_LIMIT_TPL          255U

/*! @brief Number of data registers per message */
/**
* @brief 1 Data register per message
*/
#define BCC_775A_1REG_DATA        1U
/**
* @brief 2 Data register per message
*/
#define BCC_775A_2REG_DATA        2U
/**
* @brief 3 Data register per message
*/
#define BCC_775A_3REG_DATA        3U
/**
* @brief 4 Data register per message
*/
#define BCC_775A_4REG_DATA        4U
/**
* @brief Maximal dimension for chain array.
*/
#define BCC_775A_NUM_CHAINS_MAX   7U
/**
* @brief Number of registers in each memory map mirror
*/
#define BCC_775A_MEMORY_MAP_MIRROR_SIZE (4U)
/**
* @brief Index of each mirrored register in the memory map mirror array
*/
#define BCC_775A_SYS_COM_CFG_LOCAL_INDEX                        (0U)
#define BCC_775A_SYS_CYC_WAKEUP_CFG_LOCAL_INDEX                 (1U)
#define BCC_775A_PRMM_CFG_LOCAL_INDEX                           (2U)
#define BCC_775A_SECM_CFG_LOCAL_INDEX                           (3U)

/**
* @brief Reset value for each mirrored register in the memory map mirror array
*/
#define BCC_775A_MEMORY_MAP_POR \
    {   MC33775_SYS_COM_CFG_POR_VAL, \
        MC33775_SYS_CYC_WAKEUP_CFG_POR_VAL, \
        MC33775_SECM_CFG_POR_VAL, \
        MC33775_PRMM_CFG_POR_VAL }

/**
* @brief Maximum number of elements in the hash table.
*/
#if (defined BMS_NUMBER_OF_TPL3_CMU_1_MAX_DEVICES)
#define BCC_775A_MAX_DEVICES (BMS_NUMBER_OF_TPL3_CMU_1_MAX_DEVICES)
#else
#define BCC_775A_MAX_DEVICES (1U)
#endif
/*==================================================================================================
*                                            ENUMS
==================================================================================================*/
/**
 * @brief   Bcc_775a COMM error codes.
 *
 */
typedef enum
{
    BCC_775A_COM_SUCCESS        = 0x00U,   /*!< No error. */
    BCC_775A_COM_ADDR           = 0xA1U,   /*!< BCC Read Invalid register */
    BCC_775A_COM_MSGCNT         = 0xA2U,   /*!< Response message counter value does not match with expected. */
    BCC_775A_COM_TIMEOUT        = 0xA3U,   /*!< Communication timeout. */
    BCC_775A_COM_PARAM_RANGE    = 0xA4U,   /*!< Parameter out of range. */
    BCC_775A_COM_CRC            = 0xA5U,   /*!< Wrong CRC. */
    BCC_775A_COM_TX_FAIL        = 0xA6U,   /*!< MCU SPI failure. */
    BCC_775A_COM_RESPONSE       = 0xA7U,   /*!< Response command field error */
    BCC_775A_COM_TD_OVERFLOW    = 0xA8U,   /*!< The message will not fit the destination TD */
} Bcc_775a_CommErrorType;

/*==================================================================================================
*                                STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
/**
 * @brief   Bcc_775a SYS configuration.
 *
 */
typedef struct
{
    uint16 SysComToSupplyMsg[BCC_775A_2REG_DATA];
    uint16 SysTplMsg[BCC_775A_1REG_DATA];
    uint16 SysClkSyncMsg[BCC_775A_1REG_DATA];
    boolean BusFwEn;
} Bcc_775a_SYS_ConfigType;

/**
 * @brief   Bcc_775a MSR configuration.
 *
 */
typedef struct
{
    uint16 MsrAllmPerMsg[BCC_775A_1REG_DATA];
    uint16 MsrAllmVcVbMsg[BCC_775A_1REG_DATA];
    uint16 MsrPrmmAinMsg[BCC_775A_1REG_DATA];
    uint16 MsrPrmmVdivMsg[BCC_775A_1REG_DATA];
    uint16 MsrPrmmVcOvUvMsg[BCC_775A_4REG_DATA];
    uint16 MsrPrmmAinOvMsg[BCC_775A_4REG_DATA];
    uint16 MsrPrmmAinUvMsg[BCC_775A_4REG_DATA];
    uint16 MsrSecmAinMsg[BCC_775A_1REG_DATA];
    uint16 MsrSecmVdivMsg[BCC_775A_1REG_DATA];
} Bcc_775a_MSR_ConfigType;

/**
 * @brief   Bcc_775a chain state.
 *
 */
typedef struct
{
    uint8 DeviceNum;
    uint8 LoopbackRspBuffer;
    uint8 StartAddress;
} Bcc_775a_CheckChainStateType;

/**
 * @brief   Bcc_775a device state.
 *
 */
typedef struct
{
    boolean MADD;           /**< @brief Master Address */
    boolean SETNUMNODES;    /**< @brief Indicates if NUMNODES was set for specific device */
    uint8 DADD;             /**< @brief Device Address */
    uint8 CADD;             /**< @brief Chain Address */
    uint16 MemoryMapMirror[BCC_775A_MEMORY_MAP_MIRROR_SIZE]; /**< @brief Memory map mirror array */
} Bcc_775a_DeviceStateType;

/**
 * @brief   Bcc_775a element from hash map.
 *
 */
typedef struct
{
    Bcc_775a_DeviceStateType Device;
    boolean Allocated;
} Bcc_775a_HashMapElementType;

/**
 * @brief   Bcc_775a hash map containing all devices from each chain.
 *
 */
typedef struct
{
    Bcc_775a_HashMapElementType Elements[BCC_775A_MAX_DEVICES];
} Bcc_775a_HashMapType;

/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_BCC_775A_TYPES_H */
