/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_INTSPI_H
#define CDD_PHY_665A_INTSPI_H

/**
*   @file CDD_Phy_665a_IntSpi.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Phy_665a_Cfg.h"
#include "CDD_Bms_common_Cfg.h"
#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
#include "CDD_Phy_665a_SpiIf.h"
#endif
#include "Gpt.h"
#include "CDD_Phy_665a_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_INTSPI_VENDOR_ID                    43
#define PHY_665A_INTSPI_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_INTSPI_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_INTSPI_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_INTSPI_SW_MAJOR_VERSION             1
#define PHY_665A_INTSPI_SW_MINOR_VERSION             0
#define PHY_665A_INTSPI_SW_PATCH_VERSION             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Gpt header file are of the same Autosar version */
    #if ((PHY_665A_INTSPI_AR_RELEASE_MAJOR_VERSION != GPT_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_INTSPI_AR_RELEASE_MINOR_VERSION != GPT_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_IntSpi.h and Gpt.h are different"
    #endif

    /* Check if current file and Gpt header file are of the same Autosar version */
    #if ((PHY_665A_INTSPI_AR_RELEASE_MAJOR_VERSION != BMS_COMMON_AR_RELEASE_MAJOR_VERSION_CFG) || \
        (PHY_665A_INTSPI_AR_RELEASE_MINOR_VERSION != BMS_COMMON_AR_RELEASE_MINOR_VERSION_CFG))
    #error "AutoSar Version Numbers of CDD_Phy_665a_IntSpi.h and Bms_common_Cfg.h are different"
    #endif
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same vendor */
#if (PHY_665A_INTSPI_VENDOR_ID != PHY_665A_VENDOR_ID_CFG)
#error "CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Autosar version */
#if ((PHY_665A_INTSPI_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (PHY_665A_INTSPI_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (PHY_665A_INTSPI_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Software version */
#if ((PHY_665A_INTSPI_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_CFG) || \
     (PHY_665A_INTSPI_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_CFG) || \
     (PHY_665A_INTSPI_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_INTSPI_VENDOR_ID != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_INTSPI_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_INTSPI_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_INTSPI_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_INTSPI_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_INTSPI_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_INTSPI_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_Types.h are different"
#endif

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
/* Check if this header file and CDD_Phy_665a_SpiIf.h are of the same vendor */
#if (PHY_665A_INTSPI_VENDOR_ID != PHY_665A_SPIIF_VENDOR_ID)
#error "CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_SpiIf.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_SpiIf.h are of the same Autosar version */
#if ((PHY_665A_INTSPI_AR_RELEASE_MAJOR_VERSION != PHY_665A_SPIIF_AR_RELEASE_MAJOR_VERSION) || \
     (PHY_665A_INTSPI_AR_RELEASE_MINOR_VERSION != PHY_665A_SPIIF_AR_RELEASE_MINOR_VERSION) || \
     (PHY_665A_INTSPI_AR_RELEASE_REVISION_VERSION != PHY_665A_SPIIF_AR_RELEASE_REVISION_VERSION))
#error "AutoSar Version Numbers of CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_SpiIf.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_SpiIf.h are of the same Software version */
#if ((PHY_665A_INTSPI_SW_MAJOR_VERSION != PHY_665A_SPIIF_SW_MAJOR_VERSION) || \
     (PHY_665A_INTSPI_SW_MINOR_VERSION != PHY_665A_SPIIF_SW_MINOR_VERSION) || \
     (PHY_665A_INTSPI_SW_PATCH_VERSION != PHY_665A_SPIIF_SW_PATCH_VERSION))
#error "Software Version Numbers of CDD_Phy_665a_IntSpi.h and CDD_Phy_665a_SpiIf.h are different"
#endif
#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)

#if (defined PHY_665A_SINGLE_SPI_TIME_OUT_MONITORING_PERIOD)
#error PHY_665A_SINGLE_SPI_TIME_OUT_MONITORING_PERIOD is already defined
#endif
#define PHY_665A_SINGLE_SPI_TIME_OUT_MONITORING_PERIOD  (1500U)

#if (defined PHY_665A_SPI_BUS_INTER_FRAME_DELAY)
#error PHY_665A_SPI_BUS_INTER_FRAME_DELAY is already defined
#endif
#define PHY_665A_SPI_BUS_INTER_FRAME_DELAY                (20U)

#if (defined PHY_665A_SPI_TPL3_TIMEOUT_TOLERANCE)
#error PHY_665A_SPI_TPL3_TIMEOUT_TOLERANCE is already defined
#endif
#define PHY_665A_SPI_TPL3_TIMEOUT_TOLERANCE               (80U)

#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/
#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)

#define PHY_665A_START_SEC_VAR_CLEARED_BOOLEAN
#include "Phy_665a_MemMap.h"
extern volatile boolean Phy_665a_TdSpiProcessingFlg;
#define PHY_665A_STOP_SEC_VAR_CLEARED_BOOLEAN
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"
#if (PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)
extern uint16 Phy_665a_aSSpiResponseBuffer[PHY_665A_GLOBAL_BUFFER_SIZE];
#endif
#define PHY_665A_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/
/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/

#define PHY_665A_START_SEC_CODE
#include "Phy_665a_MemMap.h"

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)

void Phy_665a_SpiTdTimeoutHandler
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatusPtr,
    Phy_ErrorStatusType ErrStatus
);


#if (STD_ON == PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED)
Std_ReturnType Phy_665a_EnQueueSpi
(
    Phy_665a_QueueStructInfoType* ElementToQueuePtr
);

void Phy_665a_SpiCancelAllTds
(
    void
);

void Phy_665a_DeQueueSpi
(
    void
);
#endif /*(STD_ON == PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED)*/

Std_ReturnType Phy_665a_SpiVariantInit
(
    void
);

void Phy_665a_SpiVariantDeinit
(
    void
);

Std_ReturnType Phy_665a_WakeupSpiDevice
(
    void
);

Std_ReturnType Phy_665a_SpiVerifyDriverState
(
    void
);

void Phy_665a_CpuTickCount
(
    uint32 CoreClockTicks
);

void Phy_665a_SpiHwDelay
(
    uint32 CpuTicksToCount
);

void Phy_665a_ResetSpiGlobalInfo
(
    void
);
Std_ReturnType Phy_665a_IO_SendMessageSpi
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatus
);

void Phy_665a_SpiTdFinishHandler
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatus
);

#if (PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)
#if (STD_ON == BMS_COMMON_ENABLE_TPL3)

Std_ReturnType Phy_665a_ValidateTpl3Crc(const uint16* ResponsePtr,
                                        uint8 MsgLen);
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/
void Phy_665a_UpdatePrefix(uint16* RequestPrefixLocation, uint8 MsgSize);

/* \ Phy_665a_ValidatePrefix
 *
 *  implementation for calculation of Parity bit.
 *  \param[in]      ResponsePtr
 *  \param[in]      MsgLen
 *  \returns Std_ReturnType
 *  \remark{Synchronous}
 */
Std_ReturnType Phy_665a_ValidatePrefix(const uint16* ResponsePtr,
                                       uint16* MsgLen);

#endif /*(PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)*/

/* \ Phy_665a_OtherSequenceNotification
 *
 *  implementation for the Sequence notifications where the  batch of less than 10 request are
 *  transmmitted by PHY_665A via request queue low interrupt(asynchronously) and receive data.
 *  Implementation of Sequence notification for Tx of less than 10 messages.
 **/
void Phy_665a_ExternalTdHandlerEos
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatus
);

void Phy_665a_InternalTdHandlerEos
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatus
);

void Phy_665a_SpiInternalTdHandlerGpt
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatus
);

void Phy_665a_SpiExternalTdHandlerGpt
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatus
);

void Phy_665a_GptSyncFailureAnalysis(void);

#if (PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED == STD_ON)
#if ((PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS) || (PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE))

/* \ Phy_665a_RequestQueueLowIrq
 *
 *  implementation for sending next requests batch when request queue buffer fill falls
 *  below or equal to  low level mark. Request Queue Low interrupt implementation.
 *
 *  \param[in]  Phy_TDType
 *  \param[in]  Phy_ErrorStatusType
 *
 *  \returns void
 *
 *
 *  \remark{Asynchronous}
 *
 */
void Phy_665a_RequestQueueLowIrq(void);

#endif /*(PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED == STD_ON)*/
#endif /*((PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS) || (PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE))*/
#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED*/

#define PHY_665A_STOP_SEC_CODE
#include "Phy_665a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_INTSPI_H */

