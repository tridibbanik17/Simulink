/*
 * Copyright 2016 - 2021 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*!
 * @file CDD_Bcc_775a_Regs.h
 *
 * This header file contains register map for the MC33775 Battery Cell Controllers.
 */

#ifndef CDD_BCC_775A_REGS_H
#define CDD_BCC_775A_REGS_H

/* General bit operations. */

/**
 * Macro for setting value to 1 of the bit given by the mask.
 *
 * @param reg Register to be modified.
 * @param mask Bit selection in register.
 */
#define BCC_775A_REG_SET_BIT_VALUE(reg, mask) ((reg) | (mask))

/**
 * Macro for setting value to 0 of the bit given by the mask.
 *
 * @param reg Register to be modified.
 * @param mask Bit selection in register.
 */
#define BCC_775A_REG_UNSET_BIT_VALUE(reg, mask) ((reg) & ~(mask))

/**
 * Macro for getting value of the bit given by the mask.
 *
 * @param reg Register to be read.
 * @param mask Bit selection in register.
 * @param shift Bit shift in register.
 */
#define BCC_775A_REG_GET_BIT_VALUE(reg, mask, shift) (((reg) & (mask)) >> (shift))

/**
 * Macro for setting value of bits given by the mask.
 *
 * @param reg Register value to be modified.
 * @param mask Bits selection in register.
 * @param shift Bits shift in register.
 * @param val Value to be applied.
 * @param range Admissible range of value.
 */
#define BCC_775A_REG_SET_BITS_VALUE(reg, mask, shift, val, range) \
    (((reg) & ~(mask)) | (((val) & (range)) << (shift)))

/**
 * Macro for getting value of bits given by the mask.
 *
 * @param reg Register to be read.
 * @param mask Bits selection in register.
 * @param shift Bits shift in register.
 */
#define BCC_775A_REG_GET_BITS_VALUE(reg, mask, shift) (((reg) & (mask)) >> (shift))


/* Overall register macros */
#define MC33775_MCU_IF_NR_OF_REGISTERS \
  (215U)
#define MC33775_MCU_IF_MAX_OFFSET \
  (0x1C8DU)

/* --------------------------------------------------------------------------
 * ALLM_CFG (write-only):General measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_ALLM_CFG_OFFSET \
  (0x1400U)
#define MC33775_ALLM_CFG_RW_MSK \
  (0x0U)
#define MC33775_ALLM_CFG_RD_MSK \
  (0x0U)
#define MC33775_ALLM_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_ALLM_CFG_MW_MSK \
  (0x0U)
#define MC33775_ALLM_CFG_RA_MSK \
  (0x0U)
#define MC33775_ALLM_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_ALLM_CFG_POR_VAL \
  (0x0U)

/* Field MEASEN: Writes MEASEN for primary and secondary measurement. */
#define MC33775_ALLM_CFG_MEASEN_POS \
  (0U)
#define MC33775_ALLM_CFG_MEASEN_MSK \
  (0x1U)

/* Field BALPAUSECYCMODEN: Writes BALPAUSECYCMODEN for primary and secondary measurement. */
#define MC33775_ALLM_CFG_BALPAUSECYCMODEN_POS \
  (1U)
#define MC33775_ALLM_CFG_BALPAUSECYCMODEN_MSK \
  (0x2U)

/* Field BALPAUSELEN: Writes BALPAUSELEN for primary and secondary measurement. */
#define MC33775_ALLM_CFG_BALPAUSELEN_POS \
  (2U)
#define MC33775_ALLM_CFG_BALPAUSELEN_MSK \
  (0xFFFCU)


/* --------------------------------------------------------------------------
 * ALLM_APP_CTRL (write-only):Application measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_ALLM_APP_CTRL_OFFSET \
  (0x1401U)
#define MC33775_ALLM_APP_CTRL_RW_MSK \
  (0x0U)
#define MC33775_ALLM_APP_CTRL_RD_MSK \
  (0x0U)
#define MC33775_ALLM_APP_CTRL_WR_MSK \
  (0xFFFFU)
#define MC33775_ALLM_APP_CTRL_MW_MSK \
  (0x0U)
#define MC33775_ALLM_APP_CTRL_RA_MSK \
  (0x0U)
#define MC33775_ALLM_APP_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_ALLM_APP_CTRL_POR_VAL \
  (0x7C00U)

/* Field CAPVC: Writes CAPVC for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33775_ALLM_APP_CTRL_CAPVC_POS \
  (0U)
#define MC33775_ALLM_APP_CTRL_CAPVC_MSK \
  (0x1U)

/* Field CAPVMODULE: Writes CAPVMODULE for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33775_ALLM_APP_CTRL_CAPVMODULE_POS \
  (1U)
#define MC33775_ALLM_APP_CTRL_CAPVMODULE_MSK \
  (0x2U)

/* Field CAPAIN0: Writes CAPAIN0 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33775_ALLM_APP_CTRL_CAPAIN0_POS \
  (2U)
#define MC33775_ALLM_APP_CTRL_CAPAIN0_MSK \
  (0x4U)

/* Field CAPAIN1: Writes CAPAIN1 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33775_ALLM_APP_CTRL_CAPAIN1_POS \
  (3U)
#define MC33775_ALLM_APP_CTRL_CAPAIN1_MSK \
  (0x8U)

/* Field CAPAIN2: Writes CAPAIN2 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33775_ALLM_APP_CTRL_CAPAIN2_POS \
  (4U)
#define MC33775_ALLM_APP_CTRL_CAPAIN2_MSK \
  (0x10U)

/* Field CAPAIN3: Writes CAPAIN3 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33775_ALLM_APP_CTRL_CAPAIN3_POS \
  (5U)
#define MC33775_ALLM_APP_CTRL_CAPAIN3_MSK \
  (0x20U)

/* Field CAPAIN4: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN4 for secondary measurement. */
#define MC33775_ALLM_APP_CTRL_CAPAIN4_POS \
  (6U)
#define MC33775_ALLM_APP_CTRL_CAPAIN4_MSK \
  (0x40U)

/* Field CAPAIN5: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN5 for secondary measurement. */
#define MC33775_ALLM_APP_CTRL_CAPAIN5_POS \
  (7U)
#define MC33775_ALLM_APP_CTRL_CAPAIN5_MSK \
  (0x80U)

/* Field CAPAIN6: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN6 for secondary measurement. */
#define MC33775_ALLM_APP_CTRL_CAPAIN6_POS \
  (8U)
#define MC33775_ALLM_APP_CTRL_CAPAIN6_MSK \
  (0x100U)

/* Field CAPAIN7: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN7 for secondary measurement. */
#define MC33775_ALLM_APP_CTRL_CAPAIN7_POS \
  (9U)
#define MC33775_ALLM_APP_CTRL_CAPAIN7_MSK \
  (0x200U)

/*ALL channel Measurements are captured*/
#define MC33775_ALLM_APP_CTRL_ALL_CAP_ENUM_VAL \
  (0x3FFU)

/* Field VCOLNUM: Writes VCOLNUM for primary measurement, if CAPVC is set. No influence on secondary measurement. */
#define MC33775_ALLM_APP_CTRL_VCOLNUM_POS \
  (10U)
#define MC33775_ALLM_APP_CTRL_VCOLNUM_MSK \
  (0x7C00U)

/* Enumerated value DISABLED: Open load detection is disabled */
#define MC33775_ALLM_APP_CTRL_VCOLNUM_DISABLED_ENUM_VAL \
  (0x1FU)

/* Field PAUSEBAL: Writes PAUSEBAL for primary and secondary measurement. */
#define MC33775_ALLM_APP_CTRL_PAUSEBAL_POS \
  (15U)
#define MC33775_ALLM_APP_CTRL_PAUSEBAL_MSK \
  (0x8000U)

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33775_ALLM_APP_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33775_ALLM_APP_CTRL_PAUSEBAL_PAUSE_ENUM_VAL \
  (1U)

/* --------------------------------------------------------------------------
 * ALLM_PER_CTRL (write-only):Periodic measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_ALLM_PER_CTRL_OFFSET \
  (0x1402U)
#define MC33775_ALLM_PER_CTRL_RW_MSK \
  (0x0U)
#define MC33775_ALLM_PER_CTRL_RD_MSK \
  (0x0U)
#define MC33775_ALLM_PER_CTRL_WR_MSK \
  (0x11FFU)
#define MC33775_ALLM_PER_CTRL_MW_MSK \
  (0x0U)
#define MC33775_ALLM_PER_CTRL_RA_MSK \
  (0x0U)
#define MC33775_ALLM_PER_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_ALLM_PER_CTRL_POR_VAL \
  (0x10U)

/* Field PERLEN: Writes PERLEN for primary and secondary measurement. */
#define MC33775_ALLM_PER_CTRL_PERLEN_POS \
  (0U)
#define MC33775_ALLM_PER_CTRL_PERLEN_MSK \
  (0x1FFU)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_ALLM_PER_CTRL_RESERVED0_POS \
  (9U)
#define MC33775_ALLM_PER_CTRL_RESERVED0_MSK \
  (0xE00U)

/* Field PERCTRL: Writes PERCTRL for primary and secondary measurement. */
#define MC33775_ALLM_PER_CTRL_PERCTRL_POS \
  (12U)
#define MC33775_ALLM_PER_CTRL_PERCTRL_MSK \
  (0x1000U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_ALLM_PER_CTRL_RESERVED1_POS \
  (13U)
#define MC33775_ALLM_PER_CTRL_RESERVED1_MSK \
  (0xE000U)


/* --------------------------------------------------------------------------
 * ALLM_SYNC_CTRL (write-only):Synchronous measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_ALLM_SYNC_CTRL_OFFSET \
  (0x1403U)
#define MC33775_ALLM_SYNC_CTRL_RW_MSK \
  (0x0U)
#define MC33775_ALLM_SYNC_CTRL_RD_MSK \
  (0x0U)
#define MC33775_ALLM_SYNC_CTRL_WR_MSK \
  (0xFC03U)
#define MC33775_ALLM_SYNC_CTRL_MW_MSK \
  (0x0U)
#define MC33775_ALLM_SYNC_CTRL_RA_MSK \
  (0x0U)
#define MC33775_ALLM_SYNC_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_ALLM_SYNC_CTRL_POR_VAL \
  (0x7C00U)

/* Field SYNCCYC: Writes SYNCCYC for primary and secondary measurement. */
#define MC33775_ALLM_SYNC_CTRL_SYNCCYC_POS \
  (0U)
#define MC33775_ALLM_SYNC_CTRL_SYNCCYC_MSK \
  (0x1U)

/* Enumerated value NO_START: No new start a synchronous measurement cycle. */
#define MC33775_ALLM_SYNC_CTRL_SYNCCYC_NO_START_ENUM_VAL \
  (0U)

/* Enumerated value STATUS: Read a zero */
#define MC33775_ALLM_SYNC_CTRL_SYNCCYC_STATUS_ENUM_VAL \
  (0U)

/* Enumerated value START: Start a synchronous measurement cycle. */
#define MC33775_ALLM_SYNC_CTRL_SYNCCYC_START_ENUM_VAL \
  (1U)

/* Field FASTVB: Dummy fast measurement cycle on primary measurement. Writes FASTVB for secondary measurement. */
#define MC33775_ALLM_SYNC_CTRL_FASTVB_POS \
  (1U)
#define MC33775_ALLM_SYNC_CTRL_FASTVB_MSK \
  (0x2U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_ALLM_SYNC_CTRL_RESERVED0_POS \
  (2U)
#define MC33775_ALLM_SYNC_CTRL_RESERVED0_MSK \
  (0x3FCU)

/* Field VBOLNUM: No influence on primary measurement. Writes VBOLNUM for secondary measurement. */
#define MC33775_ALLM_SYNC_CTRL_VBOLNUM_POS \
  (10U)
#define MC33775_ALLM_SYNC_CTRL_VBOLNUM_MSK \
  (0x7C00U)

/* Enumerated value ENABLE: open load detection is enabled for the currently measured channel */
#define MC33775_ALLM_SYNC_CTRL_VCOLNUM_ENABLED_ENUM_VAL \
  (0x1EU)

/* Enumerated value DISABLED: Open load detection is disabled */
#define MC33775_ALLM_SYNC_CTRL_VBOLNUM_DISABLED_ENUM_VAL \
  (0x1FU)

/* Field PAUSEBAL: Writes PAUSEBAL for primary and secondary measurement. */
#define MC33775_ALLM_SYNC_CTRL_PAUSEBAL_POS \
  (15U)
#define MC33775_ALLM_SYNC_CTRL_PAUSEBAL_MSK \
  (0x8000U)

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33775_ALLM_SYNC_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33775_ALLM_SYNC_CTRL_PAUSEBAL_PAUSE_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * ALLM_VCVB_CFG (write-only):Cell voltage measurement enable.
 * -------------------------------------------------------------------------- */
#define MC33775_ALLM_VCVB_CFG_OFFSET \
  (0x1408U)
#define MC33775_ALLM_VCVB_CFG_RW_MSK \
  (0x0U)
#define MC33775_ALLM_VCVB_CFG_RD_MSK \
  (0x0U)
#define MC33775_ALLM_VCVB_CFG_WR_MSK \
  (0x3FFFU)
#define MC33775_ALLM_VCVB_CFG_MW_MSK \
  (0x0U)
#define MC33775_ALLM_VCVB_CFG_RA_MSK \
  (0x0U)
#define MC33775_ALLM_VCVB_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_ALLM_VCVB_CFG_POR_VAL \
  (0x0U)

/* Field VCVB0EN: Writes VC0EN for primary and VCVB0EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB0EN_POS \
  (0U)
#define MC33775_ALLM_VCVB_CFG_VCVB0EN_MSK \
  (0x1U)

/* Field VCVB1EN: Writes VC1EN for primary and VCVB1EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB1EN_POS \
  (1U)
#define MC33775_ALLM_VCVB_CFG_VCVB1EN_MSK \
  (0x2U)

/* Field VCVB2EN: Writes VC2EN for primary and VCVB2EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB2EN_POS \
  (2U)
#define MC33775_ALLM_VCVB_CFG_VCVB2EN_MSK \
  (0x4U)

/* Field VCVB3EN: Writes VC3EN for primary and VCVB3EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB3EN_POS \
  (3U)
#define MC33775_ALLM_VCVB_CFG_VCVB3EN_MSK \
  (0x8U)

/* Field VCVB4EN: Writes VC4EN for primary and VCVB4EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB4EN_POS \
  (4U)
#define MC33775_ALLM_VCVB_CFG_VCVB4EN_MSK \
  (0x10U)

/* Field VCVB5EN: Writes VC5EN for primary and VCVB5EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB5EN_POS \
  (5U)
#define MC33775_ALLM_VCVB_CFG_VCVB5EN_MSK \
  (0x20U)

/* Field VCVB6EN: Writes VC6EN for primary and VCVB6EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB6EN_POS \
  (6U)
#define MC33775_ALLM_VCVB_CFG_VCVB6EN_MSK \
  (0x40U)

/* Field VCVB7EN: Writes VC7EN for primary and VCVB7EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB7EN_POS \
  (7U)
#define MC33775_ALLM_VCVB_CFG_VCVB7EN_MSK \
  (0x80U)

/* Field VCVB8EN: Writes VC8EN for primary and VCVB8EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB8EN_POS \
  (8U)
#define MC33775_ALLM_VCVB_CFG_VCVB8EN_MSK \
  (0x100U)

/* Field VCVB9EN: Writes VC9EN for primary and VCVB9EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB9EN_POS \
  (9U)
#define MC33775_ALLM_VCVB_CFG_VCVB9EN_MSK \
  (0x200U)

/* Field VCVB10EN: Writes VC10EN for primary and VCVB10EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB10EN_POS \
  (10U)
#define MC33775_ALLM_VCVB_CFG_VCVB10EN_MSK \
  (0x400U)

/* Field VCVB11EN: Writes VC11EN for primary and VCVB11EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB11EN_POS \
  (11U)
#define MC33775_ALLM_VCVB_CFG_VCVB11EN_MSK \
  (0x800U)

/* Field VCVB12EN: Writes VC12EN for primary and VCVB12EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB12EN_POS \
  (12U)
#define MC33775_ALLM_VCVB_CFG_VCVB12EN_MSK \
  (0x1000U)

/* Field VCVB13EN: Writes VC13EN for primary and VCVB13EN secondary measurement. */
#define MC33775_ALLM_VCVB_CFG_VCVB13EN_POS \
  (13U)
#define MC33775_ALLM_VCVB_CFG_VCVB13EN_MSK \
  (0x2000U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_ALLM_VCVB_CFG_RESERVED0_POS \
  (14U)
#define MC33775_ALLM_VCVB_CFG_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * SYS_CFG_CRC (read-only):System Configuration CRC
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_CFG_CRC_OFFSET \
  (0x0U)
#define MC33775_SYS_CFG_CRC_RW_MSK \
  (0x0U)
#define MC33775_SYS_CFG_CRC_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_CFG_CRC_WR_MSK \
  (0x0U)
#define MC33775_SYS_CFG_CRC_MW_MSK \
  (0x0U)
#define MC33775_SYS_CFG_CRC_RA_MSK \
  (0x0U)
#define MC33775_SYS_CFG_CRC_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_CFG_CRC_POR_VAL \
  (0x0U)

/* Field CRC: This CRC value is recalculated with any write to a covered register and with any read to this register. The updated CRC value is available latest 100us after the last write. The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1. */
#define MC33775_SYS_CFG_CRC_CRC_POS \
  (0U)
#define MC33775_SYS_CFG_CRC_CRC_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SYS_COM_CFG (read-write):Communication initialization.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_COM_CFG_OFFSET \
  (0x1U)
#define MC33775_SYS_COM_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_CFG_MW_MSK \
  (0x0U)
#define MC33775_SYS_COM_CFG_RA_MSK \
  (0x0U)
#define MC33775_SYS_COM_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_CFG_POR_VAL \
  (0x200U)

/* Field DADD: Defines the device address. */
#define MC33775_SYS_COM_CFG_DADD_POS \
  (0U)
#define MC33775_SYS_COM_CFG_DADD_MSK \
  (0x3FU)

/* Enumerated value UNENUMERATED: Device is unenumerated. The bus forwarding is disabled. */
#define MC33775_SYS_COM_CFG_DADD_UNENUMERATED_ENUM_VAL \
  (0U)

/* Enumerated value GLOBAL: Used for global read and write Commands. */
#define MC33775_SYS_COM_CFG_DADD_GLOBAL_ENUM_VAL \
  (63U)

/* Field CADD: Defines the daisy chain address. Only used for responses to a all chain read request. */
#define MC33775_SYS_COM_CFG_CADD_POS \
  (6U)
#define MC33775_SYS_COM_CFG_CADD_MSK \
  (0x1C0U)

/* Enumerated value RESERVED: Reserved for future usage. */
#define MC33775_SYS_COM_CFG_CADD_RESERVED_ENUM_VAL \
  (0U)

/* Enumerated value GLOBAL: Reserved for global write commands. */
#define MC33775_SYS_COM_CFG_CADD_GLOBAL_ENUM_VAL \
  (7U)

/* Field BUSFW: Bus forwarding */
#define MC33775_SYS_COM_CFG_BUSFW_POS \
  (9U)
#define MC33775_SYS_COM_CFG_BUSFW_MSK \
  (0x200U)

/* Enumerated value DISABLED: Disabled. */
#define MC33775_SYS_COM_CFG_BUSFW_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enabled if DADD is unequal 00h. */
#define MC33775_SYS_COM_CFG_BUSFW_ENABLED_ENUM_VAL \
  (1U)

/* Field NUMNODES: Number of nodes in the Daisy-Chain. Difference of NUMNODES and DADD defines the wait time for global write commands. */
#define MC33775_SYS_COM_CFG_NUMNODES_POS \
  (10U)
#define MC33775_SYS_COM_CFG_NUMNODES_MSK \
  (0xFC00U)


/* --------------------------------------------------------------------------
 * SYS_COM_TO_CFG (read-write):System communication timeout.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_COM_TO_CFG_OFFSET \
  (0x2U)
#define MC33775_SYS_COM_TO_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_TO_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_TO_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_TO_CFG_MW_MSK \
  (0x0U)
#define MC33775_SYS_COM_TO_CFG_RA_MSK \
  (0x0U)
#define MC33775_SYS_COM_TO_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_COM_TO_CFG_POR_VAL \
  (0x1EU)

/* Field COMTO: Communication timeout time LSB = 10msec. A value of 0 is treated as 10ms. */
#define MC33775_SYS_COM_TO_CFG_COMTO_POS \
  (0U)
#define MC33775_SYS_COM_TO_CFG_COMTO_MSK \
  (0xFFU)

/* Enumerated value T_MIN: 10 milliseconds */
#define MC33775_SYS_COM_TO_CFG_COMTO_T_MIN_ENUM_VAL \
  (0U)

/* Enumerated value T_10m: 10 milliseconds */
#define MC33775_SYS_COM_TO_CFG_COMTO_T_10M_ENUM_VAL \
  (1U)

/* Enumerated value T_MAX: 2550 milliseconds */
#define MC33775_SYS_COM_TO_CFG_COMTO_T_MAX_ENUM_VAL \
  (255U)

/* Field COMTODISABLE: Communication timeout disable. Only intendet for software development activities. Must never be used in release software. */
#define MC33775_SYS_COM_TO_CFG_COMTODISABLE_POS \
  (8U)
#define MC33775_SYS_COM_TO_CFG_COMTODISABLE_MSK \
  (0xFF00U)

/* Enumerated value DISABLED: Communication timeout disabled. */
#define MC33775_SYS_COM_TO_CFG_COMTODISABLE_DISABLED_ENUM_VAL \
  (90U)


/* --------------------------------------------------------------------------
 * SYS_SUPPLY_CFG (read-write):Supply configuration.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_SUPPLY_CFG_OFFSET \
  (0x3U)
#define MC33775_SYS_SUPPLY_CFG_RW_MSK \
  (0x8007U)
#define MC33775_SYS_SUPPLY_CFG_RD_MSK \
  (0x8007U)
#define MC33775_SYS_SUPPLY_CFG_WR_MSK \
  (0x8007U)
#define MC33775_SYS_SUPPLY_CFG_MW_MSK \
  (0x0U)
#define MC33775_SYS_SUPPLY_CFG_RA_MSK \
  (0x0U)
#define MC33775_SYS_SUPPLY_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_SUPPLY_CFG_POR_VAL \
  (0x8003U)

/* Field VAUXACT: Enable VAUX in active mode. */
#define MC33775_SYS_SUPPLY_CFG_VAUXACT_POS \
  (0U)
#define MC33775_SYS_SUPPLY_CFG_VAUXACT_MSK \
  (0x1U)

/* Enumerated value DISABLED: VAUX is disabled in active mode */
#define MC33775_SYS_SUPPLY_CFG_VAUXACT_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: VAUX is enabled in active mode */
#define MC33775_SYS_SUPPLY_CFG_VAUXACT_ENABLED_ENUM_VAL \
  (1U)

/* Field VAUXCYC: Enable VAUX in cyclic mode. */
#define MC33775_SYS_SUPPLY_CFG_VAUXCYC_POS \
  (1U)
#define MC33775_SYS_SUPPLY_CFG_VAUXCYC_MSK \
  (0x2U)

/* Enumerated value DISABLED: VAUX is disabled in cyclic mode */
#define MC33775_SYS_SUPPLY_CFG_VAUXCYC_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: VAUX is enabled in cyclic mode */
#define MC33775_SYS_SUPPLY_CFG_VAUXCYC_ENABLED_ENUM_VAL \
  (1U)

/* Field VDDCCYC: Enable VDDC in cyclic mode. */
#define MC33775_SYS_SUPPLY_CFG_VDDCCYC_POS \
  (2U)
#define MC33775_SYS_SUPPLY_CFG_VDDCCYC_MSK \
  (0x4U)

/* Enumerated value DISABLED: VDDC is disabled in cyclic mode */
#define MC33775_SYS_SUPPLY_CFG_VDDCCYC_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: VDDC is enabled in cyclic mode */
#define MC33775_SYS_SUPPLY_CFG_VDDCCYC_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SYS_SUPPLY_CFG_RESERVED0_POS \
  (3U)
#define MC33775_SYS_SUPPLY_CFG_RESERVED0_MSK \
  (0x7FF8U)

/* Field CURMATCH: Enable IC supply current matching in active mode. */
#define MC33775_SYS_SUPPLY_CFG_CURMATCH_POS \
  (15U)
#define MC33775_SYS_SUPPLY_CFG_CURMATCH_MSK \
  (0x8000U)

/* Enumerated value DISABLED: Supply current matching is disabled */
#define MC33775_SYS_SUPPLY_CFG_CURMATCH_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Supply current matching is enabled */
#define MC33775_SYS_SUPPLY_CFG_CURMATCH_ENABLED_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * SYS_MODE (read-write):System mode.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_MODE_OFFSET \
  (0x4U)
#define MC33775_SYS_MODE_RW_MSK \
  (0x0U)
#define MC33775_SYS_MODE_RD_MSK \
  (0x1F00U)
#define MC33775_SYS_MODE_WR_MSK \
  (0x1FU)
#define MC33775_SYS_MODE_MW_MSK \
  (0x0U)
#define MC33775_SYS_MODE_RA_MSK \
  (0x0U)
#define MC33775_SYS_MODE_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_MODE_POR_VAL \
  (0x1400U)

/* Field TARGETMODE: Target_mode. The mode transition starts immediately after writing. 01010 = sleep, 10100 = deep sleep, Undefined values are ignored. */
#define MC33775_SYS_MODE_TARGETMODE_POS \
  (0U)
#define MC33775_SYS_MODE_TARGETMODE_MSK \
  (0x1FU)

/* Enumerated value SLEEP: Sleep mode */
#define MC33775_SYS_MODE_TARGETMODE_SLEEP_ENUM_VAL \
  (10U)

/* Enumerated value DEEPSLEEP: Deep sleep mode */
#define MC33775_SYS_MODE_TARGETMODE_DEEPSLEEP_ENUM_VAL \
  (20U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SYS_MODE_RESERVED0_POS \
  (5U)
#define MC33775_SYS_MODE_RESERVED0_MSK \
  (0xE0U)

/* Field PREVMODE: Previous mode. */
#define MC33775_SYS_MODE_PREVMODE_POS \
  (8U)
#define MC33775_SYS_MODE_PREVMODE_MSK \
  (0x1F00U)

/* Enumerated value SLEEP: Sleep mode */
#define MC33775_SYS_MODE_PREVMODE_SLEEP_ENUM_VAL \
  (10U)

/* Enumerated value DEEPSLEEP: Deep sleep mode */
#define MC33775_SYS_MODE_PREVMODE_DEEPSLEEP_ENUM_VAL \
  (20U)

/* Enumerated value CYCLIC: Cyclic mode */
#define MC33775_SYS_MODE_PREVMODE_CYCLIC_ENUM_VAL \
  (31U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_SYS_MODE_RESERVED1_POS \
  (13U)
#define MC33775_SYS_MODE_RESERVED1_MSK \
  (0xE000U)


/* --------------------------------------------------------------------------
 * SYS_CYC_WAKEUP_CFG (read-write):Interval for cyclic measurements.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_CYC_WAKEUP_CFG_OFFSET \
  (0x5U)
#define MC33775_SYS_CYC_WAKEUP_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_SYS_CYC_WAKEUP_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_CYC_WAKEUP_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_SYS_CYC_WAKEUP_CFG_MW_MSK \
  (0x0U)
#define MC33775_SYS_CYC_WAKEUP_CFG_RA_MSK \
  (0x0U)
#define MC33775_SYS_CYC_WAKEUP_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_CYC_WAKEUP_CFG_POR_VAL \
  (0x0U)

/* Field PERIOD: Time between two cyclic wake-up events. */
#define MC33775_SYS_CYC_WAKEUP_CFG_PERIOD_POS \
  (0U)
#define MC33775_SYS_CYC_WAKEUP_CFG_PERIOD_MSK \
  (0xFFFFU)

/* Enumerated value DISABLED: Cyclic wakeup disabled. */
#define MC33775_SYS_CYC_WAKEUP_CFG_PERIOD_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value PERIOD: PERIOD * 100ms */
#define MC33775_SYS_CYC_WAKEUP_CFG_PERIOD_PERIOD_ENUM_VAL \
  (1U)

/* Enumerated value PERIOD_MAX: Maximum period time = 6553500 ms = approximately 1.8h */
#define MC33775_SYS_CYC_WAKEUP_CFG_PERIOD_PERIOD_MAX_ENUM_VAL \
  (65535U)


/* --------------------------------------------------------------------------
 * SYS_TPL_CFG (read-write):TPL configuration (RESERVED for customer)
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_TPL_CFG_OFFSET \
  (0x6U)
#define MC33775_SYS_TPL_CFG_RW_MSK \
  (0x1FU)
#define MC33775_SYS_TPL_CFG_RD_MSK \
  (0x1FU)
#define MC33775_SYS_TPL_CFG_WR_MSK \
  (0x1FU)
#define MC33775_SYS_TPL_CFG_MW_MSK \
  (0x0U)
#define MC33775_SYS_TPL_CFG_RA_MSK \
  (0x0U)
#define MC33775_SYS_TPL_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_TPL_CFG_POR_VAL \
  (0x10U)

/* Field WAKEUPCOMPL: Defines compatibility for the lower TPL port. (Pin 45 and pin 46) */
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPL_POS \
  (0U)
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPL_MSK \
  (0x1U)

/* Enumerated value MC33775A: Wake-up signal is compatible to MC33775A. */
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPL_MC33775A_ENUM_VAL \
  (0U)

/* Enumerated value MC33664: Wake-up signal is compatible to MC33664. */
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPL_MC33664_ENUM_VAL \
  (1U)

/* Field WAKEUPCOMPH: Defines compatibility for the upper TPL port. (Pin 47 and pin 48) */
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPH_POS \
  (1U)
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPH_MSK \
  (0x2U)

/* Enumerated value MC33775A: Wake-up signal is compatible to MC33775A. */
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPH_MC33775A_ENUM_VAL \
  (0U)

/* Enumerated value MC33664: Wake-up signal is compatible to MC33664. */
#define MC33775_SYS_TPL_CFG_WAKEUPCOMPH_MC33664_ENUM_VAL \
  (1U)

/* Field TXTERML: Termination active while transmit for the lower TPL port. (Pin 45 and pin 46) */
#define MC33775_SYS_TPL_CFG_TXTERML_POS \
  (2U)
#define MC33775_SYS_TPL_CFG_TXTERML_MSK \
  (0x4U)

/* Enumerated value DISABLED: Disabled. Termination inactive during transmit. Required for normal TPL operation. */
#define MC33775_SYS_TPL_CFG_TXTERML_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enabled. Termination active during transmit. Only needed at final daisy-chain node to have equal power consumption. */
#define MC33775_SYS_TPL_CFG_TXTERML_ENABLED_ENUM_VAL \
  (1U)

/* Field TXTERMH: Termination active while transmit for the higher TPL port. (Pin 47 and pin 48) */
#define MC33775_SYS_TPL_CFG_TXTERMH_POS \
  (3U)
#define MC33775_SYS_TPL_CFG_TXTERMH_MSK \
  (0x8U)

/* Enumerated value DISABLED: Disabled. Termination inactive during transmit. Required for normal TPL operation. */
#define MC33775_SYS_TPL_CFG_TXTERMH_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enabled. Termination active during transmit. Only needed at final daisy-chain node to have equal power consumption. */
#define MC33775_SYS_TPL_CFG_TXTERMH_ENABLED_ENUM_VAL \
  (1U)

/* Field DUALRESP: Dual response */
#define MC33775_SYS_TPL_CFG_DUALRESP_POS \
  (4U)
#define MC33775_SYS_TPL_CFG_DUALRESP_MSK \
  (0x10U)

/* Enumerated value DISABLED: Disabled. Responses are only transmitted at one side. */
#define MC33775_SYS_TPL_CFG_DUALRESP_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enabled.Responses are transmitted on both sides if DADD is unequal 00h. */
#define MC33775_SYS_TPL_CFG_DUALRESP_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SYS_TPL_CFG_RESERVED0_POS \
  (5U)
#define MC33775_SYS_TPL_CFG_RESERVED0_MSK \
  (0xFFE0U)


/* --------------------------------------------------------------------------
 * SYS_CLK_SYNC_CTRL (read-write):Clock Synchronization.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_CLK_SYNC_CTRL_OFFSET \
  (0x8U)
#define MC33775_SYS_CLK_SYNC_CTRL_RW_MSK \
  (0xFFFFU)
#define MC33775_SYS_CLK_SYNC_CTRL_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_CLK_SYNC_CTRL_WR_MSK \
  (0xFFFFU)
#define MC33775_SYS_CLK_SYNC_CTRL_MW_MSK \
  (0x0U)
#define MC33775_SYS_CLK_SYNC_CTRL_RA_MSK \
  (0x0U)
#define MC33775_SYS_CLK_SYNC_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_CLK_SYNC_CTRL_POR_VAL \
  (0x0U)

/* Field SYNCCNT: Synchronization counter value: Writing a 0x0000 resets the counter with no adjustment. For other values it is checked if the internal counter value is higher, in which case the oscillator frequency is decreased. If it is lower the internal oscillator frequency is increased. Reading the value returns the current internal counter value. 1 LSB = 10us. */
#define MC33775_SYS_CLK_SYNC_CTRL_SYNCCNT_POS \
  (0U)
#define MC33775_SYS_CLK_SYNC_CTRL_SYNCCNT_MSK \
  (0xFFFFU)

/* Enumerated value RESET: Counter is reset with no adjustment. */
#define MC33775_SYS_CLK_SYNC_CTRL_SYNCCNT_RESET_ENUM_VAL \
  (0U)

/* Enumerated value ADJUST: 10 us. */
#define MC33775_SYS_CLK_SYNC_CTRL_SYNCCNT_ADJUST_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * SYS_DBG_CTRL (read-write):Debug mode enable
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_DBG_CTRL_OFFSET \
  (0xFU)
#define MC33775_SYS_DBG_CTRL_RW_MSK \
  (0xFFFFU)
#define MC33775_SYS_DBG_CTRL_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_DBG_CTRL_WR_MSK \
  (0xFFFFU)
#define MC33775_SYS_DBG_CTRL_MW_MSK \
  (0x0U)
#define MC33775_SYS_DBG_CTRL_RA_MSK \
  (0x0U)
#define MC33775_SYS_DBG_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_DBG_CTRL_POR_VAL \
  (0x0U)

/* Field KEY: Enable the debug mode (full access to all registers and RAM content). The magic value for debug access is: 0xF14B */
#define MC33775_SYS_DBG_CTRL_KEY_POS \
  (0U)
#define MC33775_SYS_DBG_CTRL_KEY_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SYS_VERSION (read-only):Device silicon identifier.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_VERSION_OFFSET \
  (0x10U)
#define MC33775_SYS_VERSION_RW_MSK \
  (0x0U)
#define MC33775_SYS_VERSION_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_VERSION_WR_MSK \
  (0x0U)
#define MC33775_SYS_VERSION_MW_MSK \
  (0x0U)
#define MC33775_SYS_VERSION_RA_MSK \
  (0x0U)
#define MC33775_SYS_VERSION_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_VERSION_POR_VAL \
  (0x220U)

/* Field MREV: Metal revision ID. */
#define MC33775_SYS_VERSION_MREV_POS \
  (0U)
#define MC33775_SYS_VERSION_MREV_MSK \
  (0xFU)

/* Field FREV: Full mask revision ID. */
#define MC33775_SYS_VERSION_FREV_POS \
  (4U)
#define MC33775_SYS_VERSION_FREV_MSK \
  (0xF0U)

/* Field TYPE: Type identifier. */
#define MC33775_SYS_VERSION_TYPE_POS \
  (8U)
#define MC33775_SYS_VERSION_TYPE_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * SYS_UID_LOW (read-only):Unique device ID lower part.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_UID_LOW_OFFSET \
  (0x11U)
#define MC33775_SYS_UID_LOW_RW_MSK \
  (0x0U)
#define MC33775_SYS_UID_LOW_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_UID_LOW_WR_MSK \
  (0x0U)
#define MC33775_SYS_UID_LOW_MW_MSK \
  (0x0U)
#define MC33775_SYS_UID_LOW_RA_MSK \
  (0x0U)
#define MC33775_SYS_UID_LOW_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_UID_LOW_POR_VAL \
  (0x0U)

/* Field LOW: Lower part of unique device ID (encoded: wafer-lot, wafer-number, device coordinates, testprogram and test-steps). */
#define MC33775_SYS_UID_LOW_LOW_POS \
  (0U)
#define MC33775_SYS_UID_LOW_LOW_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SYS_UID_MID (read-only):Unique device ID middle part.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_UID_MID_OFFSET \
  (0x12U)
#define MC33775_SYS_UID_MID_RW_MSK \
  (0x0U)
#define MC33775_SYS_UID_MID_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_UID_MID_WR_MSK \
  (0x0U)
#define MC33775_SYS_UID_MID_MW_MSK \
  (0x0U)
#define MC33775_SYS_UID_MID_RA_MSK \
  (0x0U)
#define MC33775_SYS_UID_MID_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_UID_MID_POR_VAL \
  (0x0U)

/* Field MID: Middle part of unique device ID (encoded: wafer-lot, wafer-number, device coordinates, testprogram and test-steps). */
#define MC33775_SYS_UID_MID_MID_POS \
  (0U)
#define MC33775_SYS_UID_MID_MID_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SYS_UID_HIGH (read-only):Unique device ID higher part.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_UID_HIGH_OFFSET \
  (0x13U)
#define MC33775_SYS_UID_HIGH_RW_MSK \
  (0x0U)
#define MC33775_SYS_UID_HIGH_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_UID_HIGH_WR_MSK \
  (0x0U)
#define MC33775_SYS_UID_HIGH_MW_MSK \
  (0x0U)
#define MC33775_SYS_UID_HIGH_RA_MSK \
  (0x0U)
#define MC33775_SYS_UID_HIGH_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_UID_HIGH_POR_VAL \
  (0x0U)

/* Field HIGH: Higher part of unique device ID (encoded: wafer-lot, wafer-number, device coordinates, testprogram and test-steps). */
#define MC33775_SYS_UID_HIGH_HIGH_POS \
  (0U)
#define MC33775_SYS_UID_HIGH_HIGH_MSK \
  (0xFFFFU)

/* --------------------------------------------------------------------------
 * SYS_PROD_VER (read-only):Software interface related version of the product.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_PROD_VER_OFFSET \
                          (0x14U)
#define MC33775_SYS_PROD_VER_RW_MSK \
                         (0x0U)
#define MC33775_SYS_PROD_VER_RD_MSK \
                         (0xFFFU)
#define MC33775_SYS_PROD_VER_WR_MSK \
                         (0x0U)
#define MC33775_SYS_PROD_VER_MW_MSK \
                         (0x0U)
#define MC33775_SYS_PROD_VER_RA_MSK \
                         (0x0U)
#define MC33775_SYS_PROD_VER_POR_MSK \
                        (0xFFFFU)
#define MC33775_SYS_PROD_VER_POR_VAL \
                         (0x200U)

/* Field PATCH: Patch: Patch with no software interface change. (AutoSAR nomenclature) */
#define MC33775_SYS_PROD_VER_PATCH_POS \
                  (0x0U)
#define MC33775_SYS_PROD_VER_PATCH_MSK \
                   (0xFU)

/* Field MINOR: Minor Revision: Software interface change, e.g. improvement or extension which is covered by additional registers or transparent to the software. Existing software is compatible but may not use new features. (AutoSAR nomenclature). */
#define MC33775_SYS_PROD_VER_MINOR_POS \
                  (0x4U)
#define MC33775_SYS_PROD_VER_MINOR_MSK \
                   (0xF0U)

/* Field MAJOR: Major Revision: Software interface change, register-map or registers changed. Non-compatible with previous versions. (AutoSAR nomenclature) */
#define MC33775_SYS_PROD_VER_MAJOR_POS \
                  (0x8U)
#define MC33775_SYS_PROD_VER_MAJOR_MSK \
                   (0xF00U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SYS_PROD_VER_RESERVED0_POS \
              (0xCU)
#define MC33775_SYS_PROD_VER_RESERVED0_MSK \
               (0xF000U)

/* --------------------------------------------------------------------------
 * SYS_DS_STORAGE0 (read-write):Deep Sleep Storage Data0. The value is stored in the ULP domain.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_DS_STORAGE0_OFFSET \
  (0x80U)
#define MC33775_SYS_DS_STORAGE0_RW_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE0_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE0_WR_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE0_MW_MSK \
  (0x0U)
#define MC33775_SYS_DS_STORAGE0_RA_MSK \
  (0x0U)
#define MC33775_SYS_DS_STORAGE0_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE0_POR_VAL \
  (0x0U)

/* Field DATA: Deep Sleep surviving data. This register has no reset. This register allows to store application data and has no influence on the device. */
#define MC33775_SYS_DS_STORAGE0_DATA_POS \
  (0U)
#define MC33775_SYS_DS_STORAGE0_DATA_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SYS_DS_STORAGE1 (read-write):Deep Sleep Storage Data1. The value is stored in the ULP domain.
 * -------------------------------------------------------------------------- */
#define MC33775_SYS_DS_STORAGE1_OFFSET \
  (0x81U)
#define MC33775_SYS_DS_STORAGE1_RW_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE1_RD_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE1_WR_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE1_MW_MSK \
  (0x0U)
#define MC33775_SYS_DS_STORAGE1_RA_MSK \
  (0x0U)
#define MC33775_SYS_DS_STORAGE1_POR_MSK \
  (0xFFFFU)
#define MC33775_SYS_DS_STORAGE1_POR_VAL \
  (0x0U)

/* Field DATA: Deep Sleep surviving data. This register has no reset. This register allows to store application data and has no influence on the device. */
#define MC33775_SYS_DS_STORAGE1_DATA_POS \
  (0U)
#define MC33775_SYS_DS_STORAGE1_DATA_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * FEH_CFG_CRC (read-only):Configuration CRC
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_CFG_CRC_OFFSET \
  (0x400U)
#define MC33775_FEH_CFG_CRC_RW_MSK \
  (0x0U)
#define MC33775_FEH_CFG_CRC_RD_MSK \
  (0xFFFFU)
#define MC33775_FEH_CFG_CRC_WR_MSK \
  (0x0U)
#define MC33775_FEH_CFG_CRC_MW_MSK \
  (0x0U)
#define MC33775_FEH_CFG_CRC_RA_MSK \
  (0x0U)
#define MC33775_FEH_CFG_CRC_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_CFG_CRC_POR_VAL \
  (0x0U)

/* Field CRC: This CRC value is recalculated with any write to a covered register and with any read to this register. The updated CRC value is available latest 100us after the last write. The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1. */
#define MC33775_FEH_CFG_CRC_CRC_POS \
  (0U)
#define MC33775_FEH_CFG_CRC_CRC_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * FEH_ALARM_CFG (read-write):General alarm configuration.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_ALARM_CFG_OFFSET \
  (0x401U)
#define MC33775_FEH_ALARM_CFG_RW_MSK \
  (0x1FFU)
#define MC33775_FEH_ALARM_CFG_RD_MSK \
  (0x1FFU)
#define MC33775_FEH_ALARM_CFG_WR_MSK \
  (0x1FFU)
#define MC33775_FEH_ALARM_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_ALARM_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_ALARM_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_ALARM_CFG_POR_VAL \
  (0x0U)

/* Field ALARMIN: Enable alarm input Enabling the alarm input automatically enables the digital receiver for the Alarm input pin. */
#define MC33775_FEH_ALARM_CFG_ALARMIN_POS \
  (0U)
#define MC33775_FEH_ALARM_CFG_ALARMIN_MSK \
  (0x3U)

/* Enumerated value DISABLED: Alarm input is disabled */
#define MC33775_FEH_ALARM_CFG_ALARMIN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value HIGH_ACTIVE: Alarm input is enabled, high active */
#define MC33775_FEH_ALARM_CFG_ALARMIN_HIGH_ACTIVE_ENUM_VAL \
  (1U)

/* Enumerated value LOW_ACTIVE: Alarm input is enabled, low active */
#define MC33775_FEH_ALARM_CFG_ALARMIN_LOW_ACTIVE_ENUM_VAL \
  (2U)

/* Enumerated value HEARTBEAT: Alarm input is enabled, heartbeat configuration */
#define MC33775_FEH_ALARM_CFG_ALARMIN_HEARTBEAT_ENUM_VAL \
  (3U)

/* Field ALARMINHB: Input heartbeat low time setting */
#define MC33775_FEH_ALARM_CFG_ALARMINHB_POS \
  (2U)
#define MC33775_FEH_ALARM_CFG_ALARMINHB_MSK \
  (0xCU)

/* Enumerated value T_500u: 500 us */
#define MC33775_FEH_ALARM_CFG_ALARMINHB_T_500U_ENUM_VAL \
  (0U)

/* Enumerated value T_1ms: 1 ms */
#define MC33775_FEH_ALARM_CFG_ALARMINHB_T_1MS_ENUM_VAL \
  (1U)

/* Enumerated value T_10ms: 10 ms */
#define MC33775_FEH_ALARM_CFG_ALARMINHB_T_10MS_ENUM_VAL \
  (2U)

/* Enumerated value T_100ms: 100 ms */
#define MC33775_FEH_ALARM_CFG_ALARMINHB_T_100MS_ENUM_VAL \
  (3U)

/* Field ALARMOUT: Enable alarm output */
#define MC33775_FEH_ALARM_CFG_ALARMOUT_POS \
  (4U)
#define MC33775_FEH_ALARM_CFG_ALARMOUT_MSK \
  (0x30U)

/* Enumerated value DISABLED: disabled. Alarm output is fixed low */
#define MC33775_FEH_ALARM_CFG_ALARMOUT_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value HIGH_ACTIVE: high active */
#define MC33775_FEH_ALARM_CFG_ALARMOUT_HIGH_ACTIVE_ENUM_VAL \
  (1U)

/* Enumerated value LOW_ACTIVE: low active */
#define MC33775_FEH_ALARM_CFG_ALARMOUT_LOW_ACTIVE_ENUM_VAL \
  (2U)

/* Enumerated value HEARTBEAT: heartbeat configuration */
#define MC33775_FEH_ALARM_CFG_ALARMOUT_HEARTBEAT_ENUM_VAL \
  (3U)

/* Field ALARMOUTHB: Output heartbeat low time setting */
#define MC33775_FEH_ALARM_CFG_ALARMOUTHB_POS \
  (6U)
#define MC33775_FEH_ALARM_CFG_ALARMOUTHB_MSK \
  (0xC0U)

/* Enumerated value T_500u: 500 us */
#define MC33775_FEH_ALARM_CFG_ALARMOUTHB_T_500U_ENUM_VAL \
  (0U)

/* Enumerated value T_1ms: 1 ms */
#define MC33775_FEH_ALARM_CFG_ALARMOUTHB_T_1MS_ENUM_VAL \
  (1U)

/* Enumerated value T_10ms: 10 ms */
#define MC33775_FEH_ALARM_CFG_ALARMOUTHB_T_10MS_ENUM_VAL \
  (2U)

/* Enumerated value T_100ms: 100 ms */
#define MC33775_FEH_ALARM_CFG_ALARMOUTHB_T_100MS_ENUM_VAL \
  (3U)

/* Field ALARMINHBINV: Inverted heartbeat input */
#define MC33775_FEH_ALARM_CFG_ALARMINHBINV_POS \
  (8U)
#define MC33775_FEH_ALARM_CFG_ALARMINHBINV_MSK \
  (0x100U)

/* Enumerated value DISABLED: Normal heatbeat (low with high pulses) input used */
#define MC33775_FEH_ALARM_CFG_ALARMINHBINV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Inverted heatbeat (high with low pulses) input used */
#define MC33775_FEH_ALARM_CFG_ALARMINHBINV_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_ALARM_CFG_RESERVED0_POS \
  (9U)
#define MC33775_FEH_ALARM_CFG_RESERVED0_MSK \
  (0xFE00U)


/* --------------------------------------------------------------------------
 * FEH_ALARM_OUT_CFG (read-write):Alarm output source selection.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_ALARM_OUT_CFG_OFFSET \
  (0x402U)
#define MC33775_FEH_ALARM_OUT_CFG_RW_MSK \
  (0x7FFFU)
#define MC33775_FEH_ALARM_OUT_CFG_RD_MSK \
  (0x7FFFU)
#define MC33775_FEH_ALARM_OUT_CFG_WR_MSK \
  (0x7FFFU)
#define MC33775_FEH_ALARM_OUT_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_ALARM_OUT_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_ALARM_OUT_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_ALARM_OUT_CFG_POR_VAL \
  (0x0U)

/* Field VCOV: Enable output on alarm output for VC_OV. */
#define MC33775_FEH_ALARM_OUT_CFG_VCOV_POS \
  (0U)
#define MC33775_FEH_ALARM_OUT_CFG_VCOV_MSK \
  (0x1U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_VCOV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_VCOV_ENABLED_ENUM_VAL \
  (1U)

/* Field VCUV0: Enable output on alarm output for VC_UV0. */
#define MC33775_FEH_ALARM_OUT_CFG_VCUV0_POS \
  (1U)
#define MC33775_FEH_ALARM_OUT_CFG_VCUV0_MSK \
  (0x2U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_VCUV0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_VCUV0_ENABLED_ENUM_VAL \
  (1U)

/* Field VCUV1: Enable output on alarm output for VC_UV1. */
#define MC33775_FEH_ALARM_OUT_CFG_VCUV1_POS \
  (2U)
#define MC33775_FEH_ALARM_OUT_CFG_VCUV1_MSK \
  (0x4U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_VCUV1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_VCUV1_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN0OV: Enable output on alarm output for AIN0_OV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN0OV_POS \
  (3U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN0OV_MSK \
  (0x8U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN0OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN0OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN0UV: Enable output on alarm output for AIN0_UV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN0UV_POS \
  (4U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN0UV_MSK \
  (0x10U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN0UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN0UV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN1OV: Enable output on alarm output for AIN1_OV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN1OV_POS \
  (5U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN1OV_MSK \
  (0x20U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN1OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN1OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN1UV: Enable output on alarm output for AIN1_UV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN1UV_POS \
  (6U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN1UV_MSK \
  (0x40U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN1UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN1UV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN2OV: Enable output on alarm output for AIN2_OV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN2OV_POS \
  (7U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN2OV_MSK \
  (0x80U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN2OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN2OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN2UV: Enable output on alarm output for AIN2_UV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN2UV_POS \
  (8U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN2UV_MSK \
  (0x100U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN2UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN2UV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN3OV: Enable output on alarm output for AIN3_OV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN3OV_POS \
  (9U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN3OV_MSK \
  (0x200U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN3OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN3OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN3UV: Enable output on alarm output for AIN3_UV. */
#define MC33775_FEH_ALARM_OUT_CFG_AIN3UV_POS \
  (10U)
#define MC33775_FEH_ALARM_OUT_CFG_AIN3UV_MSK \
  (0x400U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN3UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_AIN3UV_ENABLED_ENUM_VAL \
  (1U)

/* Field ALARMIN: Enable output on alarm output for detected alarm input. */
#define MC33775_FEH_ALARM_OUT_CFG_ALARMIN_POS \
  (11U)
#define MC33775_FEH_ALARM_OUT_CFG_ALARMIN_MSK \
  (0x800U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_ALARMIN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_ALARMIN_ENABLED_ENUM_VAL \
  (1U)

/* Field WAKEUPIN: Enable output on detected wakeup input. Enabling this bit automatically enables the digital receiver for the wakeup input pin. */
#define MC33775_FEH_ALARM_OUT_CFG_WAKEUPIN_POS \
  (12U)
#define MC33775_FEH_ALARM_OUT_CFG_WAKEUPIN_MSK \
  (0x1000U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_WAKEUPIN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_WAKEUPIN_ENABLED_ENUM_VAL \
  (1U)

/* Field BALRDY: Enable output on alarm output for cell voltage balancing ready. */
#define MC33775_FEH_ALARM_OUT_CFG_BALRDY_POS \
  (13U)
#define MC33775_FEH_ALARM_OUT_CFG_BALRDY_MSK \
  (0x2000U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_BALRDY_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_BALRDY_ENABLED_ENUM_VAL \
  (1U)

/* Field SYSFLTEVT: Enable output on alarm output for a detected and selected system fault. */
#define MC33775_FEH_ALARM_OUT_CFG_SYSFLTEVT_POS \
  (14U)
#define MC33775_FEH_ALARM_OUT_CFG_SYSFLTEVT_MSK \
  (0x4000U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_ALARM_OUT_CFG_SYSFLTEVT_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_ALARM_OUT_CFG_SYSFLTEVT_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_ALARM_OUT_CFG_RESERVED0_POS \
  (15U)
#define MC33775_FEH_ALARM_OUT_CFG_RESERVED0_MSK \
  (0x8000U)


/* --------------------------------------------------------------------------
 * FEH_ALARM_OUT_REASON (read-only):Alarm output reason.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_ALARM_OUT_REASON_OFFSET \
  (0x403U)
#define MC33775_FEH_ALARM_OUT_REASON_RW_MSK \
  (0x0U)
#define MC33775_FEH_ALARM_OUT_REASON_RD_MSK \
  (0x7FFFU)
#define MC33775_FEH_ALARM_OUT_REASON_WR_MSK \
  (0x0U)
#define MC33775_FEH_ALARM_OUT_REASON_MW_MSK \
  (0x0U)
#define MC33775_FEH_ALARM_OUT_REASON_RA_MSK \
  (0x7FFFU)
#define MC33775_FEH_ALARM_OUT_REASON_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_ALARM_OUT_REASON_POR_VAL \
  (0x0U)

/* Field VCOV: VC_OV */
#define MC33775_FEH_ALARM_OUT_REASON_VCOV_POS \
  (0U)
#define MC33775_FEH_ALARM_OUT_REASON_VCOV_MSK \
  (0x1U)

/* Enumerated value NO_ALARM: Alarm not caused by VC_OV */
#define MC33775_FEH_ALARM_OUT_REASON_VCOV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by VC_OV */
#define MC33775_FEH_ALARM_OUT_REASON_VCOV_ALARM_ENUM_VAL \
  (1U)

/* Field VCUV0: VC_UV0 */
#define MC33775_FEH_ALARM_OUT_REASON_VCUV0_POS \
  (1U)
#define MC33775_FEH_ALARM_OUT_REASON_VCUV0_MSK \
  (0x2U)

/* Enumerated value NO_ALARM: Alarm not caused by VC_UV0 */
#define MC33775_FEH_ALARM_OUT_REASON_VCUV0_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by VC_UV0 */
#define MC33775_FEH_ALARM_OUT_REASON_VCUV0_ALARM_ENUM_VAL \
  (1U)

/* Field VCUV1: VC_UV1 */
#define MC33775_FEH_ALARM_OUT_REASON_VCUV1_POS \
  (2U)
#define MC33775_FEH_ALARM_OUT_REASON_VCUV1_MSK \
  (0x4U)

/* Enumerated value NO_ALARM: Alarm not caused by VC_UV1 */
#define MC33775_FEH_ALARM_OUT_REASON_VCUV1_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by VC_UV1 */
#define MC33775_FEH_ALARM_OUT_REASON_VCUV1_ALARM_ENUM_VAL \
  (1U)

/* Field AIN0OV: AIN0_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN0OV_POS \
  (3U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN0OV_MSK \
  (0x8U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN0_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN0OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN0_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN0OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN0UV: AIN0_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN0UV_POS \
  (4U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN0UV_MSK \
  (0x10U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN0_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN0UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN0_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN0UV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN1OV: AIN1_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN1OV_POS \
  (5U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN1OV_MSK \
  (0x20U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN1_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN1OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN1_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN1OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN1UV: AIN1_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN1UV_POS \
  (6U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN1UV_MSK \
  (0x40U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN1_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN1UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN1_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN1UV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN2OV: AIN2_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN2OV_POS \
  (7U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN2OV_MSK \
  (0x80U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN2_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN2OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN2_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN2OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN2UV: AIN2_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN2UV_POS \
  (8U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN2UV_MSK \
  (0x100U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN2_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN2UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN2_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN2UV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN3OV: AIN3_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN3OV_POS \
  (9U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN3OV_MSK \
  (0x200U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN3_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN3OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN3_OV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN3OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN3UV: AIN3_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN3UV_POS \
  (10U)
#define MC33775_FEH_ALARM_OUT_REASON_AIN3UV_MSK \
  (0x400U)

/* Enumerated value NO_ALARM: Alarm not caused by AIN3_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN3UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN3_UV */
#define MC33775_FEH_ALARM_OUT_REASON_AIN3UV_ALARM_ENUM_VAL \
  (1U)

/* Field ALARMIN: Detected alarm input */
#define MC33775_FEH_ALARM_OUT_REASON_ALARMIN_POS \
  (11U)
#define MC33775_FEH_ALARM_OUT_REASON_ALARMIN_MSK \
  (0x800U)

/* Enumerated value NO_ALARM: Alarm not caused by detected alarm input */
#define MC33775_FEH_ALARM_OUT_REASON_ALARMIN_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by detected alarm input */
#define MC33775_FEH_ALARM_OUT_REASON_ALARMIN_ALARM_ENUM_VAL \
  (1U)

/* Field WAKEUPIN: Detected wakeup input */
#define MC33775_FEH_ALARM_OUT_REASON_WAKEUPIN_POS \
  (12U)
#define MC33775_FEH_ALARM_OUT_REASON_WAKEUPIN_MSK \
  (0x1000U)

/* Enumerated value NO_ALARM: Alarm not caused by detected wakeup input */
#define MC33775_FEH_ALARM_OUT_REASON_WAKEUPIN_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by detected wakeup input */
#define MC33775_FEH_ALARM_OUT_REASON_WAKEUPIN_ALARM_ENUM_VAL \
  (1U)

/* Field BALRDY: Cell voltage balancing ready */
#define MC33775_FEH_ALARM_OUT_REASON_BALRDY_POS \
  (13U)
#define MC33775_FEH_ALARM_OUT_REASON_BALRDY_MSK \
  (0x2000U)

/* Enumerated value NO_ALARM: Alarm not caused by cell voltage balancing ready */
#define MC33775_FEH_ALARM_OUT_REASON_BALRDY_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by cell voltage balancing ready */
#define MC33775_FEH_ALARM_OUT_REASON_BALRDY_ALARM_ENUM_VAL \
  (1U)

/* Field SYSFLTEVT: Detected system fault. */
#define MC33775_FEH_ALARM_OUT_REASON_SYSFLTEVT_POS \
  (14U)
#define MC33775_FEH_ALARM_OUT_REASON_SYSFLTEVT_MSK \
  (0x4000U)

/* Enumerated value NO_ALARM: Alarm not caused by detected system fault */
#define MC33775_FEH_ALARM_OUT_REASON_SYSFLTEVT_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by detected system fault */
#define MC33775_FEH_ALARM_OUT_REASON_SYSFLTEVT_ALARM_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_ALARM_OUT_REASON_RESERVED0_POS \
  (15U)
#define MC33775_FEH_ALARM_OUT_REASON_RESERVED0_MSK \
  (0x8000U)


/* --------------------------------------------------------------------------
 * FEH_WAKEUP_CFG (read-write):Wake up source configuration.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_WAKEUP_CFG_OFFSET \
  (0x408U)
#define MC33775_FEH_WAKEUP_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_FEH_WAKEUP_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_FEH_WAKEUP_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_FEH_WAKEUP_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_WAKEUP_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_WAKEUP_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_WAKEUP_CFG_POR_VAL \
  (0x0U)

/* Field VCOV: Enable wakeup on VC_OV. */
#define MC33775_FEH_WAKEUP_CFG_VCOV_POS \
  (0U)
#define MC33775_FEH_WAKEUP_CFG_VCOV_MSK \
  (0x1U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_VCOV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_VCOV_ENABLED_ENUM_VAL \
  (1U)

/* Field VCUV0: Enable wakeup on VC_UV0. */
#define MC33775_FEH_WAKEUP_CFG_VCUV0_POS \
  (1U)
#define MC33775_FEH_WAKEUP_CFG_VCUV0_MSK \
  (0x2U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_VCUV0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_VCUV0_ENABLED_ENUM_VAL \
  (1U)

/* Field VCUV1: Enable wakeup on VC_UV1. */
#define MC33775_FEH_WAKEUP_CFG_VCUV1_POS \
  (2U)
#define MC33775_FEH_WAKEUP_CFG_VCUV1_MSK \
  (0x4U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_VCUV1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_VCUV1_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN0OV: Enable wakeup on AIN0_OV. */
#define MC33775_FEH_WAKEUP_CFG_AIN0OV_POS \
  (3U)
#define MC33775_FEH_WAKEUP_CFG_AIN0OV_MSK \
  (0x8U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN0OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN0OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN0UV: Enable wakeup on AIN0_UV. */
#define MC33775_FEH_WAKEUP_CFG_AIN0UV_POS \
  (4U)
#define MC33775_FEH_WAKEUP_CFG_AIN0UV_MSK \
  (0x10U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN0UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN0UV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN1OV: Enable wakeup on AIN1_OV. */
#define MC33775_FEH_WAKEUP_CFG_AIN1OV_POS \
  (5U)
#define MC33775_FEH_WAKEUP_CFG_AIN1OV_MSK \
  (0x20U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN1OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN1OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN1UV: Enable wakeup on AIN1_UV. */
#define MC33775_FEH_WAKEUP_CFG_AIN1UV_POS \
  (6U)
#define MC33775_FEH_WAKEUP_CFG_AIN1UV_MSK \
  (0x40U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN1UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN1UV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN2OV: Enable wakeup on AIN2_OV. */
#define MC33775_FEH_WAKEUP_CFG_AIN2OV_POS \
  (7U)
#define MC33775_FEH_WAKEUP_CFG_AIN2OV_MSK \
  (0x80U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN2OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN2OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN2UV: Enable wakeup on AIN2_UV. */
#define MC33775_FEH_WAKEUP_CFG_AIN2UV_POS \
  (8U)
#define MC33775_FEH_WAKEUP_CFG_AIN2UV_MSK \
  (0x100U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN2UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN2UV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN3OV: Enable wakeup on AIN3_OV. */
#define MC33775_FEH_WAKEUP_CFG_AIN3OV_POS \
  (9U)
#define MC33775_FEH_WAKEUP_CFG_AIN3OV_MSK \
  (0x200U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN3OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN3OV_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN3UV: Enable wakeup on AIN3_UV. */
#define MC33775_FEH_WAKEUP_CFG_AIN3UV_POS \
  (10U)
#define MC33775_FEH_WAKEUP_CFG_AIN3UV_MSK \
  (0x400U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_AIN3UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_AIN3UV_ENABLED_ENUM_VAL \
  (1U)

/* Field ALARMIN: Enable wakeup on detected alarm input */
#define MC33775_FEH_WAKEUP_CFG_ALARMIN_POS \
  (11U)
#define MC33775_FEH_WAKEUP_CFG_ALARMIN_MSK \
  (0x800U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_ALARMIN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_ALARMIN_ENABLED_ENUM_VAL \
  (1U)

/* Field WAKEUPIN: Enable wakeup on detected wakeup input. Enabling this bit automatically enables the digital receiver for wake-up input 0. */
#define MC33775_FEH_WAKEUP_CFG_WAKEUPIN_POS \
  (12U)
#define MC33775_FEH_WAKEUP_CFG_WAKEUPIN_MSK \
  (0x1000U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_WAKEUPIN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_WAKEUPIN_ENABLED_ENUM_VAL \
  (1U)

/* Field BALRDY: Enable wakeup on cell voltage balancing ready. */
#define MC33775_FEH_WAKEUP_CFG_BALRDY_POS \
  (13U)
#define MC33775_FEH_WAKEUP_CFG_BALRDY_MSK \
  (0x2000U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_BALRDY_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_BALRDY_ENABLED_ENUM_VAL \
  (1U)

/* Field SYSFLTEVT: Enable wakeup on a detected system fault. */
#define MC33775_FEH_WAKEUP_CFG_SYSFLTEVT_POS \
  (14U)
#define MC33775_FEH_WAKEUP_CFG_SYSFLTEVT_MSK \
  (0x4000U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_SYSFLTEVT_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33775_FEH_WAKEUP_CFG_SYSFLTEVT_ENABLED_ENUM_VAL \
  (1U)

/* Field TPLWAKEUP: Wake TPL */
#define MC33775_FEH_WAKEUP_CFG_TPLWAKEUP_POS \
  (15U)
#define MC33775_FEH_WAKEUP_CFG_TPLWAKEUP_MSK \
  (0x8000U)

/* Enumerated value DISABLED: disabled */
#define MC33775_FEH_WAKEUP_CFG_TPLWAKEUP_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled. Device sends wake-up frames on TPL if wake-up reason was other than communication */
#define MC33775_FEH_WAKEUP_CFG_TPLWAKEUP_ENABLED_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * FEH_WAKEUP_REASON (read-only):Wake up reason register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_WAKEUP_REASON_OFFSET \
  (0x409U)
#define MC33775_FEH_WAKEUP_REASON_RW_MSK \
  (0x0U)
#define MC33775_FEH_WAKEUP_REASON_RD_MSK \
  (0xFFFFU)
#define MC33775_FEH_WAKEUP_REASON_WR_MSK \
  (0x0U)
#define MC33775_FEH_WAKEUP_REASON_MW_MSK \
  (0x0U)
#define MC33775_FEH_WAKEUP_REASON_RA_MSK \
  (0xFFFFU)
#define MC33775_FEH_WAKEUP_REASON_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_WAKEUP_REASON_POR_VAL \
  (0x0U)

/* Field VCOV: VC_OV */
#define MC33775_FEH_WAKEUP_REASON_VCOV_POS \
  (0U)
#define MC33775_FEH_WAKEUP_REASON_VCOV_MSK \
  (0x1U)

/* Enumerated value NO_WAKE: Wakeup not caused by VC_OV */
#define MC33775_FEH_WAKEUP_REASON_VCOV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by VC_OV */
#define MC33775_FEH_WAKEUP_REASON_VCOV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field VCUV0: VC_UV0 */
#define MC33775_FEH_WAKEUP_REASON_VCUV0_POS \
  (1U)
#define MC33775_FEH_WAKEUP_REASON_VCUV0_MSK \
  (0x2U)

/* Enumerated value NO_WAKE: Wakeup not caused by VC_UV0 */
#define MC33775_FEH_WAKEUP_REASON_VCUV0_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by VC_UV0 */
#define MC33775_FEH_WAKEUP_REASON_VCUV0_WAKE_UP_ENUM_VAL \
  (1U)

/* Field VCUV1: VC_UV1 */
#define MC33775_FEH_WAKEUP_REASON_VCUV1_POS \
  (2U)
#define MC33775_FEH_WAKEUP_REASON_VCUV1_MSK \
  (0x4U)

/* Enumerated value NO_WAKE: Wakeup not caused by VC_UV1 */
#define MC33775_FEH_WAKEUP_REASON_VCUV1_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by VC_UV1 */
#define MC33775_FEH_WAKEUP_REASON_VCUV1_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN0OV: AIN0_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN0OV_POS \
  (3U)
#define MC33775_FEH_WAKEUP_REASON_AIN0OV_MSK \
  (0x8U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN0_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN0OV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN0_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN0OV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN0UV: AIN0_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN0UV_POS \
  (4U)
#define MC33775_FEH_WAKEUP_REASON_AIN0UV_MSK \
  (0x10U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN0_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN0UV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN0_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN0UV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN1OV: AIN1_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN1OV_POS \
  (5U)
#define MC33775_FEH_WAKEUP_REASON_AIN1OV_MSK \
  (0x20U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN1_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN1OV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN1_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN1OV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN1UV: AIN1_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN1UV_POS \
  (6U)
#define MC33775_FEH_WAKEUP_REASON_AIN1UV_MSK \
  (0x40U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN1_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN1UV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN1_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN1UV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN2OV: AIN2_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN2OV_POS \
  (7U)
#define MC33775_FEH_WAKEUP_REASON_AIN2OV_MSK \
  (0x80U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN2_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN2OV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN2_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN2OV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN2UV: AIN2_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN2UV_POS \
  (8U)
#define MC33775_FEH_WAKEUP_REASON_AIN2UV_MSK \
  (0x100U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN2_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN2UV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN2_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN2UV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN3OV: AIN3_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN3OV_POS \
  (9U)
#define MC33775_FEH_WAKEUP_REASON_AIN3OV_MSK \
  (0x200U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN3_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN3OV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN3_OV */
#define MC33775_FEH_WAKEUP_REASON_AIN3OV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AIN3UV: AIN3_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN3UV_POS \
  (10U)
#define MC33775_FEH_WAKEUP_REASON_AIN3UV_MSK \
  (0x400U)

/* Enumerated value NO_WAKE: Wakeup not caused by AIN3_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN3UV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN3_UV */
#define MC33775_FEH_WAKEUP_REASON_AIN3UV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field ALARMIN: Detected alarm input */
#define MC33775_FEH_WAKEUP_REASON_ALARMIN_POS \
  (11U)
#define MC33775_FEH_WAKEUP_REASON_ALARMIN_MSK \
  (0x800U)

/* Enumerated value NO_WAKE: Wakeup not caused by detected Wakeup input */
#define MC33775_FEH_WAKEUP_REASON_ALARMIN_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected Wakeup input */
#define MC33775_FEH_WAKEUP_REASON_ALARMIN_WAKE_UP_ENUM_VAL \
  (1U)

/* Field WAKEUPIN: Detected wakeup input */
#define MC33775_FEH_WAKEUP_REASON_WAKEUPIN_POS \
  (12U)
#define MC33775_FEH_WAKEUP_REASON_WAKEUPIN_MSK \
  (0x1000U)

/* Enumerated value NO_WAKE: Wakeup not caused by detected wakeup input */
#define MC33775_FEH_WAKEUP_REASON_WAKEUPIN_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected wakeup input */
#define MC33775_FEH_WAKEUP_REASON_WAKEUPIN_WAKE_UP_ENUM_VAL \
  (1U)

/* Field BALRDY: Cell voltage balancing ready */
#define MC33775_FEH_WAKEUP_REASON_BALRDY_POS \
  (13U)
#define MC33775_FEH_WAKEUP_REASON_BALRDY_MSK \
  (0x2000U)

/* Enumerated value NO_WAKE: Wakeup not caused by cell voltage balancing ready */
#define MC33775_FEH_WAKEUP_REASON_BALRDY_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by cell voltage balancing ready */
#define MC33775_FEH_WAKEUP_REASON_BALRDY_WAKE_UP_ENUM_VAL \
  (1U)

/* Field SYSFLTEVT: Detected system fault. */
#define MC33775_FEH_WAKEUP_REASON_SYSFLTEVT_POS \
  (14U)
#define MC33775_FEH_WAKEUP_REASON_SYSFLTEVT_MSK \
  (0x4000U)

/* Enumerated value NO_WAKE: Wakeup not caused by detected system fault */
#define MC33775_FEH_WAKEUP_REASON_SYSFLTEVT_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected system fault */
#define MC33775_FEH_WAKEUP_REASON_SYSFLTEVT_WAKE_UP_ENUM_VAL \
  (1U)

/* Field COMM: Communication detected */
#define MC33775_FEH_WAKEUP_REASON_COMM_POS \
  (15U)
#define MC33775_FEH_WAKEUP_REASON_COMM_MSK \
  (0x8000U)

/* Enumerated value NO_WAKE: Wakeup not caused by detected communication */
#define MC33775_FEH_WAKEUP_REASON_COMM_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected communication */
#define MC33775_FEH_WAKEUP_REASON_COMM_WAKE_UP_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * FEH_MON_BIST_CTRL (read-write):Monitor BIST control register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_MON_BIST_CTRL_OFFSET \
  (0x410U)
#define MC33775_FEH_MON_BIST_CTRL_RW_MSK \
  (0xFFFEU)
#define MC33775_FEH_MON_BIST_CTRL_RD_MSK \
  (0xFFFEU)
#define MC33775_FEH_MON_BIST_CTRL_WR_MSK \
  (0xFFFFU)
#define MC33775_FEH_MON_BIST_CTRL_MW_MSK \
  (0x0U)
#define MC33775_FEH_MON_BIST_CTRL_RA_MSK \
  (0x0U)
#define MC33775_FEH_MON_BIST_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_MON_BIST_CTRL_POR_VAL \
  (0x0U)

/* Field STARTBIST: Start BIST of all supply monitors, including VAUXOV, VAUXUV, VDDCOV and VDDCUV, which are not run at start-up. If the BIST is executed while measurements are running, some created secondary measurement results might be invalid. Read as zero. */
#define MC33775_FEH_MON_BIST_CTRL_STARTBIST_POS \
  (0U)
#define MC33775_FEH_MON_BIST_CTRL_STARTBIST_MSK \
  (0x1U)

/* Enumerated value NO_START: Do not start BIST */
#define MC33775_FEH_MON_BIST_CTRL_STARTBIST_NO_START_ENUM_VAL \
  (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33775_FEH_MON_BIST_CTRL_STARTBIST_STATUS_ENUM_VAL \
  (0U)

/* Enumerated value START: Start BIST */
#define MC33775_FEH_MON_BIST_CTRL_STARTBIST_START_ENUM_VAL \
  (1U)

/* Field BISTCRC: CRC of the sequential BIST results. The value is different for the automatic BIST after start-up and a manual started BIST, as more monitors are then included. */
#define MC33775_FEH_MON_BIST_CTRL_BISTCRC_POS \
  (1U)
#define MC33775_FEH_MON_BIST_CTRL_BISTCRC_MSK \
  (0xFFFEU)

/* Enumerated value MANUAL: Value 2B71h represents the correct CRC value for a manual started BIST if VAUX is enabled */
#define MC33775_FEH_MON_BIST_CTRL_BISTCRC_MANUAL_ENUM_VAL \
  (11121U)

/* Enumerated value STARTUP: Value 5198h represents the correct CRC value for the start-up BIST */
#define MC33775_FEH_MON_BIST_CTRL_BISTCRC_STARTUP_ENUM_VAL \
  (20888U)

/* Enumerated value MAN_NO_VAUX: Value 6039h represents the correct CRC value for a manual started BIST if VAUX is not enabled */
#define MC33775_FEH_MON_BIST_CTRL_BISTCRC_MAN_NO_VAUX_ENUM_VAL \
  (24633U)


/* --------------------------------------------------------------------------
 * FEH_MON_BIST_RES (read-only):Monitor BIST result register. Note: value will change at start-up, if everything is fine to 0x0000.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_MON_BIST_RES_OFFSET \
  (0x411U)
#define MC33775_FEH_MON_BIST_RES_RW_MSK \
  (0x0U)
#define MC33775_FEH_MON_BIST_RES_RD_MSK \
  (0x3FFFU)
#define MC33775_FEH_MON_BIST_RES_WR_MSK \
  (0x0U)
#define MC33775_FEH_MON_BIST_RES_MW_MSK \
  (0x0U)
#define MC33775_FEH_MON_BIST_RES_RA_MSK \
  (0x0U)
#define MC33775_FEH_MON_BIST_RES_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_MON_BIST_RES_POR_VAL \
  (0x3FFU)

/* Field VBATOV: VBAT Supply over-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_VBATOV_POS \
  (0U)
#define MC33775_FEH_MON_BIST_RES_VBATOV_MSK \
  (0x1U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VBATOV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VBATOV_FAIL_ENUM_VAL \
  (1U)

/* Field VDDAOV: VDDA Supply over-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_VDDAOV_POS \
  (1U)
#define MC33775_FEH_MON_BIST_RES_VDDAOV_MSK \
  (0x2U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VDDAOV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VDDAOV_FAIL_ENUM_VAL \
  (1U)

/* Field VDDAUV: VDDA Supply under-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_VDDAUV_POS \
  (2U)
#define MC33775_FEH_MON_BIST_RES_VDDAUV_MSK \
  (0x4U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VDDAUV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VDDAUV_FAIL_ENUM_VAL \
  (1U)

/* Field V2P5AOV: V2P5A over-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_V2P5AOV_POS \
  (3U)
#define MC33775_FEH_MON_BIST_RES_V2P5AOV_MSK \
  (0x8U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_V2P5AOV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_V2P5AOV_FAIL_ENUM_VAL \
  (1U)

/* Field V2P5AUV: V2P5A under-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_V2P5AUV_POS \
  (4U)
#define MC33775_FEH_MON_BIST_RES_V2P5AUV_MSK \
  (0x10U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_V2P5AUV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_V2P5AUV_FAIL_ENUM_VAL \
  (1U)

/* Field AFECPOV: Analog Frontend Charge Pump over-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_AFECPOV_POS \
  (5U)
#define MC33775_FEH_MON_BIST_RES_AFECPOV_MSK \
  (0x20U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_AFECPOV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_AFECPOV_FAIL_ENUM_VAL \
  (1U)

/* Field AFECPUV: Analog Frontend Charge Pump under-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_AFECPUV_POS \
  (6U)
#define MC33775_FEH_MON_BIST_RES_AFECPUV_MSK \
  (0x40U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_AFECPUV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_AFECPUV_FAIL_ENUM_VAL \
  (1U)

/* Field IBIASPERMOC: IBIAS_PERM over-current BIST failed. */
#define MC33775_FEH_MON_BIST_RES_IBIASPERMOC_POS \
  (7U)
#define MC33775_FEH_MON_BIST_RES_IBIASPERMOC_MSK \
  (0x80U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_IBIASPERMOC_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_IBIASPERMOC_FAIL_ENUM_VAL \
  (1U)

/* Field IBIASPERMUC: IBIAS_PERM under-current BIST failed. */
#define MC33775_FEH_MON_BIST_RES_IBIASPERMUC_POS \
  (8U)
#define MC33775_FEH_MON_BIST_RES_IBIASPERMUC_MSK \
  (0x100U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_IBIASPERMUC_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_IBIASPERMUC_FAIL_ENUM_VAL \
  (1U)

/* Field VPREREFSUV: VPREREFSUV Supply under-voltage BIST failed. */
#define MC33775_FEH_MON_BIST_RES_VPREREFSUV_POS \
  (9U)
#define MC33775_FEH_MON_BIST_RES_VPREREFSUV_MSK \
  (0x200U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VPREREFSUV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VPREREFSUV_FAIL_ENUM_VAL \
  (1U)

/* Field VAUXOV: VAUX Supply over-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33775_FEH_MON_BIST_RES_VAUXOV_POS \
  (10U)
#define MC33775_FEH_MON_BIST_RES_VAUXOV_MSK \
  (0x400U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VAUXOV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VAUXOV_FAIL_ENUM_VAL \
  (1U)

/* Field VAUXUV: VAUX Supply under-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33775_FEH_MON_BIST_RES_VAUXUV_POS \
  (11U)
#define MC33775_FEH_MON_BIST_RES_VAUXUV_MSK \
  (0x800U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VAUXUV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VAUXUV_FAIL_ENUM_VAL \
  (1U)

/* Field VDDCOV: VDDC Supply over-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33775_FEH_MON_BIST_RES_VDDCOV_POS \
  (12U)
#define MC33775_FEH_MON_BIST_RES_VDDCOV_MSK \
  (0x1000U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VDDCOV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VDDCOV_FAIL_ENUM_VAL \
  (1U)

/* Field VDDCUV: VDDC Supply under-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33775_FEH_MON_BIST_RES_VDDCUV_POS \
  (13U)
#define MC33775_FEH_MON_BIST_RES_VDDCUV_MSK \
  (0x2000U)

/* Enumerated value PASS: BIST passed */
#define MC33775_FEH_MON_BIST_RES_VDDCUV_PASS_ENUM_VAL \
  (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33775_FEH_MON_BIST_RES_VDDCUV_FAIL_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_MON_BIST_RES_RESERVED0_POS \
  (14U)
#define MC33775_FEH_MON_BIST_RES_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * FEH_ACC_ERR (read-only):Access error status register
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_ACC_ERR_OFFSET \
  (0x41EU)
#define MC33775_FEH_ACC_ERR_RW_MSK \
  (0x0U)
#define MC33775_FEH_ACC_ERR_RD_MSK \
  (0xFFFFU)
#define MC33775_FEH_ACC_ERR_WR_MSK \
  (0x0U)
#define MC33775_FEH_ACC_ERR_MW_MSK \
  (0x0U)
#define MC33775_FEH_ACC_ERR_RA_MSK \
  (0xFFFFU)
#define MC33775_FEH_ACC_ERR_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_ACC_ERR_POR_VAL \
  (0x0U)

/* Field ERRADD: Address of the last access which created an access error */
#define MC33775_FEH_ACC_ERR_ERRADD_POS \
  (0U)
#define MC33775_FEH_ACC_ERR_ERRADD_MSK \
  (0x3FFFU)

/* Field ERRACC: Access type of the last access error */
#define MC33775_FEH_ACC_ERR_ERRACC_POS \
  (14U)
#define MC33775_FEH_ACC_ERR_ERRACC_MSK \
  (0x4000U)

/* Enumerated value READ: Last error occurred during a read access */
#define MC33775_FEH_ACC_ERR_ERRACC_READ_ENUM_VAL \
  (0U)

/* Enumerated value WRITE: Last error occurred during a write access */
#define MC33775_FEH_ACC_ERR_ERRACC_WRITE_ENUM_VAL \
  (1U)

/* Field ERRSTAT: Access error status */
#define MC33775_FEH_ACC_ERR_ERRSTAT_POS \
  (15U)
#define MC33775_FEH_ACC_ERR_ERRSTAT_MSK \
  (0x8000U)

/* Enumerated value NO_ERROR: No error occurred */
#define MC33775_FEH_ACC_ERR_ERRSTAT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Access error has occurred */
#define MC33775_FEH_ACC_ERR_ERRSTAT_ERROR_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * FEH_GRP_FLT_STAT (read-only):Main system fault status register. this register holds one bit per fault group. For each fault group a separate status register exists. The bit here is cleared if all its sources are cleared.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_GRP_FLT_STAT_OFFSET \
  (0x41FU)
#define MC33775_FEH_GRP_FLT_STAT_RW_MSK \
  (0x0U)
#define MC33775_FEH_GRP_FLT_STAT_RD_MSK \
  (0xFU)
#define MC33775_FEH_GRP_FLT_STAT_WR_MSK \
  (0x0U)
#define MC33775_FEH_GRP_FLT_STAT_MW_MSK \
  (0x0U)
#define MC33775_FEH_GRP_FLT_STAT_RA_MSK \
  (0x0U)
#define MC33775_FEH_GRP_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_GRP_FLT_STAT_POR_VAL \
  (0x0U)

/* Field SUPPLYFLT: Internal/external supply fault status */
#define MC33775_FEH_GRP_FLT_STAT_SUPPLYFLT_POS \
  (0U)
#define MC33775_FEH_GRP_FLT_STAT_SUPPLYFLT_MSK \
  (0x1U)

/* Enumerated value NO_ERROR: No supply error detected */
#define MC33775_FEH_GRP_FLT_STAT_SUPPLYFLT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Supply error detected */
#define MC33775_FEH_GRP_FLT_STAT_SUPPLYFLT_ERROR_ENUM_VAL \
  (1U)

/* Field ANAFLT: Analog fault status */
#define MC33775_FEH_GRP_FLT_STAT_ANAFLT_POS \
  (1U)
#define MC33775_FEH_GRP_FLT_STAT_ANAFLT_MSK \
  (0x2U)

/* Enumerated value NO_ERROR: No analog fault detected */
#define MC33775_FEH_GRP_FLT_STAT_ANAFLT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Analog fault detected */
#define MC33775_FEH_GRP_FLT_STAT_ANAFLT_ERROR_ENUM_VAL \
  (1U)

/* Field COMFLT: Communication fault status */
#define MC33775_FEH_GRP_FLT_STAT_COMFLT_POS \
  (2U)
#define MC33775_FEH_GRP_FLT_STAT_COMFLT_MSK \
  (0x4U)

/* Enumerated value NO_ERROR: No communication fault detected */
#define MC33775_FEH_GRP_FLT_STAT_COMFLT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Communication fault detected. */
#define MC33775_FEH_GRP_FLT_STAT_COMFLT_ERROR_ENUM_VAL \
  (1U)

/* Field MEASFLT: Measurement fault status */
#define MC33775_FEH_GRP_FLT_STAT_MEASFLT_POS \
  (3U)
#define MC33775_FEH_GRP_FLT_STAT_MEASFLT_MSK \
  (0x8U)

/* Enumerated value NO_ERROR: No measurement fault detected */
#define MC33775_FEH_GRP_FLT_STAT_MEASFLT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Measurement fault detected */
#define MC33775_FEH_GRP_FLT_STAT_MEASFLT_ERROR_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_GRP_FLT_STAT_RESERVED0_POS \
  (4U)
#define MC33775_FEH_GRP_FLT_STAT_RESERVED0_MSK \
  (0xFFF0U)


/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_STAT0 (read-write):Supply fault status register 0 (these monitors are part of the BIST).
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_SUPPLY_FLT_STAT0_OFFSET \
  (0x420U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_RW_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_STAT0_RD_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_STAT0_WR_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_STAT0_MW_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_STAT0_RA_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_SUPPLY_FLT_STAT0_POR_VAL \
  (0x0U)

/* Field VBATOV: VBAT Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VBATOV_POS \
  (0U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VBATOV_MSK \
  (0x1U)

/* Enumerated value NO_OV: No VBAT Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VBATOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VBAT Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VBATOV_OV_ENUM_VAL \
  (1U)

/* Field VDDAOV: VDDA Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAOV_POS \
  (1U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAOV_MSK \
  (0x2U)

/* Enumerated value NO_OV: No VDDA Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VDDA Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAOV_OV_ENUM_VAL \
  (1U)

/* Field VDDAUV: VDDA Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAUV_POS \
  (2U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAUV_MSK \
  (0x4U)

/* Enumerated value NO_UV: No VDDA Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: VDDA Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDAUV_UV_ENUM_VAL \
  (1U)

/* Field V2P5AOV: V2P5A Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AOV_POS \
  (3U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AOV_MSK \
  (0x8U)

/* Enumerated value NO_OV: No V2P5A Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: V2P5A Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AOV_OV_ENUM_VAL \
  (1U)

/* Field V2P5AUV: V2P5A Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AUV_POS \
  (4U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AUV_MSK \
  (0x10U)

/* Enumerated value NO_UV: No V2P5A Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: V2P5A Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_V2P5AUV_UV_ENUM_VAL \
  (1U)

/* Field AFECPOV: AFE Charge Pump over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPOV_POS \
  (5U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPOV_MSK \
  (0x20U)

/* Enumerated value NO_OV: No AFE Charge Pump over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: AFE Charge Pump over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPOV_OV_ENUM_VAL \
  (1U)

/* Field AFECPUV: AFE Charge Pump under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPUV_POS \
  (6U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPUV_MSK \
  (0x40U)

/* Enumerated value NO_UV: No AFE Charge Pump under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: AFE Charge Pump under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_AFECPUV_UV_ENUM_VAL \
  (1U)

/* Field IBIASPERMOC: IBIAS_PERM over-current fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMOC_POS \
  (7U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMOC_MSK \
  (0x80U)

/* Enumerated value NO_OC: No IBIAS_PERM over-current detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMOC_NO_OC_ENUM_VAL \
  (0U)

/* Enumerated value OC: IBIAS_PERM over-current detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMOC_OC_ENUM_VAL \
  (1U)

/* Field IBIASPERMUC: IBIAS_PERM under-current fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMUC_POS \
  (8U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMUC_MSK \
  (0x100U)

/* Enumerated value NO_UC: No IBIAS_PERM under-current detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMUC_NO_UC_ENUM_VAL \
  (0U)

/* Enumerated value UC: IBIAS_PERM under-current detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_IBIASPERMUC_UC_ENUM_VAL \
  (1U)

/* Field VPREREFSUV: VPREREFS Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_POS \
  (9U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_MSK \
  (0x200U)

/* Enumerated value NO_UV: No VPREREFS Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: VPREREFS Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_UV_ENUM_VAL \
  (1U)

/* Field VAUXOV: VAUX Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXOV_POS \
  (10U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXOV_MSK \
  (0x400U)

/* Enumerated value NO_OV: No VAUX Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VAUX Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXOV_OV_ENUM_VAL \
  (1U)

/* Field VAUXUV: VAUX Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXUV_POS \
  (11U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXUV_MSK \
  (0x800U)

/* Enumerated value NO_UV: No VAUX Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: VAUX Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VAUXUV_UV_ENUM_VAL \
  (1U)

/* Field VDDCOV: VDDC Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCOV_POS \
  (12U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCOV_MSK \
  (0x1000U)

/* Enumerated value NO_OV: No VDDC Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VDDC Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCOV_OV_ENUM_VAL \
  (1U)

/* Field VDDCUV: VDDC Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCUV_POS \
  (13U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCUV_MSK \
  (0x2000U)

/* Enumerated value NO_UV: No VDDC Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: VDDC Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_VDDCUV_UV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_SUPPLY_FLT_STAT0_RESERVED0_POS \
  (14U)
#define MC33775_FEH_SUPPLY_FLT_STAT0_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_STAT1 (read-write):Supply fault status register 1 (these monitors are not part of the BIST).
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_SUPPLY_FLT_STAT1_OFFSET \
  (0x421U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_RW_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_STAT1_RD_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_STAT1_WR_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_STAT1_MW_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_STAT1_RA_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_SUPPLY_FLT_STAT1_POR_VAL \
  (0x0U)

/* Field VBATLV: VBAT Supply low-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VBATLV_POS \
  (0U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_VBATLV_MSK \
  (0x1U)

/* Enumerated value NO_LV: No VBAT Supply low-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VBATLV_NO_LV_ENUM_VAL \
  (0U)

/* Enumerated value LV: VBAT Supply low-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VBATLV_LV_ENUM_VAL \
  (1U)

/* Field VPREREFSOV: VPREREFS Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_POS \
  (1U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_MSK \
  (0x2U)

/* Enumerated value NO_OV: No VPREREFS Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VPREREFS Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_OV_ENUM_VAL \
  (1U)

/* Field VDDCHC: VDDC high-current fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDCHC_POS \
  (2U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDCHC_MSK \
  (0x4U)

/* Enumerated value NO_HC: No VDDC high-current detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDCHC_NO_HC_ENUM_VAL \
  (0U)

/* Enumerated value HC: VDDC high-current detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDCHC_HC_ENUM_VAL \
  (1U)

/* Field VDDIOOV: VDDIO Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOOV_POS \
  (3U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOOV_MSK \
  (0x8U)

/* Enumerated value NO_OV: No VDDIO Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VDDIO Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOOV_OV_ENUM_VAL \
  (1U)

/* Field VDDIOUV: VDDIO Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOUV_POS \
  (4U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOUV_MSK \
  (0x10U)

/* Enumerated value NO_UV: No VDDIO Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: VDDIO Supply under-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VDDIOUV_UV_ENUM_VAL \
  (1U)

/* Field VPREOV: VPRE Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREOV_POS \
  (5U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREOV_MSK \
  (0x20U)

/* Enumerated value NO_OV: No VPRE Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VPRE Supply over-voltage detected. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_VPREOV_OV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_SUPPLY_FLT_STAT1_RESERVED0_POS \
  (6U)
#define MC33775_FEH_SUPPLY_FLT_STAT1_RESERVED0_MSK \
  (0xFFC0U)


/* --------------------------------------------------------------------------
 * FEH_ANA_FLT_STAT (read-write):Analog fault status register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_ANA_FLT_STAT_OFFSET \
  (0x422U)
#define MC33775_FEH_ANA_FLT_STAT_RW_MSK \
  (0x7U)
#define MC33775_FEH_ANA_FLT_STAT_RD_MSK \
  (0x7U)
#define MC33775_FEH_ANA_FLT_STAT_WR_MSK \
  (0x7U)
#define MC33775_FEH_ANA_FLT_STAT_MW_MSK \
  (0x7U)
#define MC33775_FEH_ANA_FLT_STAT_RA_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_ANA_FLT_STAT_POR_VAL \
  (0x0U)

/* Field MONBIST: Monitor BIST failure fault. */
#define MC33775_FEH_ANA_FLT_STAT_MONBIST_POS \
  (0U)
#define MC33775_FEH_ANA_FLT_STAT_MONBIST_MSK \
  (0x1U)

/* Enumerated value NO_FLT: No monitor BIST failure detected. */
#define MC33775_FEH_ANA_FLT_STAT_MONBIST_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAILURE: Monitor BIST failure detected. */
#define MC33775_FEH_ANA_FLT_STAT_MONBIST_FAILURE_ENUM_VAL \
  (1U)

/* Field BALFLT: Cell balance function fault. */
#define MC33775_FEH_ANA_FLT_STAT_BALFLT_POS \
  (1U)
#define MC33775_FEH_ANA_FLT_STAT_BALFLT_MSK \
  (0x2U)

/* Enumerated value NO_FLT: No cell balancing fault detected */
#define MC33775_FEH_ANA_FLT_STAT_BALFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Cell balancing fault detected */
#define MC33775_FEH_ANA_FLT_STAT_BALFLT_FAULT_ENUM_VAL \
  (1U)

/* Field FUSEFLT: A correctable ECC error of the fuse data has been detected. */
#define MC33775_FEH_ANA_FLT_STAT_FUSEFLT_POS \
  (2U)
#define MC33775_FEH_ANA_FLT_STAT_FUSEFLT_MSK \
  (0x4U)

/* Enumerated value NO_ECC: No correctable ECC error detected */
#define MC33775_FEH_ANA_FLT_STAT_FUSEFLT_NO_ECC_ENUM_VAL \
  (0U)

/* Enumerated value ECC: An error was corrected by using the ECC */
#define MC33775_FEH_ANA_FLT_STAT_FUSEFLT_ECC_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_ANA_FLT_STAT_RESERVED0_POS \
  (3U)
#define MC33775_FEH_ANA_FLT_STAT_RESERVED0_MSK \
  (0xFFF8U)


/* --------------------------------------------------------------------------
 * FEH_COM_FLT_STAT (read-write):Communication fault status register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_COM_FLT_STAT_OFFSET \
  (0x423U)
#define MC33775_FEH_COM_FLT_STAT_RW_MSK \
  (0xFF1FU)
#define MC33775_FEH_COM_FLT_STAT_RD_MSK \
  (0xFF1FU)
#define MC33775_FEH_COM_FLT_STAT_WR_MSK \
  (0xFF1FU)
#define MC33775_FEH_COM_FLT_STAT_MW_MSK \
  (0xFF1FU)
#define MC33775_FEH_COM_FLT_STAT_RA_MSK \
  (0x0U)
#define MC33775_FEH_COM_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_COM_FLT_STAT_POR_VAL \
  (0x0U)

/* Field FRAMEERR: Communication frame error (Wrong number of bits or bit-length error) */
#define MC33775_FEH_COM_FLT_STAT_FRAMEERR_POS \
  (0U)
#define MC33775_FEH_COM_FLT_STAT_FRAMEERR_MSK \
  (0x1U)

/* Enumerated value NO_ERROR: No communication frame error detected. */
#define MC33775_FEH_COM_FLT_STAT_FRAMEERR_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Communication frame error detected. */
#define MC33775_FEH_COM_FLT_STAT_FRAMEERR_ERROR_ENUM_VAL \
  (1U)

/* Field CRCERR: Communication CRC error */
#define MC33775_FEH_COM_FLT_STAT_CRCERR_POS \
  (1U)
#define MC33775_FEH_COM_FLT_STAT_CRCERR_MSK \
  (0x2U)

/* Enumerated value NO_ERROR: No communication CRC error detected. */
#define MC33775_FEH_COM_FLT_STAT_CRCERR_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Communication CRC error detected. */
#define MC33775_FEH_COM_FLT_STAT_CRCERR_ERROR_ENUM_VAL \
  (1U)

/* Field ERRCNTOF: Communication error counter overflow */
#define MC33775_FEH_COM_FLT_STAT_ERRCNTOF_POS \
  (2U)
#define MC33775_FEH_COM_FLT_STAT_ERRCNTOF_MSK \
  (0x4U)

/* Enumerated value NO_MAX: Communication error counter has not reached max value. */
#define MC33775_FEH_COM_FLT_STAT_ERRCNTOF_NO_MAX_ENUM_VAL \
  (0U)

/* Enumerated value MAX: Communication error counter has reached max value. */
#define MC33775_FEH_COM_FLT_STAT_ERRCNTOF_MAX_ENUM_VAL \
  (1U)

/* Field COMTO: Communication timeout fault status */
#define MC33775_FEH_COM_FLT_STAT_COMTO_POS \
  (3U)
#define MC33775_FEH_COM_FLT_STAT_COMTO_MSK \
  (0x8U)

/* Enumerated value NO_TIMEOUT: No communication timeout has happened. */
#define MC33775_FEH_COM_FLT_STAT_COMTO_NO_TIMEOUT_ENUM_VAL \
  (0U)

/* Enumerated value TIMEMOUT: Communication timeout has happened. */
#define MC33775_FEH_COM_FLT_STAT_COMTO_TIMEMOUT_ENUM_VAL \
  (1U)

/* Field RSPLENERR: Response length error */
#define MC33775_FEH_COM_FLT_STAT_RSPLENERR_POS \
  (4U)
#define MC33775_FEH_COM_FLT_STAT_RSPLENERR_MSK \
  (0x10U)

/* Enumerated value NO_ERROR: No response length error occurred */
#define MC33775_FEH_COM_FLT_STAT_RSPLENERR_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: The number of SPI clocks did not fit to the length of a requested response */
#define MC33775_FEH_COM_FLT_STAT_RSPLENERR_ERROR_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_COM_FLT_STAT_RESERVED0_POS \
  (5U)
#define MC33775_FEH_COM_FLT_STAT_RESERVED0_MSK \
  (0xE0U)

/* Field COMERRCNT: Number of communication errors (frame errors, CRC errors) since last clear, counter saturates at 0xFF. Write with any data unequal 0 clears the counter. */
#define MC33775_FEH_COM_FLT_STAT_COMERRCNT_POS \
  (8U)
#define MC33775_FEH_COM_FLT_STAT_COMERRCNT_MSK \
  (0xFF00U)

/* Enumerated value NO_ERROR: No communication error occurred */
#define MC33775_FEH_COM_FLT_STAT_COMERRCNT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value CNT: CNT errors occurred */
#define MC33775_FEH_COM_FLT_STAT_COMERRCNT_CNT_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Maximum communication error counter = 255 communication errors occurred. */
#define MC33775_FEH_COM_FLT_STAT_COMERRCNT_MAX_ENUM_VAL \
  (255U)


/* --------------------------------------------------------------------------
 * FEH_MEAS_FLT_STAT (read-write):Other fault status register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_MEAS_FLT_STAT_OFFSET \
  (0x424U)
#define MC33775_FEH_MEAS_FLT_STAT_RW_MSK \
  (0x7U)
#define MC33775_FEH_MEAS_FLT_STAT_RD_MSK \
  (0x7U)
#define MC33775_FEH_MEAS_FLT_STAT_WR_MSK \
  (0x7U)
#define MC33775_FEH_MEAS_FLT_STAT_MW_MSK \
  (0x7U)
#define MC33775_FEH_MEAS_FLT_STAT_RA_MSK \
  (0x0U)
#define MC33775_FEH_MEAS_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_MEAS_FLT_STAT_POR_VAL \
  (0x0U)

/* Field PRIMCALCRCFLT: A fault in the primary measurement chain calibration data */
#define MC33775_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_POS \
  (0U)
#define MC33775_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_MSK \
  (0x1U)

/* Enumerated value NO_FLT: No fault in primary measurement chain calibration data detected. */
#define MC33775_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: A fault in the primary measurement chain calibration data has been detected. */
#define MC33775_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_FAULT_ENUM_VAL \
  (1U)

/* Field SECCALCCRCFLT: A fault in the secondary measurement chain calibration data */
#define MC33775_FEH_MEAS_FLT_STAT_SECCALCCRCFLT_POS \
  (1U)
#define MC33775_FEH_MEAS_FLT_STAT_SECCALCCRCFLT_MSK \
  (0x2U)

/* Enumerated value NO_FLT: No fault in secondary measurement chain calibration data detected. */
#define MC33775_FEH_MEAS_FLT_STAT_SECCALCCRCFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: A fault in the secondary measurement chain calibration data has been detected. */
#define MC33775_FEH_MEAS_FLT_STAT_SECCALCCRCFLT_FAULT_ENUM_VAL \
  (1U)

/* Field SYNCMEASFLT: Synchronization fault between the measurement units */
#define MC33775_FEH_MEAS_FLT_STAT_SYNCMEASFLT_POS \
  (2U)
#define MC33775_FEH_MEAS_FLT_STAT_SYNCMEASFLT_MSK \
  (0x4U)

/* Enumerated value NO_FLT: No synchronization fault between the measurement units for a Sync cycle has been detected.. */
#define MC33775_FEH_MEAS_FLT_STAT_SYNCMEASFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Synchronization fault between the measurement units for a Sync cycle has been detected.. */
#define MC33775_FEH_MEAS_FLT_STAT_SYNCMEASFLT_FAULT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_MEAS_FLT_STAT_RESERVED0_POS \
  (3U)
#define MC33775_FEH_MEAS_FLT_STAT_RESERVED0_MSK \
  (0xFFF8U)


/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_POR_CFG0 (read-write):Supply fault POR selection 0.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_OFFSET \
  (0x428U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_RW_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_RD_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_WR_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_MW_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_RA_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_POR_VAL \
  (0x0U)

/* Field VBATOVEN: POR on VBAT Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_POS \
  (0U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_MSK \
  (0x1U)

/* Enumerated value NO_POR: No POR in case of VBAT supply over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VBAT supply over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDAOVEN: POR on VDDA Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_POS \
  (1U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_MSK \
  (0x2U)

/* Enumerated value NO_POR: No POR in case of VDDA supply over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDA supply over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDAUVEN: POR on VDDA Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_POS \
  (2U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_MSK \
  (0x4U)

/* Enumerated value NO_POR: No POR in case of VDDA supply under-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDA supply under-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_POR_ENUM_VAL \
  (1U)

/* Field V2P5AOVEN: POR on V2P5A Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AOVEN_POS \
  (3U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AOVEN_MSK \
  (0x8U)

/* Enumerated value NO_POR: No POR in case of V2P5A supply over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: V2P5A supply over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AOVEN_POR_ENUM_VAL \
  (1U)

/* Field V2P5AUVEN: POR on V2P5A Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AUVEN_POS \
  (4U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AUVEN_MSK \
  (0x10U)

/* Enumerated value NO_POR: No POR in case of V2P5A supply under-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: V2P5A supply under-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AUVEN_POR_ENUM_VAL \
  (1U)

/* Field AFECPOVEN: POR on AFE Charge Pump over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_POS \
  (5U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_MSK \
  (0x20U)

/* Enumerated value NO_POR: No POR in case of AFE Charge Pump over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: AFE Charge Pump over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_POR_ENUM_VAL \
  (1U)

/* Field AFECPUVEN: POR on AFE Charge Pump under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_POS \
  (6U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_MSK \
  (0x40U)

/* Enumerated value NO_POR: No POR in case of AFE Charge Pump under-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: AFE Charge Pump under-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_POR_ENUM_VAL \
  (1U)

/* Field IBIASPERMOCEN: POR on IBIAS_PERM over-current fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMOCEN_POS \
  (7U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMOCEN_MSK \
  (0x80U)

/* Enumerated value NO_POR: No POR in case of IBIAS_PERM over-current */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMOCEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: IBIAS_PERM over-current error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMOCEN_POR_ENUM_VAL \
  (1U)

/* Field IBIASPERMUCEN: POR on IBIAS_PERM under-current fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMUCEN_POS \
  (8U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMUCEN_MSK \
  (0x100U)

/* Enumerated value NO_POR: No POR in case of IBIAS_PERM under-current */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMUCEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: IBIAS_PERM under-current error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMUCEN_POR_ENUM_VAL \
  (1U)

/* Field VPREREFSUVEN: POR on VPREREFS Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_POS \
  (9U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_MSK \
  (0x200U)

/* Enumerated value NO_POR: No POR in case of VPREREFS supply under-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VPREREFS supply under-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_POR_ENUM_VAL \
  (1U)

/* Field VAUXOVEN: POR on VAUX over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_POS \
  (10U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_MSK \
  (0x400U)

/* Enumerated value NO_POR: No POR in case of VAUX supply over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VAUX supply over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_POR_ENUM_VAL \
  (1U)

/* Field VAUXUVEN: POR on VAUX under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_POS \
  (11U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_MSK \
  (0x800U)

/* Enumerated value NO_POR: No POR in case of VAUX supply under-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VAUX supply under-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDCOVEN: POR on VDDC over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_POS \
  (12U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_MSK \
  (0x1000U)

/* Enumerated value NO_POR: No POR in case of VDDC over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDC over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDCUVEN: POR on VDDC under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_POS \
  (13U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_MSK \
  (0x2000U)

/* Enumerated value NO_POR: No POR in case of VDDC under-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDC under-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_POR_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_RESERVED0_POS \
  (14U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG0_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_POR_CFG1 (read-write):Supply fault POR selection 1.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_OFFSET \
  (0x429U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_RW_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_RD_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_WR_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_MW_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_RA_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_POR_VAL \
  (0x0U)

/* Field VBATLVEN: POR on VBAT Supply low-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_POS \
  (0U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_MSK \
  (0x1U)

/* Enumerated value NO_POR: No POR in case of VBAT supply low-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VBAT supply low-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_POR_ENUM_VAL \
  (1U)

/* Field VPREREFSOVEN: POR on VPREREFS Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_POS \
  (1U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_MSK \
  (0x2U)

/* Enumerated value NO_POR: No POR in case of VPREREFS over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VPREREFS over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDCHCEN: POR on VDDC high-current fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_POS \
  (2U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_MSK \
  (0x4U)

/* Enumerated value NO_POR: No POR in case of VDDC high-current */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDC high-current error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_POR_ENUM_VAL \
  (1U)

/* Field VDDIOOVEN: POR on VDDIO Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_POS \
  (3U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_MSK \
  (0x8U)

/* Enumerated value NO_POR: No POR in case of VDDIO supply over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDIO supply over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDIOUVEN: POR on VDDIO Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_POS \
  (4U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_MSK \
  (0x10U)

/* Enumerated value NO_POR: No POR in case of VDDIO supply under-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDIO supply under-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_POR_ENUM_VAL \
  (1U)

/* Field VPREOVEN: POR on VPRE Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_POS \
  (5U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_MSK \
  (0x20U)

/* Enumerated value NO_POR: No POR in case of VPRE over-voltage */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VPRE over-voltage error leads to POR */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_POR_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_RESERVED0_POS \
  (6U)
#define MC33775_FEH_SUPPLY_FLT_POR_CFG1_RESERVED0_MSK \
  (0xFFC0U)


/* --------------------------------------------------------------------------
 * FEH_ANA_FLT_POR_CFG (read-only):Analog fault POR selection.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_ANA_FLT_POR_CFG_OFFSET \
  (0x42AU)
#define MC33775_FEH_ANA_FLT_POR_CFG_RW_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_POR_CFG_RD_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_POR_CFG_WR_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_POR_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_POR_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_POR_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_ANA_FLT_POR_CFG_POR_VAL \
  (0x0U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_ANA_FLT_POR_CFG_RESERVED0_POS \
  (0U)
#define MC33775_FEH_ANA_FLT_POR_CFG_RESERVED0_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * FEH_COM_FLT_POR_CFG (read-write):Communication fault POR enable register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_COM_FLT_POR_CFG_OFFSET \
  (0x42BU)
#define MC33775_FEH_COM_FLT_POR_CFG_RW_MSK \
  (0xCU)
#define MC33775_FEH_COM_FLT_POR_CFG_RD_MSK \
  (0xCU)
#define MC33775_FEH_COM_FLT_POR_CFG_WR_MSK \
  (0xCU)
#define MC33775_FEH_COM_FLT_POR_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_COM_FLT_POR_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_COM_FLT_POR_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_COM_FLT_POR_CFG_POR_VAL \
  (0x8U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_COM_FLT_POR_CFG_RESERVED0_POS \
  (0U)
#define MC33775_FEH_COM_FLT_POR_CFG_RESERVED0_MSK \
  (0x3U)

/* Field ERRCNTOFEN: Communication error counter max value leads to POR */
#define MC33775_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_POS \
  (2U)
#define MC33775_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_MSK \
  (0x4U)

/* Enumerated value NO_POR: Communication error counter has reached max value. */
#define MC33775_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: Communication error counter max value leads to POR */
#define MC33775_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_POR_ENUM_VAL \
  (1U)

/* Field COMTOEN: Create a POR if a communication timeout happens. */
#define MC33775_FEH_COM_FLT_POR_CFG_COMTOEN_POS \
  (3U)
#define MC33775_FEH_COM_FLT_POR_CFG_COMTOEN_MSK \
  (0x8U)

/* Enumerated value PREV_MOD: Device fallbacks to prev. Mode in case of communication timeout */
#define MC33775_FEH_COM_FLT_POR_CFG_COMTOEN_PREV_MOD_ENUM_VAL \
  (0U)

/* Enumerated value POR: POR in case of communication timeout */
#define MC33775_FEH_COM_FLT_POR_CFG_COMTOEN_POR_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_COM_FLT_POR_CFG_RESERVED1_POS \
  (4U)
#define MC33775_FEH_COM_FLT_POR_CFG_RESERVED1_MSK \
  (0xFFF0U)


/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_EVT_CFG0 (read-write):Supply fault event selection register 0.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_OFFSET \
  (0x430U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_RW_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_RD_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_WR_MSK \
  (0x3FFFU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_MW_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_RA_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_POR_VAL \
  (0x0U)

/* Field VBATOVEN: Event on VBAT Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_POS \
  (0U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_MSK \
  (0x1U)

/* Enumerated value NO_EV: No event on VBAT Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VBAT Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDAOVEN: Event on VDDA Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_POS \
  (1U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_MSK \
  (0x2U)

/* Enumerated value NO_EV: No event on VDDA Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDA Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDAUVEN: Event on VDDA Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_POS \
  (2U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_MSK \
  (0x4U)

/* Enumerated value NO_EV: No event on VDDA Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDA Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field V2P5AOVEN: Event on V2P5A Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AOVEN_POS \
  (3U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AOVEN_MSK \
  (0x8U)

/* Enumerated value NO_EV: No event on V2P5A Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on V2P5A Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field V2P5AUVEN: Event on V2P5A Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AUVEN_POS \
  (4U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AUVEN_MSK \
  (0x10U)

/* Enumerated value NO_EV: No event on V2P5A Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on V2P5A Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field AFECPOVEN: Event on AFE Charge Pump over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_POS \
  (5U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_MSK \
  (0x20U)

/* Enumerated value NO_EV: No event on AFE Charge Pump over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on AFE Charge Pump over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field AFECPUVEN: Event on AFE Charge Pump under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_POS \
  (6U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_MSK \
  (0x40U)

/* Enumerated value NO_EV: No event on AFE Charge Pump under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on AFE Charge Pump under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field IBIASPERMOCEN: Event on IBIAS_PERM over-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMOCEN_POS \
  (7U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMOCEN_MSK \
  (0x80U)

/* Enumerated value NO_EV: No event on IBIAS_PERM over-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMOCEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on IBIAS_PERM over-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMOCEN_EVENT_ENUM_VAL \
  (1U)

/* Field IBIASPERMUCEN: Event on IBIAS_PERM under-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMUCEN_POS \
  (8U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMUCEN_MSK \
  (0x100U)

/* Enumerated value NO_EV: No event on IBIAS_PERM under-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMUCEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on IBIAS_PERM under-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMUCEN_EVENT_ENUM_VAL \
  (1U)

/* Field VPREREFSUVEN: Event on VPREREFS Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_POS \
  (9U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_MSK \
  (0x200U)

/* Enumerated value NO_EV: No event on VPREREFS Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VPREREFS Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VAUXOVEN: Event on VAUX over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_POS \
  (10U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_MSK \
  (0x400U)

/* Enumerated value NO_EV: No event on VAUX over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VAUX over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VAUXUVEN: Event on VAUX under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_POS \
  (11U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_MSK \
  (0x800U)

/* Enumerated value NO_EV: No event on VAUX under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VAUX under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDCOVEN: Event on VDDC over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_POS \
  (12U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_MSK \
  (0x1000U)

/* Enumerated value NO_EV: No event on VDDC over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDC over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDCUVEN: Event on VDDC under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_POS \
  (13U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_MSK \
  (0x2000U)

/* Enumerated value NO_EV: No event on VDDC under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDC under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_RESERVED0_POS \
  (14U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG0_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_EVT_CFG1 (read-write):Supply fault event selection register 1.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_OFFSET \
  (0x431U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_RW_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_RD_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_WR_MSK \
  (0x3FU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_MW_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_RA_MSK \
  (0x0U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_POR_VAL \
  (0x0U)

/* Field VBATLVEN: Event on VBAT Supply low-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_POS \
  (0U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_MSK \
  (0x1U)

/* Enumerated value NO_EV: No event on VBAT Supply low-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VBAT Supply low-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VPREREFSOVEN: Event on VPREREFS Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_POS \
  (1U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_MSK \
  (0x2U)

/* Enumerated value NO_EV: No event on VPREREFS Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VPREREFS Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDCHCEN: Event on VDDC high-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_POS \
  (2U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_MSK \
  (0x4U)

/* Enumerated value NO_EV: No event on VDDC high-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDC high-current fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDIOOVEN: Event on VDDIO Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_POS \
  (3U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_MSK \
  (0x8U)

/* Enumerated value NO_EV: No event on VDDIO Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDIO Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDIOUVEN: Event on VDDIO Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_POS \
  (4U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_MSK \
  (0x10U)

/* Enumerated value NO_EV: No event on VDDIO Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDIO Supply under-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VPREOVEN: Event on VPRE Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_POS \
  (5U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_MSK \
  (0x20U)

/* Enumerated value NO_EV: No event on VPRE Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VPRE Supply over-voltage fault. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_RESERVED0_POS \
  (6U)
#define MC33775_FEH_SUPPLY_FLT_EVT_CFG1_RESERVED0_MSK \
  (0xFFC0U)


/* --------------------------------------------------------------------------
 * FEH_ANA_FLT_EVT_CFG (read-write):Analog fault event enable register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_ANA_FLT_EVT_CFG_OFFSET \
  (0x432U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_RW_MSK \
  (0x7U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_RD_MSK \
  (0x7U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_WR_MSK \
  (0x7U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_ANA_FLT_EVT_CFG_POR_VAL \
  (0x0U)

/* Field MONBISTEN: Event on Monitor BIST fault. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_MONBISTEN_POS \
  (0U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_MONBISTEN_MSK \
  (0x1U)

/* Enumerated value NO_EV: No event on Monitor BIST fault. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_MONBISTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on Monitor BIST fault. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_MONBISTEN_EVENT_ENUM_VAL \
  (1U)

/* Field BALFLTEN: Event on cell balance function fault. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_BALFLTEN_POS \
  (1U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_BALFLTEN_MSK \
  (0x2U)

/* Enumerated value NO_EV: No event on cell balance function fault. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_BALFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on cell balance function fault. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_BALFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field FUSEFLTEN: Event on a corrected bit error in the fuse data has been detected. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_POS \
  (2U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_MSK \
  (0x4U)

/* Enumerated value NO_EV: No event on a corrected bit error in the fuse data has been detected. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on a corrected bit error in the fuse data has been detected. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_ANA_FLT_EVT_CFG_RESERVED0_POS \
  (3U)
#define MC33775_FEH_ANA_FLT_EVT_CFG_RESERVED0_MSK \
  (0xFFF8U)


/* --------------------------------------------------------------------------
 * FEH_COM_FLT_EVT_CFG (read-write):Communication fault event enable register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_COM_FLT_EVT_CFG_OFFSET \
  (0x433U)
#define MC33775_FEH_COM_FLT_EVT_CFG_RW_MSK \
  (0x17U)
#define MC33775_FEH_COM_FLT_EVT_CFG_RD_MSK \
  (0x17U)
#define MC33775_FEH_COM_FLT_EVT_CFG_WR_MSK \
  (0x17U)
#define MC33775_FEH_COM_FLT_EVT_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_COM_FLT_EVT_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_COM_FLT_EVT_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_COM_FLT_EVT_CFG_POR_VAL \
  (0x0U)

/* Field FRAMEERREN: Event on communication error detected. Wrong number of bits, bit-length error. */
#define MC33775_FEH_COM_FLT_EVT_CFG_FRAMEERREN_POS \
  (0U)
#define MC33775_FEH_COM_FLT_EVT_CFG_FRAMEERREN_MSK \
  (0x1U)

/* Enumerated value NO_EV: No event on communication error detected. */
#define MC33775_FEH_COM_FLT_EVT_CFG_FRAMEERREN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on communication error detected. */
#define MC33775_FEH_COM_FLT_EVT_CFG_FRAMEERREN_EVENT_ENUM_VAL \
  (1U)

/* Field CRCERREN: Event on communication CRC error detected. */
#define MC33775_FEH_COM_FLT_EVT_CFG_CRCERREN_POS \
  (1U)
#define MC33775_FEH_COM_FLT_EVT_CFG_CRCERREN_MSK \
  (0x2U)

/* Enumerated value NO_EV: No event on communication CRC error detected. */
#define MC33775_FEH_COM_FLT_EVT_CFG_CRCERREN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on communication CRC error detected. */
#define MC33775_FEH_COM_FLT_EVT_CFG_CRCERREN_EVENT_ENUM_VAL \
  (1U)

/* Field ERRCNTOFEN: Event on communication error counter has reached max value. */
#define MC33775_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_POS \
  (2U)
#define MC33775_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_MSK \
  (0x4U)

/* Enumerated value NO_EV: No event on communication error counter has reached max value. */
#define MC33775_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on communication error counter has reached max value. */
#define MC33775_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_COM_FLT_EVT_CFG_RESERVED0_POS \
  (3U)
#define MC33775_FEH_COM_FLT_EVT_CFG_RESERVED0_MSK \
  (0x8U)

/* Field RSPLENERREN: Event on number of SPI clocks did not fit to the length of a requested response */
#define MC33775_FEH_COM_FLT_EVT_CFG_RSPLENERREN_POS \
  (4U)
#define MC33775_FEH_COM_FLT_EVT_CFG_RSPLENERREN_MSK \
  (0x10U)

/* Enumerated value NO_EV: No event on number of SPI clocks did not fit to the length of a requested response */
#define MC33775_FEH_COM_FLT_EVT_CFG_RSPLENERREN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on number of SPI clocks did not fit to the length of a requested response */
#define MC33775_FEH_COM_FLT_EVT_CFG_RSPLENERREN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_COM_FLT_EVT_CFG_RESERVED1_POS \
  (5U)
#define MC33775_FEH_COM_FLT_EVT_CFG_RESERVED1_MSK \
  (0xFFE0U)


/* --------------------------------------------------------------------------
 * FEH_MEAS_FLT_EVT_CFG (read-write):Measurement fault event enable register.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_OFFSET \
  (0x434U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_RW_MSK \
  (0x7U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_RD_MSK \
  (0x7U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_WR_MSK \
  (0x7U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_MW_MSK \
  (0x0U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_RA_MSK \
  (0x0U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_POR_VAL \
  (0x0U)

/* Field PRIMCALCRCFLTEN: Event on primary calibration CRC fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_POS \
  (0U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_MSK \
  (0x1U)

/* Enumerated value NO_EV: No event on primary calibration CRC fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on primary calibration CRC fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field SECCALCRCFLTEN: Event on secondary calibration CRC fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_POS \
  (1U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_MSK \
  (0x2U)

/* Enumerated value NO_EV: No event on secondary calibration CRC fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on secondary calibration CRC fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field SYNCMEASFLTEN: Event on synchronization fault between the measurement units for a Sync cycle. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_POS \
  (2U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_MSK \
  (0x4U)

/* Enumerated value NO_EV: No event on synchronization fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on synchronization fault. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_MEAS_FLT_EVT_CFG_RESERVED0_POS \
  (3U)
#define MC33775_FEH_MEAS_FLT_EVT_CFG_RESERVED0_MSK \
  (0xFFF8U)


/* --------------------------------------------------------------------------
 * FEH_POR_REASON (read-only):Last power on reset reason. The value is stored in the ULP domain.
 * -------------------------------------------------------------------------- */
#define MC33775_FEH_POR_REASON_OFFSET \
  (0x480U)
#define MC33775_FEH_POR_REASON_RW_MSK \
  (0x0U)
#define MC33775_FEH_POR_REASON_RD_MSK \
  (0x3FFU)
#define MC33775_FEH_POR_REASON_WR_MSK \
  (0x0U)
#define MC33775_FEH_POR_REASON_MW_MSK \
  (0x0U)
#define MC33775_FEH_POR_REASON_RA_MSK \
  (0x0U)
#define MC33775_FEH_POR_REASON_POR_MSK \
  (0xFFFFU)
#define MC33775_FEH_POR_REASON_POR_VAL \
  (0x0U)

/* Field SOURCE: Reason for last POR: Binary coded and protected by an EDC. */
#define MC33775_FEH_POR_REASON_SOURCE_POS \
  (0U)
#define MC33775_FEH_POR_REASON_SOURCE_MSK \
  (0x3FFU)

/* Enumerated value VDDDLPPERMUV: POR caused by VDDDLPPERMUV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDDLPPERMUV_ENUM_VAL \
  (0U)

/* Enumerated value VDDDLPUV: POR caused by VDDDLPUV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDDLPUV_ENUM_VAL \
  (15U)

/* Enumerated value RESET: POR caused by RESET (In Deep Sleep, previous reason is kept) */
#define MC33775_FEH_POR_REASON_SOURCE_RESET_ENUM_VAL \
  (65U)

/* Enumerated value VDDDUV: POR caused by VDDDUV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDDUV_ENUM_VAL \
  (78U)

/* Enumerated value VBATLV: POR caused by VBATLV */
#define MC33775_FEH_POR_REASON_SOURCE_VBATLV_ENUM_VAL \
  (131U)

/* Enumerated value VDDIOUV: POR caused by VDDIOUV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDIOUV_ENUM_VAL \
  (140U)

/* Enumerated value SWRESET: POR caused by software Deep Sleep request */
#define MC33775_FEH_POR_REASON_SOURCE_SWRESET_ENUM_VAL \
  (191U)

/* Enumerated value VBATOV: POR caused by VBATOV */
#define MC33775_FEH_POR_REASON_SOURCE_VBATOV_ENUM_VAL \
  (194U)

/* Enumerated value VDDDOV: POR caused by VDDDOV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDDOV_ENUM_VAL \
  (205U)

/* Enumerated value VDDCOV: POR caused by VDDCOV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDCOV_ENUM_VAL \
  (261U)

/* Enumerated value VAUXUV: POR caused by VAUXUV */
#define MC33775_FEH_POR_REASON_SOURCE_VAUXUV_ENUM_VAL \
  (266U)

/* Enumerated value VBATUV: POR caused by VBATUV */
#define MC33775_FEH_POR_REASON_SOURCE_VBATUV_ENUM_VAL \
  (324U)

/* Enumerated value VDDIOOV: POR caused by VDDIOOV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDIOOV_ENUM_VAL \
  (331U)

/* Enumerated value VDDCUV: POR caused by VDDCUV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDCUV_ENUM_VAL \
  (390U)

/* Enumerated value VAUXOV: POR caused by VAUXOV */
#define MC33775_FEH_POR_REASON_SOURCE_VAUXOV_ENUM_VAL \
  (393U)

/* Enumerated value VDDCOC: POR caused by VDDCOC */
#define MC33775_FEH_POR_REASON_SOURCE_VDDCOC_ENUM_VAL \
  (455U)

/* Enumerated value VDDCHC: POR caused by VDDCHC */
#define MC33775_FEH_POR_REASON_SOURCE_VDDCHC_ENUM_VAL \
  (456U)

/* Enumerated value VDDAUV: POR caused by VDDAUV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDAUV_ENUM_VAL \
  (529U)

/* Enumerated value SLEEPOSC: POR caused by SLEEPOSC */
#define MC33775_FEH_POR_REASON_SOURCE_SLEEPOSC_ENUM_VAL \
  (542U)

/* Enumerated value VDDAOV: POR caused by VDDAOV */
#define MC33775_FEH_POR_REASON_SOURCE_VDDAOV_ENUM_VAL \
  (592U)

/* Enumerated value COMTO: POR caused by COMTO */
#define MC33775_FEH_POR_REASON_SOURCE_COMTO_ENUM_VAL \
  (607U)

/* Enumerated value VPREOV: POR caused by VPREOV */
#define MC33775_FEH_POR_REASON_SOURCE_VPREOV_ENUM_VAL \
  (658U)

/* Enumerated value SECCLK: POR caused by SECCLK */
#define MC33775_FEH_POR_REASON_SOURCE_SECCLK_ENUM_VAL \
  (669U)

/* Enumerated value LOGICERR: POR caused by LOGICERR */
#define MC33775_FEH_POR_REASON_SOURCE_LOGICERR_ENUM_VAL \
  (673U)

/* Enumerated value VPREREFSOV: POR caused by VPREREFSOV */
#define MC33775_FEH_POR_REASON_SOURCE_VPREREFSOV_ENUM_VAL \
  (723U)

/* Enumerated value PRMCLK: POR caused by PRMCLK */
#define MC33775_FEH_POR_REASON_SOURCE_PRMCLK_ENUM_VAL \
  (732U)

/* Enumerated value COMERRORS: POR caused by COMERRORS */
#define MC33775_FEH_POR_REASON_SOURCE_COMERRORS_ENUM_VAL \
  (736U)

/* Enumerated value VPREREFSUV: POR caused by VPREREFSUV */
#define MC33775_FEH_POR_REASON_SOURCE_VPREREFSUV_ENUM_VAL \
  (788U)

/* Enumerated value OTEMPSHUTDOWN: POR caused by OTEMPSHUTDOWN */
#define MC33775_FEH_POR_REASON_SOURCE_OTEMPSHUTDOWN_ENUM_VAL \
  (795U)

/* Enumerated value V2P5AOV: POR caused by V2P5AOV */
#define MC33775_FEH_POR_REASON_SOURCE_V2P5AOV_ENUM_VAL \
  (853U)

/* Enumerated value IBIASPERMUC: POR caused by IBIASPERMUC */
#define MC33775_FEH_POR_REASON_SOURCE_IBIASPERMUC_ENUM_VAL \
  (858U)

/* Enumerated value AFECPOV: POR caused by AFECPOV */
#define MC33775_FEH_POR_REASON_SOURCE_AFECPOV_ENUM_VAL \
  (919U)

/* Enumerated value AFECPUV: POR caused by AFECPUV */
#define MC33775_FEH_POR_REASON_SOURCE_AFECPUV_ENUM_VAL \
  (920U)

/* Enumerated value V2P5AUV: POR caused by V2P5AUV */
#define MC33775_FEH_POR_REASON_SOURCE_V2P5AUV_ENUM_VAL \
  (982U)

/* Enumerated value IBIASPERMOC: POR caused by IBIASPERMOC */
#define MC33775_FEH_POR_REASON_SOURCE_IBIASPERMOC_ENUM_VAL \
  (985U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_FEH_POR_REASON_RESERVED0_POS \
  (10U)
#define MC33775_FEH_POR_REASON_RESERVED0_MSK \
  (0xFC00U)


/* --------------------------------------------------------------------------
 * GPIO_CFG0 (read-write):GPIO configuration 0
 * -------------------------------------------------------------------------- */
#define MC33775_GPIO_CFG0_OFFSET \
  (0x800U)
#define MC33775_GPIO_CFG0_RW_MSK \
  (0xFFFFU)
#define MC33775_GPIO_CFG0_RD_MSK \
  (0xFFFFU)
#define MC33775_GPIO_CFG0_WR_MSK \
  (0xFFFFU)
#define MC33775_GPIO_CFG0_MW_MSK \
  (0x0U)
#define MC33775_GPIO_CFG0_RA_MSK \
  (0x0U)
#define MC33775_GPIO_CFG0_POR_MSK \
  (0xFFFFU)
#define MC33775_GPIO_CFG0_POR_VAL \
  (0x0U)

/* Field INPEN0: Enable the input for GPIO0. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN0_POS \
  (0U)
#define MC33775_GPIO_CFG0_INPEN0_MSK \
  (0x1U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN0_ENABLED_ENUM_VAL \
  (1U)

/* Field INPEN1: Enable the input for GPIO1. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN1_POS \
  (1U)
#define MC33775_GPIO_CFG0_INPEN1_MSK \
  (0x2U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN1_ENABLED_ENUM_VAL \
  (1U)

/* Field INPEN2: Enable the input for GPIO2. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN2_POS \
  (2U)
#define MC33775_GPIO_CFG0_INPEN2_MSK \
  (0x4U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN2_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN2_ENABLED_ENUM_VAL \
  (1U)

/* Field INPEN3: Enable the input for GPIO3. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN3_POS \
  (3U)
#define MC33775_GPIO_CFG0_INPEN3_MSK \
  (0x8U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN3_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN3_ENABLED_ENUM_VAL \
  (1U)

/* Field INPEN4: Enable the input for GPIO4. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN4_POS \
  (4U)
#define MC33775_GPIO_CFG0_INPEN4_MSK \
  (0x10U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN4_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN4_ENABLED_ENUM_VAL \
  (1U)

/* Field INPEN5: Enable the input for GPIO5. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN5_POS \
  (5U)
#define MC33775_GPIO_CFG0_INPEN5_MSK \
  (0x20U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN5_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN5_ENABLED_ENUM_VAL \
  (1U)

/* Field INPEN6: Enable the input for GPIO6. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN6_POS \
  (6U)
#define MC33775_GPIO_CFG0_INPEN6_MSK \
  (0x40U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN6_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN6_ENABLED_ENUM_VAL \
  (1U)

/* Field INPEN7: Enable the input for GPIO7. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33775_GPIO_CFG0_INPEN7_POS \
  (7U)
#define MC33775_GPIO_CFG0_INPEN7_MSK \
  (0x80U)

/* Enumerated value DISABLED: Input is disabled */
#define MC33775_GPIO_CFG0_INPEN7_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33775_GPIO_CFG0_INPEN7_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN0: Enable the output of the GPIO0. */
#define MC33775_GPIO_CFG0_OUTEN0_POS \
  (8U)
#define MC33775_GPIO_CFG0_OUTEN0_MSK \
  (0x100U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN0_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN1: Enable the output of the GPIO1. */
#define MC33775_GPIO_CFG0_OUTEN1_POS \
  (9U)
#define MC33775_GPIO_CFG0_OUTEN1_MSK \
  (0x200U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN1_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN2: Enable the output of the GPIO2. */
#define MC33775_GPIO_CFG0_OUTEN2_POS \
  (10U)
#define MC33775_GPIO_CFG0_OUTEN2_MSK \
  (0x400U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN2_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN2_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN3: Enable the output of the GPIO3. */
#define MC33775_GPIO_CFG0_OUTEN3_POS \
  (11U)
#define MC33775_GPIO_CFG0_OUTEN3_MSK \
  (0x800U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN3_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN3_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN4: Enable the output of the GPIO4. */
#define MC33775_GPIO_CFG0_OUTEN4_POS \
  (12U)
#define MC33775_GPIO_CFG0_OUTEN4_MSK \
  (0x1000U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN4_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN4_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN5: Enable the output of the GPIO5. */
#define MC33775_GPIO_CFG0_OUTEN5_POS \
  (13U)
#define MC33775_GPIO_CFG0_OUTEN5_MSK \
  (0x2000U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN5_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN5_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN6: Enable the output of the GPIO6. */
#define MC33775_GPIO_CFG0_OUTEN6_POS \
  (14U)
#define MC33775_GPIO_CFG0_OUTEN6_MSK \
  (0x4000U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN6_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN6_ENABLED_ENUM_VAL \
  (1U)

/* Field OUTEN7: Enable the output of the GPIO7. */
#define MC33775_GPIO_CFG0_OUTEN7_POS \
  (15U)
#define MC33775_GPIO_CFG0_OUTEN7_MSK \
  (0x8000U)

/* Enumerated value DISABLED: Output is disabled */
#define MC33775_GPIO_CFG0_OUTEN7_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Output is enabled */
#define MC33775_GPIO_CFG0_OUTEN7_ENABLED_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * GPIO_CFG1 (read-write):GPIO configuration 1
 * -------------------------------------------------------------------------- */
#define MC33775_GPIO_CFG1_OFFSET \
  (0x801U)
#define MC33775_GPIO_CFG1_RW_MSK \
  (0xFFU)
#define MC33775_GPIO_CFG1_RD_MSK \
  (0xFFU)
#define MC33775_GPIO_CFG1_WR_MSK \
  (0xFFU)
#define MC33775_GPIO_CFG1_MW_MSK \
  (0x0U)
#define MC33775_GPIO_CFG1_RA_MSK \
  (0x0U)
#define MC33775_GPIO_CFG1_POR_MSK \
  (0xFFFFU)
#define MC33775_GPIO_CFG1_POR_VAL \
  (0x0U)

/* Field ODEN0: Open Drain enable, GPIO0. */
#define MC33775_GPIO_CFG1_ODEN0_POS \
  (0U)
#define MC33775_GPIO_CFG1_ODEN0_MSK \
  (0x1U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN0_ENABLED_ENUM_VAL \
  (1U)

/* Field ODEN1: Open Drain enable, GPIO1. */
#define MC33775_GPIO_CFG1_ODEN1_POS \
  (1U)
#define MC33775_GPIO_CFG1_ODEN1_MSK \
  (0x2U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN1_ENABLED_ENUM_VAL \
  (1U)

/* Field ODEN2: Open Drain enable, GPIO2. */
#define MC33775_GPIO_CFG1_ODEN2_POS \
  (2U)
#define MC33775_GPIO_CFG1_ODEN2_MSK \
  (0x4U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN2_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN2_ENABLED_ENUM_VAL \
  (1U)

/* Field ODEN3: Open Drain enable, GPIO3. */
#define MC33775_GPIO_CFG1_ODEN3_POS \
  (3U)
#define MC33775_GPIO_CFG1_ODEN3_MSK \
  (0x8U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN3_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN3_ENABLED_ENUM_VAL \
  (1U)

/* Field ODEN4: Open Drain enable, GPIO4. */
#define MC33775_GPIO_CFG1_ODEN4_POS \
  (4U)
#define MC33775_GPIO_CFG1_ODEN4_MSK \
  (0x10U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN4_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN4_ENABLED_ENUM_VAL \
  (1U)

/* Field ODEN5: Open Drain enable, GPIO5. */
#define MC33775_GPIO_CFG1_ODEN5_POS \
  (5U)
#define MC33775_GPIO_CFG1_ODEN5_MSK \
  (0x20U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN5_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN5_ENABLED_ENUM_VAL \
  (1U)

/* Field ODEN6: Open Drain enable, GPIO6. */
#define MC33775_GPIO_CFG1_ODEN6_POS \
  (6U)
#define MC33775_GPIO_CFG1_ODEN6_MSK \
  (0x40U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN6_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN6_ENABLED_ENUM_VAL \
  (1U)

/* Field ODEN7: Open Drain enable, GPIO7. */
#define MC33775_GPIO_CFG1_ODEN7_POS \
  (7U)
#define MC33775_GPIO_CFG1_ODEN7_MSK \
  (0x80U)

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33775_GPIO_CFG1_ODEN7_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33775_GPIO_CFG1_ODEN7_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_GPIO_CFG1_RESERVED0_POS \
  (8U)
#define MC33775_GPIO_CFG1_RESERVED0_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * GPIO_OUT (read-write):GPIO output
 * -------------------------------------------------------------------------- */
#define MC33775_GPIO_OUT_OFFSET \
  (0x802U)
#define MC33775_GPIO_OUT_RW_MSK \
  (0xFFU)
#define MC33775_GPIO_OUT_RD_MSK \
  (0xFFU)
#define MC33775_GPIO_OUT_WR_MSK \
  (0xFFU)
#define MC33775_GPIO_OUT_MW_MSK \
  (0x0U)
#define MC33775_GPIO_OUT_RA_MSK \
  (0x0U)
#define MC33775_GPIO_OUT_POR_MSK \
  (0xFFFFU)
#define MC33775_GPIO_OUT_POR_VAL \
  (0x0U)

/* Field OUT0: Set the output level of the gpio function for GPIO0. */
#define MC33775_GPIO_OUT_OUT0_POS \
  (0U)
#define MC33775_GPIO_OUT_OUT0_MSK \
  (0x1U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT0_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT0_HIGH_ENUM_VAL \
  (1U)

/* Field OUT1: Set the output level of the gpio function for GPIO1. */
#define MC33775_GPIO_OUT_OUT1_POS \
  (1U)
#define MC33775_GPIO_OUT_OUT1_MSK \
  (0x2U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT1_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT1_HIGH_ENUM_VAL \
  (1U)

/* Field OUT2: Set the output level of the gpio function for GPIO2. */
#define MC33775_GPIO_OUT_OUT2_POS \
  (2U)
#define MC33775_GPIO_OUT_OUT2_MSK \
  (0x4U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT2_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT2_HIGH_ENUM_VAL \
  (1U)

/* Field OUT3: Set the output level of the gpio function for GPIO3. */
#define MC33775_GPIO_OUT_OUT3_POS \
  (3U)
#define MC33775_GPIO_OUT_OUT3_MSK \
  (0x8U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT3_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT3_HIGH_ENUM_VAL \
  (1U)

/* Field OUT4: Set the output level of the gpio function for GPIO4. */
#define MC33775_GPIO_OUT_OUT4_POS \
  (4U)
#define MC33775_GPIO_OUT_OUT4_MSK \
  (0x10U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT4_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT4_HIGH_ENUM_VAL \
  (1U)

/* Field OUT5: Set the output level of the gpio function for GPIO5. */
#define MC33775_GPIO_OUT_OUT5_POS \
  (5U)
#define MC33775_GPIO_OUT_OUT5_MSK \
  (0x20U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT5_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT5_HIGH_ENUM_VAL \
  (1U)

/* Field OUT6: Set the output level of the gpio function for GPIO6. */
#define MC33775_GPIO_OUT_OUT6_POS \
  (6U)
#define MC33775_GPIO_OUT_OUT6_MSK \
  (0x40U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT6_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT6_HIGH_ENUM_VAL \
  (1U)

/* Field OUT7: Set the output level of the gpio function for GPIO7. */
#define MC33775_GPIO_OUT_OUT7_POS \
  (7U)
#define MC33775_GPIO_OUT_OUT7_MSK \
  (0x80U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_OUT_OUT7_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_OUT_OUT7_HIGH_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_GPIO_OUT_RESERVED0_POS \
  (8U)
#define MC33775_GPIO_OUT_RESERVED0_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * GPIO_IN (read-only):GPIO input
 * -------------------------------------------------------------------------- */
#define MC33775_GPIO_IN_OFFSET \
  (0x804U)
#define MC33775_GPIO_IN_RW_MSK \
  (0x0U)
#define MC33775_GPIO_IN_RD_MSK \
  (0xFFFFU)
#define MC33775_GPIO_IN_WR_MSK \
  (0x0U)
#define MC33775_GPIO_IN_MW_MSK \
  (0x0U)
#define MC33775_GPIO_IN_RA_MSK \
  (0xFF00U)
#define MC33775_GPIO_IN_POR_MSK \
  (0xFFFFU)
#define MC33775_GPIO_IN_POR_VAL \
  (0x0U)

/* Field IN0: Read the level of the gpio function of GPIO0. */
#define MC33775_GPIO_IN_IN0_POS \
  (0U)
#define MC33775_GPIO_IN_IN0_MSK \
  (0x1U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN0_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN0_HIGH_ENUM_VAL \
  (1U)

/* Field IN1: Read the level of the gpio function of GPIO1. */
#define MC33775_GPIO_IN_IN1_POS \
  (1U)
#define MC33775_GPIO_IN_IN1_MSK \
  (0x2U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN1_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN1_HIGH_ENUM_VAL \
  (1U)

/* Field IN2: Read the level of the gpio function of GPIO2. */
#define MC33775_GPIO_IN_IN2_POS \
  (2U)
#define MC33775_GPIO_IN_IN2_MSK \
  (0x4U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN2_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN2_HIGH_ENUM_VAL \
  (1U)

/* Field IN3: Read the level of the gpio function of GPIO3. */
#define MC33775_GPIO_IN_IN3_POS \
  (3U)
#define MC33775_GPIO_IN_IN3_MSK \
  (0x8U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN3_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN3_HIGH_ENUM_VAL \
  (1U)

/* Field IN4: Read the level of the gpio function of GPIO4. */
#define MC33775_GPIO_IN_IN4_POS \
  (4U)
#define MC33775_GPIO_IN_IN4_MSK \
  (0x10U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN4_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN4_HIGH_ENUM_VAL \
  (1U)

/* Field IN5: Read the level of the gpio function of GPIO5. */
#define MC33775_GPIO_IN_IN5_POS \
  (5U)
#define MC33775_GPIO_IN_IN5_MSK \
  (0x20U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN5_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN5_HIGH_ENUM_VAL \
  (1U)

/* Field IN6: Read the level of the gpio function of GPIO6. */
#define MC33775_GPIO_IN_IN6_POS \
  (6U)
#define MC33775_GPIO_IN_IN6_MSK \
  (0x40U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN6_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN6_HIGH_ENUM_VAL \
  (1U)

/* Field IN7: Read the level of the gpio function of GPIO7. */
#define MC33775_GPIO_IN_IN7_POS \
  (7U)
#define MC33775_GPIO_IN_IN7_MSK \
  (0x80U)

/* Enumerated value LOW: GPIO is low */
#define MC33775_GPIO_IN_IN7_LOW_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33775_GPIO_IN_IN7_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET0: High value on GPIO0. */
#define MC33775_GPIO_IN_HIGHDET0_POS \
  (8U)
#define MC33775_GPIO_IN_HIGHDET0_MSK \
  (0x100U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET0_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET0_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET1: High value on GPIO1. */
#define MC33775_GPIO_IN_HIGHDET1_POS \
  (9U)
#define MC33775_GPIO_IN_HIGHDET1_MSK \
  (0x200U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET1_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET1_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET2: High value on GPIO2. */
#define MC33775_GPIO_IN_HIGHDET2_POS \
  (10U)
#define MC33775_GPIO_IN_HIGHDET2_MSK \
  (0x400U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET2_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET2_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET3: High value on GPIO3. */
#define MC33775_GPIO_IN_HIGHDET3_POS \
  (11U)
#define MC33775_GPIO_IN_HIGHDET3_MSK \
  (0x800U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET3_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET3_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET4: High value on GPIO4. */
#define MC33775_GPIO_IN_HIGHDET4_POS \
  (12U)
#define MC33775_GPIO_IN_HIGHDET4_MSK \
  (0x1000U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET4_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET4_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET5: High value on GPIO5. */
#define MC33775_GPIO_IN_HIGHDET5_POS \
  (13U)
#define MC33775_GPIO_IN_HIGHDET5_MSK \
  (0x2000U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET5_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET5_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET6: High value on GPIO6. */
#define MC33775_GPIO_IN_HIGHDET6_POS \
  (14U)
#define MC33775_GPIO_IN_HIGHDET6_MSK \
  (0x4000U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET6_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET6_HIGH_ENUM_VAL \
  (1U)

/* Field HIGHDET7: High value on GPIO7. */
#define MC33775_GPIO_IN_HIGHDET7_POS \
  (15U)
#define MC33775_GPIO_IN_HIGHDET7_MSK \
  (0x8000U)

/* Enumerated value NO_HIGH: No high level observed */
#define MC33775_GPIO_IN_HIGHDET7_NO_HIGH_ENUM_VAL \
  (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33775_GPIO_IN_HIGHDET7_HIGH_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * I2C_CFG (read-write):I2C configuration
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_CFG_OFFSET \
  (0xC00U)
#define MC33775_I2C_CFG_RW_MSK \
  (0x3U)
#define MC33775_I2C_CFG_RD_MSK \
  (0x3U)
#define MC33775_I2C_CFG_WR_MSK \
  (0x3U)
#define MC33775_I2C_CFG_MW_MSK \
  (0x0U)
#define MC33775_I2C_CFG_RA_MSK \
  (0x0U)
#define MC33775_I2C_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_CFG_POR_VAL \
  (0x0U)

/* Field EN: Enable I2C interface. If the I2C interface is disabled while it is active, a stop condition is created and the bus is released. When enabling this bit the GPIO to which the I2C lines are connected are switched to the I2C function (input receiver active and open-drain output function). */
#define MC33775_I2C_CFG_EN_POS \
  (0U)
#define MC33775_I2C_CFG_EN_MSK \
  (0x1U)

/* Enumerated value DISABLED: I2C interface disabled */
#define MC33775_I2C_CFG_EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: I2C interface enabled */
#define MC33775_I2C_CFG_EN_ENABLED_ENUM_VAL \
  (1U)

/* Field CLKSEL: I2C clock selection */
#define MC33775_I2C_CFG_CLKSEL_POS \
  (1U)
#define MC33775_I2C_CFG_CLKSEL_MSK \
  (0x2U)

/* Enumerated value F_100k: I2C clock is 100 kHz */
#define MC33775_I2C_CFG_CLKSEL_F_100K_ENUM_VAL \
  (0U)

/* Enumerated value F_400k: I2C clock is 400 kHz */
#define MC33775_I2C_CFG_CLKSEL_F_400K_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_I2C_CFG_RESERVED0_POS \
  (2U)
#define MC33775_I2C_CFG_RESERVED0_MSK \
  (0xFFFCU)


/* --------------------------------------------------------------------------
 * I2C_CTRL (read-write):I2C control
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_CTRL_OFFSET \
  (0xC01U)
#define MC33775_I2C_CTRL_RW_MSK \
  (0xF1FU)
#define MC33775_I2C_CTRL_RD_MSK \
  (0xF1FU)
#define MC33775_I2C_CTRL_WR_MSK \
  (0xF1FU)
#define MC33775_I2C_CTRL_MW_MSK \
  (0x0U)
#define MC33775_I2C_CTRL_RA_MSK \
  (0x0U)
#define MC33775_I2C_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_CTRL_POR_VAL \
  (0x0U)

/* Field START: Start the I2C transmission, by setting the number of bytes (including Dev. Address to be transmitted/read) */
#define MC33775_I2C_CTRL_START_POS \
  (0U)
#define MC33775_I2C_CTRL_START_MSK \
  (0xFU)

/* Enumerated value SEND_1: Send one byte */
#define MC33775_I2C_CTRL_START_SEND_1_ENUM_VAL \
  (1U)

/* Enumerated value SEND_14: Send 14 bytes */
#define MC33775_I2C_CTRL_START_SEND_14_ENUM_VAL \
  (14U)

/* Enumerated value SEND_MAX: Send 14 bytes */
#define MC33775_I2C_CTRL_START_SEND_MAX_ENUM_VAL \
  (15U)

/* Field STPAFTER: Send a stop condition after the last byte. */
#define MC33775_I2C_CTRL_STPAFTER_POS \
  (4U)
#define MC33775_I2C_CTRL_STPAFTER_MSK \
  (0x10U)

/* Enumerated value NO_STOP: No stop condition sent after last byte */
#define MC33775_I2C_CTRL_STPAFTER_NO_STOP_ENUM_VAL \
  (0U)

/* Enumerated value STOP: Stop condition sent after last byte */
#define MC33775_I2C_CTRL_STPAFTER_STOP_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_I2C_CTRL_RESERVED0_POS \
  (5U)
#define MC33775_I2C_CTRL_RESERVED0_MSK \
  (0xE0U)

/* Field RDAFTER: Switch to read (Repeated Start Condition after byte) 0 = off */
#define MC33775_I2C_CTRL_RDAFTER_POS \
  (8U)
#define MC33775_I2C_CTRL_RDAFTER_MSK \
  (0xF00U)

/* Enumerated value NO_READ: No switch to read. */
#define MC33775_I2C_CTRL_RDAFTER_NO_READ_ENUM_VAL \
  (0U)

/* Enumerated value READ_1: Switch to read after 1 byte */
#define MC33775_I2C_CTRL_RDAFTER_READ_1_ENUM_VAL \
  (1U)

/* Enumerated value READ_14: Switch to read after 14 bytes */
#define MC33775_I2C_CTRL_RDAFTER_READ_14_ENUM_VAL \
  (14U)

/* Enumerated value RESERVED: Reserved. Do not use. */
#define MC33775_I2C_CTRL_RDAFTER_RESERVED_ENUM_VAL \
  (15U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_I2C_CTRL_RESERVED1_POS \
  (12U)
#define MC33775_I2C_CTRL_RESERVED1_MSK \
  (0xF000U)


/* --------------------------------------------------------------------------
 * I2C_STAT (read-only):I2C status
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_STAT_OFFSET \
  (0xC02U)
#define MC33775_I2C_STAT_RW_MSK \
  (0x0U)
#define MC33775_I2C_STAT_RD_MSK \
  (0xF0FU)
#define MC33775_I2C_STAT_WR_MSK \
  (0x0U)
#define MC33775_I2C_STAT_MW_MSK \
  (0x0U)
#define MC33775_I2C_STAT_RA_MSK \
  (0x0U)
#define MC33775_I2C_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_STAT_POR_VAL \
  (0x0U)

/* Field PENDING: I2C execution pending */
#define MC33775_I2C_STAT_PENDING_POS \
  (0U)
#define MC33775_I2C_STAT_PENDING_MSK \
  (0x1U)

/* Enumerated value NO_TRX: No transfer is in execution, data registers can be accessed */
#define MC33775_I2C_STAT_PENDING_NO_TRX_ENUM_VAL \
  (0U)

/* Enumerated value TRX: A transfer is in execution, no access to the data registers is allowed */
#define MC33775_I2C_STAT_PENDING_TRX_ENUM_VAL \
  (1U)

/* Field ACTIVE: I2C transmission active */
#define MC33775_I2C_STAT_ACTIVE_POS \
  (1U)
#define MC33775_I2C_STAT_ACTIVE_MSK \
  (0x2U)

/* Enumerated value NO_TRX: No transaction is ongoing. */
#define MC33775_I2C_STAT_ACTIVE_NO_TRX_ENUM_VAL \
  (0U)

/* Enumerated value TRX: A transaction is ongoing (no STOP condition so far), bus is held with SCL low */
#define MC33775_I2C_STAT_ACTIVE_TRX_ENUM_VAL \
  (1U)

/* Field NACKRCV: NACK received */
#define MC33775_I2C_STAT_NACKRCV_POS \
  (2U)
#define MC33775_I2C_STAT_NACKRCV_MSK \
  (0x4U)

/* Enumerated value NO_NACK: No NACK was received */
#define MC33775_I2C_STAT_NACKRCV_NO_NACK_ENUM_VAL \
  (0U)

/* Enumerated value NACK: A NACK was received */
#define MC33775_I2C_STAT_NACKRCV_NACK_ENUM_VAL \
  (1U)

/* Field ARBLOST: Wrong data bit */
#define MC33775_I2C_STAT_ARBLOST_POS \
  (3U)
#define MC33775_I2C_STAT_ARBLOST_MSK \
  (0x8U)

/* Enumerated value NO_FLT: No wrong data bits detected */
#define MC33775_I2C_STAT_ARBLOST_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: A wrong data bit was detected */
#define MC33775_I2C_STAT_ARBLOST_FAULT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_I2C_STAT_RESERVED0_POS \
  (4U)
#define MC33775_I2C_STAT_RESERVED0_MSK \
  (0xF0U)

/* Field LEN: number of bytes transferred until NACK received */
#define MC33775_I2C_STAT_LEN_POS \
  (8U)
#define MC33775_I2C_STAT_LEN_MSK \
  (0xF00U)

/* Enumerated value NACK_0: No bytes transmitted until NACK was received */
#define MC33775_I2C_STAT_LEN_NACK_0_ENUM_VAL \
  (0U)

/* Enumerated value NACK_1: 1 byte transmitted until NACK was received */
#define MC33775_I2C_STAT_LEN_NACK_1_ENUM_VAL \
  (1U)

/* Enumerated value NACK_14: 14 bytes transmitted until NACK was received */
#define MC33775_I2C_STAT_LEN_NACK_14_ENUM_VAL \
  (14U)

/* Enumerated value RESERVED: Reserved. Not used. */
#define MC33775_I2C_STAT_LEN_RESERVED_ENUM_VAL \
  (15U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_I2C_STAT_RESERVED1_POS \
  (12U)
#define MC33775_I2C_STAT_RESERVED1_MSK \
  (0xF000U)


/* --------------------------------------------------------------------------
 * I2C_DATA0 (read-write):I2C data register 0
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_DATA0_OFFSET \
  (0xC04U)
#define MC33775_I2C_DATA0_RW_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA0_RD_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA0_WR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA0_MW_MSK \
  (0x0U)
#define MC33775_I2C_DATA0_RA_MSK \
  (0x0U)
#define MC33775_I2C_DATA0_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA0_POR_VAL \
  (0x0U)

/* Field BYTE0: I2C data byte 0 (e.g. device address) */
#define MC33775_I2C_DATA0_BYTE0_POS \
  (0U)
#define MC33775_I2C_DATA0_BYTE0_MSK \
  (0xFFU)

/* Field BYTE1: I2C data byte 1 (e.g. data or sub address) */
#define MC33775_I2C_DATA0_BYTE1_POS \
  (8U)
#define MC33775_I2C_DATA0_BYTE1_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * I2C_DATA1 (read-write):I2C data register 1
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_DATA1_OFFSET \
  (0xC05U)
#define MC33775_I2C_DATA1_RW_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA1_RD_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA1_WR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA1_MW_MSK \
  (0x0U)
#define MC33775_I2C_DATA1_RA_MSK \
  (0x0U)
#define MC33775_I2C_DATA1_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA1_POR_VAL \
  (0x0U)

/* Field BYTE2: I2C data byte 2 */
#define MC33775_I2C_DATA1_BYTE2_POS \
  (0U)
#define MC33775_I2C_DATA1_BYTE2_MSK \
  (0xFFU)

/* Field BYTE3: I2C data byte 3 */
#define MC33775_I2C_DATA1_BYTE3_POS \
  (8U)
#define MC33775_I2C_DATA1_BYTE3_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * I2C_DATA2 (read-write):I2C data register 2
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_DATA2_OFFSET \
  (0xC06U)
#define MC33775_I2C_DATA2_RW_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA2_RD_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA2_WR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA2_MW_MSK \
  (0x0U)
#define MC33775_I2C_DATA2_RA_MSK \
  (0x0U)
#define MC33775_I2C_DATA2_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA2_POR_VAL \
  (0x0U)

/* Field BYTE4: I2C data byte 4 */
#define MC33775_I2C_DATA2_BYTE4_POS \
  (0U)
#define MC33775_I2C_DATA2_BYTE4_MSK \
  (0xFFU)

/* Field BYTE5: I2C data byte 5 */
#define MC33775_I2C_DATA2_BYTE5_POS \
  (8U)
#define MC33775_I2C_DATA2_BYTE5_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * I2C_DATA3 (read-write):I2C data register 3
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_DATA3_OFFSET \
  (0xC07U)
#define MC33775_I2C_DATA3_RW_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA3_RD_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA3_WR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA3_MW_MSK \
  (0x0U)
#define MC33775_I2C_DATA3_RA_MSK \
  (0x0U)
#define MC33775_I2C_DATA3_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA3_POR_VAL \
  (0x0U)

/* Field BYTE6: I2C data byte 6 */
#define MC33775_I2C_DATA3_BYTE6_POS \
  (0U)
#define MC33775_I2C_DATA3_BYTE6_MSK \
  (0xFFU)

/* Field BYTE7: I2C data byte 7 */
#define MC33775_I2C_DATA3_BYTE7_POS \
  (8U)
#define MC33775_I2C_DATA3_BYTE7_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * I2C_DATA4 (read-write):I2C data register 4
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_DATA4_OFFSET \
  (0xC08U)
#define MC33775_I2C_DATA4_RW_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA4_RD_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA4_WR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA4_MW_MSK \
  (0x0U)
#define MC33775_I2C_DATA4_RA_MSK \
  (0x0U)
#define MC33775_I2C_DATA4_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA4_POR_VAL \
  (0x0U)

/* Field BYTE8: I2C data byte 8 */
#define MC33775_I2C_DATA4_BYTE8_POS \
  (0U)
#define MC33775_I2C_DATA4_BYTE8_MSK \
  (0xFFU)

/* Field BYTE9: I2C data byte 9 */
#define MC33775_I2C_DATA4_BYTE9_POS \
  (8U)
#define MC33775_I2C_DATA4_BYTE9_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * I2C_DATA5 (read-write):I2C data register 5
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_DATA5_OFFSET \
  (0xC09U)
#define MC33775_I2C_DATA5_RW_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA5_RD_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA5_WR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA5_MW_MSK \
  (0x0U)
#define MC33775_I2C_DATA5_RA_MSK \
  (0x0U)
#define MC33775_I2C_DATA5_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA5_POR_VAL \
  (0x0U)

/* Field BYTE10: I2C data byte 10 */
#define MC33775_I2C_DATA5_BYTE10_POS \
  (0U)
#define MC33775_I2C_DATA5_BYTE10_MSK \
  (0xFFU)

/* Field BYTE11: I2C data byte 11 */
#define MC33775_I2C_DATA5_BYTE11_POS \
  (8U)
#define MC33775_I2C_DATA5_BYTE11_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * I2C_DATA6 (read-write):I2C data register 6
 * -------------------------------------------------------------------------- */
#define MC33775_I2C_DATA6_OFFSET \
  (0xC0AU)
#define MC33775_I2C_DATA6_RW_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA6_RD_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA6_WR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA6_MW_MSK \
  (0x0U)
#define MC33775_I2C_DATA6_RA_MSK \
  (0x0U)
#define MC33775_I2C_DATA6_POR_MSK \
  (0xFFFFU)
#define MC33775_I2C_DATA6_POR_VAL \
  (0x0U)

/* Field BYTE12: I2C data byte 12 */
#define MC33775_I2C_DATA6_BYTE12_POS \
  (0U)
#define MC33775_I2C_DATA6_BYTE12_MSK \
  (0xFFU)

/* Field BYTE13: I2C data byte 13 */
#define MC33775_I2C_DATA6_BYTE13_POS \
  (8U)
#define MC33775_I2C_DATA6_BYTE13_MSK \
  (0xFF00U)


/* --------------------------------------------------------------------------
 * PRMM_CFG (read-write):General measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_CFG_OFFSET \
  (0x1800U)
#define MC33775_PRMM_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CFG_POR_VAL \
  (0x0U)

/* Field MEASEN: Enable the data acquisition. Setting this bit to zero initiates a result clear and invalidate action (this includes resetting all ready bits). The bit can only be set xxx us after it has been cleared. This bit is cleared when entering Sleep mode. Cyclic measurements are always executed, regardless of the value of this bit. Balancing is not stopped automatically (if in Active mode), as it would be permanently inhibited while measurement is active. If balancing shall be paused, please do so via the balancing control. */
#define MC33775_PRMM_CFG_MEASEN_POS \
  (0U)
#define MC33775_PRMM_CFG_MEASEN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Data acquisition disabled */
#define MC33775_PRMM_CFG_MEASEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Data acquisition enabled */
#define MC33775_PRMM_CFG_MEASEN_ENABLED_ENUM_VAL \
  (1U)

/* Field BALPAUSECYCMODEN: Enable balancing autopause. This delays the start of measurements after entering Cyclic mode until the autopause counter has elapsed. */
#define MC33775_PRMM_CFG_BALPAUSECYCMODEN_POS \
  (1U)
#define MC33775_PRMM_CFG_BALPAUSECYCMODEN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Autopause for balancing is disabled. */
#define MC33775_PRMM_CFG_BALPAUSECYCMODEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Autopause for balancing is enabled. Measurements are started when the autopause counter is elapsed. */
#define MC33775_PRMM_CFG_BALPAUSECYCMODEN_ENABLED_ENUM_VAL \
  (1U)

/* Field BALPAUSELEN: Pause of balancing before measurement cycle is executed. An on-going balancing pause operation is not influenced by a change of this value. 1 LSB = 10us. */
#define MC33775_PRMM_CFG_BALPAUSELEN_POS \
  (2U)
#define MC33775_PRMM_CFG_BALPAUSELEN_MSK \
  (0xFFFCU)

/* Enumerated value NO_PAUSE: No Pause. */
#define MC33775_PRMM_CFG_BALPAUSELEN_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE_10u: Pause = 10 us */
#define MC33775_PRMM_CFG_BALPAUSELEN_PAUSE_10U_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Maximum pause = 163830 us = 163 ms */
#define MC33775_PRMM_CFG_BALPAUSELEN_MAX_ENUM_VAL \
  (16383U)


/* --------------------------------------------------------------------------
 * PRMM_APP_CTRL (read-write):Application measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_CTRL_OFFSET \
  (0x1801U)
#define MC33775_PRMM_APP_CTRL_RW_MSK \
  (0x7C00U)
#define MC33775_PRMM_APP_CTRL_RD_MSK \
  (0x7C00U)
#define MC33775_PRMM_APP_CTRL_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_CTRL_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_CTRL_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_CTRL_POR_VAL \
  (0x7C00U)

/* Field CAPVC: Capture the application measurement values of the cell terminal measurements. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33775_PRMM_APP_CTRL_CAPVC_POS \
  (0U)
#define MC33775_PRMM_APP_CTRL_CAPVC_MSK \
  (0x1U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPVC_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPVC_CAP_ENUM_VAL \
  (1U)

/* Field CAPVMODULE: Capture the application measurement value of the module voltage measurement. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33775_PRMM_APP_CTRL_CAPVMODULE_POS \
  (1U)
#define MC33775_PRMM_APP_CTRL_CAPVMODULE_MSK \
  (0x2U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPVMODULE_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPVMODULE_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN0: Capture the application measurement value of the aux0 terminal measurement. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33775_PRMM_APP_CTRL_CAPAIN0_POS \
  (2U)
#define MC33775_PRMM_APP_CTRL_CAPAIN0_MSK \
  (0x4U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN0_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN0_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN1: Capture the application measurement value of the aux1 terminal measurement. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33775_PRMM_APP_CTRL_CAPAIN1_POS \
  (3U)
#define MC33775_PRMM_APP_CTRL_CAPAIN1_MSK \
  (0x8U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN1_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN1_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN2: Capture the application measurement value of the aux2 terminal measurement. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33775_PRMM_APP_CTRL_CAPAIN2_POS \
  (4U)
#define MC33775_PRMM_APP_CTRL_CAPAIN2_MSK \
  (0x10U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN2_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN2_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN3: Capture the application measurement value of the aux3 terminal measurement. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33775_PRMM_APP_CTRL_CAPAIN3_POS \
  (5U)
#define MC33775_PRMM_APP_CTRL_CAPAIN3_MSK \
  (0x20U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN3_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN3_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN4: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In secondary: Capture the application measurement value of the aux4 terminal measurement. */
#define MC33775_PRMM_APP_CTRL_CAPAIN4_POS \
  (6U)
#define MC33775_PRMM_APP_CTRL_CAPAIN4_MSK \
  (0x40U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN4_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN4_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN5: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the aux5 terminal measurement. */
#define MC33775_PRMM_APP_CTRL_CAPAIN5_POS \
  (7U)
#define MC33775_PRMM_APP_CTRL_CAPAIN5_MSK \
  (0x80U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN5_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN5_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN6: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the aux6 terminal measurement. */
#define MC33775_PRMM_APP_CTRL_CAPAIN6_POS \
  (8U)
#define MC33775_PRMM_APP_CTRL_CAPAIN6_MSK \
  (0x100U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN6_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN6_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN7: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the aux7 terminal measurement. */
#define MC33775_PRMM_APP_CTRL_CAPAIN7_POS \
  (9U)
#define MC33775_PRMM_APP_CTRL_CAPAIN7_MSK \
  (0x200U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN7_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_PRMM_APP_CTRL_CAPAIN7_CAP_ENUM_VAL \
  (1U)

/* Field VCOLNUM: VC channel for which the open load detection is enabled. 0 - 13 = channel for which the open load detection is enabled. 14 - 30 = reserved (no open load detection mechanism is enabled). Writing this bitfield is only possible if CAPVC is set as well. */
#define MC33775_PRMM_APP_CTRL_VCOLNUM_POS \
  (10U)
#define MC33775_PRMM_APP_CTRL_VCOLNUM_MSK \
  (0x7C00U)

/* Enumerated value DISABLED: Open load detection is disabled */
#define MC33775_PRMM_APP_CTRL_VCOLNUM_DISABLED_ENUM_VAL \
  (31U)

/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the autopause timer has elapsed. If no CAPxxx is set this bit is ignored. */
#define MC33775_PRMM_APP_CTRL_PAUSEBAL_POS \
  (15U)
#define MC33775_PRMM_APP_CTRL_PAUSEBAL_MSK \
  (0x8000U)

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33775_PRMM_APP_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33775_PRMM_APP_CTRL_PAUSEBAL_PAUSE_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * PRMM_PER_CTRL (read-write):Periodic measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_CTRL_OFFSET \
  (0x1802U)
#define MC33775_PRMM_PER_CTRL_RW_MSK \
  (0x11FFU)
#define MC33775_PRMM_PER_CTRL_RD_MSK \
  (0x11FFU)
#define MC33775_PRMM_PER_CTRL_WR_MSK \
  (0x11FFU)
#define MC33775_PRMM_PER_CTRL_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_CTRL_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_CTRL_POR_VAL \
  (0x10U)

/* Field PERLEN: Number of measurements for one periodic measurement. The minimum is 16. Writing a value lower than 16 leads to a 16 in the register. */
#define MC33775_PRMM_PER_CTRL_PERLEN_POS \
  (0U)
#define MC33775_PRMM_PER_CTRL_PERLEN_MSK \
  (0x1FFU)

/* Enumerated value PER_16: minimum value = 16 measurements per period */
#define MC33775_PRMM_PER_CTRL_PERLEN_PER_16_ENUM_VAL \
  (16U)

/* Enumerated value PER_17: 17 measurements per period */
#define MC33775_PRMM_PER_CTRL_PERLEN_PER_17_ENUM_VAL \
  (17U)

/* Enumerated value PER_MAX: maximum value = 511 measurements per period */
#define MC33775_PRMM_PER_CTRL_PERLEN_PER_MAX_ENUM_VAL \
  (511U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_PER_CTRL_RESERVED0_POS \
  (9U)
#define MC33775_PRMM_PER_CTRL_RESERVED0_MSK \
  (0xE00U)

/* Field PERCTRL: Control the periodic result behavior. */
#define MC33775_PRMM_PER_CTRL_PERCTRL_POS \
  (12U)
#define MC33775_PRMM_PER_CTRL_PERCTRL_MSK \
  (0x1000U)

/* Enumerated value AUTO: Periodic results are automatically updated */
#define MC33775_PRMM_PER_CTRL_PERCTRL_AUTO_ENUM_VAL \
  (0U)

/* Enumerated value ONCE: Periodic results are updated once with the last results. (each write updates the results). */
#define MC33775_PRMM_PER_CTRL_PERCTRL_ONCE_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_PER_CTRL_RESERVED1_POS \
  (13U)
#define MC33775_PRMM_PER_CTRL_RESERVED1_MSK \
  (0xE000U)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_CTRL (write-only):Synchronous measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_CTRL_OFFSET \
  (0x1803U)
#define MC33775_PRMM_SYNC_CTRL_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_CTRL_RD_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_CTRL_WR_MSK \
  (0x8003U)
#define MC33775_PRMM_SYNC_CTRL_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_CTRL_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_CTRL_POR_VAL \
  (0x0U)

/* Field SYNCCYC: Start a synchronous measurement cycle. In this cycle the CT and CB voltages are measured and stored as matching pairs. If no VC channel is enabled or if set during a running synchronous measurement cycle the set is ignored. Read as zero. */
#define MC33775_PRMM_SYNC_CTRL_SYNCCYC_POS \
  (0U)
#define MC33775_PRMM_SYNC_CTRL_SYNCCYC_MSK \
  (0x1U)

/* Enumerated value NO_START: No new start a synchronous measurement cycle. */
#define MC33775_PRMM_SYNC_CTRL_SYNCCYC_NO_START_ENUM_VAL \
  (0U)

/* Enumerated value STATUS: Read a zero */
#define MC33775_PRMM_SYNC_CTRL_SYNCCYC_STATUS_ENUM_VAL \
  (0U)

/* Enumerated value START: Start a synchronous measurement cycle. */
#define MC33775_PRMM_SYNC_CTRL_SYNCCYC_START_ENUM_VAL \
  (1U)

/* Field FASTCYC: Start of a dummy Fast measurement cycle. In this cycle nothing is actually measured and stored. The bit is only implemented to keep the balancing autopause synchronous between primary and secondary measurement. If set together with SYNCCYC or during an active synchronous measurement cycle, this bit is ignored. Read as zero. */
#define MC33775_PRMM_SYNC_CTRL_FASTCYC_POS \
  (1U)
#define MC33775_PRMM_SYNC_CTRL_FASTCYC_MSK \
  (0x2U)

/* Enumerated value NO_FAST: No new start of a dummy fast measurement cycle. */
#define MC33775_PRMM_SYNC_CTRL_FASTCYC_NO_FAST_ENUM_VAL \
  (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33775_PRMM_SYNC_CTRL_FASTCYC_STATUS_ENUM_VAL \
  (0U)

/* Enumerated value FAST: Start a new dummy fast measurement cycle. */
#define MC33775_PRMM_SYNC_CTRL_FASTCYC_FAST_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_SYNC_CTRL_RESERVED0_POS \
  (2U)
#define MC33775_PRMM_SYNC_CTRL_RESERVED0_MSK \
  (0x7FFCU)

/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the autopause timer has elapsed. If no capture cycle is started this bit is ignored. */
#define MC33775_PRMM_SYNC_CTRL_PAUSEBAL_POS \
  (15U)
#define MC33775_PRMM_SYNC_CTRL_PAUSEBAL_MSK \
  (0x8000U)

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33775_PRMM_SYNC_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33775_PRMM_SYNC_CTRL_PAUSEBAL_PAUSE_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * PRMM_VC_CFG (read-write):Cell voltage measurement enable.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_CFG_OFFSET \
  (0x1808U)
#define MC33775_PRMM_VC_CFG_RW_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_CFG_RD_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_CFG_WR_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_VC_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_CFG_POR_VAL \
  (0x0U)

/* Field VC0EN: Enable measurement of cell voltage 0. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC0EN_POS \
  (0U)
#define MC33775_PRMM_VC_CFG_VC0EN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC0EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC0EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC1EN: Enable measurement of cell voltage 1. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC1EN_POS \
  (1U)
#define MC33775_PRMM_VC_CFG_VC1EN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC1EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC1EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC2EN: Enable measurement of cell voltage 2. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC2EN_POS \
  (2U)
#define MC33775_PRMM_VC_CFG_VC2EN_MSK \
  (0x4U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC2EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC2EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC3EN: Enable measurement of cell voltage 3. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC3EN_POS \
  (3U)
#define MC33775_PRMM_VC_CFG_VC3EN_MSK \
  (0x8U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC3EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC3EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC4EN: Enable measurement of cell voltage 4. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC4EN_POS \
  (4U)
#define MC33775_PRMM_VC_CFG_VC4EN_MSK \
  (0x10U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC4EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC4EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC5EN: Enable measurement of cell voltage 5. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC5EN_POS \
  (5U)
#define MC33775_PRMM_VC_CFG_VC5EN_MSK \
  (0x20U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC5EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC5EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC6EN: Enable measurement of cell voltage 6. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC6EN_POS \
  (6U)
#define MC33775_PRMM_VC_CFG_VC6EN_MSK \
  (0x40U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC6EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC6EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC7EN: Enable measurement of cell voltage 7. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC7EN_POS \
  (7U)
#define MC33775_PRMM_VC_CFG_VC7EN_MSK \
  (0x80U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC7EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC7EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC8EN: Enable measurement of cell voltage 8. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC8EN_POS \
  (8U)
#define MC33775_PRMM_VC_CFG_VC8EN_MSK \
  (0x100U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC8EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC8EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC9EN: Enable measurement of cell voltage 9. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC9EN_POS \
  (9U)
#define MC33775_PRMM_VC_CFG_VC9EN_MSK \
  (0x200U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC9EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC9EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC10EN: Enable measurement of cell voltage 10. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC10EN_POS \
  (10U)
#define MC33775_PRMM_VC_CFG_VC10EN_MSK \
  (0x400U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC10EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC10EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC11EN: Enable measurement of cell voltage 11. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC11EN_POS \
  (11U)
#define MC33775_PRMM_VC_CFG_VC11EN_MSK \
  (0x800U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC11EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC11EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC12EN: Enable measurement of cell voltage 12. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC12EN_POS \
  (12U)
#define MC33775_PRMM_VC_CFG_VC12EN_MSK \
  (0x1000U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC12EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC12EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VC13EN: Enable measurement of cell voltage 13. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_VC_CFG_VC13EN_POS \
  (13U)
#define MC33775_PRMM_VC_CFG_VC13EN_MSK \
  (0x2000U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_VC_CFG_VC13EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_VC_CFG_VC13EN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_VC_CFG_RESERVED0_POS \
  (14U)
#define MC33775_PRMM_VC_CFG_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * PRMM_AIN_CFG (read-write):AINx and VMODULE measurement enables.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN_CFG_OFFSET \
  (0x1809U)
#define MC33775_PRMM_AIN_CFG_RW_MSK \
  (0xFF9FU)
#define MC33775_PRMM_AIN_CFG_RD_MSK \
  (0xFF9FU)
#define MC33775_PRMM_AIN_CFG_WR_MSK \
  (0xFF9FU)
#define MC33775_PRMM_AIN_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN_CFG_POR_VAL \
  (0x80U)

/* Field AIN0EN: Enable measurement of AIN0. Changes to this bit during active measurement can lead to undefined results. Note: TBC Switches the GPIO0/AIN0 to the analog measurement function. */
#define MC33775_PRMM_AIN_CFG_AIN0EN_POS \
  (0U)
#define MC33775_PRMM_AIN_CFG_AIN0EN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_AIN_CFG_AIN0EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_AIN_CFG_AIN0EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN1EN: Enable measurement of AIN1. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_AIN_CFG_AIN1EN_POS \
  (1U)
#define MC33775_PRMM_AIN_CFG_AIN1EN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_AIN_CFG_AIN1EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_AIN_CFG_AIN1EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN2EN: Enable measurement of AIN2. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_AIN_CFG_AIN2EN_POS \
  (2U)
#define MC33775_PRMM_AIN_CFG_AIN2EN_MSK \
  (0x4U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_AIN_CFG_AIN2EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_AIN_CFG_AIN2EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN3EN: Enable measurement of AIN3. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_PRMM_AIN_CFG_AIN3EN_POS \
  (3U)
#define MC33775_PRMM_AIN_CFG_AIN3EN_MSK \
  (0x8U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_AIN_CFG_AIN3EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_AIN_CFG_AIN3EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VMODULEEN: Enable measurement of VMODULE. Changes to this bit during active measurement can lead to undefined results. Note: VMODULE is measured in parallel to AIN4. */
#define MC33775_PRMM_AIN_CFG_VMODULEEN_POS \
  (4U)
#define MC33775_PRMM_AIN_CFG_VMODULEEN_MSK \
  (0x10U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_PRMM_AIN_CFG_VMODULEEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_PRMM_AIN_CFG_VMODULEEN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_AIN_CFG_RESERVED0_POS \
  (5U)
#define MC33775_PRMM_AIN_CFG_RESERVED0_MSK \
  (0x60U)

/* Field FLTAPPINV: Invalidate AINx application results in case of fault. */
#define MC33775_PRMM_AIN_CFG_FLTAPPINV_POS \
  (7U)
#define MC33775_PRMM_AIN_CFG_FLTAPPINV_MSK \
  (0x80U)

/* Enumerated value VALID: AINx application results are not invalidated in case of a fault */
#define MC33775_PRMM_AIN_CFG_FLTAPPINV_VALID_ENUM_VAL \
  (0U)

/* Enumerated value INVALID: AINx application results are invalidated when a fault is detected. */
#define MC33775_PRMM_AIN_CFG_FLTAPPINV_INVALID_ENUM_VAL \
  (1U)

/* Field RATIOMETRICAIN0: Reference selection for AIN0. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN0_POS \
  (8U)
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN0_MSK \
  (0x300U)

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN0_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN0_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN0_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN0_VDDC_ENUM_VAL \
  (3U)

/* Field RATIOMETRICAIN1: Reference selection for AIN1. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN1_POS \
  (10U)
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN1_MSK \
  (0xC00U)

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN1_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN1_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN1_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN1_VDDC_ENUM_VAL \
  (3U)

/* Field RATIOMETRICAIN2: Reference selection for AIN2. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN2_POS \
  (12U)
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN2_MSK \
  (0x3000U)

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN2_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN2_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN2_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN2_VDDC_ENUM_VAL \
  (3U)

/* Field RATIOMETRICAIN3: Reference selection for AIN3. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN3_POS \
  (14U)
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN3_MSK \
  (0xC000U)

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN3_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN3_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN3_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_PRMM_AIN_CFG_RATIOMETRICAIN3_VDDC_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * PRMM_AIN_OL_CFG (read-write):AINx open_load detection enable.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN_OL_CFG_OFFSET \
  (0x180AU)
#define MC33775_PRMM_AIN_OL_CFG_RW_MSK \
  (0xFU)
#define MC33775_PRMM_AIN_OL_CFG_RD_MSK \
  (0xFU)
#define MC33775_PRMM_AIN_OL_CFG_WR_MSK \
  (0xFU)
#define MC33775_PRMM_AIN_OL_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_OL_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_OL_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN_OL_CFG_POR_VAL \
  (0x0U)

/* Field AIN0EN: Open load detection circuit for AIN0 */
#define MC33775_PRMM_AIN_OL_CFG_AIN0EN_POS \
  (0U)
#define MC33775_PRMM_AIN_OL_CFG_AIN0EN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN0EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN0EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN1EN: Open load detection circuit for AIN1 */
#define MC33775_PRMM_AIN_OL_CFG_AIN1EN_POS \
  (1U)
#define MC33775_PRMM_AIN_OL_CFG_AIN1EN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN1EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN1EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN2EN: Open load detection circuit for AIN2 */
#define MC33775_PRMM_AIN_OL_CFG_AIN2EN_POS \
  (2U)
#define MC33775_PRMM_AIN_OL_CFG_AIN2EN_MSK \
  (0x4U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN2EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN2EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN3EN: Open load detection circuit for AIN3 */
#define MC33775_PRMM_AIN_OL_CFG_AIN3EN_POS \
  (3U)
#define MC33775_PRMM_AIN_OL_CFG_AIN3EN_MSK \
  (0x8U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN3EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_PRMM_AIN_OL_CFG_AIN3EN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_AIN_OL_CFG_RESERVED0_POS \
  (4U)
#define MC33775_PRMM_AIN_OL_CFG_RESERVED0_MSK \
  (0xFFF0U)


/* --------------------------------------------------------------------------
 * PRMM_VDIV_CFG (read-write):Voltage divider enable.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VDIV_CFG_OFFSET \
  (0x180BU)
#define MC33775_PRMM_VDIV_CFG_RW_MSK \
  (0x7U)
#define MC33775_PRMM_VDIV_CFG_RD_MSK \
  (0x7U)
#define MC33775_PRMM_VDIV_CFG_WR_MSK \
  (0x7U)
#define MC33775_PRMM_VDIV_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VDIV_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_VDIV_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VDIV_CFG_POR_VAL \
  (0x7U)

/* Field VAUXEN: Voltage divider for primary VAUX measurement */
#define MC33775_PRMM_VDIV_CFG_VAUXEN_POS \
  (0U)
#define MC33775_PRMM_VDIV_CFG_VAUXEN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Voltage divider for primary VAUX measurement is disabled. */
#define MC33775_PRMM_VDIV_CFG_VAUXEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Voltage divider for primary VAUX measurement is enabled. */
#define MC33775_PRMM_VDIV_CFG_VAUXEN_ENABLED_ENUM_VAL \
  (1U)

/* Field VDDCEN: Voltage divider for primary VDDC measurement */
#define MC33775_PRMM_VDIV_CFG_VDDCEN_POS \
  (1U)
#define MC33775_PRMM_VDIV_CFG_VDDCEN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Voltage divider for primary VDDC measurement is disabled. */
#define MC33775_PRMM_VDIV_CFG_VDDCEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Voltage divider for primary VDDC measurement is enabled. */
#define MC33775_PRMM_VDIV_CFG_VDDCEN_ENABLED_ENUM_VAL \
  (1U)

/* Field VMODULEEN: Voltage divider for VMODULE. */
#define MC33775_PRMM_VDIV_CFG_VMODULEEN_POS \
  (2U)
#define MC33775_PRMM_VDIV_CFG_VMODULEEN_MSK \
  (0x4U)

/* Enumerated value DISABLED: Voltage divider for VMODULE is disabled. */
#define MC33775_PRMM_VDIV_CFG_VMODULEEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Voltage divider for VMODULE is enabled. */
#define MC33775_PRMM_VDIV_CFG_VMODULEEN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_VDIV_CFG_RESERVED0_POS \
  (3U)
#define MC33775_PRMM_VDIV_CFG_RESERVED0_MSK \
  (0xFFF8U)


/* --------------------------------------------------------------------------
 * PRMM_VC_OV_UV_CFG (read-write):Cell voltage over- and undervoltage check enable.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_OV_UV_CFG_OFFSET \
  (0x1810U)
#define MC33775_PRMM_VC_OV_UV_CFG_RW_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_OV_UV_CFG_RD_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_OV_UV_CFG_WR_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_OV_UV_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_OV_UV_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_VC_OV_UV_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_OV_UV_CFG_POR_VAL \
  (0x0U)

/* Field VC0EN: Include VC0 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC0EN_POS \
  (0U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC0EN_MSK \
  (0x1U)

/* Enumerated value NO_CHECK: VC0 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC0EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC0 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC0EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC1EN: Include VC1 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC1EN_POS \
  (1U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC1EN_MSK \
  (0x2U)

/* Enumerated value NO_CHECK: VC1 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC1EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC1 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC1EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC2EN: Include VC2 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC2EN_POS \
  (2U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC2EN_MSK \
  (0x4U)

/* Enumerated value NO_CHECK: VC2 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC2EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC2 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC2EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC3EN: Include VC3 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC3EN_POS \
  (3U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC3EN_MSK \
  (0x8U)

/* Enumerated value NO_CHECK: VC3 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC3EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC3 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC3EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC4EN: Include VC4 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC4EN_POS \
  (4U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC4EN_MSK \
  (0x10U)

/* Enumerated value NO_CHECK: VC4 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC4EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC4 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC4EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC5EN: Include VC5 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC5EN_POS \
  (5U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC5EN_MSK \
  (0x20U)

/* Enumerated value NO_CHECK: VC5 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC5EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC5 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC5EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC6EN: Include VC6 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC6EN_POS \
  (6U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC6EN_MSK \
  (0x40U)

/* Enumerated value NO_CHECK: VC6 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC6EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC6 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC6EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC7EN: Include VC7 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC7EN_POS \
  (7U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC7EN_MSK \
  (0x80U)

/* Enumerated value NO_CHECK: VC7 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC7EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC7 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC7EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC8EN: Include VC8 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC8EN_POS \
  (8U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC8EN_MSK \
  (0x100U)

/* Enumerated value NO_CHECK: VC8 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC8EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC8 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC8EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC9EN: Include VC9 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC9EN_POS \
  (9U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC9EN_MSK \
  (0x200U)

/* Enumerated value NO_CHECK: VC9 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC9EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC9 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC9EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC10EN: Include VC10 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC10EN_POS \
  (10U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC10EN_MSK \
  (0x400U)

/* Enumerated value NO_CHECK: VC10 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC10EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC10 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC10EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC11EN: Include VC11 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC11EN_POS \
  (11U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC11EN_MSK \
  (0x800U)

/* Enumerated value NO_CHECK: VC11 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC11EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC11 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC11EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC12EN: Include VC12 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC12EN_POS \
  (12U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC12EN_MSK \
  (0x1000U)

/* Enumerated value NO_CHECK: VC12 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC12EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC12 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC12EN_UV_OV_ENUM_VAL \
  (1U)

/* Field VC13EN: Include VC13 in VC over- and under-voltage checks */
#define MC33775_PRMM_VC_OV_UV_CFG_VC13EN_POS \
  (13U)
#define MC33775_PRMM_VC_OV_UV_CFG_VC13EN_MSK \
  (0x2000U)

/* Enumerated value NO_CHECK: VC13 is not included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC13EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC13 is included in VC over- and under-voltage checks. */
#define MC33775_PRMM_VC_OV_UV_CFG_VC13EN_UV_OV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_VC_OV_UV_CFG_RESERVED0_POS \
  (14U)
#define MC33775_PRMM_VC_OV_UV_CFG_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * PRMM_VC_OV_TH_CFG (read-write):Upper comparator limit for VC0..13.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_OV_TH_CFG_OFFSET \
  (0x1811U)
#define MC33775_PRMM_VC_OV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_OV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_OV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_OV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_OV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_VC_OV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_OV_TH_CFG_POR_VAL \
  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV fault is activated. */
#define MC33775_PRMM_VC_OV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_VC_OV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_VC_UV0_TH_CFG (read-write):Lower comparator limit 0 for VC0..13.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_UV0_TH_CFG_OFFSET \
  (0x1812U)
#define MC33775_PRMM_VC_UV0_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV0_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV0_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV0_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV0_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV0_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV0_TH_CFG_POR_VAL \
  (0x0U)

/* Field LIMIT: Limit value. If this limit is reached, the channel individual UV fault is activated. Note: This limit is used for the channel individual balancing disable. */
#define MC33775_PRMM_VC_UV0_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_VC_UV0_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_VC_UV1_TH_CFG (read-write):Lower comparator limit 1 for VC0..13.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_UV1_TH_CFG_OFFSET \
  (0x1813U)
#define MC33775_PRMM_VC_UV1_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV1_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV1_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV1_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV1_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV1_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV1_TH_CFG_POR_VAL \
  (0x0U)

/* Field LIMIT: Limit value. If this limit is reached, the global UV fault is activated. Note: This limit is used for the global balancing disable. */
#define MC33775_PRMM_VC_UV1_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_VC_UV1_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN0_OV_TH_CFG (read-write):Upper comparator limit forAIN0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN0_OV_TH_CFG_OFFSET \
  (0x1814U)
#define MC33775_PRMM_AIN0_OV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_OV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_OV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_OV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN0_OV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN0_OV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_OV_TH_CFG_POR_VAL \
  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV fault is activated. Note: Signed value (two's complement). */
#define MC33775_PRMM_AIN0_OV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN0_OV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN1_OV_TH_CFG (read-write):Upper comparator limit forAIN1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN1_OV_TH_CFG_OFFSET \
  (0x1815U)
#define MC33775_PRMM_AIN1_OV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_OV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_OV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_OV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN1_OV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN1_OV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_OV_TH_CFG_POR_VAL \
  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV fault is activated. */
#define MC33775_PRMM_AIN1_OV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN1_OV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN2_OV_TH_CFG (read-write):Upper comparator limit forAIN2.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN2_OV_TH_CFG_OFFSET \
  (0x1816U)
#define MC33775_PRMM_AIN2_OV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_OV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_OV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_OV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN2_OV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN2_OV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_OV_TH_CFG_POR_VAL \
  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV fault is activated. */
#define MC33775_PRMM_AIN2_OV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN2_OV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN3_OV_TH_CFG (read-write):Upper comparator limit forAIN3.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN3_OV_TH_CFG_OFFSET \
  (0x1817U)
#define MC33775_PRMM_AIN3_OV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_OV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_OV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_OV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN3_OV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN3_OV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_OV_TH_CFG_POR_VAL \
  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV fault is activated. */
#define MC33775_PRMM_AIN3_OV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN3_OV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN0_UV_TH_CFG (read-write):Lower comparator limit forAIN0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN0_UV_TH_CFG_OFFSET \
  (0x1818U)
#define MC33775_PRMM_AIN0_UV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_UV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_UV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_UV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN0_UV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN0_UV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN0_UV_TH_CFG_POR_VAL \
  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV fault is activated. */
#define MC33775_PRMM_AIN0_UV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN0_UV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN1_UV_TH_CFG (read-write):Lower comparator limit forAIN1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN1_UV_TH_CFG_OFFSET \
  (0x1819U)
#define MC33775_PRMM_AIN1_UV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_UV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_UV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_UV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN1_UV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN1_UV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN1_UV_TH_CFG_POR_VAL \
  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV fault is activated. */
#define MC33775_PRMM_AIN1_UV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN1_UV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN2_UV_TH_CFG (read-write):Lower comparator limit forAIN2.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN2_UV_TH_CFG_OFFSET \
  (0x181AU)
#define MC33775_PRMM_AIN2_UV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_UV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_UV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_UV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN2_UV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN2_UV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN2_UV_TH_CFG_POR_VAL \
  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV fault is activated. */
#define MC33775_PRMM_AIN2_UV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN2_UV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_AIN3_UV_TH_CFG (read-write):Lower comparator limit forAIN3.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN3_UV_TH_CFG_OFFSET \
  (0x181BU)
#define MC33775_PRMM_AIN3_UV_TH_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_UV_TH_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_UV_TH_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_UV_TH_CFG_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN3_UV_TH_CFG_RA_MSK \
  (0x0U)
#define MC33775_PRMM_AIN3_UV_TH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN3_UV_TH_CFG_POR_VAL \
  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV fault is activated. */
#define MC33775_PRMM_AIN3_UV_TH_CFG_LIMIT_POS \
  (0U)
#define MC33775_PRMM_AIN3_UV_TH_CFG_LIMIT_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_CAL_CRC (read-write):CRC over calibration data.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_CAL_CRC_OFFSET \
  (0x181EU)
#define MC33775_PRMM_CAL_CRC_RW_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CAL_CRC_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CAL_CRC_WR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CAL_CRC_MW_MSK \
  (0x0U)
#define MC33775_PRMM_CAL_CRC_RA_MSK \
  (0x0U)
#define MC33775_PRMM_CAL_CRC_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CAL_CRC_POR_VAL \
  (0x0U)

/* Field CRC: CRC over calibration data. The CRC calculation runs automatically every time when a synchronous measurement cycle is started and when the calibration data is read from the NVM. */
#define MC33775_PRMM_CAL_CRC_CRC_POS \
  (0U)
#define MC33775_PRMM_CAL_CRC_CRC_MSK \
  (0xFFFFU)

/* Enumerated value CALIBCRC: The expected value of the calibration CRC. */
#define MC33775_PRMM_CAL_CRC_CRC_CALIBCRC_ENUM_VAL \
  (48879U)


/* --------------------------------------------------------------------------
 * PRMM_CFG_CRC (read-only):CRC over configuration values.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_CFG_CRC_OFFSET \
  (0x181FU)
#define MC33775_PRMM_CFG_CRC_RW_MSK \
  (0x0U)
#define MC33775_PRMM_CFG_CRC_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CFG_CRC_WR_MSK \
  (0x0U)
#define MC33775_PRMM_CFG_CRC_MW_MSK \
  (0x0U)
#define MC33775_PRMM_CFG_CRC_RA_MSK \
  (0x0U)
#define MC33775_PRMM_CFG_CRC_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_CFG_CRC_POR_VAL \
  (0x0U)

/* Field CRC: This CRC value is recalculated with any transition into Active mode, with any write to a covered register and with any read to this register. The updated CRC value is available latest 100us after the last write. The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1.
Following registers are included: PRMM_CFG, PRMM_PER_CTRL, PRMM_VC_CFG, PRMM_AIN_CFG, PRMM_VDIV_CFG, PRMM_VC_OV_UV_CFG, PRMM_VC_OV_TH_CFG, PRMM_VC_UV0_TH_CFG, PRMM_VC_UV1_TH_CFG, PRMM_AIN0_OV_TH_CFG, PRMM_AIN1_OV_TH_CFG, PRMM_AIN2_OV_TH_CFG, PRMM_AIN3_OV_TH_CFG, PRMM_AIN0_UV_TH_CFG, PRMM_AIN1_UV_TH_CFG, PRMM_AIN2_UV_TH_CFG, PRMM_AIN3_UV_TH_CFG. */
#define MC33775_PRMM_CFG_CRC_CRC_POS \
  (0U)
#define MC33775_PRMM_CFG_CRC_CRC_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_VC_OV_FLT_STAT (read-only):Cell voltage over-voltage faults
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_OV_FLT_STAT_OFFSET \
  (0x1820U)
#define MC33775_PRMM_VC_OV_FLT_STAT_RW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_OV_FLT_STAT_RD_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_OV_FLT_STAT_WR_MSK \
  (0x0U)
#define MC33775_PRMM_VC_OV_FLT_STAT_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_OV_FLT_STAT_RA_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_OV_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_OV_FLT_STAT_POR_VAL \
  (0x0U)

/* Field VC0: Over-voltage status VC0 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC0_POS \
  (0U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC0_MSK \
  (0x1U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC0_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC0_OV_ENUM_VAL \
  (1U)

/* Field VC1: Over-voltage status VC1 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC1_POS \
  (1U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC1_MSK \
  (0x2U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC1_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC1_OV_ENUM_VAL \
  (1U)

/* Field VC2: Over-voltage status VC2 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC2_POS \
  (2U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC2_MSK \
  (0x4U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC2_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC2_OV_ENUM_VAL \
  (1U)

/* Field VC3: Over-voltage status VC3 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC3_POS \
  (3U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC3_MSK \
  (0x8U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC3_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC3_OV_ENUM_VAL \
  (1U)

/* Field VC4: Over-voltage status VC4 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC4_POS \
  (4U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC4_MSK \
  (0x10U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC4_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC4_OV_ENUM_VAL \
  (1U)

/* Field VC5: Over-voltage status VC5 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC5_POS \
  (5U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC5_MSK \
  (0x20U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC5_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC5_OV_ENUM_VAL \
  (1U)

/* Field VC6: Over-voltage status VC6 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC6_POS \
  (6U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC6_MSK \
  (0x40U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC6_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC6_OV_ENUM_VAL \
  (1U)

/* Field VC7: Over-voltage status VC7 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC7_POS \
  (7U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC7_MSK \
  (0x80U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC7_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC7_OV_ENUM_VAL \
  (1U)

/* Field VC8: Over-voltage status VC8 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC8_POS \
  (8U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC8_MSK \
  (0x100U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC8_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC8_OV_ENUM_VAL \
  (1U)

/* Field VC9: Over-voltage status VC9 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC9_POS \
  (9U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC9_MSK \
  (0x200U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC9_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC9_OV_ENUM_VAL \
  (1U)

/* Field VC10: Over-voltage status VC10 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC10_POS \
  (10U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC10_MSK \
  (0x400U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC10_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC10_OV_ENUM_VAL \
  (1U)

/* Field VC11: Over-voltage status VC11 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC11_POS \
  (11U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC11_MSK \
  (0x800U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC11_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC11_OV_ENUM_VAL \
  (1U)

/* Field VC12: Over-voltage status VC12 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC12_POS \
  (12U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC12_MSK \
  (0x1000U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC12_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC12_OV_ENUM_VAL \
  (1U)

/* Field VC13: Over-voltage status VC13 */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC13_POS \
  (13U)
#define MC33775_PRMM_VC_OV_FLT_STAT_VC13_MSK \
  (0x2000U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC13_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_VC_OV_FLT_STAT_VC13_OV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_VC_OV_FLT_STAT_RESERVED0_POS \
  (14U)
#define MC33775_PRMM_VC_OV_FLT_STAT_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * PRMM_VC_UV0_FLT_STAT (read-only):Cell voltage under-value faults with respect to limit 0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_UV0_FLT_STAT_OFFSET \
  (0x1821U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_RW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_RD_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_UV0_FLT_STAT_WR_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_RA_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_UV0_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV0_FLT_STAT_POR_VAL \
  (0x0U)

/* Field VC0: Under-voltage status VC0 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC0_POS \
  (0U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC0_MSK \
  (0x1U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC0_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC0_UV_ENUM_VAL \
  (1U)

/* Field VC1: Under-voltage status VC1 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC1_POS \
  (1U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC1_MSK \
  (0x2U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC1_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC1_UV_ENUM_VAL \
  (1U)

/* Field VC2: Under-voltage status VC2 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC2_POS \
  (2U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC2_MSK \
  (0x4U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC2_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC2_UV_ENUM_VAL \
  (1U)

/* Field VC3: Under-voltage status VC3 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC3_POS \
  (3U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC3_MSK \
  (0x8U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC3_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC3_UV_ENUM_VAL \
  (1U)

/* Field VC4: Under-voltage status VC4 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC4_POS \
  (4U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC4_MSK \
  (0x10U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC4_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC4_UV_ENUM_VAL \
  (1U)

/* Field VC5: Under-voltage status VC5 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC5_POS \
  (5U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC5_MSK \
  (0x20U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC5_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC5_UV_ENUM_VAL \
  (1U)

/* Field VC6: Under-voltage status VC6 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC6_POS \
  (6U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC6_MSK \
  (0x40U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC6_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC6_UV_ENUM_VAL \
  (1U)

/* Field VC7: Under-voltage status VC7 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC7_POS \
  (7U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC7_MSK \
  (0x80U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC7_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC7_UV_ENUM_VAL \
  (1U)

/* Field VC8: Under-voltage status VC8 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC8_POS \
  (8U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC8_MSK \
  (0x100U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC8_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC8_UV_ENUM_VAL \
  (1U)

/* Field VC9: Under-voltage status VC9 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC9_POS \
  (9U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC9_MSK \
  (0x200U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC9_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC9_UV_ENUM_VAL \
  (1U)

/* Field VC10: Under-voltage status VC10 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC10_POS \
  (10U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC10_MSK \
  (0x400U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC10_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC10_UV_ENUM_VAL \
  (1U)

/* Field VC11: Under-voltage status VC11 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC11_POS \
  (11U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC11_MSK \
  (0x800U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC11_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC11_UV_ENUM_VAL \
  (1U)

/* Field VC12: Under-voltage status VC12 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC12_POS \
  (12U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC12_MSK \
  (0x1000U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC12_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC12_UV_ENUM_VAL \
  (1U)

/* Field VC13: Under-voltage status VC13 */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC13_POS \
  (13U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC13_MSK \
  (0x2000U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC13_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV0_FLT_STAT_VC13_UV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_VC_UV0_FLT_STAT_RESERVED0_POS \
  (14U)
#define MC33775_PRMM_VC_UV0_FLT_STAT_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * PRMM_VC_UV1_FLT_STAT (read-only):Cell voltage under-value faults with respect to limit 1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_VC_UV1_FLT_STAT_OFFSET \
  (0x1822U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_RW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_RD_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_UV1_FLT_STAT_WR_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_MW_MSK \
  (0x0U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_RA_MSK \
  (0x3FFFU)
#define MC33775_PRMM_VC_UV1_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_VC_UV1_FLT_STAT_POR_VAL \
  (0x0U)

/* Field VC0: Under-voltage status VC0 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC0_POS \
  (0U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC0_MSK \
  (0x1U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC0_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC0_UV_ENUM_VAL \
  (1U)

/* Field VC1: Under-voltage status VC1 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC1_POS \
  (1U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC1_MSK \
  (0x2U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC1_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC1_UV_ENUM_VAL \
  (1U)

/* Field VC2: Under-voltage status VC2 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC2_POS \
  (2U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC2_MSK \
  (0x4U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC2_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC2_UV_ENUM_VAL \
  (1U)

/* Field VC3: Under-voltage status VC3 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC3_POS \
  (3U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC3_MSK \
  (0x8U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC3_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC3_UV_ENUM_VAL \
  (1U)

/* Field VC4: Under-voltage status VC4 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC4_POS \
  (4U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC4_MSK \
  (0x10U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC4_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC4_UV_ENUM_VAL \
  (1U)

/* Field VC5: Under-voltage status VC5 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC5_POS \
  (5U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC5_MSK \
  (0x20U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC5_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC5_UV_ENUM_VAL \
  (1U)

/* Field VC6: Under-voltage status VC6 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC6_POS \
  (6U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC6_MSK \
  (0x40U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC6_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC6_UV_ENUM_VAL \
  (1U)

/* Field VC7: Under-voltage status VC7 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC7_POS \
  (7U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC7_MSK \
  (0x80U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC7_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC7_UV_ENUM_VAL \
  (1U)

/* Field VC8: Under-voltage status VC8 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC8_POS \
  (8U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC8_MSK \
  (0x100U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC8_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC8_UV_ENUM_VAL \
  (1U)

/* Field VC9: Under-voltage status VC9 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC9_POS \
  (9U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC9_MSK \
  (0x200U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC9_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC9_UV_ENUM_VAL \
  (1U)

/* Field VC10: Under-voltage status VC10 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC10_POS \
  (10U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC10_MSK \
  (0x400U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC10_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC10_UV_ENUM_VAL \
  (1U)

/* Field VC11: Under-voltage status VC11 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC11_POS \
  (11U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC11_MSK \
  (0x800U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC11_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC11_UV_ENUM_VAL \
  (1U)

/* Field VC12: Under-voltage status VC12 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC12_POS \
  (12U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC12_MSK \
  (0x1000U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC12_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC12_UV_ENUM_VAL \
  (1U)

/* Field VC13: Under-voltage status VC13 */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC13_POS \
  (13U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC13_MSK \
  (0x2000U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC13_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_VC_UV1_FLT_STAT_VC13_UV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_VC_UV1_FLT_STAT_RESERVED0_POS \
  (14U)
#define MC33775_PRMM_VC_UV1_FLT_STAT_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * PRMM_AIN_OV_FLT_STAT (read-only):AINx over-value faults.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN_OV_FLT_STAT_OFFSET \
  (0x1823U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_RW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_RD_MSK \
  (0xFU)
#define MC33775_PRMM_AIN_OV_FLT_STAT_WR_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_RA_MSK \
  (0xFU)
#define MC33775_PRMM_AIN_OV_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN_OV_FLT_STAT_POR_VAL \
  (0x0U)

/* Field AIN0: Over-voltage status AIN0 */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN0_POS \
  (0U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN0_MSK \
  (0x1U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN0_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN0_OV_ENUM_VAL \
  (1U)

/* Field AIN1: Over-voltage status AIN1 */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN1_POS \
  (1U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN1_MSK \
  (0x2U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN1_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN1_OV_ENUM_VAL \
  (1U)

/* Field AIN2: Over-voltage status AIN2 */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN2_POS \
  (2U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN2_MSK \
  (0x4U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN2_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN2_OV_ENUM_VAL \
  (1U)

/* Field AIN3: Over-voltage status AIN3 */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN3_POS \
  (3U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN3_MSK \
  (0x8U)

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN3_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33775_PRMM_AIN_OV_FLT_STAT_AIN3_OV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_AIN_OV_FLT_STAT_RESERVED0_POS \
  (4U)
#define MC33775_PRMM_AIN_OV_FLT_STAT_RESERVED0_MSK \
  (0xFFF0U)


/* --------------------------------------------------------------------------
 * PRMM_AIN_UV_FLT_STAT (read-only):AINx under-value faults.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_AIN_UV_FLT_STAT_OFFSET \
  (0x1824U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_RW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_RD_MSK \
  (0xFU)
#define MC33775_PRMM_AIN_UV_FLT_STAT_WR_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_MW_MSK \
  (0x0U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_RA_MSK \
  (0xFU)
#define MC33775_PRMM_AIN_UV_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_AIN_UV_FLT_STAT_POR_VAL \
  (0x0U)

/* Field AIN0: Under-voltage status AIN0 */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN0_POS \
  (0U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN0_MSK \
  (0x1U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN0_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN0_UV_ENUM_VAL \
  (1U)

/* Field AIN1: Under-voltage status AIN1 */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN1_POS \
  (1U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN1_MSK \
  (0x2U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN1_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN1_UV_ENUM_VAL \
  (1U)

/* Field AIN2: Under-voltage status AIN2 */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN2_POS \
  (2U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN2_MSK \
  (0x4U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN2_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN2_UV_ENUM_VAL \
  (1U)

/* Field AIN3: Under-voltage status AIN3 */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN3_POS \
  (3U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN3_MSK \
  (0x8U)

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN3_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33775_PRMM_AIN_UV_FLT_STAT_AIN3_UV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_AIN_UV_FLT_STAT_RESERVED0_POS \
  (4U)
#define MC33775_PRMM_AIN_UV_FLT_STAT_RESERVED0_MSK \
  (0xFFF0U)


/* --------------------------------------------------------------------------
 * PRMM_MEAS_STAT (read-only):Measurement status.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_MEAS_STAT_OFFSET \
  (0x183EU)
#define MC33775_PRMM_MEAS_STAT_RW_MSK \
  (0x0U)
#define MC33775_PRMM_MEAS_STAT_RD_MSK \
  (0xF33FU)
#define MC33775_PRMM_MEAS_STAT_WR_MSK \
  (0x0U)
#define MC33775_PRMM_MEAS_STAT_MW_MSK \
  (0x0U)
#define MC33775_PRMM_MEAS_STAT_RA_MSK \
  (0x0U)
#define MC33775_PRMM_MEAS_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_MEAS_STAT_POR_VAL \
  (0x0U)

/* Field APPRDYVC: A new VC application result can be requested / captured. */
#define MC33775_PRMM_MEAS_STAT_APPRDYVC_POS \
  (0U)
#define MC33775_PRMM_MEAS_STAT_APPRDYVC_MSK \
  (0x1U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_PRMM_MEAS_STAT_APPRDYVC_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_PRMM_MEAS_STAT_APPRDYVC_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYVMODULE: A new VMODULE application result can be requested / captured. */
#define MC33775_PRMM_MEAS_STAT_APPRDYVMODULE_POS \
  (1U)
#define MC33775_PRMM_MEAS_STAT_APPRDYVMODULE_MSK \
  (0x2U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_PRMM_MEAS_STAT_APPRDYVMODULE_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_PRMM_MEAS_STAT_APPRDYVMODULE_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYAIN0: A new AIN0 application result can be requested / captured. */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN0_POS \
  (2U)
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN0_MSK \
  (0x4U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN0_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN0_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYAIN1: A new AIN1 application result can be requested / captured. */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN1_POS \
  (3U)
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN1_MSK \
  (0x8U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN1_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN1_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYAIN2: A new AIN2 application result can be requested / captured. */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN2_POS \
  (4U)
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN2_MSK \
  (0x10U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN2_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN2_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYAIN3: A new AIN3 application result can be requested / captured. */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN3_POS \
  (5U)
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN3_MSK \
  (0x20U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN3_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_PRMM_MEAS_STAT_APPRDYAIN3_DATA_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_MEAS_STAT_RESERVED0_POS \
  (6U)
#define MC33775_PRMM_MEAS_STAT_RESERVED0_MSK \
  (0xC0U)

/* Field PERRDY: New periodic result data has been created (depending on the periodic update mode, they might need to be requested) , the bit is cleared by a read to any register in the range PRMM_PER_VC0 to (PRMM_PER_VDDC + 1). */
#define MC33775_PRMM_MEAS_STAT_PERRDY_POS \
  (8U)
#define MC33775_PRMM_MEAS_STAT_PERRDY_MSK \
  (0x100U)

/* Enumerated value NO_DATA: No data available */
#define MC33775_PRMM_MEAS_STAT_PERRDY_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33775_PRMM_MEAS_STAT_PERRDY_DATA_ENUM_VAL \
  (1U)

/* Field SYNCRDY: Synchronous measurement data is ready for readout, the bit is cleared by a read to any register in the range PRMM_SYNC_VC0 to PRMM_SYNC_VC13. */
#define MC33775_PRMM_MEAS_STAT_SYNCRDY_POS \
  (9U)
#define MC33775_PRMM_MEAS_STAT_SYNCRDY_MSK \
  (0x200U)

/* Enumerated value NO_DATA: No data available */
#define MC33775_PRMM_MEAS_STAT_SYNCRDY_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33775_PRMM_MEAS_STAT_SYNCRDY_DATA_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_PRMM_MEAS_STAT_RESERVED1_POS \
  (10U)
#define MC33775_PRMM_MEAS_STAT_RESERVED1_MSK \
  (0xC00U)

/* Field SUPPLYFLT: Internal/external supply fault status */
#define MC33775_PRMM_MEAS_STAT_SUPPLYFLT_POS \
  (12U)
#define MC33775_PRMM_MEAS_STAT_SUPPLYFLT_MSK \
  (0x1000U)

/* Enumerated value NO_FLT: No supply error detected */
#define MC33775_PRMM_MEAS_STAT_SUPPLYFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Supply error detected */
#define MC33775_PRMM_MEAS_STAT_SUPPLYFLT_FAULT_ENUM_VAL \
  (1U)

/* Field ANAFLT: Analog fault status */
#define MC33775_PRMM_MEAS_STAT_ANAFLT_POS \
  (13U)
#define MC33775_PRMM_MEAS_STAT_ANAFLT_MSK \
  (0x2000U)

/* Enumerated value NO_FLT: No analog fault detected */
#define MC33775_PRMM_MEAS_STAT_ANAFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Analog fault detected */
#define MC33775_PRMM_MEAS_STAT_ANAFLT_FAULT_ENUM_VAL \
  (1U)

/* Field COMFLT: Communication fault status */
#define MC33775_PRMM_MEAS_STAT_COMFLT_POS \
  (14U)
#define MC33775_PRMM_MEAS_STAT_COMFLT_MSK \
  (0x4000U)

/* Enumerated value NO_FLT: No communication fault detected */
#define MC33775_PRMM_MEAS_STAT_COMFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Communication fault detected. */
#define MC33775_PRMM_MEAS_STAT_COMFLT_FAULT_ENUM_VAL \
  (1U)

/* Field MEASFLT: Measurement fault status */
#define MC33775_PRMM_MEAS_STAT_MEASFLT_POS \
  (15U)
#define MC33775_PRMM_MEAS_STAT_MEASFLT_MSK \
  (0x8000U)

/* Enumerated value NO_FLT: No measurement fault detected */
#define MC33775_PRMM_MEAS_STAT_MEASFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Measurement fault detected */
#define MC33775_PRMM_MEAS_STAT_MEASFLT_FAULT_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC_CNT (read-only):Application measurement VC sample count number.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC_CNT_OFFSET \
  (0x183FU)
#define MC33775_PRMM_APP_VC_CNT_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC_CNT_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC_CNT_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC_CNT_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC_CNT_RA_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC_CNT_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC_CNT_POR_VAL \
  (0x0U)

/* Field NUM: Number of samples used for Application result. */
#define MC33775_PRMM_APP_VC_CNT_NUM_POS \
  (0U)
#define MC33775_PRMM_APP_VC_CNT_NUM_MSK \
  (0xFFFFU)

/* Enumerated value LOW: Zero or insufficient samples, VC Application results are invalid. */
#define MC33775_PRMM_APP_VC_CNT_NUM_LOW_ENUM_VAL \
  (0U)

/* Enumerated value OVERRUN: Sample counter overrun, VC Application results are invalid. */
#define MC33775_PRMM_APP_VC_CNT_NUM_OVERRUN_ENUM_VAL \
  (65535U)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC0 (read-only):Application measurement result cell 0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC0_OFFSET \
  (0x1840U)
#define MC33775_PRMM_APP_VC0_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC0_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC0_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC0_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC0_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC0_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC0_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 0 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC0_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC0_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC1 (read-only):Application measurement result cell 1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC1_OFFSET \
  (0x1841U)
#define MC33775_PRMM_APP_VC1_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC1_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC1_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC1_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC1_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC1_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC1_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 1 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC1_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC1_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC2 (read-only):Application measurement result cell 2.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC2_OFFSET \
  (0x1842U)
#define MC33775_PRMM_APP_VC2_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC2_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC2_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC2_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC2_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC2_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC2_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 2 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC2_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC2_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC3 (read-only):Application measurement result cell 3.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC3_OFFSET \
  (0x1843U)
#define MC33775_PRMM_APP_VC3_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC3_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC3_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC3_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC3_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC3_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC3_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 3 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC3_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC3_VALUE_MSK \
  (0xFFFFU)

/* --------------------------------------------------------------------------
 * PRMM_APP_VC4 (read-only):Application measurement result cell 4.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC4_OFFSET \
  (0x1844U)
#define MC33775_PRMM_APP_VC4_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC4_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC4_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC4_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC4_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC4_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC4_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 4 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC4_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC4_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC5 (read-only):Application measurement result cell 5.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC5_OFFSET \
  (0x1845U)
#define MC33775_PRMM_APP_VC5_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC5_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC5_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC5_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC5_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC5_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC5_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 5 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC5_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC5_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC6 (read-only):Application measurement result cell 6.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC6_OFFSET \
  (0x1846U)
#define MC33775_PRMM_APP_VC6_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC6_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC6_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC6_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC6_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC6_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC6_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 6 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC6_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC6_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC7 (read-only):Application measurement result cell 7.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC7_OFFSET \
  (0x1847U)
#define MC33775_PRMM_APP_VC7_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC7_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC7_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC7_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC7_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC7_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC7_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 7 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC7_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC7_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC8 (read-only):Application measurement result cell 8.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC8_OFFSET \
  (0x1848U)
#define MC33775_PRMM_APP_VC8_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC8_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC8_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC8_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC8_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC8_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC8_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 8 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC8_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC8_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC9 (read-only):Application measurement result cell 9.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC9_OFFSET \
  (0x1849U)
#define MC33775_PRMM_APP_VC9_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC9_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC9_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC9_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC9_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC9_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC9_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 9 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC9_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC9_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC10 (read-only):Application measurement result cell 10.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC10_OFFSET \
  (0x184AU)
#define MC33775_PRMM_APP_VC10_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC10_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC10_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC10_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC10_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC10_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC10_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 10 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC10_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC10_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC11 (read-only):Application measurement result cell 11.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC11_OFFSET \
  (0x184BU)
#define MC33775_PRMM_APP_VC11_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC11_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC11_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC11_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC11_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC11_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC11_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 11 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC11_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC11_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC12 (read-only):Application measurement result cell 12.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC12_OFFSET \
  (0x184CU)
#define MC33775_PRMM_APP_VC12_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC12_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC12_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC12_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC12_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC12_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC12_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 12 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC12_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC12_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VC13 (read-only):Application measurement result cell 13.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VC13_OFFSET \
  (0x184DU)
#define MC33775_PRMM_APP_VC13_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC13_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC13_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC13_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC13_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VC13_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VC13_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 13 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VC13_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VC13_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_VMODULE (read-only):Application measurement result module voltage.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_VMODULE_OFFSET \
  (0x184EU)
#define MC33775_PRMM_APP_VMODULE_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VMODULE_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VMODULE_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VMODULE_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VMODULE_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_VMODULE_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_VMODULE_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VMODULE at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_VMODULE_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_VMODULE_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_AIN0 (read-only):Application measurement result AIN0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_AIN0_OFFSET \
  (0x184FU)
#define MC33775_PRMM_APP_AIN0_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN0_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN0_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN0_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN0_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN0_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN0_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN0 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_AIN0_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_AIN0_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_AIN1 (read-only):Application measurement result AIN1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_AIN1_OFFSET \
  (0x1850U)
#define MC33775_PRMM_APP_AIN1_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN1_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN1_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN1_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN1_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN1_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN1_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN1 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_AIN1_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_AIN1_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_AIN2 (read-only):Application measurement result AIN2.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_AIN2_OFFSET \
  (0x1851U)
#define MC33775_PRMM_APP_AIN2_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN2_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN2_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN2_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN2_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN2_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN2_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN2 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_AIN2_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_AIN2_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_APP_AIN3 (read-only):Application measurement result AIN3.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_APP_AIN3_OFFSET \
  (0x1852U)
#define MC33775_PRMM_APP_AIN3_RW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN3_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN3_WR_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN3_MW_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN3_RA_MSK \
  (0x0U)
#define MC33775_PRMM_APP_AIN3_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_APP_AIN3_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN3 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_APP_AIN3_VALUE_POS \
  (0U)
#define MC33775_PRMM_APP_AIN3_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_NUM (read-only):Measurement period number of the primary periodic results.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_NUM_OFFSET \
  (0x185FU)
#define MC33775_PRMM_PER_NUM_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_NUM_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_NUM_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_NUM_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_NUM_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_NUM_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_NUM_POR_VAL \
  (0x0U)

/* Field NUM: Number of the periodic cycle in which the primary periodic results have been created. The value is incremented for each periodic cycle executed. The counting wraps at its limit. */
#define MC33775_PRMM_PER_NUM_NUM_POS \
  (0U)
#define MC33775_PRMM_PER_NUM_NUM_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC0 (read-only):Periodic measurement result cell0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC0_OFFSET \
  (0x1860U)
#define MC33775_PRMM_PER_VC0_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC0_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC0_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC0_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC0_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC0_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC0_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 0 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC0_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC0_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC1 (read-only):Periodic measurement result cell1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC1_OFFSET \
  (0x1861U)
#define MC33775_PRMM_PER_VC1_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC1_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC1_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC1_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC1_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC1_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC1_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 1 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC1_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC1_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC2 (read-only):Periodic measurement result cell2.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC2_OFFSET \
  (0x1862U)
#define MC33775_PRMM_PER_VC2_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC2_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC2_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC2_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC2_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC2_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC2_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 2 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC2_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC2_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC3 (read-only):Periodic measurement result cell3.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC3_OFFSET \
  (0x1863U)
#define MC33775_PRMM_PER_VC3_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC3_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC3_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC3_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC3_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC3_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC3_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 3 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC3_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC3_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC4 (read-only):Periodic measurement result cell4.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC4_OFFSET \
  (0x1864U)
#define MC33775_PRMM_PER_VC4_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC4_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC4_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC4_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC4_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC4_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC4_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 4 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC4_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC4_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC5 (read-only):Periodic measurement result cell5.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC5_OFFSET \
  (0x1865U)
#define MC33775_PRMM_PER_VC5_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC5_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC5_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC5_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC5_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC5_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC5_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 5 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC5_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC5_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC6 (read-only):Periodic measurement result cell6.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC6_OFFSET \
  (0x1866U)
#define MC33775_PRMM_PER_VC6_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC6_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC6_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC6_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC6_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC6_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC6_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 6 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC6_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC6_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC7 (read-only):Periodic measurement result cell7.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC7_OFFSET \
  (0x1867U)
#define MC33775_PRMM_PER_VC7_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC7_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC7_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC7_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC7_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC7_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC7_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 7 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC7_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC7_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC8 (read-only):Periodic measurement result cell8.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC8_OFFSET \
  (0x1868U)
#define MC33775_PRMM_PER_VC8_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC8_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC8_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC8_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC8_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC8_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC8_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 8 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC8_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC8_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC9 (read-only):Periodic measurement result cell9.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC9_OFFSET \
  (0x1869U)
#define MC33775_PRMM_PER_VC9_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC9_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC9_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC9_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC9_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC9_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC9_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 9 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC9_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC9_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC10 (read-only):Periodic measurement result cell10.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC10_OFFSET \
  (0x186AU)
#define MC33775_PRMM_PER_VC10_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC10_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC10_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC10_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC10_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC10_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC10_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 10 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC10_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC10_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC11 (read-only):Periodic measurement result cell11.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC11_OFFSET \
  (0x186BU)
#define MC33775_PRMM_PER_VC11_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC11_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC11_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC11_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC11_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC11_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC11_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 11 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC11_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC11_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC12 (read-only):Periodic measurement result cell12.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC12_OFFSET \
  (0x186CU)
#define MC33775_PRMM_PER_VC12_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC12_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC12_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC12_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC12_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC12_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC12_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 12 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC12_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC12_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VC13 (read-only):Periodic measurement result cell13.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VC13_OFFSET \
  (0x186DU)
#define MC33775_PRMM_PER_VC13_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC13_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC13_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC13_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC13_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VC13_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VC13_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 13 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VC13_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VC13_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VMODULE (read-only):Periodic measurement result module voltage.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VMODULE_OFFSET \
  (0x186EU)
#define MC33775_PRMM_PER_VMODULE_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VMODULE_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VMODULE_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VMODULE_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VMODULE_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VMODULE_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VMODULE_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VMODULE of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VMODULE_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VMODULE_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_AIN0 (read-only):Periodic measurement result AIN0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_AIN0_OFFSET \
  (0x186FU)
#define MC33775_PRMM_PER_AIN0_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN0_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN0_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN0_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN0_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN0_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN0_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN0 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_AIN0_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_AIN0_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_AIN1 (read-only):Periodic measurement result AIN1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_AIN1_OFFSET \
  (0x1870U)
#define MC33775_PRMM_PER_AIN1_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN1_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN1_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN1_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN1_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN1_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN1_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN1 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_AIN1_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_AIN1_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_AIN2 (read-only):Periodic measurement result AIN2.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_AIN2_OFFSET \
  (0x1871U)
#define MC33775_PRMM_PER_AIN2_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN2_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN2_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN2_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN2_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN2_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN2_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN2 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_AIN2_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_AIN2_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_AIN3 (read-only):Periodic measurement result AIN3.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_AIN3_OFFSET \
  (0x1872U)
#define MC33775_PRMM_PER_AIN3_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN3_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN3_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN3_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN3_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_AIN3_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_AIN3_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN3 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_AIN3_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_AIN3_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_PRMTEMP (read-only):Periodic measurement result primary device temperature.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_PRMTEMP_OFFSET \
  (0x1873U)
#define MC33775_PRMM_PER_PRMTEMP_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_PRMTEMP_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_PRMTEMP_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_PRMTEMP_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_PRMTEMP_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_PRMTEMP_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_PRMTEMP_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured value of primary temperature sensor of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_PRMTEMP_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_PRMTEMP_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_SECVREF (read-only):Periodic measurement result secondary voltage reference.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_SECVREF_OFFSET \
  (0x1874U)
#define MC33775_PRMM_PER_SECVREF_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_SECVREF_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_SECVREF_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_SECVREF_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_SECVREF_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_SECVREF_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_SECVREF_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of secondary reference voltage of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_SECVREF_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_SECVREF_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VAUX (read-only):Periodic measurement result auxiliary supply voltage.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VAUX_OFFSET \
  (0x1875U)
#define MC33775_PRMM_PER_VAUX_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VAUX_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VAUX_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VAUX_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VAUX_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VAUX_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VAUX_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VAUX of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VAUX_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VAUX_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_PER_VDDC (read-only):Periodic measurement result VDDC.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_PER_VDDC_OFFSET \
  (0x1876U)
#define MC33775_PRMM_PER_VDDC_RW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VDDC_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VDDC_WR_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VDDC_MW_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VDDC_RA_MSK \
  (0x0U)
#define MC33775_PRMM_PER_VDDC_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_PER_VDDC_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VDDC of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_PER_VDDC_VALUE_POS \
  (0U)
#define MC33775_PRMM_PER_VDDC_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_NUM (read-only):Measurement period number of the synchronous results.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_NUM_OFFSET \
  (0x187FU)
#define MC33775_PRMM_SYNC_NUM_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_NUM_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_NUM_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_NUM_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_NUM_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_NUM_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_NUM_POR_VAL \
  (0x0U)

/* Field NUM: Number of the synchronous cycle in which the synchronous results have been created. The value is incremented for each synchronous cycle executed. The counting wraps at its limit. */
#define MC33775_PRMM_SYNC_NUM_NUM_POS \
  (0U)
#define MC33775_PRMM_SYNC_NUM_NUM_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC0 (read-only):Synchronous measurement result cell 0.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC0_OFFSET \
  (0x1880U)
#define MC33775_PRMM_SYNC_VC0_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC0_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC0_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC0_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC0_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC0_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC0_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 0 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC0_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC0_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC1 (read-only):Synchronous measurement result cell 1.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC1_OFFSET \
  (0x1881U)
#define MC33775_PRMM_SYNC_VC1_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC1_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC1_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC1_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC1_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC1_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC1_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 1 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC1_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC1_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC2 (read-only):Synchronous measurement result cell 2.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC2_OFFSET \
  (0x1882U)
#define MC33775_PRMM_SYNC_VC2_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC2_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC2_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC2_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC2_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC2_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC2_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 2 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC2_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC2_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC3 (read-only):Synchronous measurement result cell 3.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC3_OFFSET \
  (0x1883U)
#define MC33775_PRMM_SYNC_VC3_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC3_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC3_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC3_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC3_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC3_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC3_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 3 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC3_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC3_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC4 (read-only):Synchronous measurement result cell 4.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC4_OFFSET \
  (0x1884U)
#define MC33775_PRMM_SYNC_VC4_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC4_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC4_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC4_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC4_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC4_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC4_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 4 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC4_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC4_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC5 (read-only):Synchronous measurement result cell 5.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC5_OFFSET \
  (0x1885U)
#define MC33775_PRMM_SYNC_VC5_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC5_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC5_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC5_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC5_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC5_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC5_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 5 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC5_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC5_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC6 (read-only):Synchronous measurement result cell 6.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC6_OFFSET \
  (0x1886U)
#define MC33775_PRMM_SYNC_VC6_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC6_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC6_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC6_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC6_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC6_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC6_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 6 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC6_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC6_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC7 (read-only):Synchronous measurement result cell 7.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC7_OFFSET \
  (0x1887U)
#define MC33775_PRMM_SYNC_VC7_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC7_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC7_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC7_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC7_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC7_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC7_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 7 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC7_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC7_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC8 (read-only):Synchronous measurement result cell 8.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC8_OFFSET \
  (0x1888U)
#define MC33775_PRMM_SYNC_VC8_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC8_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC8_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC8_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC8_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC8_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC8_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 8 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC8_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC8_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC9 (read-only):Synchronous measurement result cell 9.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC9_OFFSET \
  (0x1889U)
#define MC33775_PRMM_SYNC_VC9_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC9_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC9_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC9_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC9_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC9_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC9_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 9 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC9_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC9_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC10 (read-only):Synchronous measurement result cell 10.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC10_OFFSET \
  (0x188AU)
#define MC33775_PRMM_SYNC_VC10_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC10_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC10_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC10_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC10_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC10_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC10_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 10 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC10_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC10_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC11 (read-only):Synchronous measurement result cell 11.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC11_OFFSET \
  (0x188BU)
#define MC33775_PRMM_SYNC_VC11_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC11_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC11_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC11_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC11_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC11_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC11_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 11 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC11_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC11_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC12 (read-only):Synchronous measurement result cell 12.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC12_OFFSET \
  (0x188CU)
#define MC33775_PRMM_SYNC_VC12_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC12_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC12_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC12_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC12_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC12_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC12_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 12 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC12_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC12_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC13 (read-only):Synchronous measurement result cell 13.
 * -------------------------------------------------------------------------- */
#define MC33775_PRMM_SYNC_VC13_OFFSET \
  (0x188DU)
#define MC33775_PRMM_SYNC_VC13_RW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC13_RD_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC13_WR_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC13_MW_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC13_RA_MSK \
  (0x0U)
#define MC33775_PRMM_SYNC_VC13_POR_MSK \
  (0xFFFFU)
#define MC33775_PRMM_SYNC_VC13_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 13 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_PRMM_SYNC_VC13_VALUE_POS \
  (0U)
#define MC33775_PRMM_SYNC_VC13_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_CFG (read-write):General measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_CFG_OFFSET \
  (0x1C00U)
#define MC33775_SECM_CFG_RW_MSK \
  (0xFFFFU)
#define MC33775_SECM_CFG_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_CFG_WR_MSK \
  (0xFFFFU)
#define MC33775_SECM_CFG_MW_MSK \
  (0x0U)
#define MC33775_SECM_CFG_RA_MSK \
  (0x0U)
#define MC33775_SECM_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_CFG_POR_VAL \
  (0x0U)

/* Field MEASEN: Enable the data acquisition. Setting this bit to zero initiates a result clear and invalidate action (this includes resetting all ready bits). The bit can only be set xxx us after it has been cleared. This bit is cleared when entering Sleep mode. Cyclic measurements are always executed, regardless of the value of this bit. Balancing is not stopped automatically (if in Active mode), as it would be permanently inhibited while measurement is active. If balancing shall be paused, please do so via the balancing control. */
#define MC33775_SECM_CFG_MEASEN_POS \
  (0U)
#define MC33775_SECM_CFG_MEASEN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Data acquisition disabled */
#define MC33775_SECM_CFG_MEASEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Data acquisition enabled */
#define MC33775_SECM_CFG_MEASEN_ENABLED_ENUM_VAL \
  (1U)

/* Field BALPAUSECYCMODEN: Enable balancing autopause. This delays the start of measurements after entering Cyclic mode until the autopause counter has elapsed. This field has no effect in secondary measurement. */
#define MC33775_SECM_CFG_BALPAUSECYCMODEN_POS \
  (1U)
#define MC33775_SECM_CFG_BALPAUSECYCMODEN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Autopause for balancing is disabled. */
#define MC33775_SECM_CFG_BALPAUSECYCMODEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Autopause for balancing is enabled. Measurements are started when the autopause counter is elapsed. */
#define MC33775_SECM_CFG_BALPAUSECYCMODEN_ENABLED_ENUM_VAL \
  (1U)

/* Field BALPAUSELEN: Pause of balancing before measurement cycle is executed. An on-going balancing pause operation is not influenced by a change of this value. 1 LSB = 10us. */
#define MC33775_SECM_CFG_BALPAUSELEN_POS \
  (2U)
#define MC33775_SECM_CFG_BALPAUSELEN_MSK \
  (0xFFFCU)

/* Enumerated value NO_PAUSE: No Pause. */
#define MC33775_SECM_CFG_BALPAUSELEN_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE_10u: Pause = 10 us */
#define MC33775_SECM_CFG_BALPAUSELEN_PAUSE_10U_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Maximum pause = 163830 us = 163 ms */
#define MC33775_SECM_CFG_BALPAUSELEN_MAX_ENUM_VAL \
  (16383U)


/* --------------------------------------------------------------------------
 * SECM_APP_CTRL (write-only):Application measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_APP_CTRL_OFFSET \
  (0x1C01U)
#define MC33775_SECM_APP_CTRL_RW_MSK \
  (0x0U)
#define MC33775_SECM_APP_CTRL_RD_MSK \
  (0x0U)
#define MC33775_SECM_APP_CTRL_WR_MSK \
  (0x83FFU)
#define MC33775_SECM_APP_CTRL_MW_MSK \
  (0x0U)
#define MC33775_SECM_APP_CTRL_RA_MSK \
  (0x0U)
#define MC33775_SECM_APP_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_CTRL_POR_VAL \
  (0x0U)

/* Field CAPVC: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the cell terminal measurements. */
#define MC33775_SECM_APP_CTRL_CAPVC_POS \
  (0U)
#define MC33775_SECM_APP_CTRL_CAPVC_MSK \
  (0x1U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPVC_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPVC_CAP_ENUM_VAL \
  (1U)

/* Field CAPVMODULE: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the module voltage measurement. */
#define MC33775_SECM_APP_CTRL_CAPVMODULE_POS \
  (1U)
#define MC33775_SECM_APP_CTRL_CAPVMODULE_MSK \
  (0x2U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPVMODULE_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPVMODULE_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN0: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the aux0 terminal measurement. */
#define MC33775_SECM_APP_CTRL_CAPAIN0_POS \
  (2U)
#define MC33775_SECM_APP_CTRL_CAPAIN0_MSK \
  (0x4U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN0_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN0_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN1: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the aux1 terminal measurement. */
#define MC33775_SECM_APP_CTRL_CAPAIN1_POS \
  (3U)
#define MC33775_SECM_APP_CTRL_CAPAIN1_MSK \
  (0x8U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN1_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN1_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN2: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the aux2 terminal measurement. */
#define MC33775_SECM_APP_CTRL_CAPAIN2_POS \
  (4U)
#define MC33775_SECM_APP_CTRL_CAPAIN2_MSK \
  (0x10U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN2_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN2_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN3: Trigger the balancing autopause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access. In primary: Capture the application measurement value of the aux3 terminal measurement. */
#define MC33775_SECM_APP_CTRL_CAPAIN3_POS \
  (5U)
#define MC33775_SECM_APP_CTRL_CAPAIN3_MSK \
  (0x20U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN3_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN3_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN4: Capture the application measurement value of the aux4 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33775_SECM_APP_CTRL_CAPAIN4_POS \
  (6U)
#define MC33775_SECM_APP_CTRL_CAPAIN4_MSK \
  (0x40U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN4_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN4_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN5: Capture the application measurement value of the aux5 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33775_SECM_APP_CTRL_CAPAIN5_POS \
  (7U)
#define MC33775_SECM_APP_CTRL_CAPAIN5_MSK \
  (0x80U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN5_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN5_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN6: Capture the application measurement value of the aux6 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33775_SECM_APP_CTRL_CAPAIN6_POS \
  (8U)
#define MC33775_SECM_APP_CTRL_CAPAIN6_MSK \
  (0x100U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN6_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN6_CAP_ENUM_VAL \
  (1U)

/* Field CAPAIN7: Capture the application measurement value of the aux7 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33775_SECM_APP_CTRL_CAPAIN7_POS \
  (9U)
#define MC33775_SECM_APP_CTRL_CAPAIN7_MSK \
  (0x200U)

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN7_NO_CAP_ENUM_VAL \
  (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33775_SECM_APP_CTRL_CAPAIN7_CAP_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_APP_CTRL_RESERVED0_POS \
  (10U)
#define MC33775_SECM_APP_CTRL_RESERVED0_MSK \
  (0x7C00U)

/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the autopause timer has elapsed. This field has no effect in secondary measurement. */
#define MC33775_SECM_APP_CTRL_PAUSEBAL_POS \
  (15U)
#define MC33775_SECM_APP_CTRL_PAUSEBAL_MSK \
  (0x8000U)

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33775_SECM_APP_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33775_SECM_APP_CTRL_PAUSEBAL_PAUSE_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * SECM_PER_CTRL (read-write):Periodic measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_CTRL_OFFSET \
  (0x1C02U)
#define MC33775_SECM_PER_CTRL_RW_MSK \
  (0x11FFU)
#define MC33775_SECM_PER_CTRL_RD_MSK \
  (0x11FFU)
#define MC33775_SECM_PER_CTRL_WR_MSK \
  (0x11FFU)
#define MC33775_SECM_PER_CTRL_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_CTRL_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_CTRL_POR_VAL \
  (0x10U)

/* Field PERLEN: Number of measurements for one periodic measurement. The minimum is 16. Writing a value lower than 16 leads to a 16 in the register. */
#define MC33775_SECM_PER_CTRL_PERLEN_POS \
  (0U)
#define MC33775_SECM_PER_CTRL_PERLEN_MSK \
  (0x1FFU)

/* Enumerated value PER_16: minimum value = 16 measurements per period */
#define MC33775_SECM_PER_CTRL_PERLEN_PER_16_ENUM_VAL \
  (16U)

/* Enumerated value PER_17: 17 measurements per period */
#define MC33775_SECM_PER_CTRL_PERLEN_PER_17_ENUM_VAL \
  (17U)

/* Enumerated value PER_MAX: maximum value = 511 measurements per period */
#define MC33775_SECM_PER_CTRL_PERLEN_PER_MAX_ENUM_VAL \
  (511U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_PER_CTRL_RESERVED0_POS \
  (9U)
#define MC33775_SECM_PER_CTRL_RESERVED0_MSK \
  (0xE00U)

/* Field PERCTRL: Control the periodic result behavior. */
#define MC33775_SECM_PER_CTRL_PERCTRL_POS \
  (12U)
#define MC33775_SECM_PER_CTRL_PERCTRL_MSK \
  (0x1000U)

/* Enumerated value AUTO: Periodic results are automatically updated */
#define MC33775_SECM_PER_CTRL_PERCTRL_AUTO_ENUM_VAL \
  (0U)

/* Enumerated value ONCE: Periodic results are updated once with the last results. (each write updates the results). */
#define MC33775_SECM_PER_CTRL_PERCTRL_ONCE_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_PER_CTRL_RESERVED1_POS \
  (13U)
#define MC33775_SECM_PER_CTRL_RESERVED1_MSK \
  (0xE000U)


/* --------------------------------------------------------------------------
 * SECM_SYNC_CTRL (read-write):Synchronous measurement control.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_CTRL_OFFSET \
  (0x1C03U)
#define MC33775_SECM_SYNC_CTRL_RW_MSK \
  (0x7C00U)
#define MC33775_SECM_SYNC_CTRL_RD_MSK \
  (0x7C00U)
#define MC33775_SECM_SYNC_CTRL_WR_MSK \
  (0xFC03U)
#define MC33775_SECM_SYNC_CTRL_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_CTRL_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_CTRL_POR_VAL \
  (0x7C00U)

/* Field SYNCCYC: Start a synchronous measurement cycle. In this cycle the CT and CB voltages are measured and stored as matching pairs. If no VB channel is enabled or if set during a running synchronous measurement cycle or a running Fast VB cycle, the set is ignored. Read as zero. */
#define MC33775_SECM_SYNC_CTRL_SYNCCYC_POS \
  (0U)
#define MC33775_SECM_SYNC_CTRL_SYNCCYC_MSK \
  (0x1U)

/* Enumerated value NO_START: No new start a synchronous measurement cycle. */
#define MC33775_SECM_SYNC_CTRL_SYNCCYC_NO_START_ENUM_VAL \
  (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33775_SECM_SYNC_CTRL_SYNCCYC_STATUS_ENUM_VAL \
  (0U)

/* Enumerated value START: Start a synchronous measurement cycle. */
#define MC33775_SECM_SYNC_CTRL_SYNCCYC_START_ENUM_VAL \
  (1U)

/* Field FASTVB: Start a Fast VB measurement cycle. Read as zero. */
#define MC33775_SECM_SYNC_CTRL_FASTVB_POS \
  (1U)
#define MC33775_SECM_SYNC_CTRL_FASTVB_MSK \
  (0x2U)

/* Enumerated value NO_FAST: No new start of a fast VB measurement cycle. */
#define MC33775_SECM_SYNC_CTRL_FASTVB_NO_FAST_ENUM_VAL \
  (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33775_SECM_SYNC_CTRL_FASTVB_STATUS_ENUM_VAL \
  (0U)

/* Enumerated value FAST: Start a new fast VB measurement cycle. */
#define MC33775_SECM_SYNC_CTRL_FASTVB_FAST_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_SYNC_CTRL_RESERVED0_POS \
  (2U)
#define MC33775_SECM_SYNC_CTRL_RESERVED0_MSK \
  (0x3FCU)

/* Field VBOLNUM: VB channel for which the open load detection is enabled. 0 - 13 = channel for which the open load detection is enabled. 14 - 29 = reserved (no open load detection mechanism is enabled). 30 = the open load detection is enabled for the currently measured channel. */
#define MC33775_SECM_SYNC_CTRL_VBOLNUM_POS \
  (10U)
#define MC33775_SECM_SYNC_CTRL_VBOLNUM_MSK \
  (0x7C00U)

/* Enumerated value DISABLED: Open load detection is disabled */
#define MC33775_SECM_SYNC_CTRL_VBOLNUM_DISABLED_ENUM_VAL \
  (31U)


/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the autopause timer has elapsed. If no capture cycle is started this bit is ignored. */
#define MC33775_SECM_SYNC_CTRL_PAUSEBAL_POS \
  (15U)
#define MC33775_SECM_SYNC_CTRL_PAUSEBAL_MSK \
  (0x8000U)

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33775_SECM_SYNC_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL \
  (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33775_SECM_SYNC_CTRL_PAUSEBAL_PAUSE_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * SECM_VB_CFG (read-write):Balance voltage measurement enable.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_VB_CFG_OFFSET \
  (0x1C08U)
#define MC33775_SECM_VB_CFG_RW_MSK \
  (0x3FFFU)
#define MC33775_SECM_VB_CFG_RD_MSK \
  (0x3FFFU)
#define MC33775_SECM_VB_CFG_WR_MSK \
  (0x3FFFU)
#define MC33775_SECM_VB_CFG_MW_MSK \
  (0x0U)
#define MC33775_SECM_VB_CFG_RA_MSK \
  (0x0U)
#define MC33775_SECM_VB_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_VB_CFG_POR_VAL \
  (0x0U)

/* Field VB0EN: Enable measurement of balance voltage 0. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB0EN_POS \
  (0U)
#define MC33775_SECM_VB_CFG_VB0EN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB0EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB0EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB1EN: Enable measurement of balance voltage 1. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB1EN_POS \
  (1U)
#define MC33775_SECM_VB_CFG_VB1EN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB1EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB1EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB2EN: Enable measurement of balance voltage 2. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB2EN_POS \
  (2U)
#define MC33775_SECM_VB_CFG_VB2EN_MSK \
  (0x4U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB2EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB2EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB3EN: Enable measurement of balance voltage 3. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB3EN_POS \
  (3U)
#define MC33775_SECM_VB_CFG_VB3EN_MSK \
  (0x8U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB3EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB3EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB4EN: Enable measurement of balance voltage 4. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB4EN_POS \
  (4U)
#define MC33775_SECM_VB_CFG_VB4EN_MSK \
  (0x10U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB4EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB4EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB5EN: Enable measurement of balance voltage 5. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB5EN_POS \
  (5U)
#define MC33775_SECM_VB_CFG_VB5EN_MSK \
  (0x20U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB5EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB5EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB6EN: Enable measurement of balance voltage 6. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB6EN_POS \
  (6U)
#define MC33775_SECM_VB_CFG_VB6EN_MSK \
  (0x40U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB6EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB6EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB7EN: Enable measurement of balance voltage 7. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB7EN_POS \
  (7U)
#define MC33775_SECM_VB_CFG_VB7EN_MSK \
  (0x80U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB7EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB7EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB8EN: Enable measurement of balance voltage 8. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB8EN_POS \
  (8U)
#define MC33775_SECM_VB_CFG_VB8EN_MSK \
  (0x100U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB8EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB8EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB9EN: Enable measurement of balance voltage 9. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB9EN_POS \
  (9U)
#define MC33775_SECM_VB_CFG_VB9EN_MSK \
  (0x200U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB9EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB9EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB10EN: Enable measurement of balance voltage 10. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB10EN_POS \
  (10U)
#define MC33775_SECM_VB_CFG_VB10EN_MSK \
  (0x400U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB10EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB10EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB11EN: Enable measurement of balance voltage 11. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB11EN_POS \
  (11U)
#define MC33775_SECM_VB_CFG_VB11EN_MSK \
  (0x800U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB11EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB11EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB12EN: Enable measurement of balance voltage 12. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB12EN_POS \
  (12U)
#define MC33775_SECM_VB_CFG_VB12EN_MSK \
  (0x1000U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB12EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB12EN_ENABLED_ENUM_VAL \
  (1U)

/* Field VB13EN: Enable measurement of balance voltage 13. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_VB_CFG_VB13EN_POS \
  (13U)
#define MC33775_SECM_VB_CFG_VB13EN_MSK \
  (0x2000U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_VB_CFG_VB13EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_VB_CFG_VB13EN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_VB_CFG_RESERVED0_POS \
  (14U)
#define MC33775_SECM_VB_CFG_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * SECM_AIN_CFG (read-write):Measurement enables for extra channel.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_AIN_CFG_OFFSET \
  (0x1C09U)
#define MC33775_SECM_AIN_CFG_RW_MSK \
  (0xFF8FU)
#define MC33775_SECM_AIN_CFG_RD_MSK \
  (0xFF8FU)
#define MC33775_SECM_AIN_CFG_WR_MSK \
  (0xFF8FU)
#define MC33775_SECM_AIN_CFG_MW_MSK \
  (0x0U)
#define MC33775_SECM_AIN_CFG_RA_MSK \
  (0x0U)
#define MC33775_SECM_AIN_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_AIN_CFG_POR_VAL \
  (0x80U)

/* Field AIN4EN: Enable measurement of AIN4. Changes to this bit during active measurement can lead to undefined results. Note: TBC Switches the GPIO4/AIN4 to the analog measurement function. */
#define MC33775_SECM_AIN_CFG_AIN4EN_POS \
  (0U)
#define MC33775_SECM_AIN_CFG_AIN4EN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_AIN_CFG_AIN4EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_AIN_CFG_AIN4EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN5EN: Enable measurement of AIN5. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_AIN_CFG_AIN5EN_POS \
  (1U)
#define MC33775_SECM_AIN_CFG_AIN5EN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_AIN_CFG_AIN5EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_AIN_CFG_AIN5EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN6EN: Enable measurement of AIN6. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_AIN_CFG_AIN6EN_POS \
  (2U)
#define MC33775_SECM_AIN_CFG_AIN6EN_MSK \
  (0x4U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_AIN_CFG_AIN6EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_AIN_CFG_AIN6EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN7EN: Enable measurement of AIN7. Changes to this bit during active measurement can lead to undefined results. */
#define MC33775_SECM_AIN_CFG_AIN7EN_POS \
  (3U)
#define MC33775_SECM_AIN_CFG_AIN7EN_MSK \
  (0x8U)

/* Enumerated value DISABLED: Measurement disabled */
#define MC33775_SECM_AIN_CFG_AIN7EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33775_SECM_AIN_CFG_AIN7EN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_AIN_CFG_RESERVED0_POS \
  (4U)
#define MC33775_SECM_AIN_CFG_RESERVED0_MSK \
  (0x70U)

/* Field FLTAPPINV: Invalidate AINx application results in case of fault. */
#define MC33775_SECM_AIN_CFG_FLTAPPINV_POS \
  (7U)
#define MC33775_SECM_AIN_CFG_FLTAPPINV_MSK \
  (0x80U)

/* Enumerated value VAILD: AINx application results are not invalidated in case of a fault */
#define MC33775_SECM_AIN_CFG_FLTAPPINV_VAILD_ENUM_VAL \
  (0U)

/* Enumerated value INVALID: AINx application results are invalidated when a fault is detected. */
#define MC33775_SECM_AIN_CFG_FLTAPPINV_INVALID_ENUM_VAL \
  (1U)

/* Field RATIOMETRICAIN4: Reference selection for AIN4. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN4_POS \
  (8U)
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN4_MSK \
  (0x300U)

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN4_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN4_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN4_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN4_VDDC_ENUM_VAL \
  (3U)

/* Field RATIOMETRICAIN5: Reference selection for AIN5. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN5_POS \
  (10U)
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN5_MSK \
  (0xC00U)

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN5_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN5_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN5_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN5_VDDC_ENUM_VAL \
  (3U)

/* Field RATIOMETRICAIN6: Reference selection for AIN6. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN6_POS \
  (12U)
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN6_MSK \
  (0x3000U)

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN6_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN6_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN6_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN6_VDDC_ENUM_VAL \
  (3U)

/* Field RATIOMETRICAIN7: Reference selection for AIN7. Changes to these bits during active measurement can lead to undefined results. */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN7_POS \
  (14U)
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN7_MSK \
  (0xC000U)

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN7_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN7_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN7_VAUX_ENUM_VAL \
  (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33775_SECM_AIN_CFG_RATIOMETRICAIN7_VDDC_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * SECM_AIN_OL_CFG (read-write):AINx open_load detection enable.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_AIN_OL_CFG_OFFSET \
  (0x1C0AU)
#define MC33775_SECM_AIN_OL_CFG_RW_MSK \
  (0xFU)
#define MC33775_SECM_AIN_OL_CFG_RD_MSK \
  (0xFU)
#define MC33775_SECM_AIN_OL_CFG_WR_MSK \
  (0xFU)
#define MC33775_SECM_AIN_OL_CFG_MW_MSK \
  (0x0U)
#define MC33775_SECM_AIN_OL_CFG_RA_MSK \
  (0x0U)
#define MC33775_SECM_AIN_OL_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_AIN_OL_CFG_POR_VAL \
  (0x0U)

/* Field AIN4EN: Open load detection circuit for AIN4 */
#define MC33775_SECM_AIN_OL_CFG_AIN4EN_POS \
  (0U)
#define MC33775_SECM_AIN_OL_CFG_AIN4EN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN4EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN4EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN5EN: Open load detection circuit for AIN5 */
#define MC33775_SECM_AIN_OL_CFG_AIN5EN_POS \
  (1U)
#define MC33775_SECM_AIN_OL_CFG_AIN5EN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN5EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN5EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN6EN: Open load detection circuit for AIN6 */
#define MC33775_SECM_AIN_OL_CFG_AIN6EN_POS \
  (2U)
#define MC33775_SECM_AIN_OL_CFG_AIN6EN_MSK \
  (0x4U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN6EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN6EN_ENABLED_ENUM_VAL \
  (1U)

/* Field AIN7EN: Open load detection circuit for AIN7 */
#define MC33775_SECM_AIN_OL_CFG_AIN7EN_POS \
  (3U)
#define MC33775_SECM_AIN_OL_CFG_AIN7EN_MSK \
  (0x8U)

/* Enumerated value DISABLED: Disable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN7EN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Enable the open load detection circuit. */
#define MC33775_SECM_AIN_OL_CFG_AIN7EN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_AIN_OL_CFG_RESERVED0_POS \
  (4U)
#define MC33775_SECM_AIN_OL_CFG_RESERVED0_MSK \
  (0xFFF0U)


/* --------------------------------------------------------------------------
 * SECM_VDIV_CFG (read-write):Voltage divider enable.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_VDIV_CFG_OFFSET \
  (0x1C0BU)
#define MC33775_SECM_VDIV_CFG_RW_MSK \
  (0x3U)
#define MC33775_SECM_VDIV_CFG_RD_MSK \
  (0x3U)
#define MC33775_SECM_VDIV_CFG_WR_MSK \
  (0x3U)
#define MC33775_SECM_VDIV_CFG_MW_MSK \
  (0x0U)
#define MC33775_SECM_VDIV_CFG_RA_MSK \
  (0x0U)
#define MC33775_SECM_VDIV_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_VDIV_CFG_POR_VAL \
  (0x3U)

/* Field VAUXEN: Enable the voltage divider for secondary VAUX measurement. */
#define MC33775_SECM_VDIV_CFG_VAUXEN_POS \
  (0U)
#define MC33775_SECM_VDIV_CFG_VAUXEN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Voltage divider for VAUX is disabled. */
#define MC33775_SECM_VDIV_CFG_VAUXEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Voltage divider for VAUX is enabled. */
#define MC33775_SECM_VDIV_CFG_VAUXEN_ENABLED_ENUM_VAL \
  (1U)

/* Field VDDCEN: Enable the voltage divider for secondary VDDC measurement. */
#define MC33775_SECM_VDIV_CFG_VDDCEN_POS \
  (1U)
#define MC33775_SECM_VDIV_CFG_VDDCEN_MSK \
  (0x2U)

/* Enumerated value DISABLED: Voltage divider for VDDC is disabled. */
#define MC33775_SECM_VDIV_CFG_VDDCEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Voltage divider for VDDC is enabled. */
#define MC33775_SECM_VDIV_CFG_VDDCEN_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_VDIV_CFG_RESERVED0_POS \
  (2U)
#define MC33775_SECM_VDIV_CFG_RESERVED0_MSK \
  (0xFFFCU)


/* --------------------------------------------------------------------------
 * SECM_CAL_CRC (read-write):CRC over calibration data.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_CAL_CRC_OFFSET \
  (0x1C1EU)
#define MC33775_SECM_CAL_CRC_RW_MSK \
  (0xFFFFU)
#define MC33775_SECM_CAL_CRC_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_CAL_CRC_WR_MSK \
  (0xFFFFU)
#define MC33775_SECM_CAL_CRC_MW_MSK \
  (0x0U)
#define MC33775_SECM_CAL_CRC_RA_MSK \
  (0x0U)
#define MC33775_SECM_CAL_CRC_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_CAL_CRC_POR_VAL \
  (0x0U)

/* Field CRC: CRC over calibration data. The CRC calculation runs automatically every time when a synchronous measurement cycle is started and when the calibration data is read from the NVM. */
#define MC33775_SECM_CAL_CRC_CRC_POS \
  (0U)
#define MC33775_SECM_CAL_CRC_CRC_MSK \
  (0xFFFFU)

/* Enumerated value CALIBCRC: The expected value of the calibration CRC. */
#define MC33775_SECM_CAL_CRC_CRC_CALIBCRC_ENUM_VAL \
  (48879U)


/* --------------------------------------------------------------------------
 * SECM_CFG_CRC (read-only):CRC over configuration values.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_CFG_CRC_OFFSET \
  (0x1C1FU)
#define MC33775_SECM_CFG_CRC_RW_MSK \
  (0x0U)
#define MC33775_SECM_CFG_CRC_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_CFG_CRC_WR_MSK \
  (0x0U)
#define MC33775_SECM_CFG_CRC_MW_MSK \
  (0x0U)
#define MC33775_SECM_CFG_CRC_RA_MSK \
  (0x0U)
#define MC33775_SECM_CFG_CRC_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_CFG_CRC_POR_VAL \
  (0x0U)

/* Field CRC: This CRC value is recalculated with any write to a covered register. The updated CRC value is available latest 100us after the last write. The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1.
Following registers are included: SECM_CFG, SECM_PER_CTRL, SECM_VB_CFG, SECM_AIN_CFG, SECM_VDIV_CFG. */
#define MC33775_SECM_CFG_CRC_CRC_POS \
  (0U)
#define MC33775_SECM_CFG_CRC_CRC_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_MEAS_STAT (read-only):Measurement status.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_MEAS_STAT_OFFSET \
  (0x1C3EU)
#define MC33775_SECM_MEAS_STAT_RW_MSK \
  (0x0U)
#define MC33775_SECM_MEAS_STAT_RD_MSK \
  (0xF70FU)
#define MC33775_SECM_MEAS_STAT_WR_MSK \
  (0x0U)
#define MC33775_SECM_MEAS_STAT_MW_MSK \
  (0x0U)
#define MC33775_SECM_MEAS_STAT_RA_MSK \
  (0x0U)
#define MC33775_SECM_MEAS_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_MEAS_STAT_POR_VAL \
  (0x0U)

/* Field APPRDYAIN4: A new AIN4 application result can be requested / captured. */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN4_POS \
  (0U)
#define MC33775_SECM_MEAS_STAT_APPRDYAIN4_MSK \
  (0x1U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN4_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN4_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYAIN5: A new AIN5 application result can be requested / captured. */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN5_POS \
  (1U)
#define MC33775_SECM_MEAS_STAT_APPRDYAIN5_MSK \
  (0x2U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN5_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN5_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYAIN6: A new AIN6 application result can be requested / captured. */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN6_POS \
  (2U)
#define MC33775_SECM_MEAS_STAT_APPRDYAIN6_MSK \
  (0x4U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN6_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN6_DATA_ENUM_VAL \
  (1U)

/* Field APPRDYAIN7: A new AIN7 application result can be requested / captured. */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN7_POS \
  (3U)
#define MC33775_SECM_MEAS_STAT_APPRDYAIN7_MSK \
  (0x8U)

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN7_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33775_SECM_MEAS_STAT_APPRDYAIN7_DATA_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_MEAS_STAT_RESERVED0_POS \
  (4U)
#define MC33775_SECM_MEAS_STAT_RESERVED0_MSK \
  (0xF0U)

/* Field PERRDY: New periodic result data has been created (depending on the periodic update mode, they might need to be requested) , the bit is cleared by a read into the periodic result range. */
#define MC33775_SECM_MEAS_STAT_PERRDY_POS \
  (8U)
#define MC33775_SECM_MEAS_STAT_PERRDY_MSK \
  (0x100U)

/* Enumerated value NO_DATA: No data available */
#define MC33775_SECM_MEAS_STAT_PERRDY_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33775_SECM_MEAS_STAT_PERRDY_DATA_ENUM_VAL \
  (1U)

/* Field SYNCRDY: Synchronous measurement data is ready for readout, the bit is cleared by a read to any register in the range SECM_SYNC_VB0 to SECM_SYNC_VB13 or if a fast VB measurement cycle is completed. */
#define MC33775_SECM_MEAS_STAT_SYNCRDY_POS \
  (9U)
#define MC33775_SECM_MEAS_STAT_SYNCRDY_MSK \
  (0x200U)

/* Enumerated value NO_DATA: No data available */
#define MC33775_SECM_MEAS_STAT_SYNCRDY_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33775_SECM_MEAS_STAT_SYNCRDY_DATA_ENUM_VAL \
  (1U)

/* Field FASTVBRDY: Fast VB measurement data is ready for readout, the bit is cleared by a read to any register in the range SECM_SYNC_VB0 to SECM_SYNC_VB13 or if a synchronous measurement cycle is completed. */
#define MC33775_SECM_MEAS_STAT_FASTVBRDY_POS \
  (10U)
#define MC33775_SECM_MEAS_STAT_FASTVBRDY_MSK \
  (0x400U)

/* Enumerated value NO_DATA: No data available */
#define MC33775_SECM_MEAS_STAT_FASTVBRDY_NO_DATA_ENUM_VAL \
  (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33775_SECM_MEAS_STAT_FASTVBRDY_DATA_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_SECM_MEAS_STAT_RESERVED1_POS \
  (11U)
#define MC33775_SECM_MEAS_STAT_RESERVED1_MSK \
  (0x800U)

/* Field SUPPLYFLT: Internal/external supply fault status */
#define MC33775_SECM_MEAS_STAT_SUPPLYFLT_POS \
  (12U)
#define MC33775_SECM_MEAS_STAT_SUPPLYFLT_MSK \
  (0x1000U)

/* Enumerated value NO_FLT: No supply error detected */
#define MC33775_SECM_MEAS_STAT_SUPPLYFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Supply error detected */
#define MC33775_SECM_MEAS_STAT_SUPPLYFLT_FAULT_ENUM_VAL \
  (1U)

/* Field ANAFLT: Analog fault status */
#define MC33775_SECM_MEAS_STAT_ANAFLT_POS \
  (13U)
#define MC33775_SECM_MEAS_STAT_ANAFLT_MSK \
  (0x2000U)

/* Enumerated value NO_FLT: No analog fault detected */
#define MC33775_SECM_MEAS_STAT_ANAFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Analog fault detected */
#define MC33775_SECM_MEAS_STAT_ANAFLT_FAULT_ENUM_VAL \
  (1U)

/* Field COMFLT: Communication fault status */
#define MC33775_SECM_MEAS_STAT_COMFLT_POS \
  (14U)
#define MC33775_SECM_MEAS_STAT_COMFLT_MSK \
  (0x4000U)

/* Enumerated value NO_FLT: No communication fault detected */
#define MC33775_SECM_MEAS_STAT_COMFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Communication fault detected. */
#define MC33775_SECM_MEAS_STAT_COMFLT_FAULT_ENUM_VAL \
  (1U)

/* Field MEASFLT: Measurement fault status */
#define MC33775_SECM_MEAS_STAT_MEASFLT_POS \
  (15U)
#define MC33775_SECM_MEAS_STAT_MEASFLT_MSK \
  (0x8000U)

/* Enumerated value NO_FLT: No measurement fault detected */
#define MC33775_SECM_MEAS_STAT_MEASFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Measurement fault detected */
#define MC33775_SECM_MEAS_STAT_MEASFLT_FAULT_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * SECM_APP_AIN4 (read-only):Application measurement result AIN4.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_APP_AIN4_OFFSET \
  (0x1C4FU)
#define MC33775_SECM_APP_AIN4_RW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN4_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN4_WR_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN4_MW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN4_RA_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN4_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN4_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN4 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_APP_AIN4_VALUE_POS \
  (0U)
#define MC33775_SECM_APP_AIN4_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_APP_AIN5 (read-only):Application measurement result AIN5.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_APP_AIN5_OFFSET \
  (0x1C50U)
#define MC33775_SECM_APP_AIN5_RW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN5_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN5_WR_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN5_MW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN5_RA_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN5_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN5_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN5 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_APP_AIN5_VALUE_POS \
  (0U)
#define MC33775_SECM_APP_AIN5_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_APP_AIN6 (read-only):Application measurement result AIN6.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_APP_AIN6_OFFSET \
  (0x1C51U)
#define MC33775_SECM_APP_AIN6_RW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN6_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN6_WR_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN6_MW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN6_RA_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN6_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN6_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN6 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_APP_AIN6_VALUE_POS \
  (0U)
#define MC33775_SECM_APP_AIN6_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_APP_AIN7 (read-only):Application measurement result AIN7.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_APP_AIN7_OFFSET \
  (0x1C52U)
#define MC33775_SECM_APP_AIN7_RW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN7_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN7_WR_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN7_MW_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN7_RA_MSK \
  (0x0U)
#define MC33775_SECM_APP_AIN7_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_APP_AIN7_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN7 at the last application capture as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_APP_AIN7_VALUE_POS \
  (0U)
#define MC33775_SECM_APP_AIN7_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_NUM (read-only):Measurement period number of the secondary periodic results.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_NUM_OFFSET \
  (0x1C5FU)
#define MC33775_SECM_PER_NUM_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_NUM_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_NUM_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_NUM_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_NUM_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_NUM_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_NUM_POR_VAL \
  (0x0U)

/* Field NUM: Number of the periodic cycle in which the secondary periodic results have been created. The value is incremented for each periodic cycle executed. The counting wraps at its limit. */
#define MC33775_SECM_PER_NUM_NUM_POS \
  (0U)
#define MC33775_SECM_PER_NUM_NUM_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_AIN4 (read-only):Periodic measurement result AIN4.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_AIN4_OFFSET \
  (0x1C6FU)
#define MC33775_SECM_PER_AIN4_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN4_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN4_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN4_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN4_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN4_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN4_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN4 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_AIN4_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_AIN4_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_AIN5 (read-only):Periodic measurement result AIN5.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_AIN5_OFFSET \
  (0x1C70U)
#define MC33775_SECM_PER_AIN5_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN5_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN5_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN5_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN5_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN5_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN5_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN5 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_AIN5_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_AIN5_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_AIN6 (read-only):Periodic measurement result AIN6.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_AIN6_OFFSET \
  (0x1C71U)
#define MC33775_SECM_PER_AIN6_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN6_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN6_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN6_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN6_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN6_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN6_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN6 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_AIN6_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_AIN6_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_AIN7 (read-only):Periodic measurement result AIN7.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_AIN7_OFFSET \
  (0x1C72U)
#define MC33775_SECM_PER_AIN7_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN7_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN7_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN7_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN7_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_AIN7_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_AIN7_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of AIN7 of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_AIN7_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_AIN7_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_SECTEMP (read-only):Periodic measurement result secondary device temperature.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_SECTEMP_OFFSET \
  (0x1C73U)
#define MC33775_SECM_PER_SECTEMP_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_SECTEMP_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_SECTEMP_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_SECTEMP_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_SECTEMP_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_SECTEMP_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_SECTEMP_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured temperature of secondary temperature sensor of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_SECTEMP_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_SECTEMP_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_PRMVREF (read-only):Periodic measurement result primary voltage reference.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_PRMVREF_OFFSET \
  (0x1C74U)
#define MC33775_SECM_PER_PRMVREF_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_PRMVREF_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_PRMVREF_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_PRMVREF_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_PRMVREF_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_PRMVREF_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_PRMVREF_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of the primary voltage reference of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_PRMVREF_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_PRMVREF_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_VAUX (read-only):Periodic measurement result auxiliary supply voltage.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_VAUX_OFFSET \
  (0x1C75U)
#define MC33775_SECM_PER_VAUX_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VAUX_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VAUX_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_VAUX_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VAUX_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_VAUX_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VAUX_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VAUX of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_VAUX_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_VAUX_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_VBAT (read-only):Periodic measurement result VBAT.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_VBAT_OFFSET \
  (0x1C76U)
#define MC33775_SECM_PER_VBAT_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VBAT_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VBAT_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_VBAT_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VBAT_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_VBAT_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VBAT_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VBAT of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_VBAT_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_VBAT_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_VDDA (read-only):Periodic measurement result VDDA.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_VDDA_OFFSET \
  (0x1C77U)
#define MC33775_SECM_PER_VDDA_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDA_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VDDA_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDA_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDA_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDA_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VDDA_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VDDA of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_VDDA_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_VDDA_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_VDDC (read-only):Periodic measurement result VDDC.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_VDDC_OFFSET \
  (0x1C78U)
#define MC33775_SECM_PER_VDDC_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDC_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VDDC_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDC_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDC_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_VDDC_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_VDDC_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of VDDC of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_VDDC_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_VDDC_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_PER_NPNISENSE (read-only):Periodic measurement result NPN current sensor.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_PER_NPNISENSE_OFFSET \
  (0x1C7AU)
#define MC33775_SECM_PER_NPNISENSE_RW_MSK \
  (0x0U)
#define MC33775_SECM_PER_NPNISENSE_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_NPNISENSE_WR_MSK \
  (0x0U)
#define MC33775_SECM_PER_NPNISENSE_MW_MSK \
  (0x0U)
#define MC33775_SECM_PER_NPNISENSE_RA_MSK \
  (0x0U)
#define MC33775_SECM_PER_NPNISENSE_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_PER_NPNISENSE_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of NPN current sensor of the periodic cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_PER_NPNISENSE_VALUE_POS \
  (0U)
#define MC33775_SECM_PER_NPNISENSE_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_NUM (read-only):Measurement number of the secondary synchronous results.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_NUM_OFFSET \
  (0x1C7FU)
#define MC33775_SECM_SYNC_NUM_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_NUM_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_NUM_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_NUM_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_NUM_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_NUM_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_NUM_POR_VAL \
  (0x0U)

/* Field NUM: Number of the synchronous cycle in which the secondary results have been created. The value is incremented for each synchronous cycle executed. The counting wraps at its limit. The value is not incremented for FASTVB cycle. */
#define MC33775_SECM_SYNC_NUM_NUM_POS \
  (0U)
#define MC33775_SECM_SYNC_NUM_NUM_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB0 (read-only):Synchronous measurement result from balancing pins cell 0.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB0_OFFSET \
  (0x1C80U)
#define MC33775_SECM_SYNC_VB0_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB0_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB0_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB0_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB0_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB0_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB0_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 0 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB0_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB0_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB1 (read-only):Synchronous measurement result from balancing pins cell 1.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB1_OFFSET \
  (0x1C81U)
#define MC33775_SECM_SYNC_VB1_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB1_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB1_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB1_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB1_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB1_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB1_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 1 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB1_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB1_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB2 (read-only):Synchronous measurement result from balancing pins cell 2.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB2_OFFSET \
  (0x1C82U)
#define MC33775_SECM_SYNC_VB2_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB2_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB2_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB2_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB2_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB2_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB2_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 2 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB2_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB2_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB3 (read-only):Synchronous measurement result from balancing pins cell 3.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB3_OFFSET \
  (0x1C83U)
#define MC33775_SECM_SYNC_VB3_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB3_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB3_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB3_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB3_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB3_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB3_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 3 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB3_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB3_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB4 (read-only):Synchronous measurement result from balancing pins cell 4.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB4_OFFSET \
  (0x1C84U)
#define MC33775_SECM_SYNC_VB4_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB4_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB4_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB4_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB4_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB4_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB4_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 4 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB4_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB4_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB5 (read-only):Synchronous measurement result from balancing pins cell 5.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB5_OFFSET \
  (0x1C85U)
#define MC33775_SECM_SYNC_VB5_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB5_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB5_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB5_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB5_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB5_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB5_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 5 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB5_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB5_VALUE_MSK \
  (0xFFFFU)

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB6 (read-only):Synchronous measurement result from balancing pins cell 6.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB6_OFFSET \
  (0x1C86U)
#define MC33775_SECM_SYNC_VB6_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB6_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB6_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB6_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB6_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB6_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB6_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 6 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB6_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB6_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB7 (read-only):Synchronous measurement result from balancing pins cell 7.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB7_OFFSET \
  (0x1C87U)
#define MC33775_SECM_SYNC_VB7_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB7_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB7_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB7_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB7_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB7_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB7_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 7 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB7_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB7_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB8 (read-only):Synchronous measurement result from balancing pins cell 8.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB8_OFFSET \
  (0x1C88U)
#define MC33775_SECM_SYNC_VB8_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB8_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB8_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB8_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB8_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB8_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB8_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 8 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB8_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB8_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB9 (read-only):Synchronous measurement result from balancing pins cell 9.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB9_OFFSET \
  (0x1C89U)
#define MC33775_SECM_SYNC_VB9_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB9_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB9_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB9_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB9_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB9_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB9_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 9 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB9_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB9_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB10 (read-only):Synchronous measurement result from balancing pins cell 10.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB10_OFFSET \
  (0x1C8AU)
#define MC33775_SECM_SYNC_VB10_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB10_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB10_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB10_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB10_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB10_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB10_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 10 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB10_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB10_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB11 (read-only):Synchronous measurement result from balancing pins cell 11.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB11_OFFSET \
  (0x1C8BU)
#define MC33775_SECM_SYNC_VB11_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB11_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB11_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB11_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB11_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB11_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB11_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 11 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB11_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB11_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB12 (read-only):Synchronous measurement result from balancing pins cell 12.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB12_OFFSET \
  (0x1C8CU)
#define MC33775_SECM_SYNC_VB12_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB12_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB12_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB12_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB12_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB12_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB12_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 12 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB12_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB12_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * SECM_SYNC_VB13 (read-only):Synchronous measurement result from balancing pins cell 13.
 * -------------------------------------------------------------------------- */
#define MC33775_SECM_SYNC_VB13_OFFSET \
  (0x1C8DU)
#define MC33775_SECM_SYNC_VB13_RW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB13_RD_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB13_WR_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB13_MW_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB13_RA_MSK \
  (0x0U)
#define MC33775_SECM_SYNC_VB13_POR_MSK \
  (0xFFFFU)
#define MC33775_SECM_SYNC_VB13_POR_VAL \
  (0x8000U)

/* Field VALUE: Measured voltage of cell 13 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (0x8000). */
#define MC33775_SECM_SYNC_VB13_VALUE_POS \
  (0U)
#define MC33775_SECM_SYNC_VB13_VALUE_MSK \
  (0xFFFFU)


/* --------------------------------------------------------------------------
 * BAL_GLOB_CFG (read-write):The global balancing configuration register is used to configure the balancing modes.
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_GLOB_CFG_OFFSET \
  (0x1000U)
#define MC33775_BAL_GLOB_CFG_RW_MSK \
  (0x31FU)
#define MC33775_BAL_GLOB_CFG_RD_MSK \
  (0x31FU)
#define MC33775_BAL_GLOB_CFG_WR_MSK \
  (0x31FU)
#define MC33775_BAL_GLOB_CFG_MW_MSK \
  (0x0U)
#define MC33775_BAL_GLOB_CFG_RA_MSK \
  (0x0U)
#define MC33775_BAL_GLOB_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_GLOB_CFG_POR_VAL \
  (0x0U)

/* Field BALEN: Enables the balancing activity. This bit is cleared in case of a balancing timeout or if an enabled global under-voltage condition is reached. All channel individual counters are stopped if zero. The emergency discharge works without setting this bit. */
#define MC33775_BAL_GLOB_CFG_BALEN_POS \
  (0U)
#define MC33775_BAL_GLOB_CFG_BALEN_MSK \
  (0x1U)

/* Enumerated value DISABLED: Balancing is disabled. */
#define MC33775_BAL_GLOB_CFG_BALEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing is enabled. */
#define MC33775_BAL_GLOB_CFG_BALEN_ENABLED_ENUM_VAL \
  (1U)

/* Field TMRBALEN: Enables the timer based balancing feature. All channel individual counters are stopped if zero. */
#define MC33775_BAL_GLOB_CFG_TMRBALEN_POS \
  (1U)
#define MC33775_BAL_GLOB_CFG_TMRBALEN_MSK \
  (0x2U)

/* Enumerated value INDEPENDENT: Balancing is independent of the cell balancing timer. */
#define MC33775_BAL_GLOB_CFG_TMRBALEN_INDEPENDENT_ENUM_VAL \
  (0U)

/* Enumerated value STOP: Balancing for all cells will be stopped when cell balancing timer expires. */
#define MC33775_BAL_GLOB_CFG_TMRBALEN_STOP_ENUM_VAL \
  (1U)

/* Field CHUV0BALEN: Enables the voltage based balancing for the individual channel. Balancing stops once each individual channel reaches the under-voltage threshold. */
#define MC33775_BAL_GLOB_CFG_CHUV0BALEN_POS \
  (2U)
#define MC33775_BAL_GLOB_CFG_CHUV0BALEN_MSK \
  (0x4U)

/* Enumerated value INDEPENDENT: Balancing is independent of the cell undervoltage threshold. */
#define MC33775_BAL_GLOB_CFG_CHUV0BALEN_INDEPENDENT_ENUM_VAL \
  (0U)

/* Enumerated value STOP: Balancing for the individual cells stops once the cell undervoltage threshold is reached. */
#define MC33775_BAL_GLOB_CFG_CHUV0BALEN_STOP_ENUM_VAL \
  (1U)

/* Field GLOBUV1BALEN: Enables the Global undervoltage based balancing feature. */
#define MC33775_BAL_GLOB_CFG_GLOBUV1BALEN_POS \
  (3U)
#define MC33775_BAL_GLOB_CFG_GLOBUV1BALEN_MSK \
  (0x8U)

/* Enumerated value INDEPENDENT: Balancing is independent of the global undervoltage threshold. */
#define MC33775_BAL_GLOB_CFG_GLOBUV1BALEN_INDEPENDENT_ENUM_VAL \
  (0U)

/* Enumerated value STOP: Balancing for all cells stops once the global undervoltage threshold is reached by any cell. */
#define MC33775_BAL_GLOB_CFG_GLOBUV1BALEN_STOP_ENUM_VAL \
  (1U)

/* Field TEMPMODBALEN: Enables the temperature modulated balancing. After an over-temperature condition the balancing is halted until an under-temperature condition is detected. */
#define MC33775_BAL_GLOB_CFG_TEMPMODBALEN_POS \
  (4U)
#define MC33775_BAL_GLOB_CFG_TEMPMODBALEN_MSK \
  (0x10U)

/* Enumerated value NOTEMPMOD: Balancing is not temperature modulated. */
#define MC33775_BAL_GLOB_CFG_TEMPMODBALEN_NOTEMPMOD_ENUM_VAL \
  (0U)

/* Enumerated value TEMPMOD: Balancing is temperature modulated. */
#define MC33775_BAL_GLOB_CFG_TEMPMODBALEN_TEMPMOD_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_GLOB_CFG_RESERVED0_POS \
  (5U)
#define MC33775_BAL_GLOB_CFG_RESERVED0_MSK \
  (0xE0U)

/* Field TEMPSRC: Selects the source channel (AINx) for temperature modulated balancing. */
#define MC33775_BAL_GLOB_CFG_TEMPSRC_POS \
  (8U)
#define MC33775_BAL_GLOB_CFG_TEMPSRC_MSK \
  (0x300U)

/* Enumerated value AIN0: Selects AIN0 as source for temperature measurement. */
#define MC33775_BAL_GLOB_CFG_TEMPSRC_AIN0_ENUM_VAL \
  (0U)

/* Enumerated value AIN1: Selects AIN1 as source for temperature measurement. */
#define MC33775_BAL_GLOB_CFG_TEMPSRC_AIN1_ENUM_VAL \
  (1U)

/* Enumerated value AIN2: Selects AIN2 as source for temperature measurement. */
#define MC33775_BAL_GLOB_CFG_TEMPSRC_AIN2_ENUM_VAL \
  (2U)

/* Enumerated value AIN3: Selects AIN3 as source for temperature measurement. */
#define MC33775_BAL_GLOB_CFG_TEMPSRC_AIN3_ENUM_VAL \
  (3U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_GLOB_CFG_RESERVED1_POS \
  (10U)
#define MC33775_BAL_GLOB_CFG_RESERVED1_MSK \
  (0xFC00U)


/* --------------------------------------------------------------------------
 * BAL_GLOB_TO_TMR (read-write):The Global Balancing timeout timer register is used to configure the maximum balancing time for all balancing activities to make sure that in case of fault the balancing switches are switched OFF.
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_GLOB_TO_TMR_OFFSET \
  (0x1001U)
#define MC33775_BAL_GLOB_TO_TMR_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_GLOB_TO_TMR_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_GLOB_TO_TMR_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_GLOB_TO_TMR_MW_MSK \
  (0x0U)
#define MC33775_BAL_GLOB_TO_TMR_RA_MSK \
  (0x0U)
#define MC33775_BAL_GLOB_TO_TMR_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_GLOB_TO_TMR_POR_VAL \
  (0x0U)

/* Field TOTIME: Balancing timeout value, used for normal balancing. The value of this field represents the current counter value when read. The BAL_GLOB_CFG.BALEN is cleared when zero is reached. The counter saturates at zero. It counts down regardless of the balancing enable state as long as its value is non-zero. */
#define MC33775_BAL_GLOB_TO_TMR_TOTIME_POS \
  (0U)
#define MC33775_BAL_GLOB_TO_TMR_TOTIME_MSK \
  (0xFFFFU)

/* Enumerated value EXPIRED: Balancing time is expired */
#define MC33775_BAL_GLOB_TO_TMR_TOTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_GLOB_TO_TMR_TOTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Maximum balancing time = 655350 seconds = approximately 182 hours = approximately 7.6 days */
#define MC33775_BAL_GLOB_TO_TMR_TOTIME_MAX_ENUM_VAL \
  (65535U)


/* --------------------------------------------------------------------------
 * BAL_CH_CFG (read-write):Balancing channel individual enable
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_CH_CFG_OFFSET \
  (0x1002U)
#define MC33775_BAL_CH_CFG_RW_MSK \
  (0x3FFFU)
#define MC33775_BAL_CH_CFG_RD_MSK \
  (0x3FFFU)
#define MC33775_BAL_CH_CFG_WR_MSK \
  (0x3FFFU)
#define MC33775_BAL_CH_CFG_MW_MSK \
  (0x0U)
#define MC33775_BAL_CH_CFG_RA_MSK \
  (0x0U)
#define MC33775_BAL_CH_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_CH_CFG_POR_VAL \
  (0x0U)

/* Field CHEN0: Enable balancing for channel 0. The bit is cleared by the device in case of: a) a detected over-current condition on channel 0. b) a detected and enabled individual under-voltage condition for channel 0. c) the channel timer of channel 0 (BAL_TMR_CH0) is zero. */
#define MC33775_BAL_CH_CFG_CHEN0_POS \
  (0U)
#define MC33775_BAL_CH_CFG_CHEN0_MSK \
  (0x1U)

/* Enumerated value DISABLED: Balancing for Channel 0 is disabled. The balancing timer for Channel 0 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 0 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN0_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN1: Enable balancing for channel 1. The bit is cleared by the device in case of: a) a detected over-current condition on channel 1. b) a detected and enabled individual under-voltage condition for channel 1. c) the channel timer of channel 0 (BAL_TMR_CH1) is zero. */
#define MC33775_BAL_CH_CFG_CHEN1_POS \
  (1U)
#define MC33775_BAL_CH_CFG_CHEN1_MSK \
  (0x2U)

/* Enumerated value DISABLED: Balancing for Channel 1 is disabled. The balancing timer for Channel 1 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 1 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN1_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN2: Enable balancing for channel 2. The bit is cleared by the device in case of: a) a detected over-current condition on channel 2. b) a detected and enabled individual under-voltage condition for channel 2. c) the channel timer of channel 0 (BAL_TMR_CH2) is zero. */
#define MC33775_BAL_CH_CFG_CHEN2_POS \
  (2U)
#define MC33775_BAL_CH_CFG_CHEN2_MSK \
  (0x4U)

/* Enumerated value DISABLED: Balancing for Channel 2 is disabled. The balancing timer for Channel 2 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN2_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 2 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN2_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN3: Enable balancing for channel 3. The bit is cleared by the device in case of: a) a detected over-current condition on channel 3. b) a detected and enabled individual under-voltage condition for channel 3. c) the channel timer of channel 0 (BAL_TMR_CH3) is zero. */
#define MC33775_BAL_CH_CFG_CHEN3_POS \
  (3U)
#define MC33775_BAL_CH_CFG_CHEN3_MSK \
  (0x8U)

/* Enumerated value DISABLED: Balancing for Channel 3 is disabled. The balancing timer for Channel 3 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN3_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 3 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN3_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN4: Enable balancing for channel 4. The bit is cleared by the device in case of: a) a detected over-current condition on channel 4. b) a detected and enabled individual under-voltage condition for channel 4. c) the channel timer of channel 0 (BAL_TMR_CH4) is zero. */
#define MC33775_BAL_CH_CFG_CHEN4_POS \
  (4U)
#define MC33775_BAL_CH_CFG_CHEN4_MSK \
  (0x10U)

/* Enumerated value DISABLED: Balancing for Channel 4 is disabled. The balancing timer for Channel 4 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN4_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 4 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN4_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN5: Enable balancing for channel 5. The bit is cleared by the device in case of: a) a detected over-current condition on channel 5. b) a detected and enabled individual under-voltage condition for channel 5. c) the channel timer of channel 0 (BAL_TMR_CH5) is zero. */
#define MC33775_BAL_CH_CFG_CHEN5_POS \
  (5U)
#define MC33775_BAL_CH_CFG_CHEN5_MSK \
  (0x20U)

/* Enumerated value DISABLED: Balancing for Channel 5 is disabled. The balancing timer for Channel 5 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN5_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 5 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN5_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN6: Enable balancing for channel 6. The bit is cleared by the device in case of: a) a detected over-current condition on channel 6. b) a detected and enabled individual under-voltage condition for channel 6. c) the channel timer of channel 0 (BAL_TMR_CH6) is zero. */
#define MC33775_BAL_CH_CFG_CHEN6_POS \
  (6U)
#define MC33775_BAL_CH_CFG_CHEN6_MSK \
  (0x40U)

/* Enumerated value DISABLED: Balancing for Channel 6 is disabled. The balancing timer for Channel 6 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN6_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 6 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN6_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN7: Enable balancing for channel 7. The bit is cleared by the device in case of: a) a detected over-current condition on channel 7. b) a detected and enabled individual under-voltage condition for channel 7. c) the channel timer of channel 0 (BAL_TMR_CH7) is zero. */
#define MC33775_BAL_CH_CFG_CHEN7_POS \
  (7U)
#define MC33775_BAL_CH_CFG_CHEN7_MSK \
  (0x80U)

/* Enumerated value DISABLED: Balancing for Channel 7 is disabled. The balancing timer for Channel 7 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN7_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 7 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN7_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN8: Enable balancing for channel 8. The bit is cleared by the device in case of: a) a detected over-current condition on channel 8. b) a detected and enabled individual under-voltage condition for channel 8. c) the channel timer of channel 0 (BAL_TMR_CH8) is zero. */
#define MC33775_BAL_CH_CFG_CHEN8_POS \
  (8U)
#define MC33775_BAL_CH_CFG_CHEN8_MSK \
  (0x100U)

/* Enumerated value DISABLED: Balancing for Channel 8 is disabled. The balancing timer for Channel 8 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN8_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 8 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN8_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN9: Enable balancing for channel 9. The bit is cleared by the device in case of: a) a detected over-current condition on channel 9. b) a detected and enabled individual under-voltage condition for channel 9. c) the channel timer of channel 0 (BAL_TMR_CH9) is zero. */
#define MC33775_BAL_CH_CFG_CHEN9_POS \
  (9U)
#define MC33775_BAL_CH_CFG_CHEN9_MSK \
  (0x200U)

/* Enumerated value DISABLED: Balancing for Channel 9 is disabled. The balancing timer for Channel 9 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN9_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 9 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN9_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN10: Enable balancing for channel 10. The bit is cleared by the device in case of: a) a detected over-current condition on channel 10. b) a detected and enabled individual under-voltage condition for channel 10. c) the channel timer of channel 0 (BAL_TMR_CH10) is zero. */
#define MC33775_BAL_CH_CFG_CHEN10_POS \
  (10U)
#define MC33775_BAL_CH_CFG_CHEN10_MSK \
  (0x400U)

/* Enumerated value DISABLED: Balancing for Channel 10 is disabled. The balancing timer for Channel 10 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN10_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 10 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN10_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN11: Enable balancing for channel 11. The bit is cleared by the device in case of: a) a detected over-current condition on channel 11. b) a detected and enabled individual under-voltage condition for channel 11. c) the channel timer of channel 0 (BAL_TMR_CH11) is zero. */
#define MC33775_BAL_CH_CFG_CHEN11_POS \
  (11U)
#define MC33775_BAL_CH_CFG_CHEN11_MSK \
  (0x800U)

/* Enumerated value DISABLED: Balancing for Channel 11 is disabled. The balancing timer for Channel 11 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN11_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 11 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN11_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN12: Enable balancing for channel 12. The bit is cleared by the device in case of: a) a detected over-current condition on channel 12. b) a detected and enabled individual under-voltage condition for channel 12. c) the channel timer of channel 0 (BAL_TMR_CH12) is zero. */
#define MC33775_BAL_CH_CFG_CHEN12_POS \
  (12U)
#define MC33775_BAL_CH_CFG_CHEN12_MSK \
  (0x1000U)

/* Enumerated value DISABLED: Balancing for Channel 12 is disabled. The balancing timer for Channel 12 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN12_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 12 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN12_ENABLED_ENUM_VAL \
  (1U)

/* Field CHEN13: Enable balancing for channel 13. The bit is cleared by the device in case of: a) a detected over-current condition on channel 13. b) a detected and enabled individual under-voltage condition for channel 13. c) the channel timer of channel 0 (BAL_TMR_CH13) is zero. */
#define MC33775_BAL_CH_CFG_CHEN13_POS \
  (13U)
#define MC33775_BAL_CH_CFG_CHEN13_MSK \
  (0x2000U)

/* Enumerated value DISABLED: Balancing for Channel 13 is disabled. The balancing timer for Channel 13 is stopped. */
#define MC33775_BAL_CH_CFG_CHEN13_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing for Channel 13 is enabled. */
#define MC33775_BAL_CH_CFG_CHEN13_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_CH_CFG_RESERVED0_POS \
  (14U)
#define MC33775_BAL_CH_CFG_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * BAL_PRE_TMR (read-write):Pre-balancing timer
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_PRE_TMR_OFFSET \
  (0x1003U)
#define MC33775_BAL_PRE_TMR_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_PRE_TMR_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_PRE_TMR_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_PRE_TMR_MW_MSK \
  (0x0U)
#define MC33775_BAL_PRE_TMR_RA_MSK \
  (0x0U)
#define MC33775_BAL_PRE_TMR_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_PRE_TMR_POR_VAL \
  (0x0U)

/* Field PREBALTIME: Downcounter which runs if BALEN is set. Inhibits the balancing and holds the individual channel timer. The value of this field represents the current counter value when read. The counting saturates at 0 and activates the balancing. The BAL_GLOB_TO_TMR is not influenced by this timer. */
#define MC33775_BAL_PRE_TMR_PREBALTIME_POS \
  (0U)
#define MC33775_BAL_PRE_TMR_PREBALTIME_MSK \
  (0xFFFFU)

/* Enumerated value EXPIRED: Pre-balancing time is expired. */
#define MC33775_BAL_PRE_TMR_PREBALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value PREBAL: Pre-balancing time is set to PREBAL * 10 seconds */
#define MC33775_BAL_PRE_TMR_PREBALTIME_PREBAL_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Maximum pre-balancing time = 655350 seconds = approximately 182 hours = approximately 7.6 days */
#define MC33775_BAL_PRE_TMR_PREBALTIME_MAX_ENUM_VAL \
  (65535U)


/* --------------------------------------------------------------------------
 * BAL_AUTO_DISCHRG_CTRL (read-write):Emergency discharge enable
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_AUTO_DISCHRG_CTRL_OFFSET \
  (0x1004U)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_MW_MSK \
  (0x0U)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_RA_MSK \
  (0x0U)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_POR_VAL \
  (0x2152U)

/* Field KEY: Key for enabling auto discharge. After enabling, discharge will continue until disable key is received. Other values than DEADh or 2152h have no influence on the device functionality. */
#define MC33775_BAL_AUTO_DISCHRG_CTRL_KEY_POS \
  (0U)
#define MC33775_BAL_AUTO_DISCHRG_CTRL_KEY_MSK \
  (0xFFFFU)

/* Enumerated value OTHERS: Other values will be ignored. */
#define MC33775_BAL_AUTO_DISCHRG_CTRL_KEY_OTHERS_ENUM_VAL \
  (1U)

/* Enumerated value DISABLED: Disable key for auto discharge. */
#define MC33775_BAL_AUTO_DISCHRG_CTRL_KEY_DISABLED_ENUM_VAL \
  (8530U)

/* Enumerated value ENABLED: Enable key for auto discharge. */
#define MC33775_BAL_AUTO_DISCHRG_CTRL_KEY_ENABLED_ENUM_VAL \
  (57005U)

/* --------------------------------------------------------------------------
 * BAL_SWITCH_MON_CFG (read-write):Balancing switch monitoring enable
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_SWITCH_MON_CFG_OFFSET \
  (0x1005U)
#define MC33775_BAL_SWITCH_MON_CFG_RW_MSK \
  (0x3FFFU)
#define MC33775_BAL_SWITCH_MON_CFG_RD_MSK \
  (0x3FFFU)
#define MC33775_BAL_SWITCH_MON_CFG_WR_MSK \
  (0x3FFFU)
#define MC33775_BAL_SWITCH_MON_CFG_MW_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_MON_CFG_RA_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_MON_CFG_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_SWITCH_MON_CFG_POR_VAL \
  (0x3FFFU)

/* Field MONEN0: Enable balancing switch monitoring for channel 0. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN0_POS \
  (0U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN0_MSK \
  (0x1U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN0_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN0_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 0 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 0 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN0_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN1: Enable balancing switch monitoring for channel 1. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN1_POS \
  (1U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN1_MSK \
  (0x2U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN1_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN1_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN1_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 1 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 1 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN1_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN2: Enable balancing switch monitoring for channel 2. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN2_POS \
  (2U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN2_MSK \
  (0x4U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN2_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN2_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN2_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 2 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN2_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 2 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN2_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN3: Enable balancing switch monitoring for channel 3. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN3_POS \
  (3U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN3_MSK \
  (0x8U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN3_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN3_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN3_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 3 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN3_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 3 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN3_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN4: Enable balancing switch monitoring for channel 4. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN4_POS \
  (4U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN4_MSK \
  (0x10U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN4_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN4_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN4_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 4 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN4_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 4 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN4_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN5: Enable balancing switch monitoring for channel 5. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN5_POS \
  (5U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN5_MSK \
  (0x20U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN5_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN5_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN5_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 5 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN5_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 5 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN5_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN6: Enable balancing switch monitoring for channel 6. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN6_POS \
  (6U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN6_MSK \
  (0x40U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN6_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN6_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN6_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 6 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN6_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 6 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN6_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN7: Enable balancing switch monitoring for channel 7. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN7_POS \
  (7U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN7_MSK \
  (0x80U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN7_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN7_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN7_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 7 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN7_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 7 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN7_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN8: Enable balancing switch monitoring for channel 8. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN8_POS \
  (8U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN8_MSK \
  (0x100U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN8_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN8_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN8_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 8 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN8_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 8 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN8_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN9: Enable balancing switch monitoring for channel 9. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN9_POS \
  (9U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN9_MSK \
  (0x200U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN9_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN9_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN9_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 9 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN9_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 9 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN9_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN10: Enable balancing switch monitoring for channel 10. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN10_POS \
  (10U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN10_MSK \
  (0x400U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN10_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN10_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN10_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 10 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN10_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 10 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN10_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN11: Enable balancing switch monitoring for channel 11. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN11_POS \
  (11U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN11_MSK \
  (0x800U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN11_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN11_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN11_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 11 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN11_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 11 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN11_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN12: Enable balancing switch monitoring for channel 12. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN12_POS \
  (12U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN12_MSK \
  (0x1000U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN12_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN12_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN12_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 12 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN12_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 12 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN12_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN13: Enable balancing switch monitoring for channel 13. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN13_POS \
  (13U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN13_MSK \
  (0x2000U)
#define MC33775_BAL_SWITCH_MON_CFG_MONEN13_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_MONEN13_POS)) & MC33775_BAL_SWITCH_MON_CFG_MONEN13_MSK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 13 is disabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN13_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 13 is enabled. */
#define MC33775_BAL_SWITCH_MON_CFG_MONEN13_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_SWITCH_MON_CFG_RESERVED0_POS \
  (14U)
#define MC33775_BAL_SWITCH_MON_CFG_RESERVED0_MSK \
  (0xC000U)
#define MC33775_BAL_SWITCH_MON_CFG_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33775_BAL_SWITCH_MON_CFG_RESERVED0_POS)) & MC33775_BAL_SWITCH_MON_CFG_RESERVED0_MSK))

/* --------------------------------------------------------------------------
 * BAL_CH_UV0_STAT (read-only):Channel under-voltage balancing status
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_CH_UV0_STAT_OFFSET \
  (0x1009U)
#define MC33775_BAL_CH_UV0_STAT_RW_MSK \
  (0x0U)
#define MC33775_BAL_CH_UV0_STAT_RD_MSK \
  (0x3FFFU)
#define MC33775_BAL_CH_UV0_STAT_WR_MSK \
  (0x0U)
#define MC33775_BAL_CH_UV0_STAT_MW_MSK \
  (0x0U)
#define MC33775_BAL_CH_UV0_STAT_RA_MSK \
  (0x3FFFU)
#define MC33775_BAL_CH_UV0_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_CH_UV0_STAT_POR_VAL \
  (0x0U)

/* Field CH0: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 0. */
#define MC33775_BAL_CH_UV0_STAT_CH0_POS \
  (0U)
#define MC33775_BAL_CH_UV0_STAT_CH0_MSK \
  (0x1U)

/* Enumerated value NOUV: Balancing of channel 0 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH0_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 0 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH0_UV_ENUM_VAL \
  (1U)

/* Field CH1: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 1. */
#define MC33775_BAL_CH_UV0_STAT_CH1_POS \
  (1U)
#define MC33775_BAL_CH_UV0_STAT_CH1_MSK \
  (0x2U)

/* Enumerated value NOUV: Balancing of channel 1 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH1_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 1 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH1_UV_ENUM_VAL \
  (1U)

/* Field CH2: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 2. */
#define MC33775_BAL_CH_UV0_STAT_CH2_POS \
  (2U)
#define MC33775_BAL_CH_UV0_STAT_CH2_MSK \
  (0x4U)

/* Enumerated value NOUV: Balancing of channel 2 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH2_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 2 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH2_UV_ENUM_VAL \
  (1U)

/* Field CH3: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 3. */
#define MC33775_BAL_CH_UV0_STAT_CH3_POS \
  (3U)
#define MC33775_BAL_CH_UV0_STAT_CH3_MSK \
  (0x8U)

/* Enumerated value NOUV: Balancing of channel 3 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH3_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 3 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH3_UV_ENUM_VAL \
  (1U)

/* Field CH4: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 4. */
#define MC33775_BAL_CH_UV0_STAT_CH4_POS \
  (4U)
#define MC33775_BAL_CH_UV0_STAT_CH4_MSK \
  (0x10U)

/* Enumerated value NOUV: Balancing of channel 4 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH4_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 4 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH4_UV_ENUM_VAL \
  (1U)

/* Field CH5: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 5. */
#define MC33775_BAL_CH_UV0_STAT_CH5_POS \
  (5U)
#define MC33775_BAL_CH_UV0_STAT_CH5_MSK \
  (0x20U)

/* Enumerated value NOUV: Balancing of channel 5 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH5_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 5 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH5_UV_ENUM_VAL \
  (1U)

/* Field CH6: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 6. */
#define MC33775_BAL_CH_UV0_STAT_CH6_POS \
  (6U)
#define MC33775_BAL_CH_UV0_STAT_CH6_MSK \
  (0x40U)

/* Enumerated value NOUV: Balancing of channel 6 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH6_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 6 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH6_UV_ENUM_VAL \
  (1U)

/* Field CH7: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 7. */
#define MC33775_BAL_CH_UV0_STAT_CH7_POS \
  (7U)
#define MC33775_BAL_CH_UV0_STAT_CH7_MSK \
  (0x80U)

/* Enumerated value NOUV: Balancing of channel 7 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH7_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 7 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH7_UV_ENUM_VAL \
  (1U)

/* Field CH8: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 8. */
#define MC33775_BAL_CH_UV0_STAT_CH8_POS \
  (8U)
#define MC33775_BAL_CH_UV0_STAT_CH8_MSK \
  (0x100U)

/* Enumerated value NOUV: Balancing of channel 8 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH8_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 8 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH8_UV_ENUM_VAL \
  (1U)

/* Field CH9: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 9. */
#define MC33775_BAL_CH_UV0_STAT_CH9_POS \
  (9U)
#define MC33775_BAL_CH_UV0_STAT_CH9_MSK \
  (0x200U)

/* Enumerated value NOUV: Balancing of channel 9 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH9_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 9 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH9_UV_ENUM_VAL \
  (1U)

/* Field CH10: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 10. */
#define MC33775_BAL_CH_UV0_STAT_CH10_POS \
  (10U)
#define MC33775_BAL_CH_UV0_STAT_CH10_MSK \
  (0x400U)

/* Enumerated value NOUV: Balancing of channel 10 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH10_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 10 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH10_UV_ENUM_VAL \
  (1U)

/* Field CH11: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 11. */
#define MC33775_BAL_CH_UV0_STAT_CH11_POS \
  (11U)
#define MC33775_BAL_CH_UV0_STAT_CH11_MSK \
  (0x800U)

/* Enumerated value NOUV: Balancing of channel 11 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH11_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 11 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH11_UV_ENUM_VAL \
  (1U)

/* Field CH12: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 12. */
#define MC33775_BAL_CH_UV0_STAT_CH12_POS \
  (12U)
#define MC33775_BAL_CH_UV0_STAT_CH12_MSK \
  (0x1000U)

/* Enumerated value NOUV: Balancing of channel 12 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH12_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 12 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH12_UV_ENUM_VAL \
  (1U)

/* Field CH13: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 13. */
#define MC33775_BAL_CH_UV0_STAT_CH13_POS \
  (13U)
#define MC33775_BAL_CH_UV0_STAT_CH13_MSK \
  (0x2000U)

/* Enumerated value NOUV: Balancing of channel 13 was not disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH13_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing of channel 13 was disabled due to under-voltage condition. */
#define MC33775_BAL_CH_UV0_STAT_CH13_UV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_CH_UV0_STAT_RESERVED0_POS \
  (14U)
#define MC33775_BAL_CH_UV0_STAT_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * BAL_GLOB_UV1_STAT (read-only):Global under-voltage balancing status
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_GLOB_UV1_STAT_OFFSET \
  (0x100AU)
#define MC33775_BAL_GLOB_UV1_STAT_RW_MSK \
  (0x0U)
#define MC33775_BAL_GLOB_UV1_STAT_RD_MSK \
  (0x3FFFU)
#define MC33775_BAL_GLOB_UV1_STAT_WR_MSK \
  (0x0U)
#define MC33775_BAL_GLOB_UV1_STAT_MW_MSK \
  (0x0U)
#define MC33775_BAL_GLOB_UV1_STAT_RA_MSK \
  (0x3FFFU)
#define MC33775_BAL_GLOB_UV1_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_GLOB_UV1_STAT_POR_VAL \
  (0x0U)

/* Field CH0: Status bit, if a global under-voltage of channel 0 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH0_POS \
  (0U)
#define MC33775_BAL_GLOB_UV1_STAT_CH0_MSK \
  (0x1U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 0. */
#define MC33775_BAL_GLOB_UV1_STAT_CH0_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 0. */
#define MC33775_BAL_GLOB_UV1_STAT_CH0_UV_ENUM_VAL \
  (1U)

/* Field CH1: Status bit, if a global under-voltage of channel 1 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH1_POS \
  (1U)
#define MC33775_BAL_GLOB_UV1_STAT_CH1_MSK \
  (0x2U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 1. */
#define MC33775_BAL_GLOB_UV1_STAT_CH1_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 1. */
#define MC33775_BAL_GLOB_UV1_STAT_CH1_UV_ENUM_VAL \
  (1U)

/* Field CH2: Status bit, if a global under-voltage of channel 2 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH2_POS \
  (2U)
#define MC33775_BAL_GLOB_UV1_STAT_CH2_MSK \
  (0x4U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 2. */
#define MC33775_BAL_GLOB_UV1_STAT_CH2_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 2. */
#define MC33775_BAL_GLOB_UV1_STAT_CH2_UV_ENUM_VAL \
  (1U)

/* Field CH3: Status bit, if a global under-voltage of channel 3 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH3_POS \
  (3U)
#define MC33775_BAL_GLOB_UV1_STAT_CH3_MSK \
  (0x8U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 3. */
#define MC33775_BAL_GLOB_UV1_STAT_CH3_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 3. */
#define MC33775_BAL_GLOB_UV1_STAT_CH3_UV_ENUM_VAL \
  (1U)

/* Field CH4: Status bit, if a global under-voltage of channel 4 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH4_POS \
  (4U)
#define MC33775_BAL_GLOB_UV1_STAT_CH4_MSK \
  (0x10U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 4. */
#define MC33775_BAL_GLOB_UV1_STAT_CH4_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 4. */
#define MC33775_BAL_GLOB_UV1_STAT_CH4_UV_ENUM_VAL \
  (1U)

/* Field CH5: Status bit, if a global under-voltage of channel 5 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH5_POS \
  (5U)
#define MC33775_BAL_GLOB_UV1_STAT_CH5_MSK \
  (0x20U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 5. */
#define MC33775_BAL_GLOB_UV1_STAT_CH5_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 5. */
#define MC33775_BAL_GLOB_UV1_STAT_CH5_UV_ENUM_VAL \
  (1U)

/* Field CH6: Status bit, if a global under-voltage of channel 6 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH6_POS \
  (6U)
#define MC33775_BAL_GLOB_UV1_STAT_CH6_MSK \
  (0x40U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 6. */
#define MC33775_BAL_GLOB_UV1_STAT_CH6_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 6. */
#define MC33775_BAL_GLOB_UV1_STAT_CH6_UV_ENUM_VAL \
  (1U)

/* Field CH7: Status bit, if a global under-voltage of channel 7 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH7_POS \
  (7U)
#define MC33775_BAL_GLOB_UV1_STAT_CH7_MSK \
  (0x80U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 7. */
#define MC33775_BAL_GLOB_UV1_STAT_CH7_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 7. */
#define MC33775_BAL_GLOB_UV1_STAT_CH7_UV_ENUM_VAL \
  (1U)

/* Field CH8: Status bit, if a global under-voltage of channel 8 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH8_POS \
  (8U)
#define MC33775_BAL_GLOB_UV1_STAT_CH8_MSK \
  (0x100U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 8. */
#define MC33775_BAL_GLOB_UV1_STAT_CH8_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 8. */
#define MC33775_BAL_GLOB_UV1_STAT_CH8_UV_ENUM_VAL \
  (1U)

/* Field CH9: Status bit, if a global under-voltage of channel 9 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH9_POS \
  (9U)
#define MC33775_BAL_GLOB_UV1_STAT_CH9_MSK \
  (0x200U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 9. */
#define MC33775_BAL_GLOB_UV1_STAT_CH9_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 9. */
#define MC33775_BAL_GLOB_UV1_STAT_CH9_UV_ENUM_VAL \
  (1U)

/* Field CH10: Status bit, if a global under-voltage of channel 10 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH10_POS \
  (10U)
#define MC33775_BAL_GLOB_UV1_STAT_CH10_MSK \
  (0x400U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 10. */
#define MC33775_BAL_GLOB_UV1_STAT_CH10_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 10. */
#define MC33775_BAL_GLOB_UV1_STAT_CH10_UV_ENUM_VAL \
  (1U)

/* Field CH11: Status bit, if a global under-voltage of channel 11 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH11_POS \
  (11U)
#define MC33775_BAL_GLOB_UV1_STAT_CH11_MSK \
  (0x800U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 11. */
#define MC33775_BAL_GLOB_UV1_STAT_CH11_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 11. */
#define MC33775_BAL_GLOB_UV1_STAT_CH11_UV_ENUM_VAL \
  (1U)

/* Field CH12: Status bit, if a global under-voltage of channel 12 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH12_POS \
  (12U)
#define MC33775_BAL_GLOB_UV1_STAT_CH12_MSK \
  (0x1000U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 12. */
#define MC33775_BAL_GLOB_UV1_STAT_CH12_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 12. */
#define MC33775_BAL_GLOB_UV1_STAT_CH12_UV_ENUM_VAL \
  (1U)

/* Field CH13: Status bit, if a global under-voltage of channel 13 condition was the reason for disabling the global balancing: */
#define MC33775_BAL_GLOB_UV1_STAT_CH13_POS \
  (13U)
#define MC33775_BAL_GLOB_UV1_STAT_CH13_MSK \
  (0x2000U)

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 13. */
#define MC33775_BAL_GLOB_UV1_STAT_CH13_NOUV_ENUM_VAL \
  (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 13. */
#define MC33775_BAL_GLOB_UV1_STAT_CH13_UV_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_GLOB_UV1_STAT_RESERVED0_POS \
  (14U)
#define MC33775_BAL_GLOB_UV1_STAT_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * BAL_STAT0 (read-only):Logical balancing channel status
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_STAT0_OFFSET \
  (0x100BU)
#define MC33775_BAL_STAT0_RW_MSK \
  (0x0U)
#define MC33775_BAL_STAT0_RD_MSK \
  (0x3FFFU)
#define MC33775_BAL_STAT0_WR_MSK \
  (0x0U)
#define MC33775_BAL_STAT0_MW_MSK \
  (0x0U)
#define MC33775_BAL_STAT0_RA_MSK \
  (0x0U)
#define MC33775_BAL_STAT0_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_STAT0_POR_VAL \
  (0x0U)

/* Field CH0: Balancing channel 0 status (without PWM) */
#define MC33775_BAL_STAT0_CH0_POS \
  (0U)
#define MC33775_BAL_STAT0_CH0_MSK \
  (0x1U)

/* Enumerated value INACTIVE: Balancing for channel 0 inactive. */
#define MC33775_BAL_STAT0_CH0_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 0 active. */
#define MC33775_BAL_STAT0_CH0_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH1: Balancing channel 1 status (without PWM) */
#define MC33775_BAL_STAT0_CH1_POS \
  (1U)
#define MC33775_BAL_STAT0_CH1_MSK \
  (0x2U)

/* Enumerated value INACTIVE: Balancing for channel 1 inactive. */
#define MC33775_BAL_STAT0_CH1_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 1 active. */
#define MC33775_BAL_STAT0_CH1_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH2: Balancing channel 2 status (without PWM) */
#define MC33775_BAL_STAT0_CH2_POS \
  (2U)
#define MC33775_BAL_STAT0_CH2_MSK \
  (0x4U)

/* Enumerated value INACTIVE: Balancing for channel 2 inactive. */
#define MC33775_BAL_STAT0_CH2_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 2 active. */
#define MC33775_BAL_STAT0_CH2_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH3: Balancing channel 3 status (without PWM) */
#define MC33775_BAL_STAT0_CH3_POS \
  (3U)
#define MC33775_BAL_STAT0_CH3_MSK \
  (0x8U)

/* Enumerated value INACTIVE: Balancing for channel 3 inactive. */
#define MC33775_BAL_STAT0_CH3_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 3 active. */
#define MC33775_BAL_STAT0_CH3_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH4: Balancing channel 4 status (without PWM) */
#define MC33775_BAL_STAT0_CH4_POS \
  (4U)
#define MC33775_BAL_STAT0_CH4_MSK \
  (0x10U)

/* Enumerated value INACTIVE: Balancing for channel 4 inactive. */
#define MC33775_BAL_STAT0_CH4_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 4 active. */
#define MC33775_BAL_STAT0_CH4_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH5: Balancing channel 5 status (without PWM) */
#define MC33775_BAL_STAT0_CH5_POS \
  (5U)
#define MC33775_BAL_STAT0_CH5_MSK \
  (0x20U)

/* Enumerated value INACTIVE: Balancing for channel 5 inactive. */
#define MC33775_BAL_STAT0_CH5_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 5 active. */
#define MC33775_BAL_STAT0_CH5_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH6: Balancing channel 6 status (without PWM) */
#define MC33775_BAL_STAT0_CH6_POS \
  (6U)
#define MC33775_BAL_STAT0_CH6_MSK \
  (0x40U)

/* Enumerated value INACTIVE: Balancing for channel 6 inactive. */
#define MC33775_BAL_STAT0_CH6_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 6 active. */
#define MC33775_BAL_STAT0_CH6_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH7: Balancing channel 7 status (without PWM) */
#define MC33775_BAL_STAT0_CH7_POS \
  (7U)
#define MC33775_BAL_STAT0_CH7_MSK \
  (0x80U)

/* Enumerated value INACTIVE: Balancing for channel 7 inactive. */
#define MC33775_BAL_STAT0_CH7_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 7 active. */
#define MC33775_BAL_STAT0_CH7_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH8: Balancing channel 8 status (without PWM) */
#define MC33775_BAL_STAT0_CH8_POS \
  (8U)
#define MC33775_BAL_STAT0_CH8_MSK \
  (0x100U)

/* Enumerated value INACTIVE: Balancing for channel 8 inactive. */
#define MC33775_BAL_STAT0_CH8_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 8 active. */
#define MC33775_BAL_STAT0_CH8_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH9: Balancing channel 9 status (without PWM) */
#define MC33775_BAL_STAT0_CH9_POS \
  (9U)
#define MC33775_BAL_STAT0_CH9_MSK \
  (0x200U)

/* Enumerated value INACTIVE: Balancing for channel 9 inactive. */
#define MC33775_BAL_STAT0_CH9_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 9 active. */
#define MC33775_BAL_STAT0_CH9_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH10: Balancing channel 10 status (without PWM) */
#define MC33775_BAL_STAT0_CH10_POS \
  (10U)
#define MC33775_BAL_STAT0_CH10_MSK \
  (0x400U)

/* Enumerated value INACTIVE: Balancing for channel 10 inactive. */
#define MC33775_BAL_STAT0_CH10_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 10 active. */
#define MC33775_BAL_STAT0_CH10_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH11: Balancing channel 11 status (without PWM) */
#define MC33775_BAL_STAT0_CH11_POS \
  (11U)
#define MC33775_BAL_STAT0_CH11_MSK \
  (0x800U)

/* Enumerated value INACTIVE: Balancing for channel 11 inactive. */
#define MC33775_BAL_STAT0_CH11_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 11 active. */
#define MC33775_BAL_STAT0_CH11_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH12: Balancing channel 12 status (without PWM) */
#define MC33775_BAL_STAT0_CH12_POS \
  (12U)
#define MC33775_BAL_STAT0_CH12_MSK \
  (0x1000U)

/* Enumerated value INACTIVE: Balancing for channel 12 inactive. */
#define MC33775_BAL_STAT0_CH12_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 12 active. */
#define MC33775_BAL_STAT0_CH12_ACTIVE_ENUM_VAL \
  (1U)

/* Field CH13: Balancing channel 13 status (without PWM) */
#define MC33775_BAL_STAT0_CH13_POS \
  (13U)
#define MC33775_BAL_STAT0_CH13_MSK \
  (0x2000U)

/* Enumerated value INACTIVE: Balancing for channel 13 inactive. */
#define MC33775_BAL_STAT0_CH13_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Balancing for channel 13 active. */
#define MC33775_BAL_STAT0_CH13_ACTIVE_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_STAT0_RESERVED0_POS \
  (14U)
#define MC33775_BAL_STAT0_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * BAL_STAT1 (read-only):Balancing status
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_STAT1_OFFSET \
  (0x100CU)
#define MC33775_BAL_STAT1_RW_MSK \
  (0x0U)
#define MC33775_BAL_STAT1_RD_MSK \
  (0x8007U)
#define MC33775_BAL_STAT1_WR_MSK \
  (0x0U)
#define MC33775_BAL_STAT1_MW_MSK \
  (0x0U)
#define MC33775_BAL_STAT1_RA_MSK \
  (0x8000U)
#define MC33775_BAL_STAT1_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_STAT1_POR_VAL \
  (0x0U)

/* Field PREBALTMR: Pre-Balancing status */
#define MC33775_BAL_STAT1_PREBALTMR_POS \
  (0U)
#define MC33775_BAL_STAT1_PREBALTMR_MSK \
  (0x1U)

/* Enumerated value INACTIVE: No pre-balancing timer active. */
#define MC33775_BAL_STAT1_PREBALTMR_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Pre-balancing timer active (Balancing is inhibited). */
#define MC33775_BAL_STAT1_PREBALTMR_ACTIVE_ENUM_VAL \
  (1U)

/* Field TEMPBALINHIBIT: Temperature balancing status */
#define MC33775_BAL_STAT1_TEMPBALINHIBIT_POS \
  (1U)
#define MC33775_BAL_STAT1_TEMPBALINHIBIT_MSK \
  (0x2U)

/* Enumerated value INACTIVE: Temperature based balancing control allows balancing. */
#define MC33775_BAL_STAT1_TEMPBALINHIBIT_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Temperature based balancing control inhibits balancing. */
#define MC33775_BAL_STAT1_TEMPBALINHIBIT_ACTIVE_ENUM_VAL \
  (1U)

/* Field AUTODISCHRG: Auto discharge status */
#define MC33775_BAL_STAT1_AUTODISCHRG_POS \
  (2U)
#define MC33775_BAL_STAT1_AUTODISCHRG_MSK \
  (0x4U)

/* Enumerated value INACTIVE: Auto discharge inactive */
#define MC33775_BAL_STAT1_AUTODISCHRG_INACTIVE_ENUM_VAL \
  (0U)

/* Enumerated value ACTIVE: Auto discharge active */
#define MC33775_BAL_STAT1_AUTODISCHRG_ACTIVE_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_STAT1_RESERVED0_POS \
  (3U)
#define MC33775_BAL_STAT1_RESERVED0_MSK \
  (0x7FF8U)

/* Field RDY: The ready bit is set after the cell balancing operation is finished. Reasons for this are that the last BAL_CH_EN.CHx has been cleared by hardware or the BAL_GLOB_CFG.BALEN has been cleared by hardware. With setting of BAL_GLOB_CFG.BALEN this bit is cleared. */
#define MC33775_BAL_STAT1_RDY_POS \
  (15U)
#define MC33775_BAL_STAT1_RDY_MSK \
  (0x8000U)

/* Enumerated value ONGOING: Balancing operation in progress. */
#define MC33775_BAL_STAT1_RDY_ONGOING_ENUM_VAL \
  (0U)

/* Enumerated value FINISHED: Balancing operation finished. */
#define MC33775_BAL_STAT1_RDY_FINISHED_ENUM_VAL \
  (1U)


/* --------------------------------------------------------------------------
 * BAL_SWITCH_STAT (read-only):Physical balancing channel status
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_SWITCH_STAT_OFFSET \
  (0x100DU)
#define MC33775_BAL_SWITCH_STAT_RW_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_STAT_RD_MSK \
  (0x3FFFU)
#define MC33775_BAL_SWITCH_STAT_WR_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_STAT_MW_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_STAT_RA_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_SWITCH_STAT_POR_VAL \
  (0x0U)

/* Field CH0: Balancing FET status channel 0 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH0_POS \
  (0U)
#define MC33775_BAL_SWITCH_STAT_CH0_MSK \
  (0x1U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH0_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH0_CLOSED_ENUM_VAL \
  (1U)

/* Field CH1: Balancing FET status channel 1 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH1_POS \
  (1U)
#define MC33775_BAL_SWITCH_STAT_CH1_MSK \
  (0x2U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH1_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH1_CLOSED_ENUM_VAL \
  (1U)

/* Field CH2: Balancing FET status channel 2 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH2_POS \
  (2U)
#define MC33775_BAL_SWITCH_STAT_CH2_MSK \
  (0x4U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH2_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH2_CLOSED_ENUM_VAL \
  (1U)

/* Field CH3: Balancing FET status channel 3 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH3_POS \
  (3U)
#define MC33775_BAL_SWITCH_STAT_CH3_MSK \
  (0x8U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH3_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH3_CLOSED_ENUM_VAL \
  (1U)

/* Field CH4: Balancing FET status channel 4 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH4_POS \
  (4U)
#define MC33775_BAL_SWITCH_STAT_CH4_MSK \
  (0x10U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH4_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH4_CLOSED_ENUM_VAL \
  (1U)

/* Field CH5: Balancing FET status channel 5 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH5_POS \
  (5U)
#define MC33775_BAL_SWITCH_STAT_CH5_MSK \
  (0x20U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH5_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH5_CLOSED_ENUM_VAL \
  (1U)

/* Field CH6: Balancing FET status channel 6 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH6_POS \
  (6U)
#define MC33775_BAL_SWITCH_STAT_CH6_MSK \
  (0x40U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH6_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH6_CLOSED_ENUM_VAL \
  (1U)

/* Field CH7: Balancing FET status channel 7 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH7_POS \
  (7U)
#define MC33775_BAL_SWITCH_STAT_CH7_MSK \
  (0x80U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH7_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH7_CLOSED_ENUM_VAL \
  (1U)

/* Field CH8: Balancing FET status channel 8 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH8_POS \
  (8U)
#define MC33775_BAL_SWITCH_STAT_CH8_MSK \
  (0x100U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH8_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH8_CLOSED_ENUM_VAL \
  (1U)

/* Field CH9: Balancing FET status channel 9 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH9_POS \
  (9U)
#define MC33775_BAL_SWITCH_STAT_CH9_MSK \
  (0x200U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH9_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH9_CLOSED_ENUM_VAL \
  (1U)

/* Field CH10: Balancing FET status channel 10 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH10_POS \
  (10U)
#define MC33775_BAL_SWITCH_STAT_CH10_MSK \
  (0x400U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH10_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH10_CLOSED_ENUM_VAL \
  (1U)

/* Field CH11: Balancing FET status channel 11 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH11_POS \
  (11U)
#define MC33775_BAL_SWITCH_STAT_CH11_MSK \
  (0x800U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH11_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH11_CLOSED_ENUM_VAL \
  (1U)

/* Field CH12: Balancing FET status channel 12 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH12_POS \
  (12U)
#define MC33775_BAL_SWITCH_STAT_CH12_MSK \
  (0x1000U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH12_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH12_CLOSED_ENUM_VAL \
  (1U)

/* Field CH13: Balancing FET status channel 13 This is the actual status (including PWM modulation) from the switch monitor circuit. */
#define MC33775_BAL_SWITCH_STAT_CH13_POS \
  (13U)
#define MC33775_BAL_SWITCH_STAT_CH13_MSK \
  (0x2000U)

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33775_BAL_SWITCH_STAT_CH13_OPEN_ENUM_VAL \
  (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33775_BAL_SWITCH_STAT_CH13_CLOSED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_SWITCH_STAT_RESERVED0_POS \
  (14U)
#define MC33775_BAL_SWITCH_STAT_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * BAL_SWITCH_FLT_STAT (read-only):Balancing switch fault
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_SWITCH_FLT_STAT_OFFSET \
  (0x100EU)
#define MC33775_BAL_SWITCH_FLT_STAT_RW_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_FLT_STAT_RD_MSK \
  (0x3FFFU)
#define MC33775_BAL_SWITCH_FLT_STAT_WR_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_FLT_STAT_MW_MSK \
  (0x0U)
#define MC33775_BAL_SWITCH_FLT_STAT_RA_MSK \
  (0x3FFFU)
#define MC33775_BAL_SWITCH_FLT_STAT_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_SWITCH_FLT_STAT_POR_VAL \
  (0x0U)

/* Field CH0: Balancing switch fault channel 0. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH0_POS \
  (0U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH0_MSK \
  (0x1U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH0_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH0_FAULT_ENUM_VAL \
  (1U)

/* Field CH1: Balancing switch fault channel 1. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH1_POS \
  (1U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH1_MSK \
  (0x2U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH1_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH1_FAULT_ENUM_VAL \
  (1U)

/* Field CH2: Balancing switch fault channel 2. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH2_POS \
  (2U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH2_MSK \
  (0x4U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH2_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH2_FAULT_ENUM_VAL \
  (1U)

/* Field CH3: Balancing switch fault channel 3. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH3_POS \
  (3U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH3_MSK \
  (0x8U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH3_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH3_FAULT_ENUM_VAL \
  (1U)

/* Field CH4: Balancing switch fault channel 4. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH4_POS \
  (4U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH4_MSK \
  (0x10U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH4_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH4_FAULT_ENUM_VAL \
  (1U)

/* Field CH5: Balancing switch fault channel 5. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH5_POS \
  (5U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH5_MSK \
  (0x20U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH5_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH5_FAULT_ENUM_VAL \
  (1U)

/* Field CH6: Balancing switch fault channel 6. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH6_POS \
  (6U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH6_MSK \
  (0x40U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH6_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH6_FAULT_ENUM_VAL \
  (1U)

/* Field CH7: Balancing switch fault channel 7. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH7_POS \
  (7U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH7_MSK \
  (0x80U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH7_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH7_FAULT_ENUM_VAL \
  (1U)

/* Field CH8: Balancing switch fault channel 8. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH8_POS \
  (8U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH8_MSK \
  (0x100U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH8_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH8_FAULT_ENUM_VAL \
  (1U)

/* Field CH9: Balancing switch fault channel 9. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH9_POS \
  (9U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH9_MSK \
  (0x200U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH9_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH9_FAULT_ENUM_VAL \
  (1U)

/* Field CH10: Balancing switch fault channel 10. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH10_POS \
  (10U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH10_MSK \
  (0x400U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH10_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH10_FAULT_ENUM_VAL \
  (1U)

/* Field CH11: Balancing switch fault channel 11. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH11_POS \
  (11U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH11_MSK \
  (0x800U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH11_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH11_FAULT_ENUM_VAL \
  (1U)

/* Field CH12: Balancing switch fault channel 12. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH12_POS \
  (12U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH12_MSK \
  (0x1000U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH12_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH12_FAULT_ENUM_VAL \
  (1U)

/* Field CH13: Balancing switch fault channel 13. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH13_POS \
  (13U)
#define MC33775_BAL_SWITCH_FLT_STAT_CH13_MSK \
  (0x2000U)

/* Enumerated value NOFLT: No fault detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH13_NOFLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33775_BAL_SWITCH_FLT_STAT_CH13_FAULT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33775_BAL_SWITCH_FLT_STAT_RESERVED0_POS \
  (14U)
#define MC33775_BAL_SWITCH_FLT_STAT_RESERVED0_MSK \
  (0xC000U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH_ALL (write-only):Virtual register, writes in parallel into BAL_TMR_CH0 up to BAL_TMR_CH13
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH_ALL_OFFSET \
  (0x100FU)
#define MC33775_BAL_TMR_CH_ALL_RW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH_ALL_RD_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH_ALL_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH_ALL_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH_ALL_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH_ALL_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH_ALL_POR_VAL \
  (0x0U)

/* Field BALTIME: Sets the balancing time for all channels. */
#define MC33775_BAL_TMR_CH_ALL_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH_ALL_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH_ALL_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH_ALL_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH_ALL_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: Sets the PWM duty cycle for all channels. PWM cycle time is 0.5 seconds. */
#define MC33775_BAL_TMR_CH_ALL_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH_ALL_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH_ALL_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH_ALL_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH_ALL_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH_ALL_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH0 (read-write):Balancing timer channel 0
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH0_OFFSET \
  (0x1010U)
#define MC33775_BAL_TMR_CH0_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH0_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH0_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH0_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH0_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH0_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH0_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 0 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH0_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH0_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH0_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH0_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH0_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 0. */
#define MC33775_BAL_TMR_CH0_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH0_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH0_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH0_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH0_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH0_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH1 (read-write):Balancing timer channel 1
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH1_OFFSET \
  (0x1011U)
#define MC33775_BAL_TMR_CH1_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH1_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH1_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH1_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH1_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH1_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH1_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 1 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH1_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH1_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH1_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH1_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH1_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 1. */
#define MC33775_BAL_TMR_CH1_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH1_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH1_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH1_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH1_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH1_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH2 (read-write):Balancing timer channel 2
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH2_OFFSET \
  (0x1012U)
#define MC33775_BAL_TMR_CH2_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH2_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH2_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH2_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH2_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH2_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH2_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 2 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH2_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH2_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH2_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH2_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH2_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 2. */
#define MC33775_BAL_TMR_CH2_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH2_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH2_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH2_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH2_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH2_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH3 (read-write):Balancing timer channel 3
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH3_OFFSET \
  (0x1013U)
#define MC33775_BAL_TMR_CH3_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH3_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH3_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH3_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH3_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH3_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH3_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 3 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH3_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH3_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH3_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH3_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH3_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 3 */
#define MC33775_BAL_TMR_CH3_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH3_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH3_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH3_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH3_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH3_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH4 (read-write):Balancing timer channel 4
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH4_OFFSET \
  (0x1014U)
#define MC33775_BAL_TMR_CH4_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH4_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH4_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH4_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH4_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH4_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH4_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 4 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH4_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH4_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH4_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH4_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH4_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 4. */
#define MC33775_BAL_TMR_CH4_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH4_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH4_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH4_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH4_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH4_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH5 (read-write):Balancing timer channel 5
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH5_OFFSET \
  (0x1015U)
#define MC33775_BAL_TMR_CH5_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH5_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH5_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH5_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH5_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH5_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH5_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 5 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH5_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH5_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH5_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH5_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH5_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 5. */
#define MC33775_BAL_TMR_CH5_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH5_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH5_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH5_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH5_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH5_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH6 (read-write):Balancing timer channel 6
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH6_OFFSET \
  (0x1016U)
#define MC33775_BAL_TMR_CH6_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH6_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH6_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH6_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH6_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH6_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH6_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 6 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH6_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH6_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH6_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH6_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH6_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 6. */
#define MC33775_BAL_TMR_CH6_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH6_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH6_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH6_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH6_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH6_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH7 (read-write):Balancing timer channel 7
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH7_OFFSET \
  (0x1017U)
#define MC33775_BAL_TMR_CH7_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH7_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH7_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH7_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH7_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH7_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH7_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 7 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH7_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH7_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH7_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH7_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH7_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 7. */
#define MC33775_BAL_TMR_CH7_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH7_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH7_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH7_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH7_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH7_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH8 (read-write):Balancing timer channel 8
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH8_OFFSET \
  (0x1018U)
#define MC33775_BAL_TMR_CH8_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH8_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH8_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH8_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH8_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH8_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH8_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 8 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH8_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH8_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH8_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH8_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH8_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 8. */
#define MC33775_BAL_TMR_CH8_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH8_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH8_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH8_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH8_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH8_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH9 (read-write):Balancing timer channel 9
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH9_OFFSET \
  (0x1019U)
#define MC33775_BAL_TMR_CH9_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH9_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH9_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH9_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH9_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH9_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH9_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 9 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH9_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH9_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH9_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH9_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH9_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 9. */
#define MC33775_BAL_TMR_CH9_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH9_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH9_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH9_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH9_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH9_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH10 (read-write):Balancing timer channel 10
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH10_OFFSET \
  (0x101AU)
#define MC33775_BAL_TMR_CH10_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH10_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH10_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH10_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH10_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH10_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH10_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 10 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH10_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH10_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH10_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH10_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH10_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 10. */
#define MC33775_BAL_TMR_CH10_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH10_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH10_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH10_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH10_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH10_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH11 (read-write):Balancing timer channel 11
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH11_OFFSET \
  (0x101BU)
#define MC33775_BAL_TMR_CH11_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH11_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH11_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH11_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH11_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH11_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH11_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 11 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH11_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH11_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH11_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH11_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH11_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 11. */
#define MC33775_BAL_TMR_CH11_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH11_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH11_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH11_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH11_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH11_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH12 (read-write):Balancing timer channel 12
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH12_OFFSET \
  (0x101CU)
#define MC33775_BAL_TMR_CH12_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH12_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH12_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH12_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH12_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH12_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH12_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 12 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH12_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH12_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH12_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH12_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH12_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 12 */
#define MC33775_BAL_TMR_CH12_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH12_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH12_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH12_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH12_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH12_PWM_PWM100_ENUM_VAL \
  (3U)


/* --------------------------------------------------------------------------
 * BAL_TMR_CH13 (read-write):Balancing timer channel 13
 * -------------------------------------------------------------------------- */
#define MC33775_BAL_TMR_CH13_OFFSET \
  (0x101DU)
#define MC33775_BAL_TMR_CH13_RW_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH13_RD_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH13_WR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH13_MW_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH13_RA_MSK \
  (0x0U)
#define MC33775_BAL_TMR_CH13_POR_MSK \
  (0xFFFFU)
#define MC33775_BAL_TMR_CH13_POR_VAL \
  (0x0U)

/* Field BALTIME: Balancing time for channel 13 The value of this field represents the current counter value when read. The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33775_BAL_TMR_CH13_BALTIME_POS \
  (0U)
#define MC33775_BAL_TMR_CH13_BALTIME_MSK \
  (0x3FFFU)

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33775_BAL_TMR_CH13_BALTIME_EXPIRED_ENUM_VAL \
  (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33775_BAL_TMR_CH13_BALTIME_BALTIME_ENUM_VAL \
  (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33775_BAL_TMR_CH13_BALTIME_MAX_ENUM_VAL \
  (16383U)

/* Field PWM: PWM duty cycle for channel 13. */
#define MC33775_BAL_TMR_CH13_PWM_POS \
  (14U)
#define MC33775_BAL_TMR_CH13_PWM_MSK \
  (0xC000U)

/* Enumerated value PWM25: PWM duty cycle set to 25%. */
#define MC33775_BAL_TMR_CH13_PWM_PWM25_ENUM_VAL \
  (0U)

/* Enumerated value PWM50: PWM duty cycle set to 50%. */
#define MC33775_BAL_TMR_CH13_PWM_PWM50_ENUM_VAL \
  (1U)

/* Enumerated value PWM75: PWM duty cycle set to 75%. */
#define MC33775_BAL_TMR_CH13_PWM_PWM75_ENUM_VAL \
  (2U)

/* Enumerated value PWM100: PWM duty cycle set to 100%. */
#define MC33775_BAL_TMR_CH13_PWM_PWM100_ENUM_VAL \
  (3U)

#endif /* CDD_BCC_775A_REGS_H */

/*******************************************************************************
 * EOF;
 ******************************************************************************/
