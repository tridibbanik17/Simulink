/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/


#ifndef CDD_BCC_774A_REGS_H
#define CDD_BCC_774A_REGS_H


#ifdef __cplusplus
extern "C"
{
#endif


/* Overall register macros */
#define MC33774_BCC18_MCU_IF_NR_OF_REGISTERS                 (0x11EU)
#define MC33774_BCC18_MCU_IF_MAX_OFFSET                      (0x1C91U)

/* --------------------------------------------------------------------------
 * ALLM_CFG (write-only):general measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_ALLM_CFG_OFFSET                              (0x1400U)
#define MC33774_ALLM_CFG_RW_MASK                             (0x0U)
#define MC33774_ALLM_CFG_RD_MASK                             (0x0U)
#define MC33774_ALLM_CFG_WR_MASK                             (0xFFFFU)
#define MC33774_ALLM_CFG_MW_MASK                             (0x0U)
#define MC33774_ALLM_CFG_RA_MASK                             (0x0U)
#define MC33774_ALLM_CFG_POR_MASK                            (0xFFFFU)
#define MC33774_ALLM_CFG_POR_VAL                             (0x0U)

/* Field MEASEN: Writes MEASEN for primary and secondary measurement. */
#define MC33774_ALLM_CFG_MEASEN_SHIFT                        (0x0U)
#define MC33774_ALLM_CFG_MEASEN_MASK                         (0x1U)
#define MC33774_ALLM_CFG_MEASEN_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_CFG_MEASEN_SHIFT)) & MC33774_ALLM_CFG_MEASEN_MASK))

/* Field BALPAUSECYCMODEN: Writes BALPAUSECYCMODEN for primary and secondary measurement. */
#define MC33774_ALLM_CFG_BALPAUSECYCMODEN_SHIFT              (0x1U)
#define MC33774_ALLM_CFG_BALPAUSECYCMODEN_MASK               (0x2U)
#define MC33774_ALLM_CFG_BALPAUSECYCMODEN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_CFG_BALPAUSECYCMODEN_SHIFT)) & MC33774_ALLM_CFG_BALPAUSECYCMODEN_MASK))

/* Field BALPAUSELEN: Writes BALPAUSELEN for primary and secondary measurement. */
#define MC33774_ALLM_CFG_BALPAUSELEN_SHIFT                   (0x2U)
#define MC33774_ALLM_CFG_BALPAUSELEN_MASK                    (0xFFFCU)
#define MC33774_ALLM_CFG_BALPAUSELEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_CFG_BALPAUSELEN_SHIFT)) & MC33774_ALLM_CFG_BALPAUSELEN_MASK))

/* --------------------------------------------------------------------------
 * ALLM_APP_CTRL (write-only):application measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_ALLM_APP_CTRL_OFFSET                         (0x1401U)
#define MC33774_ALLM_APP_CTRL_RW_MASK                        (0x0U)
#define MC33774_ALLM_APP_CTRL_RD_MASK                        (0x0U)
#define MC33774_ALLM_APP_CTRL_WR_MASK                        (0xFFFFU)
#define MC33774_ALLM_APP_CTRL_MW_MASK                        (0x0U)
#define MC33774_ALLM_APP_CTRL_RA_MASK                        (0x0U)
#define MC33774_ALLM_APP_CTRL_POR_MASK                       (0xFFFFU)
#define MC33774_ALLM_APP_CTRL_POR_VAL                        (0x7C00U)

/* Field CAPVC: Writes CAPVC for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33774_ALLM_APP_CTRL_CAPVC_SHIFT                    (0x0U)
#define MC33774_ALLM_APP_CTRL_CAPVC_MASK                     (0x1U)
#define MC33774_ALLM_APP_CTRL_CAPVC_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPVC_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPVC_MASK))

/* Field CAPAINA: Writes CAPAINA for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33774_ALLM_APP_CTRL_CAPAINA_SHIFT                  (0x1U)
#define MC33774_ALLM_APP_CTRL_CAPAINA_MASK                   (0x2U)
#define MC33774_ALLM_APP_CTRL_CAPAINA_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAINA_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAINA_MASK))

/* Field CAPAIN0: Writes CAPAIN0 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33774_ALLM_APP_CTRL_CAPAIN0_SHIFT                  (0x2U)
#define MC33774_ALLM_APP_CTRL_CAPAIN0_MASK                   (0x4U)
#define MC33774_ALLM_APP_CTRL_CAPAIN0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN0_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN0_MASK))

/* Field CAPAIN1: Writes CAPAIN1 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33774_ALLM_APP_CTRL_CAPAIN1_SHIFT                  (0x3U)
#define MC33774_ALLM_APP_CTRL_CAPAIN1_MASK                   (0x8U)
#define MC33774_ALLM_APP_CTRL_CAPAIN1_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN1_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN1_MASK))

/* Field CAPAIN2: Writes CAPAIN2 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33774_ALLM_APP_CTRL_CAPAIN2_SHIFT                  (0x4U)
#define MC33774_ALLM_APP_CTRL_CAPAIN2_MASK                   (0x10U)
#define MC33774_ALLM_APP_CTRL_CAPAIN2_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN2_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN2_MASK))

/* Field CAPAIN3: Writes CAPAIN3 for primary measurement. No influence on secondary measurement as long as it is used without the PAUSEBAL bit. */
#define MC33774_ALLM_APP_CTRL_CAPAIN3_SHIFT                  (0x5U)
#define MC33774_ALLM_APP_CTRL_CAPAIN3_MASK                   (0x20U)
#define MC33774_ALLM_APP_CTRL_CAPAIN3_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN3_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN3_MASK))

/* Field CAPAIN4: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN4 for secondary measurement. */
#define MC33774_ALLM_APP_CTRL_CAPAIN4_SHIFT                  (0x6U)
#define MC33774_ALLM_APP_CTRL_CAPAIN4_MASK                   (0x40U)
#define MC33774_ALLM_APP_CTRL_CAPAIN4_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN4_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN4_MASK))

/* Field CAPAIN5: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN5 for secondary measurement. */
#define MC33774_ALLM_APP_CTRL_CAPAIN5_SHIFT                  (0x7U)
#define MC33774_ALLM_APP_CTRL_CAPAIN5_MASK                   (0x80U)
#define MC33774_ALLM_APP_CTRL_CAPAIN5_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN5_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN5_MASK))

/* Field CAPAIN6: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN6 for secondary measurement. */
#define MC33774_ALLM_APP_CTRL_CAPAIN6_SHIFT                  (0x8U)
#define MC33774_ALLM_APP_CTRL_CAPAIN6_MASK                   (0x100U)
#define MC33774_ALLM_APP_CTRL_CAPAIN6_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN6_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN6_MASK))

/* Field CAPAIN7: No influence on primary measurement as long as it is used without the PAUSEBAL bit. Writes CAPAIN7 for secondary measurement. */
#define MC33774_ALLM_APP_CTRL_CAPAIN7_SHIFT                  (0x9U)
#define MC33774_ALLM_APP_CTRL_CAPAIN7_MASK                   (0x200U)
#define MC33774_ALLM_APP_CTRL_CAPAIN7_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_CAPAIN7_SHIFT)) & MC33774_ALLM_APP_CTRL_CAPAIN7_MASK))

/* Field VCOLNUM: Writes VCOLNUM for primary measurement, if CAPVC is set. No influence on secondary measurement. */
#define MC33774_ALLM_APP_CTRL_VCOLNUM_SHIFT                  (0xAU)
#define MC33774_ALLM_APP_CTRL_VCOLNUM_MASK                   (0x7C00U)
#define MC33774_ALLM_APP_CTRL_VCOLNUM_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_VCOLNUM_SHIFT)) & MC33774_ALLM_APP_CTRL_VCOLNUM_MASK))

/* Field PAUSEBAL: Writes PAUSEBAL for primary and secondary measurement. */
#define MC33774_ALLM_APP_CTRL_PAUSEBAL_SHIFT                 (0xFU)
#define MC33774_ALLM_APP_CTRL_PAUSEBAL_MASK                  (0x8000U)
#define MC33774_ALLM_APP_CTRL_PAUSEBAL_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_APP_CTRL_PAUSEBAL_SHIFT)) & MC33774_ALLM_APP_CTRL_PAUSEBAL_MASK))

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33774_ALLM_APP_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL     (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33774_ALLM_APP_CTRL_PAUSEBAL_PAUSE_ENUM_VAL        (1U)

/* Enumerated value DISABLED: Open load detection is disabled */
#define MC33774_ALLM_APP_CTRL_VCOLNUM_DISABLED_ENUM_VAL      (0x1FU)

/*ALL channel Measurements are captured*/
#define MC33774_ALLM_APP_CTRL_ALL_CAP_ENUM_VAL               (0x3FFU)

/* --------------------------------------------------------------------------
 * ALLM_PER_CTRL (write-only):periodic measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_ALLM_PER_CTRL_OFFSET                         (0x1402U)
#define MC33774_ALLM_PER_CTRL_RW_MASK                        (0x0U)
#define MC33774_ALLM_PER_CTRL_RD_MASK                        (0x0U)
#define MC33774_ALLM_PER_CTRL_WR_MASK                        (0x11FFU)
#define MC33774_ALLM_PER_CTRL_MW_MASK                        (0x0U)
#define MC33774_ALLM_PER_CTRL_RA_MASK                        (0x0U)
#define MC33774_ALLM_PER_CTRL_POR_MASK                       (0xFFFFU)
#define MC33774_ALLM_PER_CTRL_POR_VAL                        (0x10U)

/* Field PERLEN: Writes PERLEN for primary and secondary measurement. */
#define MC33774_ALLM_PER_CTRL_PERLEN_SHIFT                   (0x0U)
#define MC33774_ALLM_PER_CTRL_PERLEN_MASK                    (0x1FFU)
#define MC33774_ALLM_PER_CTRL_PERLEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_PER_CTRL_PERLEN_SHIFT)) & MC33774_ALLM_PER_CTRL_PERLEN_MASK))

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_ALLM_PER_CTRL_RESERVED0_SHIFT                (0x9U)
#define MC33774_ALLM_PER_CTRL_RESERVED0_MASK                 (0xE00U)
#define MC33774_ALLM_PER_CTRL_RESERVED0_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_PER_CTRL_RESERVED0_SHIFT)) & MC33774_ALLM_PER_CTRL_RESERVED0_MASK))

/* Field PERCTRL: Writes PERCTRL for primary and secondary measurement. */
#define MC33774_ALLM_PER_CTRL_PERCTRL_SHIFT                  (0xCU)
#define MC33774_ALLM_PER_CTRL_PERCTRL_MASK                   (0x1000U)
#define MC33774_ALLM_PER_CTRL_PERCTRL_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_PER_CTRL_PERCTRL_SHIFT)) & MC33774_ALLM_PER_CTRL_PERCTRL_MASK))

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_ALLM_PER_CTRL_RESERVED1_SHIFT                (0xDU)
#define MC33774_ALLM_PER_CTRL_RESERVED1_MASK                 (0xE000U)
#define MC33774_ALLM_PER_CTRL_RESERVED1_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_PER_CTRL_RESERVED1_SHIFT)) & MC33774_ALLM_PER_CTRL_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * ALLM_SYNC_CTRL (write-only):synchronous measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_ALLM_SYNC_CTRL_OFFSET                        (0x1403U)
#define MC33774_ALLM_SYNC_CTRL_RW_MASK                       (0x0U)
#define MC33774_ALLM_SYNC_CTRL_RD_MASK                       (0x0U)
#define MC33774_ALLM_SYNC_CTRL_WR_MASK                       (0xFC03U)
#define MC33774_ALLM_SYNC_CTRL_MW_MASK                       (0x0U)
#define MC33774_ALLM_SYNC_CTRL_RA_MASK                       (0x0U)
#define MC33774_ALLM_SYNC_CTRL_POR_MASK                      (0xFFFFU)
#define MC33774_ALLM_SYNC_CTRL_POR_VAL                       (0x7C00U)

/* Field SYNCCYC: Writes SYNCCYC for primary and secondary measurement. */
#define MC33774_ALLM_SYNC_CTRL_SYNCCYC_SHIFT                 (0x0U)
#define MC33774_ALLM_SYNC_CTRL_SYNCCYC_MASK                  (0x1U)
#define MC33774_ALLM_SYNC_CTRL_SYNCCYC_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_SYNC_CTRL_SYNCCYC_SHIFT)) & MC33774_ALLM_SYNC_CTRL_SYNCCYC_MASK))

/* Field FASTVB: Dummy fast measurement cycle on primary measurement. Writes FASTVB for secondary measurement. */
#define MC33774_ALLM_SYNC_CTRL_FASTVB_SHIFT                  (0x1U)
#define MC33774_ALLM_SYNC_CTRL_FASTVB_MASK                   (0x2U)
#define MC33774_ALLM_SYNC_CTRL_FASTVB_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_SYNC_CTRL_FASTVB_SHIFT)) & MC33774_ALLM_SYNC_CTRL_FASTVB_MASK))

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_ALLM_SYNC_CTRL_RESERVED0_SHIFT               (0x2U)
#define MC33774_ALLM_SYNC_CTRL_RESERVED0_MASK                (0x3FCU)
#define MC33774_ALLM_SYNC_CTRL_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_SYNC_CTRL_RESERVED0_SHIFT)) & MC33774_ALLM_SYNC_CTRL_RESERVED0_MASK))

/* Field VBOLNUM: No influence on primary measurement. Writes VBOLNUM for secondary measurement. */
#define MC33774_ALLM_SYNC_CTRL_VBOLNUM_SHIFT                 (0xAU)
#define MC33774_ALLM_SYNC_CTRL_VBOLNUM_MASK                  (0x7C00U)
#define MC33774_ALLM_SYNC_CTRL_VBOLNUM_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_SYNC_CTRL_VBOLNUM_SHIFT)) & MC33774_ALLM_SYNC_CTRL_VBOLNUM_MASK))

/* Field PAUSEBAL: Writes PAUSEBAL for primary and secondary measurement. */
#define MC33774_ALLM_SYNC_CTRL_PAUSEBAL_SHIFT                (0xFU)
#define MC33774_ALLM_SYNC_CTRL_PAUSEBAL_MASK                 (0x8000U)
#define MC33774_ALLM_SYNC_CTRL_PAUSEBAL_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_SYNC_CTRL_PAUSEBAL_SHIFT)) & MC33774_ALLM_SYNC_CTRL_PAUSEBAL_MASK))

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33774_ALLM_SYNC_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL    (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33774_ALLM_SYNC_CTRL_PAUSEBAL_PAUSE_ENUM_VAL       (1U)

/* Enumerated value ENABLE: open load detection is enabled for the currently measured channel */
#define MC33774_ALLM_SYNC_CTRL_VCOLNUM_ENABLED_ENUM_VAL      (0x1EU)

/* Enumerated value DISABLED: Open load detection is disabled */
#define MC33774_ALLM_SYNC_CTRL_VBOLNUM_DISABLED_ENUM_VAL     (0x1FU)

/* Enumerated value STATUS: Read a zero */
#define MC33774_ALLM_SYNC_CTRL_SYNCCYC_STATUS_ENUM_VAL       (0U)

/* Enumerated value START: Start a synchronous measurement cycle. */
#define MC33774_ALLM_SYNC_CTRL_SYNCCYC_START_ENUM_VAL        (1U)

/* --------------------------------------------------------------------------
 * ALLM_VCVB_CFG0 (write-only):cell voltage measurement enable
 * -------------------------------------------------------------------------- */
#define MC33774_ALLM_VCVB_CFG0_OFFSET                        (0x1408U)
#define MC33774_ALLM_VCVB_CFG0_RW_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG0_RD_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG0_WR_MASK                       (0xFFFFU)
#define MC33774_ALLM_VCVB_CFG0_MW_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG0_RA_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG0_POR_MASK                      (0xFFFFU)
#define MC33774_ALLM_VCVB_CFG0_POR_VAL                       (0x0U)

/* Field VCVB0EN: Writes VC0EN for primary and VB0EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB0EN_SHIFT                 (0x0U)
#define MC33774_ALLM_VCVB_CFG0_VCVB0EN_MASK                  (0x1U)
#define MC33774_ALLM_VCVB_CFG0_VCVB0EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB0EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB0EN_MASK))

/* Field VCVB1EN: Writes VC1EN for primary and VB1EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB1EN_SHIFT                 (0x1U)
#define MC33774_ALLM_VCVB_CFG0_VCVB1EN_MASK                  (0x2U)
#define MC33774_ALLM_VCVB_CFG0_VCVB1EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB1EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB1EN_MASK))

/* Field VCVB2EN: Writes VC2EN for primary and VB2EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB2EN_SHIFT                 (0x2U)
#define MC33774_ALLM_VCVB_CFG0_VCVB2EN_MASK                  (0x4U)
#define MC33774_ALLM_VCVB_CFG0_VCVB2EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB2EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB2EN_MASK))

/* Field VCVB3EN: Writes VC3EN for primary and VB3EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB3EN_SHIFT                 (0x3U)
#define MC33774_ALLM_VCVB_CFG0_VCVB3EN_MASK                  (0x8U)
#define MC33774_ALLM_VCVB_CFG0_VCVB3EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB3EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB3EN_MASK))

/* Field VCVB4EN: Writes VC4EN for primary and VB4EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB4EN_SHIFT                 (0x4U)
#define MC33774_ALLM_VCVB_CFG0_VCVB4EN_MASK                  (0x10U)
#define MC33774_ALLM_VCVB_CFG0_VCVB4EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB4EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB4EN_MASK))

/* Field VCVB5EN: Writes VC5EN for primary and VB5EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB5EN_SHIFT                 (0x5U)
#define MC33774_ALLM_VCVB_CFG0_VCVB5EN_MASK                  (0x20U)
#define MC33774_ALLM_VCVB_CFG0_VCVB5EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB5EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB5EN_MASK))

/* Field VCVB6EN: Writes VC6EN for primary and VB6EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB6EN_SHIFT                 (0x6U)
#define MC33774_ALLM_VCVB_CFG0_VCVB6EN_MASK                  (0x40U)
#define MC33774_ALLM_VCVB_CFG0_VCVB6EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB6EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB6EN_MASK))

/* Field VCVB7EN: Writes VC7EN for primary and VB7EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB7EN_SHIFT                 (0x7U)
#define MC33774_ALLM_VCVB_CFG0_VCVB7EN_MASK                  (0x80U)
#define MC33774_ALLM_VCVB_CFG0_VCVB7EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB7EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB7EN_MASK))

/* Field VCVB8EN: Writes VC8EN for primary and VB8EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB8EN_SHIFT                 (0x8U)
#define MC33774_ALLM_VCVB_CFG0_VCVB8EN_MASK                  (0x100U)
#define MC33774_ALLM_VCVB_CFG0_VCVB8EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB8EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB8EN_MASK))

/* Field VCVB9EN: Writes VC9EN for primary and VB9EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB9EN_SHIFT                 (0x9U)
#define MC33774_ALLM_VCVB_CFG0_VCVB9EN_MASK                  (0x200U)
#define MC33774_ALLM_VCVB_CFG0_VCVB9EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB9EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB9EN_MASK))

/* Field VCVB10EN: Writes VC10EN for primary and VB10EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB10EN_SHIFT                (0xAU)
#define MC33774_ALLM_VCVB_CFG0_VCVB10EN_MASK                 (0x400U)
#define MC33774_ALLM_VCVB_CFG0_VCVB10EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB10EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB10EN_MASK))

/* Field VCVB11EN: Writes VC11EN for primary and VB11EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB11EN_SHIFT                (0xBU)
#define MC33774_ALLM_VCVB_CFG0_VCVB11EN_MASK                 (0x800U)
#define MC33774_ALLM_VCVB_CFG0_VCVB11EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB11EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB11EN_MASK))

/* Field VCVB12EN: Writes VC12EN for primary and VB12EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB12EN_SHIFT                (0xCU)
#define MC33774_ALLM_VCVB_CFG0_VCVB12EN_MASK                 (0x1000U)
#define MC33774_ALLM_VCVB_CFG0_VCVB12EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB12EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB12EN_MASK))

/* Field VCVB13EN: Writes VC13EN for primary and VB13EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB13EN_SHIFT                (0xDU)
#define MC33774_ALLM_VCVB_CFG0_VCVB13EN_MASK                 (0x2000U)
#define MC33774_ALLM_VCVB_CFG0_VCVB13EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB13EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB13EN_MASK))

/* Field VCVB14EN: Writes VC14EN for primary and VB14EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB14EN_SHIFT                (0xEU)
#define MC33774_ALLM_VCVB_CFG0_VCVB14EN_MASK                 (0x4000U)
#define MC33774_ALLM_VCVB_CFG0_VCVB14EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB14EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB14EN_MASK))

/* Field VCVB15EN: Writes VC15EN for primary and VB15EN secondary measurement. */
#define MC33774_ALLM_VCVB_CFG0_VCVB15EN_SHIFT                (0xFU)
#define MC33774_ALLM_VCVB_CFG0_VCVB15EN_MASK                 (0x8000U)
#define MC33774_ALLM_VCVB_CFG0_VCVB15EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG0_VCVB15EN_SHIFT)) & MC33774_ALLM_VCVB_CFG0_VCVB15EN_MASK))

/* --------------------------------------------------------------------------
 * ALLM_VCVB_CFG1 (write-only):cell voltage measurement enable
 * -------------------------------------------------------------------------- */
#define MC33774_ALLM_VCVB_CFG1_OFFSET                        (0x1409U)
#define MC33774_ALLM_VCVB_CFG1_RW_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG1_RD_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG1_WR_MASK                       (0x3U)
#define MC33774_ALLM_VCVB_CFG1_MW_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG1_RA_MASK                       (0x0U)
#define MC33774_ALLM_VCVB_CFG1_POR_MASK                      (0xFFFFU)
#define MC33774_ALLM_VCVB_CFG1_POR_VAL                       (0x0U)

/* Field VCVB16EN: writes VC16EN for primary and VB16EN secondary measurement */
#define MC33774_ALLM_VCVB_CFG1_VCVB16EN_SHIFT                (0x0U)
#define MC33774_ALLM_VCVB_CFG1_VCVB16EN_MASK                 (0x1U)
#define MC33774_ALLM_VCVB_CFG1_VCVB16EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG1_VCVB16EN_SHIFT)) & MC33774_ALLM_VCVB_CFG1_VCVB16EN_MASK))

/* Field VCVB17EN: writes VC17EN for primary and VB17EN secondary measurement */
#define MC33774_ALLM_VCVB_CFG1_VCVB17EN_SHIFT                (0x1U)
#define MC33774_ALLM_VCVB_CFG1_VCVB17EN_MASK                 (0x2U)
#define MC33774_ALLM_VCVB_CFG1_VCVB17EN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG1_VCVB17EN_SHIFT)) & MC33774_ALLM_VCVB_CFG1_VCVB17EN_MASK))

/* Field reserved0: this read-only field is reserved and always has the value 0 */
#define MC33774_ALLM_VCVB_CFG1_RESERVED0_SHIFT               (0x2U)
#define MC33774_ALLM_VCVB_CFG1_RESERVED0_MASK                (0xFFFCU)
#define MC33774_ALLM_VCVB_CFG1_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_ALLM_VCVB_CFG1_RESERVED0_SHIFT)) & MC33774_ALLM_VCVB_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * SYS_CFG_CRC (read-only):system configuration CRC
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_CFG_CRC_OFFSET                           (0x0U)
#define MC33774_SYS_CFG_CRC_RW_MASK                          (0x0U)
#define MC33774_SYS_CFG_CRC_RD_MASK                          (0xFFFFU)
#define MC33774_SYS_CFG_CRC_WR_MASK                          (0x0U)
#define MC33774_SYS_CFG_CRC_MW_MASK                          (0x0U)
#define MC33774_SYS_CFG_CRC_RA_MASK                          (0x0U)
#define MC33774_SYS_CFG_CRC_POR_MASK                         (0xFFFFU)
#define MC33774_SYS_CFG_CRC_POR_VAL                          (0x0U)

/* Field CRC: This CRC value is recalculated with any write to a covered register and with any read to this register. The updated CRC value is available latest 100us after the last write.
The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1.
Following registers are included:  SYS_COM_CFG, SYS_COM_TO_CFG, SYS_SUPPLY_CFG, SYS_CYC_WAKEUP_CFG, SYS_TPL_CFG. */
#define MC33774_SYS_CFG_CRC_CRC_SHIFT                        (0x0U)
#define MC33774_SYS_CFG_CRC_CRC_MASK                         (0xFFFFU)
#define MC33774_SYS_CFG_CRC_CRC_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_SYS_CFG_CRC_CRC_SHIFT)) & MC33774_SYS_CFG_CRC_CRC_MASK))

/* --------------------------------------------------------------------------
 * SYS_COM_CFG (read-write):communication initialization
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_COM_CFG_OFFSET                           (0x1U)
#define MC33774_SYS_COM_CFG_RW_MASK                          (0xFFFFU)
#define MC33774_SYS_COM_CFG_RD_MASK                          (0xFFFFU)
#define MC33774_SYS_COM_CFG_WR_MASK                          (0xFFFFU)
#define MC33774_SYS_COM_CFG_MW_MASK                          (0x0U)
#define MC33774_SYS_COM_CFG_RA_MASK                          (0x0U)
#define MC33774_SYS_COM_CFG_POR_MASK                         (0xFFFFU)
#define MC33774_SYS_COM_CFG_POR_VAL                          (0x200U)

/* Field DADD: Defines the device address. */
#define MC33774_SYS_COM_CFG_DADD_SHIFT                       (0x0U)
#define MC33774_SYS_COM_CFG_DADD_MASK                        (0x3FU)
#define MC33774_SYS_COM_CFG_DADD_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SYS_COM_CFG_DADD_SHIFT)) & MC33774_SYS_COM_CFG_DADD_MASK))

/* Enumerated value UNENUMERATED: Device is unenumerated; bus forwarding is disabled. */
#define MC33774_SYS_COM_CFG_DADD_UNENUMERATED_ENUM_VAL       (0U)

/* Enumerated value GLOBAL: Used for global read and write commands */
#define MC33774_SYS_COM_CFG_DADD_GLOBAL_ENUM_VAL             (63U)

/* Field CADD: Defines the daisy chain address. Only used for responses to a all chain read request. */
#define MC33774_SYS_COM_CFG_CADD_SHIFT                       (0x6U)
#define MC33774_SYS_COM_CFG_CADD_MASK                        (0x1C0U)
#define MC33774_SYS_COM_CFG_CADD_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SYS_COM_CFG_CADD_SHIFT)) & MC33774_SYS_COM_CFG_CADD_MASK))

/* Enumerated value RESERVED: Reserved for future usage */
#define MC33774_SYS_COM_CFG_CADD_RESERVED_ENUM_VAL           (0U)

/* Enumerated value GLOBAL: Reserved for global write commands */
#define MC33774_SYS_COM_CFG_CADD_GLOBAL_ENUM_VAL             (7U)

/* Field BUSFW: Bus forwarding */
#define MC33774_SYS_COM_CFG_BUSFW_SHIFT                      (0x9U)
#define MC33774_SYS_COM_CFG_BUSFW_MASK                       (0x200U)
#define MC33774_SYS_COM_CFG_BUSFW_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_SYS_COM_CFG_BUSFW_SHIFT)) & MC33774_SYS_COM_CFG_BUSFW_MASK))

/* Enumerated value DISABLED: Disabled */
#define MC33774_SYS_COM_CFG_BUSFW_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Enabled if DADD is unequal 00h */
#define MC33774_SYS_COM_CFG_BUSFW_ENABLED_ENUM_VAL           (1U)

/* Field NUMNODES: Number of nodes in the daisy chain. Difference of NUMNODES and DADD defines the wait time for global write commands. */
#define MC33774_SYS_COM_CFG_NUMNODES_SHIFT                   (0xAU)
#define MC33774_SYS_COM_CFG_NUMNODES_MASK                    (0xFC00U)
#define MC33774_SYS_COM_CFG_NUMNODES_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SYS_COM_CFG_NUMNODES_SHIFT)) & MC33774_SYS_COM_CFG_NUMNODES_MASK))

/* --------------------------------------------------------------------------
 * SYS_COM_TO_CFG (read-write):system communication timeout
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_COM_TO_CFG_OFFSET                        (0x2U)
#define MC33774_SYS_COM_TO_CFG_RW_MASK                       (0xFFFFU)
#define MC33774_SYS_COM_TO_CFG_RD_MASK                       (0xFFFFU)
#define MC33774_SYS_COM_TO_CFG_WR_MASK                       (0xFFFFU)
#define MC33774_SYS_COM_TO_CFG_MW_MASK                       (0x0U)
#define MC33774_SYS_COM_TO_CFG_RA_MASK                       (0x0U)
#define MC33774_SYS_COM_TO_CFG_POR_MASK                      (0xFFFFU)
#define MC33774_SYS_COM_TO_CFG_POR_VAL                       (0x1EU)

/* Field COMTO: Communication timeout time LSB = 10 ms A value of 0 is treated as 10 ms. */
#define MC33774_SYS_COM_TO_CFG_COMTO_SHIFT                   (0x0U)
#define MC33774_SYS_COM_TO_CFG_COMTO_MASK                    (0xFFU)
#define MC33774_SYS_COM_TO_CFG_COMTO_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SYS_COM_TO_CFG_COMTO_SHIFT)) & MC33774_SYS_COM_TO_CFG_COMTO_MASK))

/* Enumerated value T_MIN: 10 ms */
#define MC33774_SYS_COM_TO_CFG_COMTO_T_MIN_ENUM_VAL          (0U)

/* Enumerated value T_10m: 10 ms */
#define MC33774_SYS_COM_TO_CFG_COMTO_T_10M_ENUM_VAL          (1U)

/* Enumerated value T_300m: 300 ms */
#define MC33774_SYS_COM_TO_CFG_COMTO_T_300M_ENUM_VAL         (30U)

/* Enumerated value T_MAX: 2550 ms */
#define MC33774_SYS_COM_TO_CFG_COMTO_T_MAX_ENUM_VAL          (255U)

/* Field COMTODISABLE: Communication timeout disable. Only intended for software development activities. Must never be used in release software. */
#define MC33774_SYS_COM_TO_CFG_COMTODISABLE_SHIFT            (0x8U)
#define MC33774_SYS_COM_TO_CFG_COMTODISABLE_MASK             (0xFF00U)
#define MC33774_SYS_COM_TO_CFG_COMTODISABLE_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_SYS_COM_TO_CFG_COMTODISABLE_SHIFT)) & MC33774_SYS_COM_TO_CFG_COMTODISABLE_MASK))

/* Enumerated value DEFAULT: Communication timeout enabled */
#define MC33774_SYS_COM_TO_CFG_COMTODISABLE_DEFAULT_ENUM_VAL \
  (0U)

/* Enumerated value DISABLED: Communication timeout disabled */
#define MC33774_SYS_COM_TO_CFG_COMTODISABLE_DISABLED_ENUM_VAL \
  (90U)

/* --------------------------------------------------------------------------
 * SYS_SUPPLY_CFG (read-write):supply configuration
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_SUPPLY_CFG_OFFSET                        (0x3U)
#define MC33774_SYS_SUPPLY_CFG_RW_MASK                       (0x8007U)
#define MC33774_SYS_SUPPLY_CFG_RD_MASK                       (0x8007U)
#define MC33774_SYS_SUPPLY_CFG_WR_MASK                       (0x8007U)
#define MC33774_SYS_SUPPLY_CFG_MW_MASK                       (0x0U)
#define MC33774_SYS_SUPPLY_CFG_RA_MASK                       (0x0U)
#define MC33774_SYS_SUPPLY_CFG_POR_MASK                      (0xFFFFU)
#define MC33774_SYS_SUPPLY_CFG_POR_VAL                       (0x8003U)

/* Field VAUXACT: Enable VAUX in active mode. */
#define MC33774_SYS_SUPPLY_CFG_VAUXACT_SHIFT                 (0x0U)
#define MC33774_SYS_SUPPLY_CFG_VAUXACT_MASK                  (0x1U)
#define MC33774_SYS_SUPPLY_CFG_VAUXACT_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SYS_SUPPLY_CFG_VAUXACT_SHIFT)) & MC33774_SYS_SUPPLY_CFG_VAUXACT_MASK))

/* Enumerated value DISABLED: VAUX is disabled in active mode */
#define MC33774_SYS_SUPPLY_CFG_VAUXACT_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: VAUX is enabled in active mode */
#define MC33774_SYS_SUPPLY_CFG_VAUXACT_ENABLED_ENUM_VAL      (1U)

/* Field VAUXCYC: Enable VAUX in cyclic mode. */
#define MC33774_SYS_SUPPLY_CFG_VAUXCYC_SHIFT                 (0x1U)
#define MC33774_SYS_SUPPLY_CFG_VAUXCYC_MASK                  (0x2U)
#define MC33774_SYS_SUPPLY_CFG_VAUXCYC_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SYS_SUPPLY_CFG_VAUXCYC_SHIFT)) & MC33774_SYS_SUPPLY_CFG_VAUXCYC_MASK))

/* Enumerated value DISABLED: VAUX is disabled in cyclic mode */
#define MC33774_SYS_SUPPLY_CFG_VAUXCYC_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: VAUX is enabled in cyclic mode */
#define MC33774_SYS_SUPPLY_CFG_VAUXCYC_ENABLED_ENUM_VAL      (1U)

/* Field VDDCCYC: Enable VDDC in cyclic mode. */
#define MC33774_SYS_SUPPLY_CFG_VDDCCYC_SHIFT                 (0x2U)
#define MC33774_SYS_SUPPLY_CFG_VDDCCYC_MASK                  (0x4U)
#define MC33774_SYS_SUPPLY_CFG_VDDCCYC_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SYS_SUPPLY_CFG_VDDCCYC_SHIFT)) & MC33774_SYS_SUPPLY_CFG_VDDCCYC_MASK))

/* Enumerated value DISABLED: VDDC is disabled in cyclic mode */
#define MC33774_SYS_SUPPLY_CFG_VDDCCYC_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: VDDC is enabled in cyclic mode */
#define MC33774_SYS_SUPPLY_CFG_VDDCCYC_ENABLED_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SYS_SUPPLY_CFG_RESERVED0_SHIFT               (0x3U)
#define MC33774_SYS_SUPPLY_CFG_RESERVED0_MASK                (0x7FF8U)
#define MC33774_SYS_SUPPLY_CFG_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_SYS_SUPPLY_CFG_RESERVED0_SHIFT)) & MC33774_SYS_SUPPLY_CFG_RESERVED0_MASK))

/* Field CURMATCH: Enable IC supply current matching in active mode. */
#define MC33774_SYS_SUPPLY_CFG_CURMATCH_SHIFT                (0xFU)
#define MC33774_SYS_SUPPLY_CFG_CURMATCH_MASK                 (0x8000U)
#define MC33774_SYS_SUPPLY_CFG_CURMATCH_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_SYS_SUPPLY_CFG_CURMATCH_SHIFT)) & MC33774_SYS_SUPPLY_CFG_CURMATCH_MASK))

/* Enumerated value DISABLED: Supply current matching is disabled */
#define MC33774_SYS_SUPPLY_CFG_CURMATCH_DISABLED_ENUM_VAL    (0U)

/* Enumerated value ENABLED: Supply current matching is enabled */
#define MC33774_SYS_SUPPLY_CFG_CURMATCH_ENABLED_ENUM_VAL     (1U)

/* --------------------------------------------------------------------------
 * SYS_MODE (read-write):system mode
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_MODE_OFFSET                              (0x4U)
#define MC33774_SYS_MODE_RW_MASK                             (0x0U)
#define MC33774_SYS_MODE_RD_MASK                             (0x1F00U)
#define MC33774_SYS_MODE_WR_MASK                             (0x1FU)
#define MC33774_SYS_MODE_MW_MASK                             (0x0U)
#define MC33774_SYS_MODE_RA_MASK                             (0x0U)
#define MC33774_SYS_MODE_POR_MASK                            (0xFFFFU)
#define MC33774_SYS_MODE_POR_VAL                             (0x1400U)

/* Field TARGETMODE: Target_mode. The mode transition starts immediately after writing. 01010 = sleep, 10100 = deep sleep, Undefined values are ignored. */
#define MC33774_SYS_MODE_TARGETMODE_SHIFT                    (0x0U)
#define MC33774_SYS_MODE_TARGETMODE_MASK                     (0x1FU)
#define MC33774_SYS_MODE_TARGETMODE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SYS_MODE_TARGETMODE_SHIFT)) & MC33774_SYS_MODE_TARGETMODE_MASK))

/* Enumerated value SLEEP: Sleep mode */
#define MC33774_SYS_MODE_TARGETMODE_SLEEP_ENUM_VAL           (10U)

/* Enumerated value DEEPSLEEP: Deep sleep mode */
#define MC33774_SYS_MODE_TARGETMODE_DEEPSLEEP_ENUM_VAL       (20U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SYS_MODE_RESERVED0_SHIFT                     (0x5U)
#define MC33774_SYS_MODE_RESERVED0_MASK                      (0xE0U)
#define MC33774_SYS_MODE_RESERVED0_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SYS_MODE_RESERVED0_SHIFT)) & MC33774_SYS_MODE_RESERVED0_MASK))

/* Field PREVMODE: Previous mode */
#define MC33774_SYS_MODE_PREVMODE_SHIFT                      (0x8U)
#define MC33774_SYS_MODE_PREVMODE_MASK                       (0x1F00U)
#define MC33774_SYS_MODE_PREVMODE_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_SYS_MODE_PREVMODE_SHIFT)) & MC33774_SYS_MODE_PREVMODE_MASK))

/* Enumerated value SLEEP: Sleep mode */
#define MC33774_SYS_MODE_PREVMODE_SLEEP_ENUM_VAL             (10U)

/* Enumerated value DEEPSLEEP: Deep sleep mode */
#define MC33774_SYS_MODE_PREVMODE_DEEPSLEEP_ENUM_VAL         (20U)

/* Enumerated value CYCLIC: Cyclic mode */
#define MC33774_SYS_MODE_PREVMODE_CYCLIC_ENUM_VAL            (31U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_SYS_MODE_RESERVED1_SHIFT                     (0xDU)
#define MC33774_SYS_MODE_RESERVED1_MASK                      (0xE000U)
#define MC33774_SYS_MODE_RESERVED1_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SYS_MODE_RESERVED1_SHIFT)) & MC33774_SYS_MODE_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * SYS_CYC_WAKEUP_CFG (read-write):interval for cyclic measurements
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_CYC_WAKEUP_CFG_OFFSET                    (0x5U)
#define MC33774_SYS_CYC_WAKEUP_CFG_RW_MASK                   (0xFFFFU)
#define MC33774_SYS_CYC_WAKEUP_CFG_RD_MASK                   (0xFFFFU)
#define MC33774_SYS_CYC_WAKEUP_CFG_WR_MASK                   (0xFFFFU)
#define MC33774_SYS_CYC_WAKEUP_CFG_MW_MASK                   (0x0U)
#define MC33774_SYS_CYC_WAKEUP_CFG_RA_MASK                   (0x0U)
#define MC33774_SYS_CYC_WAKEUP_CFG_POR_MASK                  (0xFFFFU)
#define MC33774_SYS_CYC_WAKEUP_CFG_POR_VAL                   (0x0U)

/* Field PERIOD: Time between two cyclic wake-up events */
#define MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_SHIFT              (0x0U)
#define MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_MASK               (0xFFFFU)
#define MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_SHIFT)) & MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_MASK))

/* Enumerated value DISABLED: Cyclic wakeup disabled */
#define MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value PERIOD: PERIOD * 100 ms */
#define MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_PERIOD_ENUM_VAL    (1U)

/* Enumerated value PERIOD_MAX: Maximum period time = 6553500 ms = approximately 1.8 h */
#define MC33774_SYS_CYC_WAKEUP_CFG_PERIOD_PERIOD_MAX_ENUM_VAL \
  (65535U)

/* --------------------------------------------------------------------------
 * SYS_TPL_CFG (read-write):TPL configuration
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_TPL_CFG_OFFSET                           (0x6U)
#define MC33774_SYS_TPL_CFG_RW_MASK                          (0x3FU)
#define MC33774_SYS_TPL_CFG_RD_MASK                          (0x3FU)
#define MC33774_SYS_TPL_CFG_WR_MASK                          (0x3FU)
#define MC33774_SYS_TPL_CFG_MW_MASK                          (0x0U)
#define MC33774_SYS_TPL_CFG_RA_MASK                          (0x0U)
#define MC33774_SYS_TPL_CFG_POR_MASK                         (0xFFFFU)
#define MC33774_SYS_TPL_CFG_POR_VAL                          (0x10U)

/* Field WAKEUPCOMP: Defines compatibility for the MC33664 wake-up by the Daisy Chain. Undefined values are treated as HIGHER. */
#define MC33774_SYS_TPL_CFG_WAKEUPCOMP_SHIFT                 (0x0U)
#define MC33774_SYS_TPL_CFG_WAKEUPCOMP_MASK                  (0x3U)
#define MC33774_SYS_TPL_CFG_WAKEUPCOMP_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SYS_TPL_CFG_WAKEUPCOMP_SHIFT)) & MC33774_SYS_TPL_CFG_WAKEUPCOMP_MASK))

/* Enumerated value DEFAULT: Wake-up signal on both ports is compatible to MC33775 and MC33774. */
#define MC33774_SYS_TPL_CFG_WAKEUPCOMP_DEFAULT_ENUM_VAL      (0U)

/* Enumerated value LOWER: Wake-up signal on lower TPL port is compatible to MC33664. The other port is compatible to MC33775 and MC33774. */
#define MC33774_SYS_TPL_CFG_WAKEUPCOMP_LOWER_ENUM_VAL        (1U)

/* Enumerated value HIGHER: Wake-up signal on higher TPL port is compatible to MC33664. The other port is compatible to MC33775 and MC33774. */
#define MC33774_SYS_TPL_CFG_WAKEUPCOMP_HIGHER_ENUM_VAL       (2U)

/* Field TXTERML: Termination active while transmit for the lower TPL port. (Pin 47 and pin 48) */
#define MC33774_SYS_TPL_CFG_TXTERML_SHIFT                    (0x2U)
#define MC33774_SYS_TPL_CFG_TXTERML_MASK                     (0x4U)
#define MC33774_SYS_TPL_CFG_TXTERML_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SYS_TPL_CFG_TXTERML_SHIFT)) & MC33774_SYS_TPL_CFG_TXTERML_MASK))

/* Enumerated value DISABLED: Disabled; termination is inactive during transmit. Required for normal TPL operation. */
#define MC33774_SYS_TPL_CFG_TXTERML_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Enabled; termination is active during transmit. Only needed at final daisy-chain node to have equal power consumption. */
#define MC33774_SYS_TPL_CFG_TXTERML_ENABLED_ENUM_VAL         (1U)

/* Field TXTERMH: Termination active while transmit for the higher TPL port. (Pin 49 and pin 50) */
#define MC33774_SYS_TPL_CFG_TXTERMH_SHIFT                    (0x3U)
#define MC33774_SYS_TPL_CFG_TXTERMH_MASK                     (0x8U)
#define MC33774_SYS_TPL_CFG_TXTERMH_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SYS_TPL_CFG_TXTERMH_SHIFT)) & MC33774_SYS_TPL_CFG_TXTERMH_MASK))

/* Enumerated value DISABLED: Disabled; termination is inactive during transmit. Required for normal TPL operation. */
#define MC33774_SYS_TPL_CFG_TXTERMH_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Enabled; termination is active during transmit. Only needed at final daisy-chain node to have equal power consumption. */
#define MC33774_SYS_TPL_CFG_TXTERMH_ENABLED_ENUM_VAL         (1U)

/* Field RESPCFG: Response interface */
#define MC33774_SYS_TPL_CFG_RESPCFG_SHIFT                    (0x4U)
#define MC33774_SYS_TPL_CFG_RESPCFG_MASK                     (0x30U)
#define MC33774_SYS_TPL_CFG_RESPCFG_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SYS_TPL_CFG_RESPCFG_SHIFT)) & MC33774_SYS_TPL_CFG_RESPCFG_MASK))

/* Enumerated value SAME: Responses are only transmitted on the receiving port. */
#define MC33774_SYS_TPL_CFG_RESPCFG_SAME_ENUM_VAL            (0U)

/* Enumerated value BOTH: Responses are transmitted on both ports if DADD is unequal 00h. */
#define MC33774_SYS_TPL_CFG_RESPCFG_BOTH_ENUM_VAL            (1U)

/* Enumerated value OPPOSITE: Responses are transmitted on the opposite port of the receiving port. */
#define MC33774_SYS_TPL_CFG_RESPCFG_OPPOSITE_ENUM_VAL        (2U)

/* Enumerated value RESERVED: Reserved, do not use. For now same as BOTH. */
#define MC33774_SYS_TPL_CFG_RESPCFG_RESERVED_ENUM_VAL        (3U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SYS_TPL_CFG_RESERVED0_SHIFT                  (0x6U)
#define MC33774_SYS_TPL_CFG_RESERVED0_MASK                   (0xFFC0U)
#define MC33774_SYS_TPL_CFG_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SYS_TPL_CFG_RESERVED0_SHIFT)) & MC33774_SYS_TPL_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * SYS_CLK_SYNC_CTRL (read-write):clock Synchronization
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_CLK_SYNC_CTRL_OFFSET                     (0x8U)
#define MC33774_SYS_CLK_SYNC_CTRL_RW_MASK                    (0xFFFFU)
#define MC33774_SYS_CLK_SYNC_CTRL_RD_MASK                    (0xFFFFU)
#define MC33774_SYS_CLK_SYNC_CTRL_WR_MASK                    (0xFFFFU)
#define MC33774_SYS_CLK_SYNC_CTRL_MW_MASK                    (0x0U)
#define MC33774_SYS_CLK_SYNC_CTRL_RA_MASK                    (0x0U)
#define MC33774_SYS_CLK_SYNC_CTRL_POR_MASK                   (0xFFFFU)
#define MC33774_SYS_CLK_SYNC_CTRL_POR_VAL                    (0x0U)

/* Field SYNCCNT: Synchronization counter value: Writing a 0x0000 resets the counter with no adjustment. For other values it is checked if the internal counter value is higher, in which case the oscillator frequency is decreased.
If it is lower the internal oscillator frequency is increased. Reading the value returns the current internal counter value. 1 LSB = 10 �s. */
#define MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_SHIFT              (0x0U)
#define MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_MASK               (0xFFFFU)
#define MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_SHIFT)) & MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_MASK))

/* Enumerated value RESET: Counter is reset with no adjustment. */
#define MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_RESET_ENUM_VAL     (0U)

/* Enumerated value ADJUST: 10 �s */
#define MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_ADJUST_ENUM_VAL    (1U)

/* --------------------------------------------------------------------------
 * SYS_VERSION (read-only):device silicon identifier
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_VERSION_OFFSET                           (0x10U)
#define MC33774_SYS_VERSION_RW_MASK                          (0x0U)
#define MC33774_SYS_VERSION_RD_MASK                          (0xFFFFU)
#define MC33774_SYS_VERSION_WR_MASK                          (0x0U)
#define MC33774_SYS_VERSION_MW_MASK                          (0x0U)
#define MC33774_SYS_VERSION_RA_MASK                          (0x0U)
#define MC33774_SYS_VERSION_POR_MASK                         (0xFFFFU)
#define MC33774_SYS_VERSION_POR_VAL                          (0x321U)

/* Field MREV: Metal revision ID */
#define MC33774_SYS_VERSION_MREV_SHIFT                       (0x0U)
#define MC33774_SYS_VERSION_MREV_MASK                        (0xFU)
#define MC33774_SYS_VERSION_MREV_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SYS_VERSION_MREV_SHIFT)) & MC33774_SYS_VERSION_MREV_MASK))

/* Field FREV: Full mask revision ID */
#define MC33774_SYS_VERSION_FREV_SHIFT                       (0x4U)
#define MC33774_SYS_VERSION_FREV_MASK                        (0xF0U)
#define MC33774_SYS_VERSION_FREV_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SYS_VERSION_FREV_SHIFT)) & MC33774_SYS_VERSION_FREV_MASK))

/* Field TYPE: Type identifier. Development samples might show a different value. */
#define MC33774_SYS_VERSION_TYPE_SHIFT                       (0x8U)
#define MC33774_SYS_VERSION_TYPE_MASK                        (0xFF00U)
#define MC33774_SYS_VERSION_TYPE_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SYS_VERSION_TYPE_SHIFT)) & MC33774_SYS_VERSION_TYPE_MASK))

/* --------------------------------------------------------------------------
 * SYS_UID_LOW (read-only):unique device ID lower part
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_UID_LOW_OFFSET                           (0x11U)
#define MC33774_SYS_UID_LOW_RW_MASK                          (0x0U)
#define MC33774_SYS_UID_LOW_RD_MASK                          (0xFFFFU)
#define MC33774_SYS_UID_LOW_WR_MASK                          (0x0U)
#define MC33774_SYS_UID_LOW_MW_MASK                          (0x0U)
#define MC33774_SYS_UID_LOW_RA_MASK                          (0x0U)
#define MC33774_SYS_UID_LOW_POR_MASK                         (0xFFFFU)
#define MC33774_SYS_UID_LOW_POR_VAL                          (0x0U)

/* Field LOW: Lower part of unique device ID (encoded: wafer-lot, wafer-number, device coordinates, testprogram and test-steps). */
#define MC33774_SYS_UID_LOW_LOW_SHIFT                        (0x0U)
#define MC33774_SYS_UID_LOW_LOW_MASK                         (0xFFFFU)
#define MC33774_SYS_UID_LOW_LOW_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_SYS_UID_LOW_LOW_SHIFT)) & MC33774_SYS_UID_LOW_LOW_MASK))

/* --------------------------------------------------------------------------
 * SYS_UID_MID (read-only):unique device ID middle part
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_UID_MID_OFFSET                           (0x12U)
#define MC33774_SYS_UID_MID_RW_MASK                          (0x0U)
#define MC33774_SYS_UID_MID_RD_MASK                          (0xFFFFU)
#define MC33774_SYS_UID_MID_WR_MASK                          (0x0U)
#define MC33774_SYS_UID_MID_MW_MASK                          (0x0U)
#define MC33774_SYS_UID_MID_RA_MASK                          (0x0U)
#define MC33774_SYS_UID_MID_POR_MASK                         (0xFFFFU)
#define MC33774_SYS_UID_MID_POR_VAL                          (0x0U)

/* Field MID: Middle part of unique device ID (encoded: wafer-lot, wafer-number, device coordinates, testprogram and test-steps). */
#define MC33774_SYS_UID_MID_MID_SHIFT                        (0x0U)
#define MC33774_SYS_UID_MID_MID_MASK                         (0xFFFFU)
#define MC33774_SYS_UID_MID_MID_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_SYS_UID_MID_MID_SHIFT)) & MC33774_SYS_UID_MID_MID_MASK))

/* --------------------------------------------------------------------------
 * SYS_UID_HIGH (read-only):unique device ID higher part
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_UID_HIGH_OFFSET                          (0x13U)
#define MC33774_SYS_UID_HIGH_RW_MASK                         (0x0U)
#define MC33774_SYS_UID_HIGH_RD_MASK                         (0xFFFFU)
#define MC33774_SYS_UID_HIGH_WR_MASK                         (0x0U)
#define MC33774_SYS_UID_HIGH_MW_MASK                         (0x0U)
#define MC33774_SYS_UID_HIGH_RA_MASK                         (0x0U)
#define MC33774_SYS_UID_HIGH_POR_MASK                        (0xFFFFU)
#define MC33774_SYS_UID_HIGH_POR_VAL                         (0x0U)

/* Field HIGH: Higher part of unique device ID (encoded: wafer-lot, wafer-number, device coordinates, testprogram and test-steps). */
#define MC33774_SYS_UID_HIGH_HIGH_SHIFT                      (0x0U)
#define MC33774_SYS_UID_HIGH_HIGH_MASK                       (0xFFFFU)
#define MC33774_SYS_UID_HIGH_HIGH_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_SYS_UID_HIGH_HIGH_SHIFT)) & MC33774_SYS_UID_HIGH_HIGH_MASK))

/* --------------------------------------------------------------------------
 * SYS_PROD_VER (read-only):software interface related version of the product
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_PROD_VER_OFFSET                          (0x14U)
#define MC33774_SYS_PROD_VER_RW_MASK                         (0x0U)
#define MC33774_SYS_PROD_VER_RD_MASK                         (0xFFFU)
#define MC33774_SYS_PROD_VER_WR_MASK                         (0x0U)
#define MC33774_SYS_PROD_VER_MW_MASK                         (0x0U)
#define MC33774_SYS_PROD_VER_RA_MASK                         (0x0U)
#define MC33774_SYS_PROD_VER_POR_MASK                        (0xFFFFU)
#define MC33774_SYS_PROD_VER_POR_VAL                         (0x200U)

/* Field PATCH: Patch: Patch with no software interface change. (AutoSAR nomenclature) */
#define MC33774_SYS_PROD_VER_PATCH_SHIFT                     (0x0U)
#define MC33774_SYS_PROD_VER_PATCH_MASK                      (0xFU)
#define MC33774_SYS_PROD_VER_PATCH_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SYS_PROD_VER_PATCH_SHIFT)) & MC33774_SYS_PROD_VER_PATCH_MASK))

/* Field MINOR: Minor Revision: Software interface change, for example improvement or extension which is covered by additional registers or transparent to the software.
Existing software is compatible but may not use new features. (AutoSAR nomenclature). */
#define MC33774_SYS_PROD_VER_MINOR_SHIFT                     (0x4U)
#define MC33774_SYS_PROD_VER_MINOR_MASK                      (0xF0U)
#define MC33774_SYS_PROD_VER_MINOR_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SYS_PROD_VER_MINOR_SHIFT)) & MC33774_SYS_PROD_VER_MINOR_MASK))

/* Field MAJOR: Major Revision: Software interface change, register-map or registers changed. Non-compatible with previous versions. (AutoSAR nomenclature) */
#define MC33774_SYS_PROD_VER_MAJOR_SHIFT                     (0x8U)
#define MC33774_SYS_PROD_VER_MAJOR_MASK                      (0xF00U)
#define MC33774_SYS_PROD_VER_MAJOR_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SYS_PROD_VER_MAJOR_SHIFT)) & MC33774_SYS_PROD_VER_MAJOR_MASK))

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SYS_PROD_VER_RESERVED0_SHIFT                 (0xCU)
#define MC33774_SYS_PROD_VER_RESERVED0_MASK                  (0xF000U)
#define MC33774_SYS_PROD_VER_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SYS_PROD_VER_RESERVED0_SHIFT)) & MC33774_SYS_PROD_VER_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * SYS_DS_STORAGE0 (read-write):deep sleep storage data 0; the value is stored in the ULP domain
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_DS_STORAGE0_OFFSET                       (0x80U)
#define MC33774_SYS_DS_STORAGE0_RW_MASK                      (0xFFFFU)
#define MC33774_SYS_DS_STORAGE0_RD_MASK                      (0xFFFFU)
#define MC33774_SYS_DS_STORAGE0_WR_MASK                      (0xFFFFU)
#define MC33774_SYS_DS_STORAGE0_MW_MASK                      (0x0U)
#define MC33774_SYS_DS_STORAGE0_RA_MASK                      (0x0U)
#define MC33774_SYS_DS_STORAGE0_POR_MASK                     (0xFFFFU)
#define MC33774_SYS_DS_STORAGE0_POR_VAL                      (0x0U)

/* Field DATA: Deep Sleep surviving data; this register has no reset. This register allows to store application data and has no influence on the device. */
#define MC33774_SYS_DS_STORAGE0_DATA_SHIFT                   (0x0U)
#define MC33774_SYS_DS_STORAGE0_DATA_MASK                    (0xFFFFU)
#define MC33774_SYS_DS_STORAGE0_DATA_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SYS_DS_STORAGE0_DATA_SHIFT)) & MC33774_SYS_DS_STORAGE0_DATA_MASK))

/* --------------------------------------------------------------------------
 * SYS_DS_STORAGE1 (read-write):deep sleep storage data 1; the value is stored in the ULP domain
 * -------------------------------------------------------------------------- */
#define MC33774_SYS_DS_STORAGE1_OFFSET                       (0x81U)
#define MC33774_SYS_DS_STORAGE1_RW_MASK                      (0xFFFFU)
#define MC33774_SYS_DS_STORAGE1_RD_MASK                      (0xFFFFU)
#define MC33774_SYS_DS_STORAGE1_WR_MASK                      (0xFFFFU)
#define MC33774_SYS_DS_STORAGE1_MW_MASK                      (0x0U)
#define MC33774_SYS_DS_STORAGE1_RA_MASK                      (0x0U)
#define MC33774_SYS_DS_STORAGE1_POR_MASK                     (0xFFFFU)
#define MC33774_SYS_DS_STORAGE1_POR_VAL                      (0x0U)

/* Field DATA: Deep Sleep surviving data; this register has no reset. This register allows to store application data and has no influence on the device. */
#define MC33774_SYS_DS_STORAGE1_DATA_SHIFT                   (0x0U)
#define MC33774_SYS_DS_STORAGE1_DATA_MASK                    (0xFFFFU)
#define MC33774_SYS_DS_STORAGE1_DATA_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SYS_DS_STORAGE1_DATA_SHIFT)) & MC33774_SYS_DS_STORAGE1_DATA_MASK))

/* --------------------------------------------------------------------------
 * FEH_CFG_CRC (read-only):configuration CRC
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_CFG_CRC_OFFSET                           (0x400U)
#define MC33774_FEH_CFG_CRC_RW_MASK                          (0x0U)
#define MC33774_FEH_CFG_CRC_RD_MASK                          (0xFFFFU)
#define MC33774_FEH_CFG_CRC_WR_MASK                          (0x0U)
#define MC33774_FEH_CFG_CRC_MW_MASK                          (0x0U)
#define MC33774_FEH_CFG_CRC_RA_MASK                          (0x0U)
#define MC33774_FEH_CFG_CRC_POR_MASK                         (0xFFFFU)
#define MC33774_FEH_CFG_CRC_POR_VAL                          (0x0U)

/* Field CRC: This CRC value is recalculated with any write to a covered register and with any read to this register. The updated CRC value is available latest 100us after the last write.
The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1.
Following registers are included:  FEH_ALARM_CFG, FEH_ALARM_OUT_CFG0, FEH_ALARM_OUT_CFG1, FEH_WAKEUP_CFG0, FEH_WAKEUP_CFG1, FEH_SUPPLY_FLT_POR_CFG0, FEH_SUPPLY_FLT_POR_CFG1,
FEH_ANA_FLT_POR_CFG, FEH_COM_FLT_POR_CFG, FEH_SUPPLY_FLT_EVT_CFG0, FEH_SUPPLY_FLT_EVT_CFG1, FEH_ANA_FLT_EVT_CFG, FEH_COM_FLT_EVT_CFG, FEH_MEAS_FLT_EVT_CFG. */
#define MC33774_FEH_CFG_CRC_CRC_SHIFT                        (0x0U)
#define MC33774_FEH_CFG_CRC_CRC_MASK                         (0xFFFFU)
#define MC33774_FEH_CFG_CRC_CRC_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_CFG_CRC_CRC_SHIFT)) & MC33774_FEH_CFG_CRC_CRC_MASK))

/* --------------------------------------------------------------------------
 * FEH_ALARM_CFG (read-write):general alarm configuration
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ALARM_CFG_OFFSET                         (0x401U)
#define MC33774_FEH_ALARM_CFG_RW_MASK                        (0x1FFU)
#define MC33774_FEH_ALARM_CFG_RD_MASK                        (0x1FFU)
#define MC33774_FEH_ALARM_CFG_WR_MASK                        (0x1FFU)
#define MC33774_FEH_ALARM_CFG_MW_MASK                        (0x0U)
#define MC33774_FEH_ALARM_CFG_RA_MASK                        (0x0U)
#define MC33774_FEH_ALARM_CFG_POR_MASK                       (0xFFFFU)
#define MC33774_FEH_ALARM_CFG_POR_VAL                        (0x0U)

/* Field ALARMIN: Enable alarm input Enabling the alarm input automatically enables the digital receiver for the Alarm input pin. */
#define MC33774_FEH_ALARM_CFG_ALARMIN_SHIFT                  (0x0U)
#define MC33774_FEH_ALARM_CFG_ALARMIN_MASK                   (0x3U)
#define MC33774_FEH_ALARM_CFG_ALARMIN_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_CFG_ALARMIN_SHIFT)) & MC33774_FEH_ALARM_CFG_ALARMIN_MASK))

/* Enumerated value DISABLED: Alarm input is disabled */
#define MC33774_FEH_ALARM_CFG_ALARMIN_DISABLED_ENUM_VAL      (0U)

/* Enumerated value HIGH_ACTIVE: Alarm input is enabled, high active */
#define MC33774_FEH_ALARM_CFG_ALARMIN_HIGH_ACTIVE_ENUM_VAL   (1U)

/* Enumerated value LOW_ACTIVE: Alarm input is enabled, low active */
#define MC33774_FEH_ALARM_CFG_ALARMIN_LOW_ACTIVE_ENUM_VAL    (2U)

/* Enumerated value HEARTBEAT: Alarm input is enabled, heartbeat configuration */
#define MC33774_FEH_ALARM_CFG_ALARMIN_HEARTBEAT_ENUM_VAL     (3U)

/* Field ALARMINHB: Input heartbeat low time setting */
#define MC33774_FEH_ALARM_CFG_ALARMINHB_SHIFT                (0x2U)
#define MC33774_FEH_ALARM_CFG_ALARMINHB_MASK                 (0xCU)
#define MC33774_FEH_ALARM_CFG_ALARMINHB_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_CFG_ALARMINHB_SHIFT)) & MC33774_FEH_ALARM_CFG_ALARMINHB_MASK))

/* Enumerated value T_500u: 500 us */
#define MC33774_FEH_ALARM_CFG_ALARMINHB_T_500U_ENUM_VAL      (0U)

/* Enumerated value T_1ms: 1 ms */
#define MC33774_FEH_ALARM_CFG_ALARMINHB_T_1MS_ENUM_VAL       (1U)

/* Enumerated value T_10ms: 10 ms */
#define MC33774_FEH_ALARM_CFG_ALARMINHB_T_10MS_ENUM_VAL      (2U)

/* Enumerated value T_100ms: 100 ms */
#define MC33774_FEH_ALARM_CFG_ALARMINHB_T_100MS_ENUM_VAL     (3U)

/* Field ALARMOUT: Enable alarm output */
#define MC33774_FEH_ALARM_CFG_ALARMOUT_SHIFT                 (0x4U)
#define MC33774_FEH_ALARM_CFG_ALARMOUT_MASK                  (0x30U)
#define MC33774_FEH_ALARM_CFG_ALARMOUT_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_CFG_ALARMOUT_SHIFT)) & MC33774_FEH_ALARM_CFG_ALARMOUT_MASK))

/* Enumerated value DISABLED: disabled. Alarm output is high impedance. */
#define MC33774_FEH_ALARM_CFG_ALARMOUT_DISABLED_ENUM_VAL     (0U)

/* Enumerated value HIGH_ACTIVE: high active */
#define MC33774_FEH_ALARM_CFG_ALARMOUT_HIGH_ACTIVE_ENUM_VAL \
  (1U)

/* Enumerated value LOW_ACTIVE: low active */
#define MC33774_FEH_ALARM_CFG_ALARMOUT_LOW_ACTIVE_ENUM_VAL   (2U)

/* Enumerated value HEARTBEAT: heartbeat configuration */
#define MC33774_FEH_ALARM_CFG_ALARMOUT_HEARTBEAT_ENUM_VAL    (3U)

/* Field ALARMOUTHB: Output heartbeat low time setting */
#define MC33774_FEH_ALARM_CFG_ALARMOUTHB_SHIFT               (0x6U)
#define MC33774_FEH_ALARM_CFG_ALARMOUTHB_MASK                (0xC0U)
#define MC33774_FEH_ALARM_CFG_ALARMOUTHB_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_CFG_ALARMOUTHB_SHIFT)) & MC33774_FEH_ALARM_CFG_ALARMOUTHB_MASK))

/* Enumerated value T_500u: 500 us */
#define MC33774_FEH_ALARM_CFG_ALARMOUTHB_T_500U_ENUM_VAL     (0U)

/* Enumerated value T_1ms: 1 ms */
#define MC33774_FEH_ALARM_CFG_ALARMOUTHB_T_1MS_ENUM_VAL      (1U)

/* Enumerated value T_10ms: 10 ms */
#define MC33774_FEH_ALARM_CFG_ALARMOUTHB_T_10MS_ENUM_VAL     (2U)

/* Enumerated value T_100ms: 100 ms */
#define MC33774_FEH_ALARM_CFG_ALARMOUTHB_T_100MS_ENUM_VAL    (3U)

/* Field ALARMINHBINV: Inverted heartbeat input */
#define MC33774_FEH_ALARM_CFG_ALARMINHBINV_SHIFT             (0x8U)
#define MC33774_FEH_ALARM_CFG_ALARMINHBINV_MASK              (0x100U)
#define MC33774_FEH_ALARM_CFG_ALARMINHBINV_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_CFG_ALARMINHBINV_SHIFT)) & MC33774_FEH_ALARM_CFG_ALARMINHBINV_MASK))

/* Enumerated value DISABLED: Normal heartbeat (LOW with HIGH pulses) input used */
#define MC33774_FEH_ALARM_CFG_ALARMINHBINV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Inverted heartbeat (HIGH with LOW pulses) input used */
#define MC33774_FEH_ALARM_CFG_ALARMINHBINV_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ALARM_CFG_RESERVED0_SHIFT                (0x9U)
#define MC33774_FEH_ALARM_CFG_RESERVED0_MASK                 (0xFE00U)
#define MC33774_FEH_ALARM_CFG_RESERVED0_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_CFG_RESERVED0_SHIFT)) & MC33774_FEH_ALARM_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_ALARM_OUT_CFG0 (read-write):alarm output source selection
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ALARM_OUT_CFG0_OFFSET                    (0x402U)
#define MC33774_FEH_ALARM_OUT_CFG0_RW_MASK                   (0x7FFFU)
#define MC33774_FEH_ALARM_OUT_CFG0_RD_MASK                   (0x7FFFU)
#define MC33774_FEH_ALARM_OUT_CFG0_WR_MASK                   (0x7FFFU)
#define MC33774_FEH_ALARM_OUT_CFG0_MW_MASK                   (0x0U)
#define MC33774_FEH_ALARM_OUT_CFG0_RA_MASK                   (0x0U)
#define MC33774_FEH_ALARM_OUT_CFG0_POR_MASK                  (0xFFFFU)
#define MC33774_FEH_ALARM_OUT_CFG0_POR_VAL                   (0x0U)

/* Field VCOV: Enable output on alarm output for VC_OV. */
#define MC33774_FEH_ALARM_OUT_CFG0_VCOV_SHIFT                (0x0U)
#define MC33774_FEH_ALARM_OUT_CFG0_VCOV_MASK                 (0x1U)
#define MC33774_FEH_ALARM_OUT_CFG0_VCOV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_VCOV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_VCOV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_VCOV_DISABLED_ENUM_VAL    (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_VCOV_ENABLED_ENUM_VAL     (1U)

/* Field VCUV0: Enable output on alarm output for VC_UV0. */
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV0_SHIFT               (0x1U)
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV0_MASK                (0x2U)
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_VCUV0_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_VCUV0_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV0_DISABLED_ENUM_VAL   (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV0_ENABLED_ENUM_VAL    (1U)

/* Field VCUV1: Enable output on alarm output for VC_UV1. */
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV1_SHIFT               (0x2U)
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV1_MASK                (0x4U)
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV1_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_VCUV1_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_VCUV1_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV1_DISABLED_ENUM_VAL   (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_VCUV1_ENABLED_ENUM_VAL    (1U)

/* Field AIN0OV: Enable output on alarm output for AIN0_OV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_SHIFT              (0x3U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_MASK               (0x8U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_ENABLED_ENUM_VAL   (1U)

/* Field AIN0UV: Enable output on alarm output for AIN0_UV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_SHIFT              (0x4U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_MASK               (0x10U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_ENABLED_ENUM_VAL   (1U)

/* Field AIN1OV: Enable output on alarm output for AIN1_OV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_SHIFT              (0x5U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_MASK               (0x20U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_ENABLED_ENUM_VAL   (1U)

/* Field AIN1UV: Enable output on alarm output for AIN1_UV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_SHIFT              (0x6U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_MASK               (0x40U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_ENABLED_ENUM_VAL   (1U)

/* Field AIN2OV: Enable output on alarm output for AIN2_OV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_SHIFT              (0x7U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_MASK               (0x80U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_ENABLED_ENUM_VAL   (1U)

/* Field AIN2UV: Enable output on alarm output for AIN2_UV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_SHIFT              (0x8U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_MASK               (0x100U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_ENABLED_ENUM_VAL   (1U)

/* Field AIN3OV: Enable output on alarm output for AIN3_OV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_SHIFT              (0x9U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_MASK               (0x200U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_ENABLED_ENUM_VAL   (1U)

/* Field AIN3UV: Enable output on alarm output for AIN3_UV. */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_SHIFT              (0xAU)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_MASK               (0x400U)
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_ENABLED_ENUM_VAL   (1U)

/* Field ALARMIN: Enable output on alarm output for detected alarm input. */
#define MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_SHIFT             (0xBU)
#define MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_MASK              (0x800U)
#define MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_ENABLED_ENUM_VAL \
  (1U)

/* Field WAKEUPIN: Enable output on detected wakeup input. Enabling this bit automatically enables the digital receiver for the wakeup input pin. */
#define MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_SHIFT            (0xCU)
#define MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_MASK             (0x1000U)
#define MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_ENABLED_ENUM_VAL \
  (1U)

/* Field BALRDY: Enable output on alarm output for cell voltage balancing ready. */
#define MC33774_FEH_ALARM_OUT_CFG0_BALRDY_SHIFT              (0xDU)
#define MC33774_FEH_ALARM_OUT_CFG0_BALRDY_MASK               (0x2000U)
#define MC33774_FEH_ALARM_OUT_CFG0_BALRDY_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_BALRDY_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_BALRDY_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_BALRDY_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_BALRDY_ENABLED_ENUM_VAL   (1U)

/* Field SYSFLTEVT: Enable output on alarm output for a detected and selected system fault. */
#define MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_SHIFT           (0xEU)
#define MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_MASK            (0x4000U)
#define MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ALARM_OUT_CFG0_RESERVED0_SHIFT           (0xFU)
#define MC33774_FEH_ALARM_OUT_CFG0_RESERVED0_MASK            (0x8000U)
#define MC33774_FEH_ALARM_OUT_CFG0_RESERVED0_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG0_RESERVED0_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG0_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_ALARM_OUT_CFG1 (read-write):alarm output source selection
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ALARM_OUT_CFG1_OFFSET                    (0x403U)
#define MC33774_FEH_ALARM_OUT_CFG1_RW_MASK                   (0x103U)
#define MC33774_FEH_ALARM_OUT_CFG1_RD_MASK                   (0x103U)
#define MC33774_FEH_ALARM_OUT_CFG1_WR_MASK                   (0x103U)
#define MC33774_FEH_ALARM_OUT_CFG1_MW_MASK                   (0x0U)
#define MC33774_FEH_ALARM_OUT_CFG1_RA_MASK                   (0x0U)
#define MC33774_FEH_ALARM_OUT_CFG1_POR_MASK                  (0xFFFFU)
#define MC33774_FEH_ALARM_OUT_CFG1_POR_VAL                   (0x0U)

/* Field AINAOV: Enable output on alarm output for AINA_OV. */
#define MC33774_FEH_ALARM_OUT_CFG1_AINAOV_SHIFT              (0x0U)
#define MC33774_FEH_ALARM_OUT_CFG1_AINAOV_MASK               (0x1U)
#define MC33774_FEH_ALARM_OUT_CFG1_AINAOV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG1_AINAOV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG1_AINAOV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG1_AINAOV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG1_AINAOV_ENABLED_ENUM_VAL   (1U)

/* Field AINAUV: Enable output on alarm output for AINA_UV. */
#define MC33774_FEH_ALARM_OUT_CFG1_AINAUV_SHIFT              (0x1U)
#define MC33774_FEH_ALARM_OUT_CFG1_AINAUV_MASK               (0x2U)
#define MC33774_FEH_ALARM_OUT_CFG1_AINAUV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG1_AINAUV_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG1_AINAUV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG1_AINAUV_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG1_AINAUV_ENABLED_ENUM_VAL   (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ALARM_OUT_CFG1_RESERVED0_SHIFT           (0x2U)
#define MC33774_FEH_ALARM_OUT_CFG1_RESERVED0_MASK            (0xFCU)
#define MC33774_FEH_ALARM_OUT_CFG1_RESERVED0_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG1_RESERVED0_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG1_RESERVED0_MASK))

/* Field BALPROT: Enable output on alarm output for detected balancing protection */
#define MC33774_FEH_ALARM_OUT_CFG1_BALPROT_SHIFT             (0x8U)
#define MC33774_FEH_ALARM_OUT_CFG1_BALPROT_MASK              (0x100U)
#define MC33774_FEH_ALARM_OUT_CFG1_BALPROT_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG1_BALPROT_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG1_BALPROT_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_ALARM_OUT_CFG1_BALPROT_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_ALARM_OUT_CFG1_BALPROT_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ALARM_OUT_CFG1_RESERVED1_SHIFT           (0x9U)
#define MC33774_FEH_ALARM_OUT_CFG1_RESERVED1_MASK            (0xFE00U)
#define MC33774_FEH_ALARM_OUT_CFG1_RESERVED1_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_CFG1_RESERVED1_SHIFT)) & MC33774_FEH_ALARM_OUT_CFG1_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * FEH_ALARM_OUT_REASON0 (read-only):alarm output reason
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ALARM_OUT_REASON0_OFFSET                 (0x404U)
#define MC33774_FEH_ALARM_OUT_REASON0_RW_MASK                (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON0_RD_MASK                (0x7FFFU)
#define MC33774_FEH_ALARM_OUT_REASON0_WR_MASK                (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON0_MW_MASK                (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON0_RA_MASK                (0x7FFFU)
#define MC33774_FEH_ALARM_OUT_REASON0_POR_MASK               (0xFFFFU)
#define MC33774_FEH_ALARM_OUT_REASON0_POR_VAL                (0x0U)

/* Field VCOV: VC_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_VCOV_SHIFT             (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON0_VCOV_MASK              (0x1U)
#define MC33774_FEH_ALARM_OUT_REASON0_VCOV_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_VCOV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_VCOV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by VC_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_VCOV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by VC_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_VCOV_ALARM_ENUM_VAL    (1U)

/* Field VCUV0: VC_UV0 */
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV0_SHIFT            (0x1U)
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV0_MASK             (0x2U)
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV0_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_VCUV0_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_VCUV0_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by VC_UV0 */
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV0_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by VC_UV0 */
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV0_ALARM_ENUM_VAL   (1U)

/* Field VCUV1: VC_UV1 */
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV1_SHIFT            (0x2U)
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV1_MASK             (0x4U)
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV1_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_VCUV1_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_VCUV1_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by VC_UV1 */
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV1_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by VC_UV1 */
#define MC33774_FEH_ALARM_OUT_REASON0_VCUV1_ALARM_ENUM_VAL   (1U)

/* Field AIN0OV: AIN0_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0OV_SHIFT           (0x3U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0OV_MASK            (0x8U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0OV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN0OV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN0OV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN0_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN0_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN0UV: AIN0_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0UV_SHIFT           (0x4U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0UV_MASK            (0x10U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0UV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN0UV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN0UV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN0_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN0_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN0UV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN1OV: AIN1_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1OV_SHIFT           (0x5U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1OV_MASK            (0x20U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1OV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN1OV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN1OV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN1_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN1_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN1UV: AIN1_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1UV_SHIFT           (0x6U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1UV_MASK            (0x40U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1UV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN1UV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN1UV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN1_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN1_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN1UV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN2OV: AIN2_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2OV_SHIFT           (0x7U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2OV_MASK            (0x80U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2OV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN2OV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN2OV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN2_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN2_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN2UV: AIN2_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2UV_SHIFT           (0x8U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2UV_MASK            (0x100U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2UV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN2UV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN2UV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN2_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN2_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN2UV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN3OV: AIN3_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3OV_SHIFT           (0x9U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3OV_MASK            (0x200U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3OV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN3OV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN3OV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN3_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3OV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN3_OV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3OV_ALARM_ENUM_VAL \
  (1U)

/* Field AIN3UV: AIN3_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3UV_SHIFT           (0xAU)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3UV_MASK            (0x400U)
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3UV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_AIN3UV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_AIN3UV_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by AIN3_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3UV_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by AIN3_UV */
#define MC33774_FEH_ALARM_OUT_REASON0_AIN3UV_ALARM_ENUM_VAL \
  (1U)

/* Field ALARMIN: Detected alarm input */
#define MC33774_FEH_ALARM_OUT_REASON0_ALARMIN_SHIFT          (0xBU)
#define MC33774_FEH_ALARM_OUT_REASON0_ALARMIN_MASK           (0x800U)
#define MC33774_FEH_ALARM_OUT_REASON0_ALARMIN_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_ALARMIN_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_ALARMIN_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by detected alarm input */
#define MC33774_FEH_ALARM_OUT_REASON0_ALARMIN_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by detected alarm input */
#define MC33774_FEH_ALARM_OUT_REASON0_ALARMIN_ALARM_ENUM_VAL \
  (1U)

/* Field WAKEUPIN: Detected wakeup input */
#define MC33774_FEH_ALARM_OUT_REASON0_WAKEUPIN_SHIFT         (0xCU)
#define MC33774_FEH_ALARM_OUT_REASON0_WAKEUPIN_MASK          (0x1000U)
#define MC33774_FEH_ALARM_OUT_REASON0_WAKEUPIN_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_WAKEUPIN_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_WAKEUPIN_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by detected wakeup input */
#define MC33774_FEH_ALARM_OUT_REASON0_WAKEUPIN_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by detected wakeup input */
#define MC33774_FEH_ALARM_OUT_REASON0_WAKEUPIN_ALARM_ENUM_VAL \
  (1U)

/* Field BALRDY: Cell voltage balancing ready */
#define MC33774_FEH_ALARM_OUT_REASON0_BALRDY_SHIFT           (0xDU)
#define MC33774_FEH_ALARM_OUT_REASON0_BALRDY_MASK            (0x2000U)
#define MC33774_FEH_ALARM_OUT_REASON0_BALRDY_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_BALRDY_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_BALRDY_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by cell voltage balancing ready */
#define MC33774_FEH_ALARM_OUT_REASON0_BALRDY_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by cell voltage balancing ready */
#define MC33774_FEH_ALARM_OUT_REASON0_BALRDY_ALARM_ENUM_VAL \
  (1U)

/* Field SYSFLTEVT: Detected system fault. */
#define MC33774_FEH_ALARM_OUT_REASON0_SYSFLTEVT_SHIFT        (0xEU)
#define MC33774_FEH_ALARM_OUT_REASON0_SYSFLTEVT_MASK         (0x4000U)
#define MC33774_FEH_ALARM_OUT_REASON0_SYSFLTEVT_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_SYSFLTEVT_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_SYSFLTEVT_MASK))

/* Enumerated value NO_ALARM: Alarm not caused by detected system fault */
#define MC33774_FEH_ALARM_OUT_REASON0_SYSFLTEVT_NO_ALARM_ENUM_VAL \
  (0U)

/* Enumerated value ALARM: Alarm caused by detected system fault */
#define MC33774_FEH_ALARM_OUT_REASON0_SYSFLTEVT_ALARM_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ALARM_OUT_REASON0_RESERVED0_SHIFT        (0xFU)
#define MC33774_FEH_ALARM_OUT_REASON0_RESERVED0_MASK         (0x8000U)
#define MC33774_FEH_ALARM_OUT_REASON0_RESERVED0_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON0_RESERVED0_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON0_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_ALARM_OUT_REASON1 (read-only):alarm output reason
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ALARM_OUT_REASON1_OFFSET                 (0x405U)
#define MC33774_FEH_ALARM_OUT_REASON1_RW_MASK                (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON1_RD_MASK                (0x103U)
#define MC33774_FEH_ALARM_OUT_REASON1_WR_MASK                (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON1_MW_MASK                (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON1_RA_MASK                (0x103U)
#define MC33774_FEH_ALARM_OUT_REASON1_POR_MASK               (0xFFFFU)
#define MC33774_FEH_ALARM_OUT_REASON1_POR_VAL                (0x0U)

/* Field AINAOV: AINA_OV */
#define MC33774_FEH_ALARM_OUT_REASON1_AINAOV_SHIFT           (0x0U)
#define MC33774_FEH_ALARM_OUT_REASON1_AINAOV_MASK            (0x1U)
#define MC33774_FEH_ALARM_OUT_REASON1_AINAOV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON1_AINAOV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON1_AINAOV_MASK))

/* Enumerated value NO_WAKE: Alarm not caused by AINA_OV */
#define MC33774_FEH_ALARM_OUT_REASON1_AINAOV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Alarm caused by AINA_OV */
#define MC33774_FEH_ALARM_OUT_REASON1_AINAOV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field AINAUV: AINA_UV */
#define MC33774_FEH_ALARM_OUT_REASON1_AINAUV_SHIFT           (0x1U)
#define MC33774_FEH_ALARM_OUT_REASON1_AINAUV_MASK            (0x2U)
#define MC33774_FEH_ALARM_OUT_REASON1_AINAUV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON1_AINAUV_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON1_AINAUV_MASK))

/* Enumerated value NO_WAKE: Alarm not caused by AINA_UV */
#define MC33774_FEH_ALARM_OUT_REASON1_AINAUV_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Alarm caused by AINA_UV */
#define MC33774_FEH_ALARM_OUT_REASON1_AINAUV_WAKE_UP_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ALARM_OUT_REASON1_RESERVED0_SHIFT        (0x2U)
#define MC33774_FEH_ALARM_OUT_REASON1_RESERVED0_MASK         (0xFCU)
#define MC33774_FEH_ALARM_OUT_REASON1_RESERVED0_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON1_RESERVED0_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON1_RESERVED0_MASK))

/* Field BALPROT: Balancing protection detection */
#define MC33774_FEH_ALARM_OUT_REASON1_BALPROT_SHIFT          (0x8U)
#define MC33774_FEH_ALARM_OUT_REASON1_BALPROT_MASK           (0x100U)
#define MC33774_FEH_ALARM_OUT_REASON1_BALPROT_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON1_BALPROT_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON1_BALPROT_MASK))

/* Enumerated value NO_WAKE: Alarm not caused by detected Balancing protection */
#define MC33774_FEH_ALARM_OUT_REASON1_BALPROT_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Alarm caused by detected Balancing protection */
#define MC33774_FEH_ALARM_OUT_REASON1_BALPROT_WAKE_UP_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ALARM_OUT_REASON1_RESERVED1_SHIFT        (0x9U)
#define MC33774_FEH_ALARM_OUT_REASON1_RESERVED1_MASK         (0xFE00U)
#define MC33774_FEH_ALARM_OUT_REASON1_RESERVED1_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ALARM_OUT_REASON1_RESERVED1_SHIFT)) & MC33774_FEH_ALARM_OUT_REASON1_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * FEH_WAKEUP_CFG0 (read-write):wake up source configuration
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_WAKEUP_CFG0_OFFSET                       (0x408U)
#define MC33774_FEH_WAKEUP_CFG0_RW_MASK                      (0xFFFFU)
#define MC33774_FEH_WAKEUP_CFG0_RD_MASK                      (0xFFFFU)
#define MC33774_FEH_WAKEUP_CFG0_WR_MASK                      (0xFFFFU)
#define MC33774_FEH_WAKEUP_CFG0_MW_MASK                      (0x0U)
#define MC33774_FEH_WAKEUP_CFG0_RA_MASK                      (0x0U)
#define MC33774_FEH_WAKEUP_CFG0_POR_MASK                     (0xFFFFU)
#define MC33774_FEH_WAKEUP_CFG0_POR_VAL                      (0x0U)

/* Field VCOV: Enable wakeup on VC_OV. */
#define MC33774_FEH_WAKEUP_CFG0_VCOV_SHIFT                   (0x0U)
#define MC33774_FEH_WAKEUP_CFG0_VCOV_MASK                    (0x1U)
#define MC33774_FEH_WAKEUP_CFG0_VCOV_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_VCOV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_VCOV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_VCOV_DISABLED_ENUM_VAL       (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_VCOV_ENABLED_ENUM_VAL        (1U)

/* Field VCUV0: Enable wakeup on VC_UV0. */
#define MC33774_FEH_WAKEUP_CFG0_VCUV0_SHIFT                  (0x1U)
#define MC33774_FEH_WAKEUP_CFG0_VCUV0_MASK                   (0x2U)
#define MC33774_FEH_WAKEUP_CFG0_VCUV0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_VCUV0_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_VCUV0_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_VCUV0_DISABLED_ENUM_VAL      (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_VCUV0_ENABLED_ENUM_VAL       (1U)

/* Field VCUV1: Enable wakeup on VC_UV1. */
#define MC33774_FEH_WAKEUP_CFG0_VCUV1_SHIFT                  (0x2U)
#define MC33774_FEH_WAKEUP_CFG0_VCUV1_MASK                   (0x4U)
#define MC33774_FEH_WAKEUP_CFG0_VCUV1_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_VCUV1_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_VCUV1_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_VCUV1_DISABLED_ENUM_VAL      (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_VCUV1_ENABLED_ENUM_VAL       (1U)

/* Field AIN0OV: Enable wakeup on AIN0_OV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN0OV_SHIFT                 (0x3U)
#define MC33774_FEH_WAKEUP_CFG0_AIN0OV_MASK                  (0x8U)
#define MC33774_FEH_WAKEUP_CFG0_AIN0OV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN0OV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN0OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN0OV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN0OV_ENABLED_ENUM_VAL      (1U)

/* Field AIN0UV: Enable wakeup on AIN0_UV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN0UV_SHIFT                 (0x4U)
#define MC33774_FEH_WAKEUP_CFG0_AIN0UV_MASK                  (0x10U)
#define MC33774_FEH_WAKEUP_CFG0_AIN0UV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN0UV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN0UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN0UV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN0UV_ENABLED_ENUM_VAL      (1U)

/* Field AIN1OV: Enable wakeup on AIN1_OV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN1OV_SHIFT                 (0x5U)
#define MC33774_FEH_WAKEUP_CFG0_AIN1OV_MASK                  (0x20U)
#define MC33774_FEH_WAKEUP_CFG0_AIN1OV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN1OV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN1OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN1OV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN1OV_ENABLED_ENUM_VAL      (1U)

/* Field AIN1UV: Enable wakeup on AIN1_UV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN1UV_SHIFT                 (0x6U)
#define MC33774_FEH_WAKEUP_CFG0_AIN1UV_MASK                  (0x40U)
#define MC33774_FEH_WAKEUP_CFG0_AIN1UV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN1UV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN1UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN1UV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN1UV_ENABLED_ENUM_VAL      (1U)

/* Field AIN2OV: Enable wakeup on AIN2_OV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN2OV_SHIFT                 (0x7U)
#define MC33774_FEH_WAKEUP_CFG0_AIN2OV_MASK                  (0x80U)
#define MC33774_FEH_WAKEUP_CFG0_AIN2OV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN2OV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN2OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN2OV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN2OV_ENABLED_ENUM_VAL      (1U)

/* Field AIN2UV: Enable wakeup on AIN2_UV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN2UV_SHIFT                 (0x8U)
#define MC33774_FEH_WAKEUP_CFG0_AIN2UV_MASK                  (0x100U)
#define MC33774_FEH_WAKEUP_CFG0_AIN2UV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN2UV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN2UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN2UV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN2UV_ENABLED_ENUM_VAL      (1U)

/* Field AIN3OV: Enable wakeup on AIN3_OV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN3OV_SHIFT                 (0x9U)
#define MC33774_FEH_WAKEUP_CFG0_AIN3OV_MASK                  (0x200U)
#define MC33774_FEH_WAKEUP_CFG0_AIN3OV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN3OV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN3OV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN3OV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN3OV_ENABLED_ENUM_VAL      (1U)

/* Field AIN3UV: Enable wakeup on AIN3_UV. */
#define MC33774_FEH_WAKEUP_CFG0_AIN3UV_SHIFT                 (0xAU)
#define MC33774_FEH_WAKEUP_CFG0_AIN3UV_MASK                  (0x400U)
#define MC33774_FEH_WAKEUP_CFG0_AIN3UV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_AIN3UV_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_AIN3UV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN3UV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_AIN3UV_ENABLED_ENUM_VAL      (1U)

/* Field ALARMIN: Enable wakeup on detected alarm input */
#define MC33774_FEH_WAKEUP_CFG0_ALARMIN_SHIFT                (0xBU)
#define MC33774_FEH_WAKEUP_CFG0_ALARMIN_MASK                 (0x800U)
#define MC33774_FEH_WAKEUP_CFG0_ALARMIN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_ALARMIN_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_ALARMIN_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_ALARMIN_DISABLED_ENUM_VAL    (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_ALARMIN_ENABLED_ENUM_VAL     (1U)

/* Field WAKEUPIN: Enable wakeup on detected wakeup input. Enabling this bit automatically enables the digital receiver for wake-up input 0. */
#define MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_SHIFT               (0xCU)
#define MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_MASK                (0x1000U)
#define MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_DISABLED_ENUM_VAL   (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_ENABLED_ENUM_VAL    (1U)

/* Field BALRDY: Enable wakeup on cell voltage balancing ready. */
#define MC33774_FEH_WAKEUP_CFG0_BALRDY_SHIFT                 (0xDU)
#define MC33774_FEH_WAKEUP_CFG0_BALRDY_MASK                  (0x2000U)
#define MC33774_FEH_WAKEUP_CFG0_BALRDY_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_BALRDY_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_BALRDY_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_BALRDY_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_BALRDY_ENABLED_ENUM_VAL      (1U)

/* Field SYSFLTEVT: Enable wakeup on a detected system fault. */
#define MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_SHIFT              (0xEU)
#define MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_MASK               (0x4000U)
#define MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_ENABLED_ENUM_VAL   (1U)

/* Field TPLWAKEUP: Wake TPL */
#define MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_SHIFT              (0xFU)
#define MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_MASK               (0x8000U)
#define MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_SHIFT)) & MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: enabled. Device sends wake-up frames on TPL if wake-up reason was other than communication */
#define MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_ENABLED_ENUM_VAL   (1U)

/* --------------------------------------------------------------------------
 * FEH_WAKEUP_CFG1 (read-write):wake up source configuration
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_WAKEUP_CFG1_OFFSET                       (0x409U)
#define MC33774_FEH_WAKEUP_CFG1_RW_MASK                      (0x103U)
#define MC33774_FEH_WAKEUP_CFG1_RD_MASK                      (0x103U)
#define MC33774_FEH_WAKEUP_CFG1_WR_MASK                      (0x103U)
#define MC33774_FEH_WAKEUP_CFG1_MW_MASK                      (0x0U)
#define MC33774_FEH_WAKEUP_CFG1_RA_MASK                      (0x0U)
#define MC33774_FEH_WAKEUP_CFG1_POR_MASK                     (0xFFFFU)
#define MC33774_FEH_WAKEUP_CFG1_POR_VAL                      (0x0U)

/* Field AINAOV: Enable wakeup on AINA_OV. */
#define MC33774_FEH_WAKEUP_CFG1_AINAOV_SHIFT                 (0x0U)
#define MC33774_FEH_WAKEUP_CFG1_AINAOV_MASK                  (0x1U)
#define MC33774_FEH_WAKEUP_CFG1_AINAOV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG1_AINAOV_SHIFT)) & MC33774_FEH_WAKEUP_CFG1_AINAOV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG1_AINAOV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG1_AINAOV_ENABLED_ENUM_VAL      (1U)

/* Field AINAUV: Enable wakeup on AINA_UV. */
#define MC33774_FEH_WAKEUP_CFG1_AINAUV_SHIFT                 (0x1U)
#define MC33774_FEH_WAKEUP_CFG1_AINAUV_MASK                  (0x2U)
#define MC33774_FEH_WAKEUP_CFG1_AINAUV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG1_AINAUV_SHIFT)) & MC33774_FEH_WAKEUP_CFG1_AINAUV_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG1_AINAUV_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG1_AINAUV_ENABLED_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_WAKEUP_CFG1_RESERVED0_SHIFT              (0x2U)
#define MC33774_FEH_WAKEUP_CFG1_RESERVED0_MASK               (0xFCU)
#define MC33774_FEH_WAKEUP_CFG1_RESERVED0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG1_RESERVED0_SHIFT)) & MC33774_FEH_WAKEUP_CFG1_RESERVED0_MASK))

/* Field BALPROT: Enable wakeup on detected balancing protection */
#define MC33774_FEH_WAKEUP_CFG1_BALPROT_SHIFT                (0x8U)
#define MC33774_FEH_WAKEUP_CFG1_BALPROT_MASK                 (0x100U)
#define MC33774_FEH_WAKEUP_CFG1_BALPROT_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG1_BALPROT_SHIFT)) & MC33774_FEH_WAKEUP_CFG1_BALPROT_MASK))

/* Enumerated value DISABLED: disabled */
#define MC33774_FEH_WAKEUP_CFG1_BALPROT_DISABLED_ENUM_VAL    (0U)

/* Enumerated value ENABLED: enabled */
#define MC33774_FEH_WAKEUP_CFG1_BALPROT_ENABLED_ENUM_VAL     (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_WAKEUP_CFG1_RESERVED1_SHIFT              (0x9U)
#define MC33774_FEH_WAKEUP_CFG1_RESERVED1_MASK               (0xFE00U)
#define MC33774_FEH_WAKEUP_CFG1_RESERVED1_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_CFG1_RESERVED1_SHIFT)) & MC33774_FEH_WAKEUP_CFG1_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * FEH_WAKEUP_REASON0 (read-only):wake up reason register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_WAKEUP_REASON0_OFFSET                    (0x40AU)
#define MC33774_FEH_WAKEUP_REASON0_RW_MASK                   (0x0U)
#define MC33774_FEH_WAKEUP_REASON0_RD_MASK                   (0xFFFFU)
#define MC33774_FEH_WAKEUP_REASON0_WR_MASK                   (0x0U)
#define MC33774_FEH_WAKEUP_REASON0_MW_MASK                   (0x0U)
#define MC33774_FEH_WAKEUP_REASON0_RA_MASK                   (0xFFFFU)
#define MC33774_FEH_WAKEUP_REASON0_POR_MASK                  (0xFFFFU)
#define MC33774_FEH_WAKEUP_REASON0_POR_VAL                   (0x0U)

/* Field VCOV: VC_OV */
#define MC33774_FEH_WAKEUP_REASON0_VCOV_SHIFT                (0x0U)
#define MC33774_FEH_WAKEUP_REASON0_VCOV_MASK                 (0x1U)
#define MC33774_FEH_WAKEUP_REASON0_VCOV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_VCOV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_VCOV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by VC_OV */
#define MC33774_FEH_WAKEUP_REASON0_VCOV_NO_WAKE_ENUM_VAL     (0U)

/* Enumerated value WAKE_UP: Wakeup caused by VC_OV */
#define MC33774_FEH_WAKEUP_REASON0_VCOV_WAKE_UP_ENUM_VAL     (1U)

/* Field VCUV0: VC_UV0 */
#define MC33774_FEH_WAKEUP_REASON0_VCUV0_SHIFT               (0x1U)
#define MC33774_FEH_WAKEUP_REASON0_VCUV0_MASK                (0x2U)
#define MC33774_FEH_WAKEUP_REASON0_VCUV0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_VCUV0_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_VCUV0_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by VC_UV0 */
#define MC33774_FEH_WAKEUP_REASON0_VCUV0_NO_WAKE_ENUM_VAL    (0U)

/* Enumerated value WAKE_UP: Wakeup caused by VC_UV0 */
#define MC33774_FEH_WAKEUP_REASON0_VCUV0_WAKE_UP_ENUM_VAL    (1U)

/* Field VCUV1: VC_UV1 */
#define MC33774_FEH_WAKEUP_REASON0_VCUV1_SHIFT               (0x2U)
#define MC33774_FEH_WAKEUP_REASON0_VCUV1_MASK                (0x4U)
#define MC33774_FEH_WAKEUP_REASON0_VCUV1_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_VCUV1_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_VCUV1_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by VC_UV1 */
#define MC33774_FEH_WAKEUP_REASON0_VCUV1_NO_WAKE_ENUM_VAL    (0U)

/* Enumerated value WAKE_UP: Wakeup caused by VC_UV1 */
#define MC33774_FEH_WAKEUP_REASON0_VCUV1_WAKE_UP_ENUM_VAL    (1U)

/* Field AIN0OV: AIN0_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN0OV_SHIFT              (0x3U)
#define MC33774_FEH_WAKEUP_REASON0_AIN0OV_MASK               (0x8U)
#define MC33774_FEH_WAKEUP_REASON0_AIN0OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN0OV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN0OV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN0_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN0OV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN0_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN0OV_WAKE_UP_ENUM_VAL   (1U)

/* Field AIN0UV: AIN0_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN0UV_SHIFT              (0x4U)
#define MC33774_FEH_WAKEUP_REASON0_AIN0UV_MASK               (0x10U)
#define MC33774_FEH_WAKEUP_REASON0_AIN0UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN0UV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN0UV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN0_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN0UV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN0_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN0UV_WAKE_UP_ENUM_VAL   (1U)

/* Field AIN1OV: AIN1_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN1OV_SHIFT              (0x5U)
#define MC33774_FEH_WAKEUP_REASON0_AIN1OV_MASK               (0x20U)
#define MC33774_FEH_WAKEUP_REASON0_AIN1OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN1OV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN1OV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN1_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN1OV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN1_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN1OV_WAKE_UP_ENUM_VAL   (1U)

/* Field AIN1UV: AIN1_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN1UV_SHIFT              (0x6U)
#define MC33774_FEH_WAKEUP_REASON0_AIN1UV_MASK               (0x40U)
#define MC33774_FEH_WAKEUP_REASON0_AIN1UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN1UV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN1UV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN1_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN1UV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN1_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN1UV_WAKE_UP_ENUM_VAL   (1U)

/* Field AIN2OV: AIN2_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN2OV_SHIFT              (0x7U)
#define MC33774_FEH_WAKEUP_REASON0_AIN2OV_MASK               (0x80U)
#define MC33774_FEH_WAKEUP_REASON0_AIN2OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN2OV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN2OV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN2_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN2OV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN2_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN2OV_WAKE_UP_ENUM_VAL   (1U)

/* Field AIN2UV: AIN2_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN2UV_SHIFT              (0x8U)
#define MC33774_FEH_WAKEUP_REASON0_AIN2UV_MASK               (0x100U)
#define MC33774_FEH_WAKEUP_REASON0_AIN2UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN2UV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN2UV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN2_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN2UV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN2_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN2UV_WAKE_UP_ENUM_VAL   (1U)

/* Field AIN3OV: AIN3_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN3OV_SHIFT              (0x9U)
#define MC33774_FEH_WAKEUP_REASON0_AIN3OV_MASK               (0x200U)
#define MC33774_FEH_WAKEUP_REASON0_AIN3OV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN3OV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN3OV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN3_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN3OV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN3_OV */
#define MC33774_FEH_WAKEUP_REASON0_AIN3OV_WAKE_UP_ENUM_VAL   (1U)

/* Field AIN3UV: AIN3_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN3UV_SHIFT              (0xAU)
#define MC33774_FEH_WAKEUP_REASON0_AIN3UV_MASK               (0x400U)
#define MC33774_FEH_WAKEUP_REASON0_AIN3UV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_AIN3UV_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_AIN3UV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AIN3_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN3UV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AIN3_UV */
#define MC33774_FEH_WAKEUP_REASON0_AIN3UV_WAKE_UP_ENUM_VAL   (1U)

/* Field ALARMIN: Detected alarm input */
#define MC33774_FEH_WAKEUP_REASON0_ALARMIN_SHIFT             (0xBU)
#define MC33774_FEH_WAKEUP_REASON0_ALARMIN_MASK              (0x800U)
#define MC33774_FEH_WAKEUP_REASON0_ALARMIN_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_ALARMIN_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_ALARMIN_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by detected Wakeup input */
#define MC33774_FEH_WAKEUP_REASON0_ALARMIN_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected Wakeup input */
#define MC33774_FEH_WAKEUP_REASON0_ALARMIN_WAKE_UP_ENUM_VAL \
  (1U)

/* Field WAKEUPIN: Detected wakeup input */
#define MC33774_FEH_WAKEUP_REASON0_WAKEUPIN_SHIFT            (0xCU)
#define MC33774_FEH_WAKEUP_REASON0_WAKEUPIN_MASK             (0x1000U)
#define MC33774_FEH_WAKEUP_REASON0_WAKEUPIN_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_WAKEUPIN_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_WAKEUPIN_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by detected wakeup input */
#define MC33774_FEH_WAKEUP_REASON0_WAKEUPIN_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected wakeup input */
#define MC33774_FEH_WAKEUP_REASON0_WAKEUPIN_WAKE_UP_ENUM_VAL \
  (1U)

/* Field BALRDY: Cell voltage balancing ready */
#define MC33774_FEH_WAKEUP_REASON0_BALRDY_SHIFT              (0xDU)
#define MC33774_FEH_WAKEUP_REASON0_BALRDY_MASK               (0x2000U)
#define MC33774_FEH_WAKEUP_REASON0_BALRDY_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_BALRDY_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_BALRDY_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by cell voltage balancing ready */
#define MC33774_FEH_WAKEUP_REASON0_BALRDY_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by cell voltage balancing ready */
#define MC33774_FEH_WAKEUP_REASON0_BALRDY_WAKE_UP_ENUM_VAL   (1U)

/* Field SYSFLTEVT: Detected system fault. */
#define MC33774_FEH_WAKEUP_REASON0_SYSFLTEVT_SHIFT           (0xEU)
#define MC33774_FEH_WAKEUP_REASON0_SYSFLTEVT_MASK            (0x4000U)
#define MC33774_FEH_WAKEUP_REASON0_SYSFLTEVT_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_SYSFLTEVT_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_SYSFLTEVT_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by detected system fault */
#define MC33774_FEH_WAKEUP_REASON0_SYSFLTEVT_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected system fault */
#define MC33774_FEH_WAKEUP_REASON0_SYSFLTEVT_WAKE_UP_ENUM_VAL \
  (1U)

/* Field COMM: Communication detected */
#define MC33774_FEH_WAKEUP_REASON0_COMM_SHIFT                (0xFU)
#define MC33774_FEH_WAKEUP_REASON0_COMM_MASK                 (0x8000U)
#define MC33774_FEH_WAKEUP_REASON0_COMM_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON0_COMM_SHIFT)) & MC33774_FEH_WAKEUP_REASON0_COMM_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by detected communication */
#define MC33774_FEH_WAKEUP_REASON0_COMM_NO_WAKE_ENUM_VAL     (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected communication */
#define MC33774_FEH_WAKEUP_REASON0_COMM_WAKE_UP_ENUM_VAL     (1U)

/* --------------------------------------------------------------------------
 * FEH_WAKEUP_REASON1 (read-only):wake up reason register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_WAKEUP_REASON1_OFFSET                    (0x40BU)
#define MC33774_FEH_WAKEUP_REASON1_RW_MASK                   (0x0U)
#define MC33774_FEH_WAKEUP_REASON1_RD_MASK                   (0x103U)
#define MC33774_FEH_WAKEUP_REASON1_WR_MASK                   (0x0U)
#define MC33774_FEH_WAKEUP_REASON1_MW_MASK                   (0x0U)
#define MC33774_FEH_WAKEUP_REASON1_RA_MASK                   (0x103U)
#define MC33774_FEH_WAKEUP_REASON1_POR_MASK                  (0xFFFFU)
#define MC33774_FEH_WAKEUP_REASON1_POR_VAL                   (0x0U)

/* Field AINAOV: AINA_OV */
#define MC33774_FEH_WAKEUP_REASON1_AINAOV_SHIFT              (0x0U)
#define MC33774_FEH_WAKEUP_REASON1_AINAOV_MASK               (0x1U)
#define MC33774_FEH_WAKEUP_REASON1_AINAOV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON1_AINAOV_SHIFT)) & MC33774_FEH_WAKEUP_REASON1_AINAOV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AINA_OV */
#define MC33774_FEH_WAKEUP_REASON1_AINAOV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AINA_OV */
#define MC33774_FEH_WAKEUP_REASON1_AINAOV_WAKE_UP_ENUM_VAL   (1U)

/* Field AINAUV: AIN0_UV */
#define MC33774_FEH_WAKEUP_REASON1_AINAUV_SHIFT              (0x1U)
#define MC33774_FEH_WAKEUP_REASON1_AINAUV_MASK               (0x2U)
#define MC33774_FEH_WAKEUP_REASON1_AINAUV_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON1_AINAUV_SHIFT)) & MC33774_FEH_WAKEUP_REASON1_AINAUV_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by AINA_UV */
#define MC33774_FEH_WAKEUP_REASON1_AINAUV_NO_WAKE_ENUM_VAL   (0U)

/* Enumerated value WAKE_UP: Wakeup caused by AINA_UV */
#define MC33774_FEH_WAKEUP_REASON1_AINAUV_WAKE_UP_ENUM_VAL   (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_WAKEUP_REASON1_RESERVED0_SHIFT           (0x2U)
#define MC33774_FEH_WAKEUP_REASON1_RESERVED0_MASK            (0xFCU)
#define MC33774_FEH_WAKEUP_REASON1_RESERVED0_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON1_RESERVED0_SHIFT)) & MC33774_FEH_WAKEUP_REASON1_RESERVED0_MASK))

/* Field BALPROT: Balancing protection detection */
#define MC33774_FEH_WAKEUP_REASON1_BALPROT_SHIFT             (0x8U)
#define MC33774_FEH_WAKEUP_REASON1_BALPROT_MASK              (0x100U)
#define MC33774_FEH_WAKEUP_REASON1_BALPROT_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON1_BALPROT_SHIFT)) & MC33774_FEH_WAKEUP_REASON1_BALPROT_MASK))

/* Enumerated value NO_WAKE: Wakeup not caused by detected Balancing protection */
#define MC33774_FEH_WAKEUP_REASON1_BALPROT_NO_WAKE_ENUM_VAL \
  (0U)

/* Enumerated value WAKE_UP: Wakeup caused by detected Balancing protection */
#define MC33774_FEH_WAKEUP_REASON1_BALPROT_WAKE_UP_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_WAKEUP_REASON1_RESERVED1_SHIFT           (0x9U)
#define MC33774_FEH_WAKEUP_REASON1_RESERVED1_MASK            (0xFE00U)
#define MC33774_FEH_WAKEUP_REASON1_RESERVED1_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_WAKEUP_REASON1_RESERVED1_SHIFT)) & MC33774_FEH_WAKEUP_REASON1_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * FEH_MON_BIST_CTRL (read-write):monitor BIST control register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_MON_BIST_CTRL_OFFSET                     (0x410U)
#define MC33774_FEH_MON_BIST_CTRL_RW_MASK                    (0xFFFEU)
#define MC33774_FEH_MON_BIST_CTRL_RD_MASK                    (0xFFFEU)
#define MC33774_FEH_MON_BIST_CTRL_WR_MASK                    (0xFFFFU)
#define MC33774_FEH_MON_BIST_CTRL_MW_MASK                    (0x0U)
#define MC33774_FEH_MON_BIST_CTRL_RA_MASK                    (0x0U)
#define MC33774_FEH_MON_BIST_CTRL_POR_MASK                   (0xFFFFU)
#define MC33774_FEH_MON_BIST_CTRL_POR_VAL                    (0x0U)

/* Field STARTBIST: Start BIST of all supply monitors, including VAUXOV, VAUXUV, VDDCOV and VDDCUV, which are not run at start-up.
If the BIST is executed while measurements are running, some created secondary measurement results might be invalid. Read as zero. */
#define MC33774_FEH_MON_BIST_CTRL_STARTBIST_SHIFT            (0x0U)
#define MC33774_FEH_MON_BIST_CTRL_STARTBIST_MASK             (0x1U)
#define MC33774_FEH_MON_BIST_CTRL_STARTBIST_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_CTRL_STARTBIST_SHIFT)) & MC33774_FEH_MON_BIST_CTRL_STARTBIST_MASK))

/* Enumerated value NO_START: Do not start BIST */
#define MC33774_FEH_MON_BIST_CTRL_STARTBIST_NO_START_ENUM_VAL \
  (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33774_FEH_MON_BIST_CTRL_STARTBIST_STATUS_ENUM_VAL \
  (0U)

/* Enumerated value START: Start BIST */
#define MC33774_FEH_MON_BIST_CTRL_STARTBIST_START_ENUM_VAL   (1U)

/* Field BISTCRC: CRC of the sequential BIST results. The value is different for the automatic BIST after start-up and a manual started BIST, as more monitors are then included.
If the resulting CRC differs from the defined values, the BIST was not executed correctly. */
#define MC33774_FEH_MON_BIST_CTRL_BISTCRC_SHIFT              (0x1U)
#define MC33774_FEH_MON_BIST_CTRL_BISTCRC_MASK               (0xFFFEU)
#define MC33774_FEH_MON_BIST_CTRL_BISTCRC_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_CTRL_BISTCRC_SHIFT)) & MC33774_FEH_MON_BIST_CTRL_BISTCRC_MASK))

/* Enumerated value STARTUP: Value 10B7h represents correct CRC value for start-up BIST */
#define MC33774_FEH_MON_BIST_CTRL_BISTCRC_STARTUP_ENUM_VAL   (4279U)

/* Enumerated value MAN_NO_VAUX: Value 4E3Dh represents the correct CRC value for a manual started BIST if VAUX is not enabled */
#define MC33774_FEH_MON_BIST_CTRL_BISTCRC_MAN_NO_VAUX_ENUM_VAL \
  (20029U)

/* Enumerated value MANUAL: Value 7742h represents correct CRC value for manual started BIST */
#define MC33774_FEH_MON_BIST_CTRL_BISTCRC_MANUAL_ENUM_VAL    (30530U)

/* --------------------------------------------------------------------------
 * FEH_MON_BIST_RES (read-only):monitor BIST result register; value changes at start-up, if everything is fine to 0000h
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_MON_BIST_RES_OFFSET                      (0x411U)
#define MC33774_FEH_MON_BIST_RES_RW_MASK                     (0x0U)
#define MC33774_FEH_MON_BIST_RES_RD_MASK                     (0xFFFU)
#define MC33774_FEH_MON_BIST_RES_WR_MASK                     (0x0U)
#define MC33774_FEH_MON_BIST_RES_MW_MASK                     (0x0U)
#define MC33774_FEH_MON_BIST_RES_RA_MASK                     (0x0U)
#define MC33774_FEH_MON_BIST_RES_POR_MASK                    (0xFFFFU)
#define MC33774_FEH_MON_BIST_RES_POR_VAL                     (0xFFU)

/* Field VBATOV: VBAT Supply over-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_VBATOV_SHIFT                (0x0U)
#define MC33774_FEH_MON_BIST_RES_VBATOV_MASK                 (0x1U)
#define MC33774_FEH_MON_BIST_RES_VBATOV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VBATOV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VBATOV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VBATOV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VBATOV_FAIL_ENUM_VAL        (1U)

/* Field VDDAOV: VDDA Supply over-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_VDDAOV_SHIFT                (0x1U)
#define MC33774_FEH_MON_BIST_RES_VDDAOV_MASK                 (0x2U)
#define MC33774_FEH_MON_BIST_RES_VDDAOV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VDDAOV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VDDAOV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VDDAOV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VDDAOV_FAIL_ENUM_VAL        (1U)

/* Field VDDAUV: VDDA Supply under-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_VDDAUV_SHIFT                (0x2U)
#define MC33774_FEH_MON_BIST_RES_VDDAUV_MASK                 (0x4U)
#define MC33774_FEH_MON_BIST_RES_VDDAUV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VDDAUV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VDDAUV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VDDAUV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VDDAUV_FAIL_ENUM_VAL        (1U)

/* Field VANAOV: VANA over-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_VANAOV_SHIFT                (0x3U)
#define MC33774_FEH_MON_BIST_RES_VANAOV_MASK                 (0x8U)
#define MC33774_FEH_MON_BIST_RES_VANAOV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VANAOV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VANAOV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VANAOV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VANAOV_FAIL_ENUM_VAL        (1U)

/* Field VANAUV: VANA under-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_VANAUV_SHIFT                (0x4U)
#define MC33774_FEH_MON_BIST_RES_VANAUV_MASK                 (0x10U)
#define MC33774_FEH_MON_BIST_RES_VANAUV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VANAUV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VANAUV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VANAUV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VANAUV_FAIL_ENUM_VAL        (1U)

/* Field AFECPOV: Analog Frontend Charge Pump over-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_AFECPOV_SHIFT               (0x5U)
#define MC33774_FEH_MON_BIST_RES_AFECPOV_MASK                (0x20U)
#define MC33774_FEH_MON_BIST_RES_AFECPOV_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_AFECPOV_SHIFT)) & MC33774_FEH_MON_BIST_RES_AFECPOV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_AFECPOV_PASS_ENUM_VAL       (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_AFECPOV_FAIL_ENUM_VAL       (1U)

/* Field AFECPUV: Analog Frontend Charge Pump under-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_AFECPUV_SHIFT               (0x6U)
#define MC33774_FEH_MON_BIST_RES_AFECPUV_MASK                (0x40U)
#define MC33774_FEH_MON_BIST_RES_AFECPUV_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_AFECPUV_SHIFT)) & MC33774_FEH_MON_BIST_RES_AFECPUV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_AFECPUV_PASS_ENUM_VAL       (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_AFECPUV_FAIL_ENUM_VAL       (1U)

/* Field VPREREFSUV: VPREREFSUV Supply under-voltage BIST failed. */
#define MC33774_FEH_MON_BIST_RES_VPREREFSUV_SHIFT            (0x7U)
#define MC33774_FEH_MON_BIST_RES_VPREREFSUV_MASK             (0x80U)
#define MC33774_FEH_MON_BIST_RES_VPREREFSUV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VPREREFSUV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VPREREFSUV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VPREREFSUV_PASS_ENUM_VAL    (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VPREREFSUV_FAIL_ENUM_VAL    (1U)

/* Field VAUXOV: VAUX Supply over-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33774_FEH_MON_BIST_RES_VAUXOV_SHIFT                (0x8U)
#define MC33774_FEH_MON_BIST_RES_VAUXOV_MASK                 (0x100U)
#define MC33774_FEH_MON_BIST_RES_VAUXOV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VAUXOV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VAUXOV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VAUXOV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VAUXOV_FAIL_ENUM_VAL        (1U)

/* Field VAUXUV: VAUX Supply under-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33774_FEH_MON_BIST_RES_VAUXUV_SHIFT                (0x9U)
#define MC33774_FEH_MON_BIST_RES_VAUXUV_MASK                 (0x200U)
#define MC33774_FEH_MON_BIST_RES_VAUXUV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VAUXUV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VAUXUV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VAUXUV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VAUXUV_FAIL_ENUM_VAL        (1U)

/* Field VDDCOV: VDDC Supply over-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33774_FEH_MON_BIST_RES_VDDCOV_SHIFT                (0xAU)
#define MC33774_FEH_MON_BIST_RES_VDDCOV_MASK                 (0x400U)
#define MC33774_FEH_MON_BIST_RES_VDDCOV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VDDCOV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VDDCOV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VDDCOV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VDDCOV_FAIL_ENUM_VAL        (1U)

/* Field VDDCUV: VDDC Supply under-voltage BIST failed. Not part of start-up BIST, only executed for manual BIST execution. */
#define MC33774_FEH_MON_BIST_RES_VDDCUV_SHIFT                (0xBU)
#define MC33774_FEH_MON_BIST_RES_VDDCUV_MASK                 (0x800U)
#define MC33774_FEH_MON_BIST_RES_VDDCUV_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_VDDCUV_SHIFT)) & MC33774_FEH_MON_BIST_RES_VDDCUV_MASK))

/* Enumerated value PASS: BIST passed */
#define MC33774_FEH_MON_BIST_RES_VDDCUV_PASS_ENUM_VAL        (0U)

/* Enumerated value FAIL: BIST failed */
#define MC33774_FEH_MON_BIST_RES_VDDCUV_FAIL_ENUM_VAL        (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_MON_BIST_RES_RESERVED0_SHIFT             (0xCU)
#define MC33774_FEH_MON_BIST_RES_RESERVED0_MASK              (0xF000U)
#define MC33774_FEH_MON_BIST_RES_RESERVED0_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MON_BIST_RES_RESERVED0_SHIFT)) & MC33774_FEH_MON_BIST_RES_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_ACC_ERR (read-only):access error status register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ACC_ERR_OFFSET                           (0x41EU)
#define MC33774_FEH_ACC_ERR_RW_MASK                          (0x0U)
#define MC33774_FEH_ACC_ERR_RD_MASK                          (0xFFFFU)
#define MC33774_FEH_ACC_ERR_WR_MASK                          (0x0U)
#define MC33774_FEH_ACC_ERR_MW_MASK                          (0x0U)
#define MC33774_FEH_ACC_ERR_RA_MASK                          (0xFFFFU)
#define MC33774_FEH_ACC_ERR_POR_MASK                         (0xFFFFU)
#define MC33774_FEH_ACC_ERR_POR_VAL                          (0x0U)

/* Field ERRADD: Address of the last access which created an access error */
#define MC33774_FEH_ACC_ERR_ERRADD_SHIFT                     (0x0U)
#define MC33774_FEH_ACC_ERR_ERRADD_MASK                      (0x3FFFU)
#define MC33774_FEH_ACC_ERR_ERRADD_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ACC_ERR_ERRADD_SHIFT)) & MC33774_FEH_ACC_ERR_ERRADD_MASK))

/* Field ERRACC: Access type of the last access error */
#define MC33774_FEH_ACC_ERR_ERRACC_SHIFT                     (0xEU)
#define MC33774_FEH_ACC_ERR_ERRACC_MASK                      (0x4000U)
#define MC33774_FEH_ACC_ERR_ERRACC_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ACC_ERR_ERRACC_SHIFT)) & MC33774_FEH_ACC_ERR_ERRACC_MASK))

/* Enumerated value READ: Last error occurred during a read access */
#define MC33774_FEH_ACC_ERR_ERRACC_READ_ENUM_VAL             (0U)

/* Enumerated value WRITE: Last error occurred during a write access */
#define MC33774_FEH_ACC_ERR_ERRACC_WRITE_ENUM_VAL            (1U)

/* Field ERRSTAT: Access error status */
#define MC33774_FEH_ACC_ERR_ERRSTAT_SHIFT                    (0xFU)
#define MC33774_FEH_ACC_ERR_ERRSTAT_MASK                     (0x8000U)
#define MC33774_FEH_ACC_ERR_ERRSTAT_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ACC_ERR_ERRSTAT_SHIFT)) & MC33774_FEH_ACC_ERR_ERRSTAT_MASK))

/* Enumerated value NO_ERROR: No error occurred */
#define MC33774_FEH_ACC_ERR_ERRSTAT_NO_ERROR_ENUM_VAL        (0U)

/* Enumerated value ERROR: Access error has occurred */
#define MC33774_FEH_ACC_ERR_ERRSTAT_ERROR_ENUM_VAL           (1U)

/* --------------------------------------------------------------------------
 * FEH_GRP_FLT_STAT (read-only):main system fault status register; this register holds one bit per fault group. For each fault group a separate status register exists. The bit here is cleared if all its sources are cleared.
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_GRP_FLT_STAT_OFFSET                      (0x41FU)
#define MC33774_FEH_GRP_FLT_STAT_RW_MASK                     (0x0U)
#define MC33774_FEH_GRP_FLT_STAT_RD_MASK                     (0xFU)
#define MC33774_FEH_GRP_FLT_STAT_WR_MASK                     (0x0U)
#define MC33774_FEH_GRP_FLT_STAT_MW_MASK                     (0x0U)
#define MC33774_FEH_GRP_FLT_STAT_RA_MASK                     (0x0U)
#define MC33774_FEH_GRP_FLT_STAT_POR_MASK                    (0xFFFFU)
#define MC33774_FEH_GRP_FLT_STAT_POR_VAL                     (0x0U)

/* Field SUPPLYFLT: Internal/external supply fault status */
#define MC33774_FEH_GRP_FLT_STAT_SUPPLYFLT_SHIFT             (0x0U)
#define MC33774_FEH_GRP_FLT_STAT_SUPPLYFLT_MASK              (0x1U)
#define MC33774_FEH_GRP_FLT_STAT_SUPPLYFLT_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_GRP_FLT_STAT_SUPPLYFLT_SHIFT)) & MC33774_FEH_GRP_FLT_STAT_SUPPLYFLT_MASK))

/* Enumerated value NO_ERROR: No supply error detected */
#define MC33774_FEH_GRP_FLT_STAT_SUPPLYFLT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Supply error detected */
#define MC33774_FEH_GRP_FLT_STAT_SUPPLYFLT_ERROR_ENUM_VAL    (1U)

/* Field ANAFLT: Analog fault status */
#define MC33774_FEH_GRP_FLT_STAT_ANAFLT_SHIFT                (0x1U)
#define MC33774_FEH_GRP_FLT_STAT_ANAFLT_MASK                 (0x2U)
#define MC33774_FEH_GRP_FLT_STAT_ANAFLT_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_GRP_FLT_STAT_ANAFLT_SHIFT)) & MC33774_FEH_GRP_FLT_STAT_ANAFLT_MASK))

/* Enumerated value NO_ERROR: No analog fault detected */
#define MC33774_FEH_GRP_FLT_STAT_ANAFLT_NO_ERROR_ENUM_VAL    (0U)

/* Enumerated value ERROR: Analog fault detected */
#define MC33774_FEH_GRP_FLT_STAT_ANAFLT_ERROR_ENUM_VAL       (1U)

/* Field COMFLT: Communication fault status */
#define MC33774_FEH_GRP_FLT_STAT_COMFLT_SHIFT                (0x2U)
#define MC33774_FEH_GRP_FLT_STAT_COMFLT_MASK                 (0x4U)
#define MC33774_FEH_GRP_FLT_STAT_COMFLT_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_GRP_FLT_STAT_COMFLT_SHIFT)) & MC33774_FEH_GRP_FLT_STAT_COMFLT_MASK))

/* Enumerated value NO_ERROR: No communication fault detected */
#define MC33774_FEH_GRP_FLT_STAT_COMFLT_NO_ERROR_ENUM_VAL    (0U)

/* Enumerated value ERROR: Communication fault detected. */
#define MC33774_FEH_GRP_FLT_STAT_COMFLT_ERROR_ENUM_VAL       (1U)

/* Field MEASFLT: Measurement fault status */
#define MC33774_FEH_GRP_FLT_STAT_MEASFLT_SHIFT               (0x3U)
#define MC33774_FEH_GRP_FLT_STAT_MEASFLT_MASK                (0x8U)
#define MC33774_FEH_GRP_FLT_STAT_MEASFLT_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_GRP_FLT_STAT_MEASFLT_SHIFT)) & MC33774_FEH_GRP_FLT_STAT_MEASFLT_MASK))

/* Enumerated value NO_ERROR: No measurement fault detected */
#define MC33774_FEH_GRP_FLT_STAT_MEASFLT_NO_ERROR_ENUM_VAL   (0U)

/* Enumerated value ERROR: Measurement fault detected */
#define MC33774_FEH_GRP_FLT_STAT_MEASFLT_ERROR_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_GRP_FLT_STAT_RESERVED0_SHIFT             (0x4U)
#define MC33774_FEH_GRP_FLT_STAT_RESERVED0_MASK              (0xFFF0U)
#define MC33774_FEH_GRP_FLT_STAT_RESERVED0_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_GRP_FLT_STAT_RESERVED0_SHIFT)) & MC33774_FEH_GRP_FLT_STAT_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_STAT0 (read-write):supply fault status register 0 (these monitors are part of the BIST)
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_SUPPLY_FLT_STAT0_OFFSET                  (0x420U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_RW_MASK                 (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_RD_MASK                 (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_WR_MASK                 (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_MW_MASK                 (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_RA_MASK                 (0x0U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_POR_MASK                (0xFFFFU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_POR_VAL                 (0x0U)

/* Field VBATOV: VBAT Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VBATOV_SHIFT            (0x0U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VBATOV_MASK             (0x1U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VBATOV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VBATOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VBATOV_MASK))

/* Enumerated value NO_OV: No VBAT Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VBATOV_NO_OV_ENUM_VAL   (0U)

/* Enumerated value OV: VBAT Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VBATOV_OV_ENUM_VAL      (1U)

/* Field VDDAOV: VDDA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAOV_SHIFT            (0x1U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAOV_MASK             (0x2U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAOV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VDDAOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VDDAOV_MASK))

/* Enumerated value NO_OV: No VDDA Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAOV_NO_OV_ENUM_VAL   (0U)

/* Enumerated value OV: VDDA Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAOV_OV_ENUM_VAL      (1U)

/* Field VDDAUV: VDDA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAUV_SHIFT            (0x2U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAUV_MASK             (0x4U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAUV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VDDAUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VDDAUV_MASK))

/* Enumerated value NO_UV: No VDDA Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAUV_NO_UV_ENUM_VAL   (0U)

/* Enumerated value UV: VDDA Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDAUV_UV_ENUM_VAL      (1U)

/* Field VANAOV: VANA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAOV_SHIFT            (0x3U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAOV_MASK             (0x8U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAOV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VANAOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VANAOV_MASK))

/* Enumerated value NO_OV: No VANA Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAOV_NO_OV_ENUM_VAL   (0U)

/* Enumerated value OV: VANA Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAOV_OV_ENUM_VAL      (1U)

/* Field VANAUV: VANA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAUV_SHIFT            (0x4U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAUV_MASK             (0x10U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAUV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VANAUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VANAUV_MASK))

/* Enumerated value NO_UV: No VANA Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAUV_NO_UV_ENUM_VAL   (0U)

/* Enumerated value UV: VANA Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VANAUV_UV_ENUM_VAL      (1U)

/* Field AFECPOV: AFE Charge Pump over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPOV_SHIFT           (0x5U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPOV_MASK            (0x20U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPOV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_AFECPOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_AFECPOV_MASK))

/* Enumerated value NO_OV: No AFE Charge Pump over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: AFE Charge Pump over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPOV_OV_ENUM_VAL     (1U)

/* Field AFECPUV: AFE Charge Pump under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPUV_SHIFT           (0x6U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPUV_MASK            (0x40U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPUV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_AFECPUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_AFECPUV_MASK))

/* Enumerated value NO_UV: No AFE Charge Pump under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: AFE Charge Pump under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_AFECPUV_UV_ENUM_VAL     (1U)

/* Field VPREREFSUV: VPREREFS Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_SHIFT        (0x7U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_MASK         (0x80U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_MASK))

/* Enumerated value NO_UV: No VPREREFS Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: VPREREFS Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VPREREFSUV_UV_ENUM_VAL \
  (1U)

/* Field VAUXOV: VAUX Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXOV_SHIFT            (0x8U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXOV_MASK             (0x100U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXOV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VAUXOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VAUXOV_MASK))

/* Enumerated value NO_OV: No VAUX Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXOV_NO_OV_ENUM_VAL   (0U)

/* Enumerated value OV: VAUX Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXOV_OV_ENUM_VAL      (1U)

/* Field VAUXUV: VAUX Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXUV_SHIFT            (0x9U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXUV_MASK             (0x200U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXUV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VAUXUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VAUXUV_MASK))

/* Enumerated value NO_UV: No VAUX Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXUV_NO_UV_ENUM_VAL   (0U)

/* Enumerated value UV: VAUX Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VAUXUV_UV_ENUM_VAL      (1U)

/* Field VDDCOV: VDDC Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCOV_SHIFT            (0xAU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCOV_MASK             (0x400U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCOV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VDDCOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VDDCOV_MASK))

/* Enumerated value NO_OV: No VDDC Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCOV_NO_OV_ENUM_VAL   (0U)

/* Enumerated value OV: VDDC Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCOV_OV_ENUM_VAL      (1U)

/* Field VDDCUV: VDDC Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCUV_SHIFT            (0xBU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCUV_MASK             (0x800U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCUV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_VDDCUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_VDDCUV_MASK))

/* Enumerated value NO_UV: No VDDC Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCUV_NO_UV_ENUM_VAL   (0U)

/* Enumerated value UV: VDDC Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_VDDCUV_UV_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_SUPPLY_FLT_STAT0_RESERVED0_SHIFT         (0xCU)
#define MC33774_FEH_SUPPLY_FLT_STAT0_RESERVED0_MASK          (0xF000U)
#define MC33774_FEH_SUPPLY_FLT_STAT0_RESERVED0_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT0_RESERVED0_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT0_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_STAT1 (read-write):supply fault status register 1 (these monitors are not part of the BIST)
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_SUPPLY_FLT_STAT1_OFFSET                  (0x421U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_RW_MASK                 (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_STAT1_RD_MASK                 (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_STAT1_WR_MASK                 (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_STAT1_MW_MASK                 (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_STAT1_RA_MASK                 (0x0U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_POR_MASK                (0xFFFFU)
#define MC33774_FEH_SUPPLY_FLT_STAT1_POR_VAL                 (0x0U)

/* Field VBATLV: VBAT Supply low-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VBATLV_SHIFT            (0x0U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VBATLV_MASK             (0x1U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VBATLV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_VBATLV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_VBATLV_MASK))

/* Enumerated value NO_LV: No VBAT Supply low-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VBATLV_NO_LV_ENUM_VAL   (0U)

/* Enumerated value LV: VBAT Supply low-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VBATLV_LV_ENUM_VAL      (1U)

/* Field VPREREFSOV: VPREREFS Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_SHIFT        (0x1U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_MASK         (0x2U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_MASK))

/* Enumerated value NO_OV: No VPREREFS Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VPREREFS Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREREFSOV_OV_ENUM_VAL \
  (1U)

/* Field VDDCHC: VDDC high-current fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDCHC_SHIFT            (0x2U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDCHC_MASK             (0x4U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDCHC_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_VDDCHC_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_VDDCHC_MASK))

/* Enumerated value NO_HC: No VDDC high-current detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDCHC_NO_HC_ENUM_VAL   (0U)

/* Enumerated value HC: VDDC high-current detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDCHC_HC_ENUM_VAL      (1U)

/* Field VDDIOOV: VDDIO Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOOV_SHIFT           (0x3U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOOV_MASK            (0x8U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOOV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOOV_MASK))

/* Enumerated value NO_OV: No VDDIO Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOOV_NO_OV_ENUM_VAL \
  (0U)

/* Enumerated value OV: VDDIO Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOOV_OV_ENUM_VAL     (1U)

/* Field VDDIOUV: VDDIO Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOUV_SHIFT           (0x4U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOUV_MASK            (0x10U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOUV_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOUV_MASK))

/* Enumerated value NO_UV: No VDDIO Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOUV_NO_UV_ENUM_VAL \
  (0U)

/* Enumerated value UV: VDDIO Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VDDIOUV_UV_ENUM_VAL     (1U)

/* Field VPREOV: VPRE Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREOV_SHIFT            (0x5U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREOV_MASK             (0x20U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREOV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_VPREOV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_VPREOV_MASK))

/* Enumerated value NO_OV: No VPRE Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREOV_NO_OV_ENUM_VAL   (0U)

/* Enumerated value OV: VPRE Supply over-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREOV_OV_ENUM_VAL      (1U)

/* Field VPREUV: VPRE Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREUV_SHIFT            (0x6U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREUV_MASK             (0x40U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREUV_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_VPREUV_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_VPREUV_MASK))

/* Enumerated value NO_UV: No VPRE Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREUV_NO_UV_ENUM_VAL   (0U)

/* Enumerated value UV: VPRE Supply under-voltage detected. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_VPREUV_UV_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_SUPPLY_FLT_STAT1_RESERVED0_SHIFT         (0x7U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_RESERVED0_MASK          (0xFF80U)
#define MC33774_FEH_SUPPLY_FLT_STAT1_RESERVED0_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_STAT1_RESERVED0_SHIFT)) & MC33774_FEH_SUPPLY_FLT_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_ANA_FLT_STAT (read-write):analog fault status register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ANA_FLT_STAT_OFFSET                      (0x422U)
#define MC33774_FEH_ANA_FLT_STAT_RW_MASK                     (0x3U)
#define MC33774_FEH_ANA_FLT_STAT_RD_MASK                     (0x3U)
#define MC33774_FEH_ANA_FLT_STAT_WR_MASK                     (0x3U)
#define MC33774_FEH_ANA_FLT_STAT_MW_MASK                     (0x3U)
#define MC33774_FEH_ANA_FLT_STAT_RA_MASK                     (0x0U)
#define MC33774_FEH_ANA_FLT_STAT_POR_MASK                    (0xFFFFU)
#define MC33774_FEH_ANA_FLT_STAT_POR_VAL                     (0x0U)

/* Field MONBIST: Monitor BIST failure fault. */
#define MC33774_FEH_ANA_FLT_STAT_MONBIST_SHIFT               (0x0U)
#define MC33774_FEH_ANA_FLT_STAT_MONBIST_MASK                (0x1U)
#define MC33774_FEH_ANA_FLT_STAT_MONBIST_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_STAT_MONBIST_SHIFT)) & MC33774_FEH_ANA_FLT_STAT_MONBIST_MASK))

/* Enumerated value NO_FLT: No monitor BIST failure detected. */
#define MC33774_FEH_ANA_FLT_STAT_MONBIST_NO_FLT_ENUM_VAL     (0U)

/* Enumerated value FAILURE: Monitor BIST failure detected. */
#define MC33774_FEH_ANA_FLT_STAT_MONBIST_FAILURE_ENUM_VAL    (1U)

/* Field BALFLT: Cell balance function fault. */
#define MC33774_FEH_ANA_FLT_STAT_BALFLT_SHIFT                (0x1U)
#define MC33774_FEH_ANA_FLT_STAT_BALFLT_MASK                 (0x2U)
#define MC33774_FEH_ANA_FLT_STAT_BALFLT_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_STAT_BALFLT_SHIFT)) & MC33774_FEH_ANA_FLT_STAT_BALFLT_MASK))

/* Enumerated value NO_FLT: No cell balancing fault detected */
#define MC33774_FEH_ANA_FLT_STAT_BALFLT_NO_FLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Cell balancing fault detected */
#define MC33774_FEH_ANA_FLT_STAT_BALFLT_FAULT_ENUM_VAL       (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ANA_FLT_STAT_RESERVED0_SHIFT             (0x2U)
#define MC33774_FEH_ANA_FLT_STAT_RESERVED0_MASK              (0xFFFCU)
#define MC33774_FEH_ANA_FLT_STAT_RESERVED0_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_STAT_RESERVED0_SHIFT)) & MC33774_FEH_ANA_FLT_STAT_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_COM_FLT_STAT (read-write):communication fault status register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_COM_FLT_STAT_OFFSET                      (0x423U)
#define MC33774_FEH_COM_FLT_STAT_RW_MASK                     (0xFF1FU)
#define MC33774_FEH_COM_FLT_STAT_RD_MASK                     (0xFF1FU)
#define MC33774_FEH_COM_FLT_STAT_WR_MASK                     (0xFF1FU)
#define MC33774_FEH_COM_FLT_STAT_MW_MASK                     (0xFF1FU)
#define MC33774_FEH_COM_FLT_STAT_RA_MASK                     (0x0U)
#define MC33774_FEH_COM_FLT_STAT_POR_MASK                    (0xFFFFU)
#define MC33774_FEH_COM_FLT_STAT_POR_VAL                     (0x0U)

/* Field FRAMEERR: Communication frame error (Wrong number of bits or bit-length error) */
#define MC33774_FEH_COM_FLT_STAT_FRAMEERR_SHIFT              (0x0U)
#define MC33774_FEH_COM_FLT_STAT_FRAMEERR_MASK               (0x1U)
#define MC33774_FEH_COM_FLT_STAT_FRAMEERR_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_STAT_FRAMEERR_SHIFT)) & MC33774_FEH_COM_FLT_STAT_FRAMEERR_MASK))

/* Enumerated value NO_ERROR: No communication frame error detected. */
#define MC33774_FEH_COM_FLT_STAT_FRAMEERR_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: Communication frame error detected. */
#define MC33774_FEH_COM_FLT_STAT_FRAMEERR_ERROR_ENUM_VAL     (1U)

/* Field CRCERR: Communication CRC error */
#define MC33774_FEH_COM_FLT_STAT_CRCERR_SHIFT                (0x1U)
#define MC33774_FEH_COM_FLT_STAT_CRCERR_MASK                 (0x2U)
#define MC33774_FEH_COM_FLT_STAT_CRCERR_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_STAT_CRCERR_SHIFT)) & MC33774_FEH_COM_FLT_STAT_CRCERR_MASK))

/* Enumerated value NO_ERROR: No communication CRC error detected. */
#define MC33774_FEH_COM_FLT_STAT_CRCERR_NO_ERROR_ENUM_VAL    (0U)

/* Enumerated value ERROR: Communication CRC error detected. */
#define MC33774_FEH_COM_FLT_STAT_CRCERR_ERROR_ENUM_VAL       (1U)

/* Field ERRCNTOF: Communication error counter overflow */
#define MC33774_FEH_COM_FLT_STAT_ERRCNTOF_SHIFT              (0x2U)
#define MC33774_FEH_COM_FLT_STAT_ERRCNTOF_MASK               (0x4U)
#define MC33774_FEH_COM_FLT_STAT_ERRCNTOF_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_STAT_ERRCNTOF_SHIFT)) & MC33774_FEH_COM_FLT_STAT_ERRCNTOF_MASK))

/* Enumerated value NO_MAX: Communication error counter has not reached max value. */
#define MC33774_FEH_COM_FLT_STAT_ERRCNTOF_NO_MAX_ENUM_VAL    (0U)

/* Enumerated value MAX: Communication error counter has reached max value. */
#define MC33774_FEH_COM_FLT_STAT_ERRCNTOF_MAX_ENUM_VAL       (1U)

/* Field COMTO: Communication timeout fault status */
#define MC33774_FEH_COM_FLT_STAT_COMTO_SHIFT                 (0x3U)
#define MC33774_FEH_COM_FLT_STAT_COMTO_MASK                  (0x8U)
#define MC33774_FEH_COM_FLT_STAT_COMTO_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_STAT_COMTO_SHIFT)) & MC33774_FEH_COM_FLT_STAT_COMTO_MASK))

/* Enumerated value NO_TIMEOUT: No communication timeout has happened. */
#define MC33774_FEH_COM_FLT_STAT_COMTO_NO_TIMEOUT_ENUM_VAL   (0U)

/* Enumerated value TIMEMOUT: Communication timeout has happened. */
#define MC33774_FEH_COM_FLT_STAT_COMTO_TIMEMOUT_ENUM_VAL     (1U)

/* Field RSPLENERR: Response length error */
#define MC33774_FEH_COM_FLT_STAT_RSPLENERR_SHIFT             (0x4U)
#define MC33774_FEH_COM_FLT_STAT_RSPLENERR_MASK              (0x10U)
#define MC33774_FEH_COM_FLT_STAT_RSPLENERR_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_STAT_RSPLENERR_SHIFT)) & MC33774_FEH_COM_FLT_STAT_RSPLENERR_MASK))

/* Enumerated value NO_ERROR: No response length error occurred */
#define MC33774_FEH_COM_FLT_STAT_RSPLENERR_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value ERROR: The number of SPI clocks did not fit to the length of a requested response */
#define MC33774_FEH_COM_FLT_STAT_RSPLENERR_ERROR_ENUM_VAL    (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_COM_FLT_STAT_RESERVED0_SHIFT             (0x5U)
#define MC33774_FEH_COM_FLT_STAT_RESERVED0_MASK              (0xE0U)
#define MC33774_FEH_COM_FLT_STAT_RESERVED0_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_STAT_RESERVED0_SHIFT)) & MC33774_FEH_COM_FLT_STAT_RESERVED0_MASK))

/* Field COMERRCNT: Number of communication errors (frame errors, CRC errors) since last clear, counter saturates at 0xFF. Write with any data unequal 0 clears the counter. The counter value is preserved during Sleep mode. Write 1 clears bits. */
#define MC33774_FEH_COM_FLT_STAT_COMERRCNT_SHIFT             (0x8U)
#define MC33774_FEH_COM_FLT_STAT_COMERRCNT_MASK              (0xFF00U)
#define MC33774_FEH_COM_FLT_STAT_COMERRCNT_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_STAT_COMERRCNT_SHIFT)) & MC33774_FEH_COM_FLT_STAT_COMERRCNT_MASK))

/* Enumerated value NO_ERROR: No communication error occurred */
#define MC33774_FEH_COM_FLT_STAT_COMERRCNT_NO_ERROR_ENUM_VAL \
  (0U)

/* Enumerated value CNT: CNT errors occurred */
#define MC33774_FEH_COM_FLT_STAT_COMERRCNT_CNT_ENUM_VAL      (1U)

/* Enumerated value MAX: Maximum communication error counter = 255 communication errors occurred. */
#define MC33774_FEH_COM_FLT_STAT_COMERRCNT_MAX_ENUM_VAL      (255U)

/* --------------------------------------------------------------------------
 * FEH_MEAS_FLT_STAT (read-write):other fault status register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_MEAS_FLT_STAT_OFFSET                     (0x424U)
#define MC33774_FEH_MEAS_FLT_STAT_RW_MASK                    (0x7U)
#define MC33774_FEH_MEAS_FLT_STAT_RD_MASK                    (0x7U)
#define MC33774_FEH_MEAS_FLT_STAT_WR_MASK                    (0x7U)
#define MC33774_FEH_MEAS_FLT_STAT_MW_MASK                    (0x7U)
#define MC33774_FEH_MEAS_FLT_STAT_RA_MASK                    (0x0U)
#define MC33774_FEH_MEAS_FLT_STAT_POR_MASK                   (0xFFFFU)
#define MC33774_FEH_MEAS_FLT_STAT_POR_VAL                    (0x0U)

/* Field PRIMCALCRCFLT: A fault in the primary measurement chain calibration data */
#define MC33774_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_SHIFT        (0x0U)
#define MC33774_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_MASK         (0x1U)
#define MC33774_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_SHIFT)) & MC33774_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_MASK))

/* Enumerated value NO_FLT: No fault in primary measurement chain calibration data detected. */
#define MC33774_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: A fault in the primary measurement chain calibration data has been detected. */
#define MC33774_FEH_MEAS_FLT_STAT_PRIMCALCRCFLT_FAULT_ENUM_VAL \
  (1U)

/* Field SECCALCRCFLT: A fault in the secondary measurement chain calibration data */
#define MC33774_FEH_MEAS_FLT_STAT_SECCALCRCFLT_SHIFT         (0x1U)
#define MC33774_FEH_MEAS_FLT_STAT_SECCALCRCFLT_MASK          (0x2U)
#define MC33774_FEH_MEAS_FLT_STAT_SECCALCRCFLT_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_STAT_SECCALCRCFLT_SHIFT)) & MC33774_FEH_MEAS_FLT_STAT_SECCALCRCFLT_MASK))

/* Enumerated value NO_FLT: No fault in secondary measurement chain calibration data detected. */
#define MC33774_FEH_MEAS_FLT_STAT_SECCALCRCFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: A fault in the secondary measurement chain calibration data has been detected. */
#define MC33774_FEH_MEAS_FLT_STAT_SECCALCRCFLT_FAULT_ENUM_VAL \
  (1U)

/* Field SYNCMEASFLT: Synchronization fault between the measurement units */
#define MC33774_FEH_MEAS_FLT_STAT_SYNCMEASFLT_SHIFT          (0x2U)
#define MC33774_FEH_MEAS_FLT_STAT_SYNCMEASFLT_MASK           (0x4U)
#define MC33774_FEH_MEAS_FLT_STAT_SYNCMEASFLT_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_STAT_SYNCMEASFLT_SHIFT)) & MC33774_FEH_MEAS_FLT_STAT_SYNCMEASFLT_MASK))

/* Enumerated value NO_FLT: No synchronization fault between the measurement units for a Sync cycle has been detected.. */
#define MC33774_FEH_MEAS_FLT_STAT_SYNCMEASFLT_NO_FLT_ENUM_VAL \
  (0U)

/* Enumerated value FAULT: Synchronization fault between the measurement units for a Sync cycle has been detected.. */
#define MC33774_FEH_MEAS_FLT_STAT_SYNCMEASFLT_FAULT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_MEAS_FLT_STAT_RESERVED0_SHIFT            (0x3U)
#define MC33774_FEH_MEAS_FLT_STAT_RESERVED0_MASK             (0xFFF8U)
#define MC33774_FEH_MEAS_FLT_STAT_RESERVED0_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_STAT_RESERVED0_SHIFT)) & MC33774_FEH_MEAS_FLT_STAT_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_POR_CFG0 (read-write):supply fault POR selection 0
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_OFFSET               (0x428U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_RW_MASK              (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_RD_MASK              (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_WR_MASK              (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_MW_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_RA_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_POR_MASK             (0xFFFFU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_POR_VAL              (0x0U)

/* Field VBATOVEN: POR on VBAT Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_SHIFT       (0x0U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_MASK        (0x1U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VBAT supply over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VBAT supply over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDAOVEN: POR on VDDA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_SHIFT       (0x1U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_MASK        (0x2U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VDDA supply over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDA supply over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDAUVEN: POR on VDDA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_SHIFT       (0x2U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_MASK        (0x4U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VDDA supply under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDA supply under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_POR_ENUM_VAL \
  (1U)

/* Field VANAOVEN: POR on VANA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_SHIFT       (0x3U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_MASK        (0x8U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VANA supply over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VANA supply over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_POR_ENUM_VAL \
  (1U)

/* Field VANAUVEN: POR on VANA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_SHIFT       (0x4U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_MASK        (0x10U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VANA supply under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VANA supply under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_POR_ENUM_VAL \
  (1U)

/* Field AFECPOVEN: POR on AFE Charge Pump over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_SHIFT      (0x5U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_MASK       (0x20U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of AFE Charge Pump over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: AFE Charge Pump over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_POR_ENUM_VAL \
  (1U)

/* Field AFECPUVEN: POR on AFE Charge Pump under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_SHIFT      (0x6U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_MASK       (0x40U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of AFE Charge Pump under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: AFE Charge Pump under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_POR_ENUM_VAL \
  (1U)

/* Field VPREREFSUVEN: POR on VPREREFS Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_SHIFT   (0x7U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_MASK    (0x80U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_U16(x)  (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VPREREFS supply under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VPREREFS supply under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_POR_ENUM_VAL \
  (1U)

/* Field VAUXOVEN: POR on VAUX over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_SHIFT       (0x8U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_MASK        (0x100U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VAUX supply over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VAUX supply over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_POR_ENUM_VAL \
  (1U)

/* Field VAUXUVEN: POR on VAUX under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_SHIFT       (0x9U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_MASK        (0x200U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VAUX supply under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VAUX supply under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDCOVEN: POR on VDDC over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_SHIFT       (0xAU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_MASK        (0x400U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VDDC over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDC over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDCUVEN: POR on VDDC under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_SHIFT       (0xBU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_MASK        (0x800U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VDDC under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDC under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_POR_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_RESERVED0_SHIFT      (0xCU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_RESERVED0_MASK       (0xF000U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG0_RESERVED0_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_RESERVED0_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG0_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_POR_CFG1 (read-write):supply fault POR selection 1
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_OFFSET               (0x429U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_RW_MASK              (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_RD_MASK              (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_WR_MASK              (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_MW_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_RA_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_POR_MASK             (0xFFFFU)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_POR_VAL              (0x0U)

/* Field VBATLVEN: POR on VBAT Supply low-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_SHIFT       (0x0U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_MASK        (0x1U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VBAT supply low-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VBAT supply low-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_POR_ENUM_VAL \
  (1U)

/* Field VPREREFSOVEN: POR on VPREREFS Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_SHIFT   (0x1U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_MASK    (0x2U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_U16(x)  (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VPREREFS over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VPREREFS over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDCHCEN: POR on VDDC high-current fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_SHIFT       (0x2U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_MASK        (0x4U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_MASK))

/* Enumerated value NO_POR: No POR in case of VDDC high-current */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDC high-current error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_POR_ENUM_VAL \
  (1U)

/* Field VDDIOOVEN: POR on VDDIO Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_SHIFT      (0x3U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_MASK       (0x8U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VDDIO supply over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDIO supply over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_POR_ENUM_VAL \
  (1U)

/* Field VDDIOUVEN: POR on VDDIO Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_SHIFT      (0x4U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_MASK       (0x10U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VDDIO supply under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VDDIO supply under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_POR_ENUM_VAL \
  (1U)

/* Field VPREOVEN: POR on VPRE Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_SHIFT       (0x5U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_MASK        (0x20U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VPRE over-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VPRE over-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_POR_ENUM_VAL \
  (1U)

/* Field VPREUVEN: POR on VPRE Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_SHIFT       (0x6U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_MASK        (0x40U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_MASK))

/* Enumerated value NO_POR: No POR in case of VPRE supply under-voltage */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: VPRE supply under-voltage error leads to POR */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_POR_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_RESERVED0_SHIFT      (0x7U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_RESERVED0_MASK       (0xFF80U)
#define MC33774_FEH_SUPPLY_FLT_POR_CFG1_RESERVED0_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_RESERVED0_SHIFT)) & MC33774_FEH_SUPPLY_FLT_POR_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_ANA_FLT_POR_CFG (read-only):analog fault POR selection
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ANA_FLT_POR_CFG_OFFSET                   (0x42AU)
#define MC33774_FEH_ANA_FLT_POR_CFG_RW_MASK                  (0x0U)
#define MC33774_FEH_ANA_FLT_POR_CFG_RD_MASK                  (0x0U)
#define MC33774_FEH_ANA_FLT_POR_CFG_WR_MASK                  (0x0U)
#define MC33774_FEH_ANA_FLT_POR_CFG_MW_MASK                  (0x0U)
#define MC33774_FEH_ANA_FLT_POR_CFG_RA_MASK                  (0x0U)
#define MC33774_FEH_ANA_FLT_POR_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_FEH_ANA_FLT_POR_CFG_POR_VAL                  (0x0U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ANA_FLT_POR_CFG_RESERVED0_SHIFT          (0x0U)
#define MC33774_FEH_ANA_FLT_POR_CFG_RESERVED0_MASK           (0xFFFFU)
#define MC33774_FEH_ANA_FLT_POR_CFG_RESERVED0_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_POR_CFG_RESERVED0_SHIFT)) & MC33774_FEH_ANA_FLT_POR_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_COM_FLT_POR_CFG (read-write):communication fault POR enable register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_COM_FLT_POR_CFG_OFFSET                   (0x42BU)
#define MC33774_FEH_COM_FLT_POR_CFG_RW_MASK                  (0xCU)
#define MC33774_FEH_COM_FLT_POR_CFG_RD_MASK                  (0xCU)
#define MC33774_FEH_COM_FLT_POR_CFG_WR_MASK                  (0xCU)
#define MC33774_FEH_COM_FLT_POR_CFG_MW_MASK                  (0x0U)
#define MC33774_FEH_COM_FLT_POR_CFG_RA_MASK                  (0x0U)
#define MC33774_FEH_COM_FLT_POR_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_FEH_COM_FLT_POR_CFG_POR_VAL                  (0x8U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_COM_FLT_POR_CFG_RESERVED0_SHIFT          (0x0U)
#define MC33774_FEH_COM_FLT_POR_CFG_RESERVED0_MASK           (0x3U)
#define MC33774_FEH_COM_FLT_POR_CFG_RESERVED0_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_POR_CFG_RESERVED0_SHIFT)) & MC33774_FEH_COM_FLT_POR_CFG_RESERVED0_MASK))

/* Field ERRCNTOFEN: Communication error counter max value leads to POR */
#define MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_SHIFT         (0x2U)
#define MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_MASK          (0x4U)
#define MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_SHIFT)) & MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_MASK))

/* Enumerated value NO_POR: Communication error counter has reached max value. */
#define MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_NO_POR_ENUM_VAL \
  (0U)

/* Enumerated value POR: Communication error counter max value leads to POR */
#define MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_POR_ENUM_VAL \
  (1U)

/* Field COMTOEN: Create a POR if a communication timeout happens. */
#define MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_SHIFT            (0x3U)
#define MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_MASK             (0x8U)
#define MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_SHIFT)) & MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_MASK))

/* Enumerated value PREV_MOD: Device fallbacks to prev. Mode in case of communication timeout */
#define MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_PREV_MOD_ENUM_VAL \
  (0U)

/* Enumerated value POR: POR in case of communication timeout */
#define MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_POR_ENUM_VAL     (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_COM_FLT_POR_CFG_RESERVED1_SHIFT          (0x4U)
#define MC33774_FEH_COM_FLT_POR_CFG_RESERVED1_MASK           (0xFFF0U)
#define MC33774_FEH_COM_FLT_POR_CFG_RESERVED1_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_POR_CFG_RESERVED1_SHIFT)) & MC33774_FEH_COM_FLT_POR_CFG_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_EVT_CFG0 (read-write):supply fault event selection register 0
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_OFFSET               (0x430U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RW_MASK              (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RD_MASK              (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_WR_MASK              (0xFFFU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_MW_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RA_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_POR_MASK             (0xFFFFU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_POR_VAL              (0x0U)

/* Field VBATOVEN: Event on VBAT Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_SHIFT       (0x0U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_MASK        (0x1U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_MASK))

/* Enumerated value NO_EV: No event on VBAT Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VBAT Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDAOVEN: Event on VDDA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_SHIFT       (0x1U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_MASK        (0x2U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_MASK))

/* Enumerated value NO_EV: No event on VDDA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDAUVEN: Event on VDDA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_SHIFT       (0x2U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_MASK        (0x4U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_MASK))

/* Enumerated value NO_EV: No event on VDDA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VANAOVEN: Event on VANA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_SHIFT       (0x3U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_MASK        (0x8U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_MASK))

/* Enumerated value NO_EV: No event on VANA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VANA Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VANAUVEN: Event on VANA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_SHIFT       (0x4U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_MASK        (0x10U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_MASK))

/* Enumerated value NO_EV: No event on VANA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VANA Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field AFECPOVEN: Event on AFE Charge Pump over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_SHIFT      (0x5U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_MASK       (0x20U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_MASK))

/* Enumerated value NO_EV: No event on AFE Charge Pump over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on AFE Charge Pump over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field AFECPUVEN: Event on AFE Charge Pump under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_SHIFT      (0x6U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_MASK       (0x40U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_MASK))

/* Enumerated value NO_EV: No event on AFE Charge Pump under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on AFE Charge Pump under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VPREREFSUVEN: Event on VPREREFS Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_SHIFT   (0x7U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_MASK    (0x80U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_U16(x)  (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_MASK))

/* Enumerated value NO_EV: No event on VPREREFS Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VPREREFS Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VAUXOVEN: Event on VAUX over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_SHIFT       (0x8U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_MASK        (0x100U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_MASK))

/* Enumerated value NO_EV: No event on VAUX over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VAUX over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VAUXUVEN: Event on VAUX under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_SHIFT       (0x9U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_MASK        (0x200U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_MASK))

/* Enumerated value NO_EV: No event on VAUX under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VAUX under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDCOVEN: Event on VDDC over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_SHIFT       (0xAU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_MASK        (0x400U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_MASK))

/* Enumerated value NO_EV: No event on VDDC over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDC over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDCUVEN: Event on VDDC under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_SHIFT       (0xBU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_MASK        (0x800U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_MASK))

/* Enumerated value NO_EV: No event on VDDC under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDC under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RESERVED0_SHIFT      (0xCU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RESERVED0_MASK       (0xF000U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RESERVED0_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RESERVED0_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG0_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_SUPPLY_FLT_EVT_CFG1 (read-write):supply fault event selection register 1
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_OFFSET               (0x431U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RW_MASK              (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RD_MASK              (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_WR_MASK              (0x7FU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_MW_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RA_MASK              (0x0U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_POR_MASK             (0xFFFFU)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_POR_VAL              (0x0U)

/* Field VBATLVEN: Event on VBAT Supply low-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_SHIFT       (0x0U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_MASK        (0x1U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_MASK))

/* Enumerated value NO_EV: No event on VBAT Supply low-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VBAT Supply low-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VPREREFSOVEN: Event on VPREREFS Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_SHIFT   (0x1U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_MASK    (0x2U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_U16(x)  (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_MASK))

/* Enumerated value NO_EV: No event on VPREREFS Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VPREREFS Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDCHCEN: Event on VDDC high-current fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_SHIFT       (0x2U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_MASK        (0x4U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_MASK))

/* Enumerated value NO_EV: No event on VDDC high-current fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDC high-current fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDIOOVEN: Event on VDDIO Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_SHIFT      (0x3U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_MASK       (0x8U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_MASK))

/* Enumerated value NO_EV: No event on VDDIO Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDIO Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VDDIOUVEN: Event on VDDIO Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_SHIFT      (0x4U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_MASK       (0x10U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_MASK))

/* Enumerated value NO_EV: No event on VDDIO Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VDDIO Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VPREOVEN: Event on VPRE Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_SHIFT       (0x5U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_MASK        (0x20U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_MASK))

/* Enumerated value NO_EV: No event on VPRE Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VPRE Supply over-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_EVENT_ENUM_VAL \
  (1U)

/* Field VPREUVEN: Event on VPRE Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_SHIFT       (0x6U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_MASK        (0x40U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_U16(x)      (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_MASK))

/* Enumerated value NO_EV: No event on VPRE Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on VPRE Supply under-voltage fault. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RESERVED0_SHIFT      (0x7U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RESERVED0_MASK       (0xFF80U)
#define MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RESERVED0_U16(x)     (((uint16_t)(((uint16_t)(x) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RESERVED0_SHIFT)) & MC33774_FEH_SUPPLY_FLT_EVT_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_ANA_FLT_EVT_CFG (read-write):analog fault event enable register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_ANA_FLT_EVT_CFG_OFFSET                   (0x432U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_RW_MASK                  (0x3U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_RD_MASK                  (0x3U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_WR_MASK                  (0x3U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_MW_MASK                  (0x0U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_RA_MASK                  (0x0U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_FEH_ANA_FLT_EVT_CFG_POR_VAL                  (0x0U)

/* Field MONBISTEN: Event on Monitor BIST fault. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_SHIFT          (0x0U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_MASK           (0x1U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_SHIFT)) & MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_MASK))

/* Enumerated value NO_EV: No event on Monitor BIST fault. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on Monitor BIST fault. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_EVENT_ENUM_VAL \
  (1U)

/* Field BALFLTEN: Event on cell balance function fault. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_SHIFT           (0x1U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_MASK            (0x2U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_SHIFT)) & MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_MASK))

/* Enumerated value NO_EV: No event on cell balance function fault. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on cell balance function fault. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field FUSEFLTEN: Event on a corrected bit error in the fuse data has been detected. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_SHIFT          (0x2U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_MASK           (0x4U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_SHIFT)) & MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_MASK))

/* Enumerated value NO_EV: No event on a corrected bit error in the fuse data has been detected. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on a corrected bit error in the fuse data has been detected. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_ANA_FLT_EVT_CFG_RESERVED0_SHIFT          (0x3U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_RESERVED0_MASK           (0xFFF8U)
#define MC33774_FEH_ANA_FLT_EVT_CFG_RESERVED0_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_ANA_FLT_EVT_CFG_RESERVED0_SHIFT)) & MC33774_FEH_ANA_FLT_EVT_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_COM_FLT_EVT_CFG (read-write):communication fault event enable register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_COM_FLT_EVT_CFG_OFFSET                   (0x433U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RW_MASK                  (0x17U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RD_MASK                  (0x17U)
#define MC33774_FEH_COM_FLT_EVT_CFG_WR_MASK                  (0x17U)
#define MC33774_FEH_COM_FLT_EVT_CFG_MW_MASK                  (0x0U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RA_MASK                  (0x0U)
#define MC33774_FEH_COM_FLT_EVT_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_FEH_COM_FLT_EVT_CFG_POR_VAL                  (0x0U)

/* Field FRAMEERREN: Event on communication error detected. Wrong number of bits, bit-length error. */
#define MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_SHIFT         (0x0U)
#define MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_MASK          (0x1U)
#define MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_SHIFT)) & MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_MASK))

/* Enumerated value NO_EV: No event on communication error detected. */
#define MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on communication error detected. */
#define MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_EVENT_ENUM_VAL \
  (1U)

/* Field CRCERREN: Event on communication CRC error detected. */
#define MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_SHIFT           (0x1U)
#define MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_MASK            (0x2U)
#define MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_SHIFT)) & MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_MASK))

/* Enumerated value NO_EV: No event on communication CRC error detected. */
#define MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on communication CRC error detected. */
#define MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_EVENT_ENUM_VAL \
  (1U)

/* Field ERRCNTOFEN: Event on communication error counter has reached max value. */
#define MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_SHIFT         (0x2U)
#define MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_MASK          (0x4U)
#define MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_SHIFT)) & MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_MASK))

/* Enumerated value NO_EV: No event on communication error counter has reached max value. */
#define MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on communication error counter has reached max value. */
#define MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_COM_FLT_EVT_CFG_RESERVED0_SHIFT          (0x3U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RESERVED0_MASK           (0x8U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RESERVED0_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_EVT_CFG_RESERVED0_SHIFT)) & MC33774_FEH_COM_FLT_EVT_CFG_RESERVED0_MASK))

/* Field RSPLENERREN: Event on number of SPI clocks did not fit to the length of a requested response */
#define MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_SHIFT        (0x4U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_MASK         (0x10U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_SHIFT)) & MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_MASK))

/* Enumerated value NO_EV: No event on number of SPI clocks did not fit to the length of a requested response */
#define MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on number of SPI clocks did not fit to the length of a requested response */
#define MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_COM_FLT_EVT_CFG_RESERVED1_SHIFT          (0x5U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RESERVED1_MASK           (0xFFE0U)
#define MC33774_FEH_COM_FLT_EVT_CFG_RESERVED1_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_FEH_COM_FLT_EVT_CFG_RESERVED1_SHIFT)) & MC33774_FEH_COM_FLT_EVT_CFG_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * FEH_MEAS_FLT_EVT_CFG (read-write):measurement fault event enable register
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_OFFSET                  (0x434U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_RW_MASK                 (0x7U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_RD_MASK                 (0x7U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_WR_MASK                 (0x7U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_MW_MASK                 (0x0U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_RA_MASK                 (0x0U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_POR_MASK                (0xFFFFU)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_POR_VAL                 (0x0U)

/* Field PRIMCALCRCFLTEN: Event on primary calibration CRC fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_SHIFT   (0x0U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_MASK    (0x1U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_U16(x)  (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_SHIFT)) & MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_MASK))

/* Enumerated value NO_EV: No event on primary calibration CRC fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on primary calibration CRC fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field SECCALCRCFLTEN: Event on secondary calibration CRC fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_SHIFT    (0x1U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_MASK     (0x2U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_U16(x)   (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_SHIFT)) & MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_MASK))

/* Enumerated value NO_EV: No event on secondary calibration CRC fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on secondary calibration CRC fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field SYNCMEASFLTEN: Event on synchronization fault between the measurement units for a Sync cycle. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_SHIFT     (0x2U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_MASK      (0x4U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_U16(x)    (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_SHIFT)) & MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_MASK))

/* Enumerated value NO_EV: No event on synchronization fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_NO_EV_ENUM_VAL \
  (0U)

/* Enumerated value EVENT: Event on synchronization fault. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_EVENT_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_MEAS_FLT_EVT_CFG_RESERVED0_SHIFT         (0x3U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_RESERVED0_MASK          (0xFFF8U)
#define MC33774_FEH_MEAS_FLT_EVT_CFG_RESERVED0_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FEH_MEAS_FLT_EVT_CFG_RESERVED0_SHIFT)) & MC33774_FEH_MEAS_FLT_EVT_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FEH_POR_REASON (read-only):power-on reset reason. The value is stored in the ULP domain.
 * -------------------------------------------------------------------------- */
#define MC33774_FEH_POR_REASON_OFFSET                        (0x480U)
#define MC33774_FEH_POR_REASON_RW_MASK                       (0x0U)
#define MC33774_FEH_POR_REASON_RD_MASK                       (0x3FFU)
#define MC33774_FEH_POR_REASON_WR_MASK                       (0x0U)
#define MC33774_FEH_POR_REASON_MW_MASK                       (0x0U)
#define MC33774_FEH_POR_REASON_RA_MASK                       (0x0U)
#define MC33774_FEH_POR_REASON_POR_MASK                      (0xFFFFU)
#define MC33774_FEH_POR_REASON_POR_VAL                       (0x0U)

/* Field SOURCE: Reason for POR: Binary coded and protected by an EDC. */
#define MC33774_FEH_POR_REASON_SOURCE_SHIFT                  (0x0U)
#define MC33774_FEH_POR_REASON_SOURCE_MASK                   (0x3FFU)
#define MC33774_FEH_POR_REASON_SOURCE_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_FEH_POR_REASON_SOURCE_SHIFT)) & MC33774_FEH_POR_REASON_SOURCE_MASK))

/* Enumerated value VDDDLPPERMUV: POR caused by VDDDLPPERMUV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDDLPPERMUV_ENUM_VAL \
  (0U)

/* Enumerated value VDDDLPUV: POR caused by VDDDLPUV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDDLPUV_ENUM_VAL      (15U)

/* Enumerated value VDDDUV: POR caused by VDDDUV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDDUV_ENUM_VAL        (78U)

/* Enumerated value VBATLV: POR caused by VBATLV */
#define MC33774_FEH_POR_REASON_SOURCE_VBATLV_ENUM_VAL        (131U)

/* Enumerated value VDDIOUV: POR caused by VDDIOUV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDIOUV_ENUM_VAL       (140U)

/* Enumerated value SWRESET: POR caused by software Deep Sleep request */
#define MC33774_FEH_POR_REASON_SOURCE_SWRESET_ENUM_VAL       (191U)

/* Enumerated value VBATOV: POR caused by VBATOV */
#define MC33774_FEH_POR_REASON_SOURCE_VBATOV_ENUM_VAL        (194U)

/* Enumerated value VDDDOV: POR caused by VDDDOV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDDOV_ENUM_VAL        (205U)

/* Enumerated value VDDCOV: POR caused by VDDCOV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDCOV_ENUM_VAL        (261U)

/* Enumerated value VAUXUV: POR caused by VAUXUV */
#define MC33774_FEH_POR_REASON_SOURCE_VAUXUV_ENUM_VAL        (266U)

/* Enumerated value VBATUV: POR caused by VBATUV */
#define MC33774_FEH_POR_REASON_SOURCE_VBATUV_ENUM_VAL        (324U)

/* Enumerated value VDDIOOV: POR caused by VDDIOOV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDIOOV_ENUM_VAL       (331U)

/* Enumerated value VDDCUV: POR caused by VDDCUV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDCUV_ENUM_VAL        (390U)

/* Enumerated value VAUXOV: POR caused by VAUXOV */
#define MC33774_FEH_POR_REASON_SOURCE_VAUXOV_ENUM_VAL        (393U)

/* Enumerated value VDDCOC: POR caused by VDDCOC */
#define MC33774_FEH_POR_REASON_SOURCE_VDDCOC_ENUM_VAL        (455U)

/* Enumerated value VDDCHC: POR caused by VDDCHC */
#define MC33774_FEH_POR_REASON_SOURCE_VDDCHC_ENUM_VAL        (456U)

/* Enumerated value VDDAUV: POR caused by VDDAUV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDAUV_ENUM_VAL        (529U)

/* Enumerated value SLEEPOSC: POR caused by SLEEPOSC */
#define MC33774_FEH_POR_REASON_SOURCE_SLEEPOSC_ENUM_VAL      (542U)

/* Enumerated value VPREUV: POR caused by VPREUV */
#define MC33774_FEH_POR_REASON_SOURCE_VPREUV_ENUM_VAL        (546U)

/* Enumerated value VDDAOV: POR caused by VDDAOV */
#define MC33774_FEH_POR_REASON_SOURCE_VDDAOV_ENUM_VAL        (592U)

/* Enumerated value COMTO: POR caused by COMTO */
#define MC33774_FEH_POR_REASON_SOURCE_COMTO_ENUM_VAL         (607U)

/* Enumerated value VPREOV: POR caused by VPREOV */
#define MC33774_FEH_POR_REASON_SOURCE_VPREOV_ENUM_VAL        (658U)

/* Enumerated value SECCLK: POR caused by SECCLK */
#define MC33774_FEH_POR_REASON_SOURCE_SECCLK_ENUM_VAL        (669U)

/* Enumerated value LOGICERR: POR caused by LOGICERR */
#define MC33774_FEH_POR_REASON_SOURCE_LOGICERR_ENUM_VAL      (673U)

/* Enumerated value VPREREFSOV: POR caused by VPREREFSOV */
#define MC33774_FEH_POR_REASON_SOURCE_VPREREFSOV_ENUM_VAL    (723U)

/* Enumerated value PRMCLK: POR caused by PRMCLK */
#define MC33774_FEH_POR_REASON_SOURCE_PRMCLK_ENUM_VAL        (732U)

/* Enumerated value COMERRORS: POR caused by COMERRORS */
#define MC33774_FEH_POR_REASON_SOURCE_COMERRORS_ENUM_VAL     (736U)

/* Enumerated value VPREREFSUV: POR caused by VPREREFSUV */
#define MC33774_FEH_POR_REASON_SOURCE_VPREREFSUV_ENUM_VAL    (788U)

/* Enumerated value OTEMPSHUTDOWN: POR caused by OTEMPSHUTDOWN */
#define MC33774_FEH_POR_REASON_SOURCE_OTEMPSHUTDOWN_ENUM_VAL \
  (795U)

/* Enumerated value VANAOV: POR caused by VANAOV */
#define MC33774_FEH_POR_REASON_SOURCE_VANAOV_ENUM_VAL        (853U)

/* Enumerated value AFECPOV: POR caused by AFECPOV */
#define MC33774_FEH_POR_REASON_SOURCE_AFECPOV_ENUM_VAL       (919U)

/* Enumerated value AFECPUV: POR caused by AFECPUV */
#define MC33774_FEH_POR_REASON_SOURCE_AFECPUV_ENUM_VAL       (920U)

/* Enumerated value VANAUV: POR caused by VANAUV */
#define MC33774_FEH_POR_REASON_SOURCE_VANAUV_ENUM_VAL        (982U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_FEH_POR_REASON_RESERVED0_SHIFT               (0xAU)
#define MC33774_FEH_POR_REASON_RESERVED0_MASK                (0xFC00U)
#define MC33774_FEH_POR_REASON_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_FEH_POR_REASON_RESERVED0_SHIFT)) & MC33774_FEH_POR_REASON_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_CFG (read-write):general measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_CFG_OFFSET                              (0x1800U)
#define MC33774_PRMM_CFG_RW_MASK                             (0xFFFFU)
#define MC33774_PRMM_CFG_RD_MASK                             (0xFFFFU)
#define MC33774_PRMM_CFG_WR_MASK                             (0xFFFFU)
#define MC33774_PRMM_CFG_MW_MASK                             (0x0U)
#define MC33774_PRMM_CFG_RA_MASK                             (0x0U)
#define MC33774_PRMM_CFG_POR_MASK                            (0xFFFFU)
#define MC33774_PRMM_CFG_POR_VAL                             (0x0U)

/* Field MEASEN: Enable the data acquisition. Setting this bit to zero initiates a result clear and invalidate action (this includes resetting all ready bits). This bit is cleared when entering Sleep mode. Cyclic measurements are always executed, regardless of the value of this bit. Balancing is not stopped automatically (if in Active mode), as it would be permanently inhibited while measurement is active. If balancing shall be paused, please do so via the balancing control. */
#define MC33774_PRMM_CFG_MEASEN_SHIFT                        (0x0U)
#define MC33774_PRMM_CFG_MEASEN_MASK                         (0x1U)
#define MC33774_PRMM_CFG_MEASEN_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_CFG_MEASEN_SHIFT)) & MC33774_PRMM_CFG_MEASEN_MASK))

/* Enumerated value DISABLED: Data acquisition disabled */
#define MC33774_PRMM_CFG_MEASEN_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Data acquisition enabled */
#define MC33774_PRMM_CFG_MEASEN_ENABLED_ENUM_VAL             (1U)

/* Field BALPAUSECYCMODEN: Enable balancing auto pause. This delays the start of measurements after entering Cyclic mode until the auto pause counter has elapsed. */
#define MC33774_PRMM_CFG_BALPAUSECYCMODEN_SHIFT              (0x1U)
#define MC33774_PRMM_CFG_BALPAUSECYCMODEN_MASK               (0x2U)
#define MC33774_PRMM_CFG_BALPAUSECYCMODEN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_CFG_BALPAUSECYCMODEN_SHIFT)) & MC33774_PRMM_CFG_BALPAUSECYCMODEN_MASK))

/* Enumerated value DISABLED: Auto pause for balancing is disabled. */
#define MC33774_PRMM_CFG_BALPAUSECYCMODEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Auto pause for balancing is enabled. Measurements are started when the auto pause counter is elapsed. */
#define MC33774_PRMM_CFG_BALPAUSECYCMODEN_ENABLED_ENUM_VAL   (1U)

/* Field BALPAUSELEN: Pause of balancing before measurement cycle is executed. An on-going balancing pause operation is not influenced by a change of this value. 1 LSB = 10 us. */
#define MC33774_PRMM_CFG_BALPAUSELEN_SHIFT                   (0x2U)
#define MC33774_PRMM_CFG_BALPAUSELEN_MASK                    (0xFFFCU)
#define MC33774_PRMM_CFG_BALPAUSELEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_CFG_BALPAUSELEN_SHIFT)) & MC33774_PRMM_CFG_BALPAUSELEN_MASK))

/* Enumerated value NO_PAUSE: No Pause. */
#define MC33774_PRMM_CFG_BALPAUSELEN_NO_PAUSE_ENUM_VAL       (0U)

/* Enumerated value PAUSE_10u: Pause = 10 us */
#define MC33774_PRMM_CFG_BALPAUSELEN_PAUSE_10U_ENUM_VAL      (1U)

/* Enumerated value MAX: Maximum pause = 163830 us = 163 ms */
#define MC33774_PRMM_CFG_BALPAUSELEN_MAX_ENUM_VAL            (16383U)

/* --------------------------------------------------------------------------
 * PRMM_APP_CTRL (read-write):application measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_CTRL_OFFSET                         (0x1801U)
#define MC33774_PRMM_APP_CTRL_RW_MASK                        (0x7C00U)
#define MC33774_PRMM_APP_CTRL_RD_MASK                        (0x7C00U)
#define MC33774_PRMM_APP_CTRL_WR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_CTRL_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_CTRL_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_CTRL_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_CTRL_POR_VAL                        (0x7C00U)

/* Field CAPVC: Capture the application measurement values of the cell terminal measurements. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33774_PRMM_APP_CTRL_CAPVC_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_CTRL_CAPVC_MASK                     (0x1U)
#define MC33774_PRMM_APP_CTRL_CAPVC_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPVC_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPVC_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPVC_NO_CAP_ENUM_VAL          (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPVC_CAP_ENUM_VAL             (1U)

/* Field CAPAINA: Capture the application measurement value of the AINA voltage measurement. The values are now readable via the app_result register. This bit is only available in the primary measurement chain. */
#define MC33774_PRMM_APP_CTRL_CAPAINA_SHIFT                  (0x1U)
#define MC33774_PRMM_APP_CTRL_CAPAINA_MASK                   (0x2U)
#define MC33774_PRMM_APP_CTRL_CAPAINA_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAINA_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAINA_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAINA_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAINA_CAP_ENUM_VAL           (1U)

/* Field CAPAIN0: Capture the application measurement value of the AIN0 terminal measurement. The values are now readable via the app_result register. */
#define MC33774_PRMM_APP_CTRL_CAPAIN0_SHIFT                  (0x2U)
#define MC33774_PRMM_APP_CTRL_CAPAIN0_MASK                   (0x4U)
#define MC33774_PRMM_APP_CTRL_CAPAIN0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN0_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN0_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN0_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN0_CAP_ENUM_VAL           (1U)

/* Field CAPAIN1: Capture the application measurement value of the AIN1 terminal measurement. The values are now readable via the app_result register. */
#define MC33774_PRMM_APP_CTRL_CAPAIN1_SHIFT                  (0x3U)
#define MC33774_PRMM_APP_CTRL_CAPAIN1_MASK                   (0x8U)
#define MC33774_PRMM_APP_CTRL_CAPAIN1_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN1_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN1_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN1_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN1_CAP_ENUM_VAL           (1U)

/* Field CAPAIN2: Capture the application measurement value of the AIN2 terminal measurement. The values are now readable via the app_result register. */
#define MC33774_PRMM_APP_CTRL_CAPAIN2_SHIFT                  (0x4U)
#define MC33774_PRMM_APP_CTRL_CAPAIN2_MASK                   (0x10U)
#define MC33774_PRMM_APP_CTRL_CAPAIN2_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN2_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN2_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN2_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN2_CAP_ENUM_VAL           (1U)

/* Field CAPAIN3: Capture the application measurement value of the AIN3 terminal measurement. The values are now readable via the app_result register. */
#define MC33774_PRMM_APP_CTRL_CAPAIN3_SHIFT                  (0x5U)
#define MC33774_PRMM_APP_CTRL_CAPAIN3_MASK                   (0x20U)
#define MC33774_PRMM_APP_CTRL_CAPAIN3_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN3_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN3_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN3_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN3_CAP_ENUM_VAL           (1U)

/* Field CAPAIN4: AIN4 is not part of the primary measurement chain. Still, when used in combination with PAUSEBAL, a pause of the balancing is forced. The allows to keep the primary and secondary measurement chain synchronized. */
#define MC33774_PRMM_APP_CTRL_CAPAIN4_SHIFT                  (0x6U)
#define MC33774_PRMM_APP_CTRL_CAPAIN4_MASK                   (0x40U)
#define MC33774_PRMM_APP_CTRL_CAPAIN4_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN4_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN4_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN4_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN4_CAP_ENUM_VAL           (1U)

/* Field CAPAIN5: AIN5 is not part of the primary measurement chain. Still, when used in combination with PAUSEBAL, a pause of the balancing is forced. The allows to keep the primary and secondary measurement chain synchronized. */
#define MC33774_PRMM_APP_CTRL_CAPAIN5_SHIFT                  (0x7U)
#define MC33774_PRMM_APP_CTRL_CAPAIN5_MASK                   (0x80U)
#define MC33774_PRMM_APP_CTRL_CAPAIN5_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN5_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN5_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN5_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN5_CAP_ENUM_VAL           (1U)

/* Field CAPAIN6: AIN6 is not part of the primary measurement chain. Still, when used in combination with PAUSEBAL, a pause of the balancing is forced. The allows to keep the primary and secondary measurement chain synchronized. */
#define MC33774_PRMM_APP_CTRL_CAPAIN6_SHIFT                  (0x8U)
#define MC33774_PRMM_APP_CTRL_CAPAIN6_MASK                   (0x100U)
#define MC33774_PRMM_APP_CTRL_CAPAIN6_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN6_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN6_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN6_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN6_CAP_ENUM_VAL           (1U)

/* Field CAPAIN7: AIN7 is not part of the primary measurement chain. Still, when used in combination with PAUSEBAL, a pause of the balancing is forced. The allows to keep the primary and secondary measurement chain synchronized. */
#define MC33774_PRMM_APP_CTRL_CAPAIN7_SHIFT                  (0x9U)
#define MC33774_PRMM_APP_CTRL_CAPAIN7_MASK                   (0x200U)
#define MC33774_PRMM_APP_CTRL_CAPAIN7_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_CAPAIN7_SHIFT)) & MC33774_PRMM_APP_CTRL_CAPAIN7_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN7_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_PRMM_APP_CTRL_CAPAIN7_CAP_ENUM_VAL           (1U)

/* Field VCOLNUM: VC channel for which the open-load detection is enabled. 0 - 17 = channel for which the open-load detection is enabled. 18 - 30 = reserved (no open-load detection mechanism is enabled).
Writing this bit field is only possible if CAPVC is set as well. */
#define MC33774_PRMM_APP_CTRL_VCOLNUM_SHIFT                  (0xAU)
#define MC33774_PRMM_APP_CTRL_VCOLNUM_MASK                   (0x7C00U)
#define MC33774_PRMM_APP_CTRL_VCOLNUM_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_VCOLNUM_SHIFT)) & MC33774_PRMM_APP_CTRL_VCOLNUM_MASK))

/* Enumerated value DISABLED: Open-load detection is disabled */
#define MC33774_PRMM_APP_CTRL_VCOLNUM_DISABLED_ENUM_VAL      (31U)

/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the auto pause timer has elapsed. If no CAPxxx is set this bit is ignored. */
#define MC33774_PRMM_APP_CTRL_PAUSEBAL_SHIFT                 (0xFU)
#define MC33774_PRMM_APP_CTRL_PAUSEBAL_MASK                  (0x8000U)
#define MC33774_PRMM_APP_CTRL_PAUSEBAL_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_CTRL_PAUSEBAL_SHIFT)) & MC33774_PRMM_APP_CTRL_PAUSEBAL_MASK))

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33774_PRMM_APP_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL     (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33774_PRMM_APP_CTRL_PAUSEBAL_PAUSE_ENUM_VAL        (1U)

/* --------------------------------------------------------------------------
 * PRMM_PER_CTRL (read-write):periodic measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_CTRL_OFFSET                         (0x1802U)
#define MC33774_PRMM_PER_CTRL_RW_MASK                        (0x11FFU)
#define MC33774_PRMM_PER_CTRL_RD_MASK                        (0x11FFU)
#define MC33774_PRMM_PER_CTRL_WR_MASK                        (0x11FFU)
#define MC33774_PRMM_PER_CTRL_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_CTRL_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_CTRL_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_CTRL_POR_VAL                        (0x10U)

/* Field PERLEN: Number of measurements for one periodic measurement. The minimum is 16. Writing a value lower than 16 leads to a 16 in the register. */
#define MC33774_PRMM_PER_CTRL_PERLEN_SHIFT                   (0x0U)
#define MC33774_PRMM_PER_CTRL_PERLEN_MASK                    (0x1FFU)
#define MC33774_PRMM_PER_CTRL_PERLEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_CTRL_PERLEN_SHIFT)) & MC33774_PRMM_PER_CTRL_PERLEN_MASK))

/* Enumerated value PER_16: minimum value = 16 measurements per period */
#define MC33774_PRMM_PER_CTRL_PERLEN_PER_16_ENUM_VAL         (16U)

/* Enumerated value PER_17: 17 measurements per period */
#define MC33774_PRMM_PER_CTRL_PERLEN_PER_17_ENUM_VAL         (17U)

/* Enumerated value PER_MAX: maximum value = 511 measurements per period */
#define MC33774_PRMM_PER_CTRL_PERLEN_PER_MAX_ENUM_VAL        (511U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_PER_CTRL_RESERVED0_SHIFT                (0x9U)
#define MC33774_PRMM_PER_CTRL_RESERVED0_MASK                 (0xE00U)
#define MC33774_PRMM_PER_CTRL_RESERVED0_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_CTRL_RESERVED0_SHIFT)) & MC33774_PRMM_PER_CTRL_RESERVED0_MASK))

/* Field PERCTRL: Control the periodic result behavior. */
#define MC33774_PRMM_PER_CTRL_PERCTRL_SHIFT                  (0xCU)
#define MC33774_PRMM_PER_CTRL_PERCTRL_MASK                   (0x1000U)
#define MC33774_PRMM_PER_CTRL_PERCTRL_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_CTRL_PERCTRL_SHIFT)) & MC33774_PRMM_PER_CTRL_PERCTRL_MASK))

/* Enumerated value AUTO: Periodic results are automatically updated */
#define MC33774_PRMM_PER_CTRL_PERCTRL_AUTO_ENUM_VAL          (0U)

/* Enumerated value ONCE: Periodic results are updated once with the last results. (each write updates the results). */
#define MC33774_PRMM_PER_CTRL_PERCTRL_ONCE_ENUM_VAL          (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_PER_CTRL_RESERVED1_SHIFT                (0xDU)
#define MC33774_PRMM_PER_CTRL_RESERVED1_MASK                 (0xE000U)
#define MC33774_PRMM_PER_CTRL_RESERVED1_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_CTRL_RESERVED1_SHIFT)) & MC33774_PRMM_PER_CTRL_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_CTRL (write-only):synchronous measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_CTRL_OFFSET                        (0x1803U)
#define MC33774_PRMM_SYNC_CTRL_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_CTRL_RD_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_CTRL_WR_MASK                       (0x8003U)
#define MC33774_PRMM_SYNC_CTRL_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_CTRL_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_CTRL_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_CTRL_POR_VAL                       (0x0U)

/* Field SYNCCYC: Start a synchronous measurement cycle. In this cycle the CT and CB voltages are measured and stored as matching pairs.
If no VC channel is enabled or if set during a running synchronous measurement cycle the set is ignored. Read as zero. */
#define MC33774_PRMM_SYNC_CTRL_SYNCCYC_SHIFT                 (0x0U)
#define MC33774_PRMM_SYNC_CTRL_SYNCCYC_MASK                  (0x1U)
#define MC33774_PRMM_SYNC_CTRL_SYNCCYC_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_CTRL_SYNCCYC_SHIFT)) & MC33774_PRMM_SYNC_CTRL_SYNCCYC_MASK))

/* Enumerated value NO_START: No new start a synchronous measurement cycle. */
#define MC33774_PRMM_SYNC_CTRL_SYNCCYC_NO_START_ENUM_VAL     (0U)

/* Enumerated value STATUS: Read a zero */
#define MC33774_PRMM_SYNC_CTRL_SYNCCYC_STATUS_ENUM_VAL       (0U)

/* Enumerated value START: Start a synchronous measurement cycle. */
#define MC33774_PRMM_SYNC_CTRL_SYNCCYC_START_ENUM_VAL        (1U)

/* Field FASTCYC: Start of a dummy Fast measurement cycle. In this cycle nothing is actually measured and stored.
The bit is only implemented to keep the balancing auto pause synchronous between primary and secondary measurement. If set together with SYNCCYC or during an active synchronous measurement cycle, this bit is ignored. Read as zero. */
#define MC33774_PRMM_SYNC_CTRL_FASTCYC_SHIFT                 (0x1U)
#define MC33774_PRMM_SYNC_CTRL_FASTCYC_MASK                  (0x2U)
#define MC33774_PRMM_SYNC_CTRL_FASTCYC_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_CTRL_FASTCYC_SHIFT)) & MC33774_PRMM_SYNC_CTRL_FASTCYC_MASK))

/* Enumerated value NO_FAST: No new start of a dummy fast measurement cycle. */
#define MC33774_PRMM_SYNC_CTRL_FASTCYC_NO_FAST_ENUM_VAL      (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33774_PRMM_SYNC_CTRL_FASTCYC_STATUS_ENUM_VAL       (0U)

/* Enumerated value FAST: Start a new dummy fast measurement cycle. */
#define MC33774_PRMM_SYNC_CTRL_FASTCYC_FAST_ENUM_VAL         (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_SYNC_CTRL_RESERVED0_SHIFT               (0x2U)
#define MC33774_PRMM_SYNC_CTRL_RESERVED0_MASK                (0x7FFCU)
#define MC33774_PRMM_SYNC_CTRL_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_CTRL_RESERVED0_SHIFT)) & MC33774_PRMM_SYNC_CTRL_RESERVED0_MASK))

/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the auto pause timer has elapsed. If no capture cycle is started this bit is ignored. */
#define MC33774_PRMM_SYNC_CTRL_PAUSEBAL_SHIFT                (0xFU)
#define MC33774_PRMM_SYNC_CTRL_PAUSEBAL_MASK                 (0x8000U)
#define MC33774_PRMM_SYNC_CTRL_PAUSEBAL_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_CTRL_PAUSEBAL_SHIFT)) & MC33774_PRMM_SYNC_CTRL_PAUSEBAL_MASK))

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33774_PRMM_SYNC_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL    (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33774_PRMM_SYNC_CTRL_PAUSEBAL_PAUSE_ENUM_VAL       (1U)

/* --------------------------------------------------------------------------
 * PRMM_VC_CFG0 (read-write):cell voltage measurement enable
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_CFG0_OFFSET                          (0x1808U)
#define MC33774_PRMM_VC_CFG0_RW_MASK                         (0xFFFFU)
#define MC33774_PRMM_VC_CFG0_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_VC_CFG0_WR_MASK                         (0xFFFFU)
#define MC33774_PRMM_VC_CFG0_MW_MASK                         (0x0U)
#define MC33774_PRMM_VC_CFG0_RA_MASK                         (0x0U)
#define MC33774_PRMM_VC_CFG0_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_VC_CFG0_POR_VAL                         (0x0U)

/* Field VC0EN: Enable measurement of cell voltage 0. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC0EN_SHIFT                     (0x0U)
#define MC33774_PRMM_VC_CFG0_VC0EN_MASK                      (0x1U)
#define MC33774_PRMM_VC_CFG0_VC0EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC0EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC0EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC0EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC0EN_ENABLED_ENUM_VAL          (1U)

/* Field VC1EN: Enable measurement of cell voltage 1. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC1EN_SHIFT                     (0x1U)
#define MC33774_PRMM_VC_CFG0_VC1EN_MASK                      (0x2U)
#define MC33774_PRMM_VC_CFG0_VC1EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC1EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC1EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC1EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC1EN_ENABLED_ENUM_VAL          (1U)

/* Field VC2EN: Enable measurement of cell voltage 2. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC2EN_SHIFT                     (0x2U)
#define MC33774_PRMM_VC_CFG0_VC2EN_MASK                      (0x4U)
#define MC33774_PRMM_VC_CFG0_VC2EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC2EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC2EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC2EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC2EN_ENABLED_ENUM_VAL          (1U)

/* Field VC3EN: Enable measurement of cell voltage 3. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC3EN_SHIFT                     (0x3U)
#define MC33774_PRMM_VC_CFG0_VC3EN_MASK                      (0x8U)
#define MC33774_PRMM_VC_CFG0_VC3EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC3EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC3EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC3EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC3EN_ENABLED_ENUM_VAL          (1U)

/* Field VC4EN: Enable measurement of cell voltage 4. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC4EN_SHIFT                     (0x4U)
#define MC33774_PRMM_VC_CFG0_VC4EN_MASK                      (0x10U)
#define MC33774_PRMM_VC_CFG0_VC4EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC4EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC4EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC4EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC4EN_ENABLED_ENUM_VAL          (1U)

/* Field VC5EN: Enable measurement of cell voltage 5. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC5EN_SHIFT                     (0x5U)
#define MC33774_PRMM_VC_CFG0_VC5EN_MASK                      (0x20U)
#define MC33774_PRMM_VC_CFG0_VC5EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC5EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC5EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC5EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC5EN_ENABLED_ENUM_VAL          (1U)

/* Field VC6EN: Enable measurement of cell voltage 6. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC6EN_SHIFT                     (0x6U)
#define MC33774_PRMM_VC_CFG0_VC6EN_MASK                      (0x40U)
#define MC33774_PRMM_VC_CFG0_VC6EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC6EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC6EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC6EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC6EN_ENABLED_ENUM_VAL          (1U)

/* Field VC7EN: Enable measurement of cell voltage 7. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC7EN_SHIFT                     (0x7U)
#define MC33774_PRMM_VC_CFG0_VC7EN_MASK                      (0x80U)
#define MC33774_PRMM_VC_CFG0_VC7EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC7EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC7EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC7EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC7EN_ENABLED_ENUM_VAL          (1U)

/* Field VC8EN: Enable measurement of cell voltage 8. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC8EN_SHIFT                     (0x8U)
#define MC33774_PRMM_VC_CFG0_VC8EN_MASK                      (0x100U)
#define MC33774_PRMM_VC_CFG0_VC8EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC8EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC8EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC8EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC8EN_ENABLED_ENUM_VAL          (1U)

/* Field VC9EN: Enable measurement of cell voltage 9. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC9EN_SHIFT                     (0x9U)
#define MC33774_PRMM_VC_CFG0_VC9EN_MASK                      (0x200U)
#define MC33774_PRMM_VC_CFG0_VC9EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC9EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC9EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC9EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC9EN_ENABLED_ENUM_VAL          (1U)

/* Field VC10EN: Enable measurement of cell voltage 10. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC10EN_SHIFT                    (0xAU)
#define MC33774_PRMM_VC_CFG0_VC10EN_MASK                     (0x400U)
#define MC33774_PRMM_VC_CFG0_VC10EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC10EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC10EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC10EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC10EN_ENABLED_ENUM_VAL         (1U)

/* Field VC11EN: Enable measurement of cell voltage 11. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC11EN_SHIFT                    (0xBU)
#define MC33774_PRMM_VC_CFG0_VC11EN_MASK                     (0x800U)
#define MC33774_PRMM_VC_CFG0_VC11EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC11EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC11EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC11EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC11EN_ENABLED_ENUM_VAL         (1U)

/* Field VC12EN: Enable measurement of cell voltage 12. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC12EN_SHIFT                    (0xCU)
#define MC33774_PRMM_VC_CFG0_VC12EN_MASK                     (0x1000U)
#define MC33774_PRMM_VC_CFG0_VC12EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC12EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC12EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC12EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC12EN_ENABLED_ENUM_VAL         (1U)

/* Field VC13EN: Enable measurement of cell voltage 13. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC13EN_SHIFT                    (0xDU)
#define MC33774_PRMM_VC_CFG0_VC13EN_MASK                     (0x2000U)
#define MC33774_PRMM_VC_CFG0_VC13EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC13EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC13EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC13EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC13EN_ENABLED_ENUM_VAL         (1U)

/* Field VC14EN: Enable measurement of cell voltage 14. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC14EN_SHIFT                    (0xEU)
#define MC33774_PRMM_VC_CFG0_VC14EN_MASK                     (0x4000U)
#define MC33774_PRMM_VC_CFG0_VC14EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC14EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC14EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC14EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC14EN_ENABLED_ENUM_VAL         (1U)

/* Field VC15EN: Enable measurement of cell voltage 15. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG0_VC15EN_SHIFT                    (0xFU)
#define MC33774_PRMM_VC_CFG0_VC15EN_MASK                     (0x8000U)
#define MC33774_PRMM_VC_CFG0_VC15EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG0_VC15EN_SHIFT)) & MC33774_PRMM_VC_CFG0_VC15EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG0_VC15EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG0_VC15EN_ENABLED_ENUM_VAL         (1U)

/* --------------------------------------------------------------------------
 * PRMM_VC_CFG1 (read-write):cell voltage measurement enable
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_CFG1_OFFSET                          (0x1809U)
#define MC33774_PRMM_VC_CFG1_RW_MASK                         (0x3U)
#define MC33774_PRMM_VC_CFG1_RD_MASK                         (0x3U)
#define MC33774_PRMM_VC_CFG1_WR_MASK                         (0x3U)
#define MC33774_PRMM_VC_CFG1_MW_MASK                         (0x0U)
#define MC33774_PRMM_VC_CFG1_RA_MASK                         (0x0U)
#define MC33774_PRMM_VC_CFG1_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_VC_CFG1_POR_VAL                         (0x0U)

/* Field VC16EN: Enable measurement of cell voltage 16. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG1_VC16EN_SHIFT                    (0x0U)
#define MC33774_PRMM_VC_CFG1_VC16EN_MASK                     (0x1U)
#define MC33774_PRMM_VC_CFG1_VC16EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG1_VC16EN_SHIFT)) & MC33774_PRMM_VC_CFG1_VC16EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG1_VC16EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG1_VC16EN_ENABLED_ENUM_VAL         (1U)

/* Field VC17EN: Enable measurement of cell voltage 17. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_VC_CFG1_VC17EN_SHIFT                    (0x1U)
#define MC33774_PRMM_VC_CFG1_VC17EN_MASK                     (0x2U)
#define MC33774_PRMM_VC_CFG1_VC17EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG1_VC17EN_SHIFT)) & MC33774_PRMM_VC_CFG1_VC17EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_VC_CFG1_VC17EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_VC_CFG1_VC17EN_ENABLED_ENUM_VAL         (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_VC_CFG1_RESERVED0_SHIFT                 (0x2U)
#define MC33774_PRMM_VC_CFG1_RESERVED0_MASK                  (0xFFFCU)
#define MC33774_PRMM_VC_CFG1_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_CFG1_RESERVED0_SHIFT)) & MC33774_PRMM_VC_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN_CFG (read-write):AINx measurement enables
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN_CFG_OFFSET                          (0x180AU)
#define MC33774_PRMM_AIN_CFG_RW_MASK                         (0xFF3FU)
#define MC33774_PRMM_AIN_CFG_RD_MASK                         (0xFF3FU)
#define MC33774_PRMM_AIN_CFG_WR_MASK                         (0xFF3FU)
#define MC33774_PRMM_AIN_CFG_MW_MASK                         (0x0U)
#define MC33774_PRMM_AIN_CFG_RA_MASK                         (0x0U)
#define MC33774_PRMM_AIN_CFG_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_AIN_CFG_POR_VAL                         (0x20U)

/* Field AIN0EN: Enable measurement of AIN0. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_AIN0EN_SHIFT                    (0x0U)
#define MC33774_PRMM_AIN_CFG_AIN0EN_MASK                     (0x1U)
#define MC33774_PRMM_AIN_CFG_AIN0EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_AIN0EN_SHIFT)) & MC33774_PRMM_AIN_CFG_AIN0EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_AIN_CFG_AIN0EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_PRMM_AIN_CFG_AIN0EN_ENABLED_ENUM_VAL         (1U)

/* Field AIN1EN: Enable measurement of AIN1. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_AIN1EN_SHIFT                    (0x1U)
#define MC33774_PRMM_AIN_CFG_AIN1EN_MASK                     (0x2U)
#define MC33774_PRMM_AIN_CFG_AIN1EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_AIN1EN_SHIFT)) & MC33774_PRMM_AIN_CFG_AIN1EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_AIN_CFG_AIN1EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_PRMM_AIN_CFG_AIN1EN_ENABLED_ENUM_VAL         (1U)

/* Field AIN2EN: Enable measurement of AIN2. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_AIN2EN_SHIFT                    (0x2U)
#define MC33774_PRMM_AIN_CFG_AIN2EN_MASK                     (0x4U)
#define MC33774_PRMM_AIN_CFG_AIN2EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_AIN2EN_SHIFT)) & MC33774_PRMM_AIN_CFG_AIN2EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_AIN_CFG_AIN2EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_PRMM_AIN_CFG_AIN2EN_ENABLED_ENUM_VAL         (1U)

/* Field AIN3EN: Enable measurement of AIN3. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_AIN3EN_SHIFT                    (0x3U)
#define MC33774_PRMM_AIN_CFG_AIN3EN_MASK                     (0x8U)
#define MC33774_PRMM_AIN_CFG_AIN3EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_AIN3EN_SHIFT)) & MC33774_PRMM_AIN_CFG_AIN3EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_AIN_CFG_AIN3EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_PRMM_AIN_CFG_AIN3EN_ENABLED_ENUM_VAL         (1U)

/* Field AINAEN: Enable measurement of AINA. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_AINAEN_SHIFT                    (0x4U)
#define MC33774_PRMM_AIN_CFG_AINAEN_MASK                     (0x10U)
#define MC33774_PRMM_AIN_CFG_AINAEN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_AINAEN_SHIFT)) & MC33774_PRMM_AIN_CFG_AINAEN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_PRMM_AIN_CFG_AINAEN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_PRMM_AIN_CFG_AINAEN_ENABLED_ENUM_VAL         (1U)

/* Field FLTAPPINV: Invalidate AINx application results in case of fault. */
#define MC33774_PRMM_AIN_CFG_FLTAPPINV_SHIFT                 (0x5U)
#define MC33774_PRMM_AIN_CFG_FLTAPPINV_MASK                  (0x20U)
#define MC33774_PRMM_AIN_CFG_FLTAPPINV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_FLTAPPINV_SHIFT)) & MC33774_PRMM_AIN_CFG_FLTAPPINV_MASK))

/* Enumerated value VALID: AINx application results are not invalidated in case of a fault */
#define MC33774_PRMM_AIN_CFG_FLTAPPINV_VALID_ENUM_VAL        (0U)

/* Enumerated value INVALID: AINx application results are invalidated when a fault is detected. */
#define MC33774_PRMM_AIN_CFG_FLTAPPINV_INVALID_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_AIN_CFG_RESERVED0_SHIFT                 (0x6U)
#define MC33774_PRMM_AIN_CFG_RESERVED0_MASK                  (0xC0U)
#define MC33774_PRMM_AIN_CFG_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_RESERVED0_SHIFT)) & MC33774_PRMM_AIN_CFG_RESERVED0_MASK))

/* Field RATIOMETRICAIN0: Reference selection for AIN0. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_SHIFT           (0x8U)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_MASK            (0x300U)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_SHIFT)) & MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_MASK))

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_VDDC_ENUM_VAL   (3U)

/* Field RATIOMETRICAIN1: Reference selection for AIN1. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_SHIFT           (0xAU)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_MASK            (0xC00U)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_SHIFT)) & MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_MASK))

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_VDDC_ENUM_VAL   (3U)

/* Field RATIOMETRICAIN2: Reference selection for AIN2. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_SHIFT           (0xCU)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_MASK            (0x3000U)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_SHIFT)) & MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_MASK))

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_VDDC_ENUM_VAL   (3U)

/* Field RATIOMETRICAIN3: Reference selection for AIN3. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_SHIFT           (0xEU)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_MASK            (0xC000U)
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_SHIFT)) & MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_MASK))

/* Enumerated value PRMVREF: Absolute (PRMVREF) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_PRMVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_VDDC_ENUM_VAL   (3U)

/* --------------------------------------------------------------------------
 * PRMM_AIN_OL_CFG (read-write):AINx open-load detection enable
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN_OL_CFG_OFFSET                       (0x180BU)
#define MC33774_PRMM_AIN_OL_CFG_RW_MASK                      (0x1FU)
#define MC33774_PRMM_AIN_OL_CFG_RD_MASK                      (0x1FU)
#define MC33774_PRMM_AIN_OL_CFG_WR_MASK                      (0x1FU)
#define MC33774_PRMM_AIN_OL_CFG_MW_MASK                      (0x0U)
#define MC33774_PRMM_AIN_OL_CFG_RA_MASK                      (0x0U)
#define MC33774_PRMM_AIN_OL_CFG_POR_MASK                     (0xFFFFU)
#define MC33774_PRMM_AIN_OL_CFG_POR_VAL                      (0x0U)

/* Field AIN0EN: Open-load detection circuit for AIN0 */
#define MC33774_PRMM_AIN_OL_CFG_AIN0EN_SHIFT                 (0x0U)
#define MC33774_PRMM_AIN_OL_CFG_AIN0EN_MASK                  (0x1U)
#define MC33774_PRMM_AIN_OL_CFG_AIN0EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OL_CFG_AIN0EN_SHIFT)) & MC33774_PRMM_AIN_OL_CFG_AIN0EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN0EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN0EN_ENABLED_ENUM_VAL      (1U)

/* Field AIN1EN: Open-load detection circuit for AIN1 */
#define MC33774_PRMM_AIN_OL_CFG_AIN1EN_SHIFT                 (0x1U)
#define MC33774_PRMM_AIN_OL_CFG_AIN1EN_MASK                  (0x2U)
#define MC33774_PRMM_AIN_OL_CFG_AIN1EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OL_CFG_AIN1EN_SHIFT)) & MC33774_PRMM_AIN_OL_CFG_AIN1EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN1EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN1EN_ENABLED_ENUM_VAL      (1U)

/* Field AIN2EN: Open-load detection circuit for AIN2 */
#define MC33774_PRMM_AIN_OL_CFG_AIN2EN_SHIFT                 (0x2U)
#define MC33774_PRMM_AIN_OL_CFG_AIN2EN_MASK                  (0x4U)
#define MC33774_PRMM_AIN_OL_CFG_AIN2EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OL_CFG_AIN2EN_SHIFT)) & MC33774_PRMM_AIN_OL_CFG_AIN2EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN2EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN2EN_ENABLED_ENUM_VAL      (1U)

/* Field AIN3EN: Open-load detection circuit for AIN3 */
#define MC33774_PRMM_AIN_OL_CFG_AIN3EN_SHIFT                 (0x3U)
#define MC33774_PRMM_AIN_OL_CFG_AIN3EN_MASK                  (0x8U)
#define MC33774_PRMM_AIN_OL_CFG_AIN3EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OL_CFG_AIN3EN_SHIFT)) & MC33774_PRMM_AIN_OL_CFG_AIN3EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN3EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AIN3EN_ENABLED_ENUM_VAL      (1U)

/* Field AINAEN: Open-load detection circuit for AINA */
#define MC33774_PRMM_AIN_OL_CFG_AINAEN_SHIFT                 (0x4U)
#define MC33774_PRMM_AIN_OL_CFG_AINAEN_MASK                  (0x10U)
#define MC33774_PRMM_AIN_OL_CFG_AINAEN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OL_CFG_AINAEN_SHIFT)) & MC33774_PRMM_AIN_OL_CFG_AINAEN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AINAEN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_PRMM_AIN_OL_CFG_AINAEN_ENABLED_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_AIN_OL_CFG_RESERVED0_SHIFT              (0x5U)
#define MC33774_PRMM_AIN_OL_CFG_RESERVED0_MASK               (0xFFE0U)
#define MC33774_PRMM_AIN_OL_CFG_RESERVED0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OL_CFG_RESERVED0_SHIFT)) & MC33774_PRMM_AIN_OL_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VBUF_CFG (read-write):voltage buffer enable
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VBUF_CFG_OFFSET                         (0x180CU)
#define MC33774_PRMM_VBUF_CFG_RW_MASK                        (0x3U)
#define MC33774_PRMM_VBUF_CFG_RD_MASK                        (0x3U)
#define MC33774_PRMM_VBUF_CFG_WR_MASK                        (0x3U)
#define MC33774_PRMM_VBUF_CFG_MW_MASK                        (0x0U)
#define MC33774_PRMM_VBUF_CFG_RA_MASK                        (0x0U)
#define MC33774_PRMM_VBUF_CFG_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_VBUF_CFG_POR_VAL                        (0x3U)

/* Field VAUXEN: Voltage buffer for primary VAUX measurement */
#define MC33774_PRMM_VBUF_CFG_VAUXEN_SHIFT                   (0x0U)
#define MC33774_PRMM_VBUF_CFG_VAUXEN_MASK                    (0x1U)
#define MC33774_PRMM_VBUF_CFG_VAUXEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VBUF_CFG_VAUXEN_SHIFT)) & MC33774_PRMM_VBUF_CFG_VAUXEN_MASK))

/* Enumerated value DISABLED: Voltage buffer for primary VAUX measurement is disabled. */
#define MC33774_PRMM_VBUF_CFG_VAUXEN_DISABLED_ENUM_VAL       (0U)

/* Enumerated value ENABLED: Voltage buffer for primary VAUX measurement is enabled. */
#define MC33774_PRMM_VBUF_CFG_VAUXEN_ENABLED_ENUM_VAL        (1U)

/* Field VDDCEN: Voltage buffer for primary VDDC measurement */
#define MC33774_PRMM_VBUF_CFG_VDDCEN_SHIFT                   (0x1U)
#define MC33774_PRMM_VBUF_CFG_VDDCEN_MASK                    (0x2U)
#define MC33774_PRMM_VBUF_CFG_VDDCEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VBUF_CFG_VDDCEN_SHIFT)) & MC33774_PRMM_VBUF_CFG_VDDCEN_MASK))

/* Enumerated value DISABLED: Voltage buffer for primary VDDC measurement is disabled. */
#define MC33774_PRMM_VBUF_CFG_VDDCEN_DISABLED_ENUM_VAL       (0U)

/* Enumerated value ENABLED: Voltage buffer for primary VDDC measurement is enabled. */
#define MC33774_PRMM_VBUF_CFG_VDDCEN_ENABLED_ENUM_VAL        (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_VBUF_CFG_RESERVED0_SHIFT                (0x2U)
#define MC33774_PRMM_VBUF_CFG_RESERVED0_MASK                 (0xFFFCU)
#define MC33774_PRMM_VBUF_CFG_RESERVED0_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VBUF_CFG_RESERVED0_SHIFT)) & MC33774_PRMM_VBUF_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VC_OV_UV_CFG0 (read-write):cell voltage over-voltage and under-voltage check enable
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_OV_UV_CFG0_OFFSET                    (0x1810U)
#define MC33774_PRMM_VC_OV_UV_CFG0_RW_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_OV_UV_CFG0_RD_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_OV_UV_CFG0_WR_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_OV_UV_CFG0_MW_MASK                   (0x0U)
#define MC33774_PRMM_VC_OV_UV_CFG0_RA_MASK                   (0x0U)
#define MC33774_PRMM_VC_OV_UV_CFG0_POR_MASK                  (0xFFFFU)
#define MC33774_PRMM_VC_OV_UV_CFG0_POR_VAL                   (0x0U)

/* Field VC0EN: Include VC0 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_SHIFT               (0x0U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_MASK                (0x1U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_MASK))

/* Enumerated value NO_CHECK: VC0 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC0 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_UV_OV_ENUM_VAL      (1U)

/* Field VC1EN: Include VC1 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_SHIFT               (0x1U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_MASK                (0x2U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_MASK))

/* Enumerated value NO_CHECK: VC1 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC1 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_UV_OV_ENUM_VAL      (1U)

/* Field VC2EN: Include VC2 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_SHIFT               (0x2U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_MASK                (0x4U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_MASK))

/* Enumerated value NO_CHECK: VC2 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC2 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_UV_OV_ENUM_VAL      (1U)

/* Field VC3EN: Include VC3 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_SHIFT               (0x3U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_MASK                (0x8U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_MASK))

/* Enumerated value NO_CHECK: VC3 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC3 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_UV_OV_ENUM_VAL      (1U)

/* Field VC4EN: Include VC4 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_SHIFT               (0x4U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_MASK                (0x10U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_MASK))

/* Enumerated value NO_CHECK: VC4 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC4 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_UV_OV_ENUM_VAL      (1U)

/* Field VC5EN: Include VC5 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_SHIFT               (0x5U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_MASK                (0x20U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_MASK))

/* Enumerated value NO_CHECK: VC5 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC5 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_UV_OV_ENUM_VAL      (1U)

/* Field VC6EN: Include VC6 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_SHIFT               (0x6U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_MASK                (0x40U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_MASK))

/* Enumerated value NO_CHECK: VC6 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC6 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_UV_OV_ENUM_VAL      (1U)

/* Field VC7EN: Include VC7 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_SHIFT               (0x7U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_MASK                (0x80U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_MASK))

/* Enumerated value NO_CHECK: VC7 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC7 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_UV_OV_ENUM_VAL      (1U)

/* Field VC8EN: Include VC8 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_SHIFT               (0x8U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_MASK                (0x100U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_MASK))

/* Enumerated value NO_CHECK: VC8 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC8 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_UV_OV_ENUM_VAL      (1U)

/* Field VC9EN: Include VC9 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_SHIFT               (0x9U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_MASK                (0x200U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_MASK))

/* Enumerated value NO_CHECK: VC9 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_NO_CHECK_ENUM_VAL   (0U)

/* Enumerated value UV_OV: VC9 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_UV_OV_ENUM_VAL      (1U)

/* Field VC10EN: Include VC10 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_SHIFT              (0xAU)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_MASK               (0x400U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_MASK))

/* Enumerated value NO_CHECK: VC10 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC10 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_UV_OV_ENUM_VAL     (1U)

/* Field VC11EN: Include VC11 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_SHIFT              (0xBU)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_MASK               (0x800U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_MASK))

/* Enumerated value NO_CHECK: VC11 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC11 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_UV_OV_ENUM_VAL     (1U)

/* Field VC12EN: Include VC12 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_SHIFT              (0xCU)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_MASK               (0x1000U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_MASK))

/* Enumerated value NO_CHECK: VC12 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC12 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_UV_OV_ENUM_VAL     (1U)

/* Field VC13EN: Include VC13 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_SHIFT              (0xDU)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_MASK               (0x2000U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_MASK))

/* Enumerated value NO_CHECK: VC13 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC13 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_UV_OV_ENUM_VAL     (1U)

/* Field VC14EN: Include VC14 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_SHIFT              (0xEU)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_MASK               (0x4000U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_MASK))

/* Enumerated value NO_CHECK: VC14 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC14 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_UV_OV_ENUM_VAL     (1U)

/* Field VC15EN: Include VC15 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_SHIFT              (0xFU)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_MASK               (0x8000U)
#define MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_MASK))

/* Enumerated value NO_CHECK: VC15 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC15 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_UV_OV_ENUM_VAL     (1U)

/* --------------------------------------------------------------------------
 * PRMM_VC_OV_UV_CFG1 (read-write):cell voltage over-voltage and under-voltage check enable
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_OV_UV_CFG1_OFFSET                    (0x1811U)
#define MC33774_PRMM_VC_OV_UV_CFG1_RW_MASK                   (0x3U)
#define MC33774_PRMM_VC_OV_UV_CFG1_RD_MASK                   (0x3U)
#define MC33774_PRMM_VC_OV_UV_CFG1_WR_MASK                   (0x3U)
#define MC33774_PRMM_VC_OV_UV_CFG1_MW_MASK                   (0x0U)
#define MC33774_PRMM_VC_OV_UV_CFG1_RA_MASK                   (0x0U)
#define MC33774_PRMM_VC_OV_UV_CFG1_POR_MASK                  (0xFFFFU)
#define MC33774_PRMM_VC_OV_UV_CFG1_POR_VAL                   (0x0U)

/* Field VC16EN: Include VC16 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_SHIFT              (0x0U)
#define MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_MASK               (0x1U)
#define MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_MASK))

/* Enumerated value NO_CHECK: VC16 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC16 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_UV_OV_ENUM_VAL     (1U)

/* Field VC17EN: Include VC17 in VC over-voltage and under-voltage checks */
#define MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_SHIFT              (0x1U)
#define MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_MASK               (0x2U)
#define MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_MASK))

/* Enumerated value NO_CHECK: VC17 is not included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_NO_CHECK_ENUM_VAL \
  (0U)

/* Enumerated value UV_OV: VC17 is included in VC over-voltage and under-voltage checks. */
#define MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_UV_OV_ENUM_VAL     (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_VC_OV_UV_CFG1_RESERVED0_SHIFT           (0x2U)
#define MC33774_PRMM_VC_OV_UV_CFG1_RESERVED0_MASK            (0xFFFCU)
#define MC33774_PRMM_VC_OV_UV_CFG1_RESERVED0_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_UV_CFG1_RESERVED0_SHIFT)) & MC33774_PRMM_VC_OV_UV_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VC_OV_TH_CFG (read-write):upper comparator limit for VC0 to VC17
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_OV_TH_CFG_OFFSET                     (0x1812U)
#define MC33774_PRMM_VC_OV_TH_CFG_RW_MASK                    (0xFFFFU)
#define MC33774_PRMM_VC_OV_TH_CFG_RD_MASK                    (0xFFFFU)
#define MC33774_PRMM_VC_OV_TH_CFG_WR_MASK                    (0xFFFFU)
#define MC33774_PRMM_VC_OV_TH_CFG_MW_MASK                    (0x0U)
#define MC33774_PRMM_VC_OV_TH_CFG_RA_MASK                    (0x0U)
#define MC33774_PRMM_VC_OV_TH_CFG_POR_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_OV_TH_CFG_POR_VAL                    (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV status is activated. */
#define MC33774_PRMM_VC_OV_TH_CFG_LIMIT_SHIFT                (0x0U)
#define MC33774_PRMM_VC_OV_TH_CFG_LIMIT_MASK                 (0xFFFFU)
#define MC33774_PRMM_VC_OV_TH_CFG_LIMIT_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_VC_OV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VC_UV0_TH_CFG (read-write):lower comparator limit 0 for VC0 to VC17
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_UV0_TH_CFG_OFFSET                    (0x1813U)
#define MC33774_PRMM_VC_UV0_TH_CFG_RW_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_UV0_TH_CFG_RD_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_UV0_TH_CFG_WR_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_UV0_TH_CFG_MW_MASK                   (0x0U)
#define MC33774_PRMM_VC_UV0_TH_CFG_RA_MASK                   (0x0U)
#define MC33774_PRMM_VC_UV0_TH_CFG_POR_MASK                  (0xFFFFU)
#define MC33774_PRMM_VC_UV0_TH_CFG_POR_VAL                   (0x0U)

/* Field LIMIT: Limit value. If this limit is reached, the channel individual UV status is activated. Note: This limit is used for the channel individual balancing disable. */
#define MC33774_PRMM_VC_UV0_TH_CFG_LIMIT_SHIFT               (0x0U)
#define MC33774_PRMM_VC_UV0_TH_CFG_LIMIT_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_UV0_TH_CFG_LIMIT_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_VC_UV0_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VC_UV1_TH_CFG (read-write):lower comparator limit 1 for VC0 to VC17
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_UV1_TH_CFG_OFFSET                    (0x1814U)
#define MC33774_PRMM_VC_UV1_TH_CFG_RW_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_UV1_TH_CFG_RD_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_UV1_TH_CFG_WR_MASK                   (0xFFFFU)
#define MC33774_PRMM_VC_UV1_TH_CFG_MW_MASK                   (0x0U)
#define MC33774_PRMM_VC_UV1_TH_CFG_RA_MASK                   (0x0U)
#define MC33774_PRMM_VC_UV1_TH_CFG_POR_MASK                  (0xFFFFU)
#define MC33774_PRMM_VC_UV1_TH_CFG_POR_VAL                   (0x0U)

/* Field LIMIT: Limit value. If this limit is reached, the global UV status is activated. Note: This limit is used for the global balancing disable. */
#define MC33774_PRMM_VC_UV1_TH_CFG_LIMIT_SHIFT               (0x0U)
#define MC33774_PRMM_VC_UV1_TH_CFG_LIMIT_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_UV1_TH_CFG_LIMIT_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_VC_UV1_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN0_OV_TH_CFG (read-write):upper comparator limit for AIN0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN0_OV_TH_CFG_OFFSET                   (0x1815U)
#define MC33774_PRMM_AIN0_OV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN0_OV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN0_OV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN0_OV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN0_OV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN0_OV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN0_OV_TH_CFG_POR_VAL                  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV status is activated. */
#define MC33774_PRMM_AIN0_OV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN0_OV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN0_OV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN0_OV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN0_OV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN1_OV_TH_CFG (read-write):upper comparator limit for AIN1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN1_OV_TH_CFG_OFFSET                   (0x1816U)
#define MC33774_PRMM_AIN1_OV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN1_OV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN1_OV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN1_OV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN1_OV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN1_OV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN1_OV_TH_CFG_POR_VAL                  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV status is activated. */
#define MC33774_PRMM_AIN1_OV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN1_OV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN1_OV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN1_OV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN1_OV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN2_OV_TH_CFG (read-write):upper comparator limit for AIN2
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN2_OV_TH_CFG_OFFSET                   (0x1817U)
#define MC33774_PRMM_AIN2_OV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN2_OV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN2_OV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN2_OV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN2_OV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN2_OV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN2_OV_TH_CFG_POR_VAL                  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV status is activated. */
#define MC33774_PRMM_AIN2_OV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN2_OV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN2_OV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN2_OV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN2_OV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN3_OV_TH_CFG (read-write):upper comparator limit for AIN3
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN3_OV_TH_CFG_OFFSET                   (0x1818U)
#define MC33774_PRMM_AIN3_OV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN3_OV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN3_OV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN3_OV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN3_OV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN3_OV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN3_OV_TH_CFG_POR_VAL                  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV status is activated. */
#define MC33774_PRMM_AIN3_OV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN3_OV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN3_OV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN3_OV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN3_OV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AINA_OV_TH_CFG (read-write):upper comparator limit for AINA
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AINA_OV_TH_CFG_OFFSET                   (0x1819U)
#define MC33774_PRMM_AINA_OV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AINA_OV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AINA_OV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AINA_OV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AINA_OV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AINA_OV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AINA_OV_TH_CFG_POR_VAL                  (0x7FFFU)

/* Field LIMIT: Limit value. If this limit is reached, the OV status is activated. */
#define MC33774_PRMM_AINA_OV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AINA_OV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AINA_OV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AINA_OV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AINA_OV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN0_UV_TH_CFG (read-write):lower comparator limit for AIN0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN0_UV_TH_CFG_OFFSET                   (0x181AU)
#define MC33774_PRMM_AIN0_UV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN0_UV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN0_UV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN0_UV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN0_UV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN0_UV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN0_UV_TH_CFG_POR_VAL                  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV status is activated. */
#define MC33774_PRMM_AIN0_UV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN0_UV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN0_UV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN0_UV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN0_UV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN1_UV_TH_CFG (read-write):lower comparator limit for AIN1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN1_UV_TH_CFG_OFFSET                   (0x181BU)
#define MC33774_PRMM_AIN1_UV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN1_UV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN1_UV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN1_UV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN1_UV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN1_UV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN1_UV_TH_CFG_POR_VAL                  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV status is activated. */
#define MC33774_PRMM_AIN1_UV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN1_UV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN1_UV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN1_UV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN1_UV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN2_UV_TH_CFG (read-write):lower comparator limit for AIN2
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN2_UV_TH_CFG_OFFSET                   (0x181CU)
#define MC33774_PRMM_AIN2_UV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN2_UV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN2_UV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN2_UV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN2_UV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN2_UV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN2_UV_TH_CFG_POR_VAL                  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV status is activated. */
#define MC33774_PRMM_AIN2_UV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN2_UV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN2_UV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN2_UV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN2_UV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN3_UV_TH_CFG (read-write):lower comparator limit for AIN3
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN3_UV_TH_CFG_OFFSET                   (0x181DU)
#define MC33774_PRMM_AIN3_UV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN3_UV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN3_UV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AIN3_UV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AIN3_UV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AIN3_UV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AIN3_UV_TH_CFG_POR_VAL                  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV status is activated. */
#define MC33774_PRMM_AIN3_UV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AIN3_UV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AIN3_UV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN3_UV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AIN3_UV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AINA_UV_TH_CFG (read-write):lower comparator limit for AINA
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AINA_UV_TH_CFG_OFFSET                   (0x181EU)
#define MC33774_PRMM_AINA_UV_TH_CFG_RW_MASK                  (0xFFFFU)
#define MC33774_PRMM_AINA_UV_TH_CFG_RD_MASK                  (0xFFFFU)
#define MC33774_PRMM_AINA_UV_TH_CFG_WR_MASK                  (0xFFFFU)
#define MC33774_PRMM_AINA_UV_TH_CFG_MW_MASK                  (0x0U)
#define MC33774_PRMM_AINA_UV_TH_CFG_RA_MASK                  (0x0U)
#define MC33774_PRMM_AINA_UV_TH_CFG_POR_MASK                 (0xFFFFU)
#define MC33774_PRMM_AINA_UV_TH_CFG_POR_VAL                  (0x8001U)

/* Field LIMIT: Limit value. If this limit is reached, the UV status is activated. */
#define MC33774_PRMM_AINA_UV_TH_CFG_LIMIT_SHIFT              (0x0U)
#define MC33774_PRMM_AINA_UV_TH_CFG_LIMIT_MASK               (0xFFFFU)
#define MC33774_PRMM_AINA_UV_TH_CFG_LIMIT_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AINA_UV_TH_CFG_LIMIT_SHIFT)) & MC33774_PRMM_AINA_UV_TH_CFG_LIMIT_MASK))

/* --------------------------------------------------------------------------
 * PRMM_CAL_CRC (read-write):CRC over calibration data
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_CAL_CRC_OFFSET                          (0x1820U)
#define MC33774_PRMM_CAL_CRC_RW_MASK                         (0xFFFFU)
#define MC33774_PRMM_CAL_CRC_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_CAL_CRC_WR_MASK                         (0xFFFFU)
#define MC33774_PRMM_CAL_CRC_MW_MASK                         (0x0U)
#define MC33774_PRMM_CAL_CRC_RA_MASK                         (0x0U)
#define MC33774_PRMM_CAL_CRC_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_CAL_CRC_POR_VAL                         (0x0U)

/* Field CRC: CRC over calibration data. The CRC calculation runs automatically every time when a synchronous measurement cycle is started and when the calibration data is read from the NVM. */
#define MC33774_PRMM_CAL_CRC_CRC_SHIFT                       (0x0U)
#define MC33774_PRMM_CAL_CRC_CRC_MASK                        (0xFFFFU)
#define MC33774_PRMM_CAL_CRC_CRC_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_CAL_CRC_CRC_SHIFT)) & MC33774_PRMM_CAL_CRC_CRC_MASK))

/* Enumerated value CALIBCRC: The expected value of the calibration CRC. */
#define MC33774_PRMM_CAL_CRC_CRC_CALIBCRC_ENUM_VAL           (48879U)

/* --------------------------------------------------------------------------
 * PRMM_CFG_CRC (read-only):CRC over configuration values
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_CFG_CRC_OFFSET                          (0x1821U)
#define MC33774_PRMM_CFG_CRC_RW_MASK                         (0x0U)
#define MC33774_PRMM_CFG_CRC_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_CFG_CRC_WR_MASK                         (0x0U)
#define MC33774_PRMM_CFG_CRC_MW_MASK                         (0x0U)
#define MC33774_PRMM_CFG_CRC_RA_MASK                         (0x0U)
#define MC33774_PRMM_CFG_CRC_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_CFG_CRC_POR_VAL                         (0x0U)

/* Field CRC: This CRC value is recalculated with any transition into Active mode, with any write to a covered register and with any read to this register.
The updated CRC value is available latest 100us after the last write. The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1.
Following registers are included:  PRMM_CFG, PRMM_PER_CTRL, PRMM_VC_CFG0, PRMM_VC_CFG1, PRMM_AIN_CFG, PRMM_VBUF_CFG, PRMM_VC_OV_UV_CFG0, PRMM_VC_OV_UV_CFG1, PRMM_VC_OV_TH_CFG, PRMM_VC_UV0_TH_CFG, PRMM_VC_UV1_TH_CFG, PRMM_AIN0_OV_TH_CFG,
PRMM_AIN1_OV_TH_CFG, PRMM_AIN2_OV_TH_CFG, PRMM_AIN3_OV_TH_CFG, PRMM_AINA_OV_TH_CFG, PRMM_AIN0_UV_TH_CFG, PRMM_AIN1_UV_TH_CFG, PRMM_AIN2_UV_TH_CFG, PRMM_AIN3_UV_TH_CFG, PRMM_AINA_UV_TH_CFG. */
#define MC33774_PRMM_CFG_CRC_CRC_SHIFT                       (0x0U)
#define MC33774_PRMM_CFG_CRC_CRC_MASK                        (0xFFFFU)
#define MC33774_PRMM_CFG_CRC_CRC_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_CFG_CRC_CRC_SHIFT)) & MC33774_PRMM_CFG_CRC_CRC_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VC_OV_FLT_STAT0 (read-only):cell voltage over-voltage status
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_OV_FLT_STAT0_OFFSET                  (0x1822U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_RW_MASK                 (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_RD_MASK                 (0xFFFFU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_WR_MASK                 (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_MW_MASK                 (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_RA_MASK                 (0xFFFFU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_POR_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_POR_VAL                 (0x0U)

/* Field VC0: Over-voltage status VC0 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC0_SHIFT               (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC0_MASK                (0x1U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC0_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC0_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC0_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC0_OV_ENUM_VAL         (1U)

/* Field VC1: Over-voltage status VC1 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC1_SHIFT               (0x1U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC1_MASK                (0x2U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC1_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC1_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC1_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC1_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC1_OV_ENUM_VAL         (1U)

/* Field VC2: Over-voltage status VC2 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC2_SHIFT               (0x2U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC2_MASK                (0x4U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC2_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC2_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC2_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC2_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC2_OV_ENUM_VAL         (1U)

/* Field VC3: Over-voltage status VC3 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC3_SHIFT               (0x3U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC3_MASK                (0x8U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC3_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC3_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC3_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC3_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC3_OV_ENUM_VAL         (1U)

/* Field VC4: Over-voltage status VC4 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC4_SHIFT               (0x4U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC4_MASK                (0x10U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC4_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC4_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC4_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC4_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC4_OV_ENUM_VAL         (1U)

/* Field VC5: Over-voltage status VC5 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC5_SHIFT               (0x5U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC5_MASK                (0x20U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC5_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC5_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC5_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC5_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC5_OV_ENUM_VAL         (1U)

/* Field VC6: Over-voltage status VC6 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC6_SHIFT               (0x6U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC6_MASK                (0x40U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC6_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC6_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC6_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC6_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC6_OV_ENUM_VAL         (1U)

/* Field VC7: Over-voltage status VC7 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC7_SHIFT               (0x7U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC7_MASK                (0x80U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC7_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC7_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC7_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC7_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC7_OV_ENUM_VAL         (1U)

/* Field VC8: Over-voltage status VC8 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC8_SHIFT               (0x8U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC8_MASK                (0x100U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC8_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC8_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC8_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC8_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC8_OV_ENUM_VAL         (1U)

/* Field VC9: Over-voltage status VC9 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC9_SHIFT               (0x9U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC9_MASK                (0x200U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC9_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC9_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC9_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC9_NO_OV_ENUM_VAL      (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC9_OV_ENUM_VAL         (1U)

/* Field VC10: Over-voltage status VC10 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC10_SHIFT              (0xAU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC10_MASK               (0x400U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC10_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC10_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC10_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC10_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC10_OV_ENUM_VAL        (1U)

/* Field VC11: Over-voltage status VC11 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC11_SHIFT              (0xBU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC11_MASK               (0x800U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC11_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC11_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC11_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC11_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC11_OV_ENUM_VAL        (1U)

/* Field VC12: Over-voltage status VC12 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC12_SHIFT              (0xCU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC12_MASK               (0x1000U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC12_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC12_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC12_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC12_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC12_OV_ENUM_VAL        (1U)

/* Field VC13: Over-voltage status VC13 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC13_SHIFT              (0xDU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC13_MASK               (0x2000U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC13_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC13_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC13_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC13_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC13_OV_ENUM_VAL        (1U)

/* Field VC14: Over-voltage status VC14 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC14_SHIFT              (0xEU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC14_MASK               (0x4000U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC14_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC14_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC14_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC14_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC14_OV_ENUM_VAL        (1U)

/* Field VC15: Over-voltage status VC15 */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC15_SHIFT              (0xFU)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC15_MASK               (0x8000U)
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC15_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT0_VC15_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT0_VC15_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC15_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT0_VC15_OV_ENUM_VAL        (1U)

/* --------------------------------------------------------------------------
 * PRMM_VC_OV_FLT_STAT1 (read-only):cell voltage over-voltage status
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_OV_FLT_STAT1_OFFSET                  (0x1823U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_RW_MASK                 (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_RD_MASK                 (0x3U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_WR_MASK                 (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_MW_MASK                 (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_RA_MASK                 (0x3U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_POR_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_OV_FLT_STAT1_POR_VAL                 (0x0U)

/* Field VC16: Over-voltage status VC16 */
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC16_SHIFT              (0x0U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC16_MASK               (0x1U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC16_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT1_VC16_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT1_VC16_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC16_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC16_OV_ENUM_VAL        (1U)

/* Field VC17: Over-voltage status VC17 */
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC17_SHIFT              (0x1U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC17_MASK               (0x2U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC17_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT1_VC17_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT1_VC17_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC17_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_VC_OV_FLT_STAT1_VC17_OV_ENUM_VAL        (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_VC_OV_FLT_STAT1_RESERVED0_SHIFT         (0x2U)
#define MC33774_PRMM_VC_OV_FLT_STAT1_RESERVED0_MASK          (0xFFFCU)
#define MC33774_PRMM_VC_OV_FLT_STAT1_RESERVED0_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_OV_FLT_STAT1_RESERVED0_SHIFT)) & MC33774_PRMM_VC_OV_FLT_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VC_UV0_FLT_STAT0 (read-only):cell voltage under-voltage status regarding limit 0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_OFFSET                 (0x1824U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_RW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_RD_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_WR_MASK                (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_MW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_RA_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_POR_MASK               (0xFFFFU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_POR_VAL                (0x0U)

/* Field VC0: Under-voltage status VC0 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC0_SHIFT              (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC0_MASK               (0x1U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC0_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC0_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC0_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC0_UV_ENUM_VAL        (1U)

/* Field VC1: Under-voltage status VC1 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC1_SHIFT              (0x1U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC1_MASK               (0x2U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC1_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC1_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC1_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC1_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC1_UV_ENUM_VAL        (1U)

/* Field VC2: Under-voltage status VC2 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC2_SHIFT              (0x2U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC2_MASK               (0x4U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC2_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC2_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC2_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC2_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC2_UV_ENUM_VAL        (1U)

/* Field VC3: Under-voltage status VC3 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC3_SHIFT              (0x3U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC3_MASK               (0x8U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC3_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC3_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC3_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC3_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC3_UV_ENUM_VAL        (1U)

/* Field VC4: Under-voltage status VC4 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC4_SHIFT              (0x4U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC4_MASK               (0x10U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC4_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC4_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC4_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC4_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC4_UV_ENUM_VAL        (1U)

/* Field VC5: Under-voltage status VC5 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC5_SHIFT              (0x5U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC5_MASK               (0x20U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC5_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC5_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC5_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC5_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC5_UV_ENUM_VAL        (1U)

/* Field VC6: Under-voltage status VC6 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC6_SHIFT              (0x6U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC6_MASK               (0x40U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC6_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC6_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC6_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC6_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC6_UV_ENUM_VAL        (1U)

/* Field VC7: Under-voltage status VC7 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC7_SHIFT              (0x7U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC7_MASK               (0x80U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC7_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC7_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC7_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC7_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC7_UV_ENUM_VAL        (1U)

/* Field VC8: Under-voltage status VC8 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC8_SHIFT              (0x8U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC8_MASK               (0x100U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC8_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC8_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC8_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC8_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC8_UV_ENUM_VAL        (1U)

/* Field VC9: Under-voltage status VC9 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC9_SHIFT              (0x9U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC9_MASK               (0x200U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC9_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC9_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC9_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC9_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC9_UV_ENUM_VAL        (1U)

/* Field VC10: Under-voltage status VC10 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC10_SHIFT             (0xAU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC10_MASK              (0x400U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC10_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC10_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC10_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC10_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC10_UV_ENUM_VAL       (1U)

/* Field VC11: Under-voltage status VC11 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC11_SHIFT             (0xBU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC11_MASK              (0x800U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC11_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC11_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC11_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC11_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC11_UV_ENUM_VAL       (1U)

/* Field VC12: Under-voltage status VC12 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC12_SHIFT             (0xCU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC12_MASK              (0x1000U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC12_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC12_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC12_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC12_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC12_UV_ENUM_VAL       (1U)

/* Field VC13: Under-voltage status VC13 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC13_SHIFT             (0xDU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC13_MASK              (0x2000U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC13_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC13_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC13_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC13_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC13_UV_ENUM_VAL       (1U)

/* Field VC14: Under-voltage status VC14 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC14_SHIFT             (0xEU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC14_MASK              (0x4000U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC14_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC14_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC14_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC14_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC14_UV_ENUM_VAL       (1U)

/* Field VC15: Under-voltage status VC15 */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC15_SHIFT             (0xFU)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC15_MASK              (0x8000U)
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC15_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT0_VC15_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT0_VC15_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC15_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT0_VC15_UV_ENUM_VAL       (1U)

/* --------------------------------------------------------------------------
 * PRMM_VC_UV0_FLT_STAT1 (read-only):cell voltage under-voltage status regarding limit 0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_OFFSET                 (0x1825U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_RW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_RD_MASK                (0x3U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_WR_MASK                (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_MW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_RA_MASK                (0x3U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_POR_MASK               (0xFFFFU)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_POR_VAL                (0x0U)

/* Field VC16: Under-voltage status VC16 */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC16_SHIFT             (0x0U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC16_MASK              (0x1U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC16_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT1_VC16_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT1_VC16_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC16_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC16_UV_ENUM_VAL       (1U)

/* Field VC17: Under-voltage status VC17 */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC17_SHIFT             (0x1U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC17_MASK              (0x2U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC17_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT1_VC17_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT1_VC17_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC17_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_VC17_UV_ENUM_VAL       (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_VC_UV0_FLT_STAT1_RESERVED0_SHIFT        (0x2U)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_RESERVED0_MASK         (0xFFFCU)
#define MC33774_PRMM_VC_UV0_FLT_STAT1_RESERVED0_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV0_FLT_STAT1_RESERVED0_SHIFT)) & MC33774_PRMM_VC_UV0_FLT_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_VC_UV1_FLT_STAT0 (read-only):cell voltage under-voltage status regarding limit 1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_OFFSET                 (0x1826U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_RW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_RD_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_WR_MASK                (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_MW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_RA_MASK                (0xFFFFU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_POR_MASK               (0xFFFFU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_POR_VAL                (0x0U)

/* Field VC0: Under-voltage status VC0 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC0_SHIFT              (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC0_MASK               (0x1U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC0_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC0_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC0_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC0_UV_ENUM_VAL        (1U)

/* Field VC1: Under-voltage status VC1 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC1_SHIFT              (0x1U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC1_MASK               (0x2U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC1_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC1_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC1_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC1_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC1_UV_ENUM_VAL        (1U)

/* Field VC2: Under-voltage status VC2 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC2_SHIFT              (0x2U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC2_MASK               (0x4U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC2_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC2_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC2_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC2_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC2_UV_ENUM_VAL        (1U)

/* Field VC3: Under-voltage status VC3 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC3_SHIFT              (0x3U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC3_MASK               (0x8U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC3_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC3_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC3_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC3_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC3_UV_ENUM_VAL        (1U)

/* Field VC4: Under-voltage status VC4 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC4_SHIFT              (0x4U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC4_MASK               (0x10U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC4_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC4_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC4_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC4_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC4_UV_ENUM_VAL        (1U)

/* Field VC5: Under-voltage status VC5 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC5_SHIFT              (0x5U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC5_MASK               (0x20U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC5_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC5_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC5_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC5_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC5_UV_ENUM_VAL        (1U)

/* Field VC6: Under-voltage status VC6 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC6_SHIFT              (0x6U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC6_MASK               (0x40U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC6_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC6_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC6_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC6_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC6_UV_ENUM_VAL        (1U)

/* Field VC7: Under-voltage status VC7 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC7_SHIFT              (0x7U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC7_MASK               (0x80U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC7_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC7_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC7_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC7_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC7_UV_ENUM_VAL        (1U)

/* Field VC8: Under-voltage status VC8 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC8_SHIFT              (0x8U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC8_MASK               (0x100U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC8_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC8_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC8_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC8_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC8_UV_ENUM_VAL        (1U)

/* Field VC9: Under-voltage status VC9 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC9_SHIFT              (0x9U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC9_MASK               (0x200U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC9_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC9_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC9_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC9_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC9_UV_ENUM_VAL        (1U)

/* Field VC10: Under-voltage status VC10 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC10_SHIFT             (0xAU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC10_MASK              (0x400U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC10_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC10_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC10_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC10_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC10_UV_ENUM_VAL       (1U)

/* Field VC11: Under-voltage status VC11 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC11_SHIFT             (0xBU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC11_MASK              (0x800U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC11_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC11_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC11_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC11_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC11_UV_ENUM_VAL       (1U)

/* Field VC12: Under-voltage status VC12 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC12_SHIFT             (0xCU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC12_MASK              (0x1000U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC12_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC12_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC12_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC12_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC12_UV_ENUM_VAL       (1U)

/* Field VC13: Under-voltage status VC13 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC13_SHIFT             (0xDU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC13_MASK              (0x2000U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC13_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC13_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC13_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC13_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC13_UV_ENUM_VAL       (1U)

/* Field VC14: Under-voltage status VC14 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC14_SHIFT             (0xEU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC14_MASK              (0x4000U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC14_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC14_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC14_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC14_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC14_UV_ENUM_VAL       (1U)

/* Field VC15: Under-voltage status VC15 */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC15_SHIFT             (0xFU)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC15_MASK              (0x8000U)
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC15_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT0_VC15_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT0_VC15_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC15_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT0_VC15_UV_ENUM_VAL       (1U)

/* --------------------------------------------------------------------------
 * PRMM_VC_UV1_FLT_STAT1 (read-only):cell voltage under-voltage status regarding limit 1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_OFFSET                 (0x1827U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_RW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_RD_MASK                (0x3U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_WR_MASK                (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_MW_MASK                (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_RA_MASK                (0x3U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_POR_MASK               (0xFFFFU)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_POR_VAL                (0x0U)

/* Field VC16: Under-voltage status VC16 */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC16_SHIFT             (0x0U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC16_MASK              (0x1U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC16_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT1_VC16_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT1_VC16_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC16_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC16_UV_ENUM_VAL       (1U)

/* Field VC17: Under-voltage status VC17 */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC17_SHIFT             (0x1U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC17_MASK              (0x2U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC17_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT1_VC17_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT1_VC17_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC17_NO_UV_ENUM_VAL    (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_VC17_UV_ENUM_VAL       (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_VC_UV1_FLT_STAT1_RESERVED0_SHIFT        (0x2U)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_RESERVED0_MASK         (0xFFFCU)
#define MC33774_PRMM_VC_UV1_FLT_STAT1_RESERVED0_U16(x)       (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_VC_UV1_FLT_STAT1_RESERVED0_SHIFT)) & MC33774_PRMM_VC_UV1_FLT_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN_OV_FLT_STAT (read-only):AINx over-voltage status
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN_OV_FLT_STAT_OFFSET                  (0x1828U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_RW_MASK                 (0x0U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_RD_MASK                 (0x1FU)
#define MC33774_PRMM_AIN_OV_FLT_STAT_WR_MASK                 (0x0U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_MW_MASK                 (0x0U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_RA_MASK                 (0x1FU)
#define MC33774_PRMM_AIN_OV_FLT_STAT_POR_MASK                (0xFFFFU)
#define MC33774_PRMM_AIN_OV_FLT_STAT_POR_VAL                 (0x0U)

/* Field AIN0: Over-voltage status AIN0 */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN0_SHIFT              (0x0U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN0_MASK               (0x1U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OV_FLT_STAT_AIN0_SHIFT)) & MC33774_PRMM_AIN_OV_FLT_STAT_AIN0_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN0_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN0_OV_ENUM_VAL        (1U)

/* Field AIN1: Over-voltage status AIN1 */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN1_SHIFT              (0x1U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN1_MASK               (0x2U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN1_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OV_FLT_STAT_AIN1_SHIFT)) & MC33774_PRMM_AIN_OV_FLT_STAT_AIN1_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN1_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN1_OV_ENUM_VAL        (1U)

/* Field AIN2: Over-voltage status AIN2 */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN2_SHIFT              (0x2U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN2_MASK               (0x4U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN2_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OV_FLT_STAT_AIN2_SHIFT)) & MC33774_PRMM_AIN_OV_FLT_STAT_AIN2_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN2_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN2_OV_ENUM_VAL        (1U)

/* Field AIN3: Over-voltage status AIN3 */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN3_SHIFT              (0x3U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN3_MASK               (0x8U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN3_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OV_FLT_STAT_AIN3_SHIFT)) & MC33774_PRMM_AIN_OV_FLT_STAT_AIN3_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN3_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AIN3_OV_ENUM_VAL        (1U)

/* Field AINA: Over-voltage status AINA */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AINA_SHIFT              (0x4U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AINA_MASK               (0x10U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_AINA_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OV_FLT_STAT_AINA_SHIFT)) & MC33774_PRMM_AIN_OV_FLT_STAT_AINA_MASK))

/* Enumerated value NO_OV: No over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AINA_NO_OV_ENUM_VAL     (0U)

/* Enumerated value OV: Over-voltage detected */
#define MC33774_PRMM_AIN_OV_FLT_STAT_AINA_OV_ENUM_VAL        (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_AIN_OV_FLT_STAT_RESERVED0_SHIFT         (0x5U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_RESERVED0_MASK          (0xFFE0U)
#define MC33774_PRMM_AIN_OV_FLT_STAT_RESERVED0_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_OV_FLT_STAT_RESERVED0_SHIFT)) & MC33774_PRMM_AIN_OV_FLT_STAT_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_AIN_UV_FLT_STAT (read-only):AINx under-voltage status
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_AIN_UV_FLT_STAT_OFFSET                  (0x1829U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_RW_MASK                 (0x0U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_RD_MASK                 (0x1FU)
#define MC33774_PRMM_AIN_UV_FLT_STAT_WR_MASK                 (0x0U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_MW_MASK                 (0x0U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_RA_MASK                 (0x1FU)
#define MC33774_PRMM_AIN_UV_FLT_STAT_POR_MASK                (0xFFFFU)
#define MC33774_PRMM_AIN_UV_FLT_STAT_POR_VAL                 (0x0U)

/* Field AIN0: Under-voltage status AIN0 */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN0_SHIFT              (0x0U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN0_MASK               (0x1U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_UV_FLT_STAT_AIN0_SHIFT)) & MC33774_PRMM_AIN_UV_FLT_STAT_AIN0_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN0_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN0_UV_ENUM_VAL        (1U)

/* Field AIN1: Under-voltage status AIN1 */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN1_SHIFT              (0x1U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN1_MASK               (0x2U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN1_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_UV_FLT_STAT_AIN1_SHIFT)) & MC33774_PRMM_AIN_UV_FLT_STAT_AIN1_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN1_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN1_UV_ENUM_VAL        (1U)

/* Field AIN2: Under-voltage status AIN2 */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN2_SHIFT              (0x2U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN2_MASK               (0x4U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN2_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_UV_FLT_STAT_AIN2_SHIFT)) & MC33774_PRMM_AIN_UV_FLT_STAT_AIN2_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN2_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN2_UV_ENUM_VAL        (1U)

/* Field AIN3: Under-voltage status AIN3 */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN3_SHIFT              (0x3U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN3_MASK               (0x8U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN3_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_UV_FLT_STAT_AIN3_SHIFT)) & MC33774_PRMM_AIN_UV_FLT_STAT_AIN3_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN3_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AIN3_UV_ENUM_VAL        (1U)

/* Field AINA: Under-voltage status AINA */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AINA_SHIFT              (0x4U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AINA_MASK               (0x10U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_AINA_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_UV_FLT_STAT_AINA_SHIFT)) & MC33774_PRMM_AIN_UV_FLT_STAT_AINA_MASK))

/* Enumerated value NO_UV: No under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AINA_NO_UV_ENUM_VAL     (0U)

/* Enumerated value UV: Under-voltage detected */
#define MC33774_PRMM_AIN_UV_FLT_STAT_AINA_UV_ENUM_VAL        (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_AIN_UV_FLT_STAT_RESERVED0_SHIFT         (0x5U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_RESERVED0_MASK          (0xFFE0U)
#define MC33774_PRMM_AIN_UV_FLT_STAT_RESERVED0_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_AIN_UV_FLT_STAT_RESERVED0_SHIFT)) & MC33774_PRMM_AIN_UV_FLT_STAT_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * PRMM_MEAS_STAT (read-only):measurement status
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_MEAS_STAT_OFFSET                        (0x183EU)
#define MC33774_PRMM_MEAS_STAT_RW_MASK                       (0x0U)
#define MC33774_PRMM_MEAS_STAT_RD_MASK                       (0xF33FU)
#define MC33774_PRMM_MEAS_STAT_WR_MASK                       (0x0U)
#define MC33774_PRMM_MEAS_STAT_MW_MASK                       (0x0U)
#define MC33774_PRMM_MEAS_STAT_RA_MASK                       (0x0U)
#define MC33774_PRMM_MEAS_STAT_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_MEAS_STAT_POR_VAL                       (0x0U)

/* Field APPRDYVC: A new VC application result can be requested / captured. */
#define MC33774_PRMM_MEAS_STAT_APPRDYVC_SHIFT                (0x0U)
#define MC33774_PRMM_MEAS_STAT_APPRDYVC_MASK                 (0x1U)
#define MC33774_PRMM_MEAS_STAT_APPRDYVC_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_APPRDYVC_SHIFT)) & MC33774_PRMM_MEAS_STAT_APPRDYVC_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_PRMM_MEAS_STAT_APPRDYVC_NO_DATA_ENUM_VAL     (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_PRMM_MEAS_STAT_APPRDYVC_DATA_ENUM_VAL        (1U)

/* Field APPRDYAINA: A new AINA application result can be requested / captured. */
#define MC33774_PRMM_MEAS_STAT_APPRDYAINA_SHIFT              (0x1U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAINA_MASK               (0x2U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAINA_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_APPRDYAINA_SHIFT)) & MC33774_PRMM_MEAS_STAT_APPRDYAINA_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_PRMM_MEAS_STAT_APPRDYAINA_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_PRMM_MEAS_STAT_APPRDYAINA_DATA_ENUM_VAL      (1U)

/* Field APPRDYAIN0: A new AIN0 application result can be requested / captured. */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN0_SHIFT              (0x2U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN0_MASK               (0x4U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_APPRDYAIN0_SHIFT)) & MC33774_PRMM_MEAS_STAT_APPRDYAIN0_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN0_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN0_DATA_ENUM_VAL      (1U)

/* Field APPRDYAIN1: A new AIN1 application result can be requested / captured. */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN1_SHIFT              (0x3U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN1_MASK               (0x8U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN1_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_APPRDYAIN1_SHIFT)) & MC33774_PRMM_MEAS_STAT_APPRDYAIN1_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN1_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN1_DATA_ENUM_VAL      (1U)

/* Field APPRDYAIN2: A new AIN2 application result can be requested / captured. */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN2_SHIFT              (0x4U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN2_MASK               (0x10U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN2_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_APPRDYAIN2_SHIFT)) & MC33774_PRMM_MEAS_STAT_APPRDYAIN2_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN2_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN2_DATA_ENUM_VAL      (1U)

/* Field APPRDYAIN3: A new AIN3 application result can be requested / captured. */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN3_SHIFT              (0x5U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN3_MASK               (0x20U)
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN3_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_APPRDYAIN3_SHIFT)) & MC33774_PRMM_MEAS_STAT_APPRDYAIN3_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN3_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_PRMM_MEAS_STAT_APPRDYAIN3_DATA_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_MEAS_STAT_RESERVED0_SHIFT               (0x6U)
#define MC33774_PRMM_MEAS_STAT_RESERVED0_MASK                (0xC0U)
#define MC33774_PRMM_MEAS_STAT_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_RESERVED0_SHIFT)) & MC33774_PRMM_MEAS_STAT_RESERVED0_MASK))

/* Field PERRDY: New periodic result data has been created (depending on the periodic update mode, they might need to be requested),
the bit is cleared by a read to any register in the range PRMM_PER_VC0 to (PRMM_PER_VDDC + 1) if PRMM_PER_CTRL.PERCTRL is set to AUTO.
If PRMM_PER_CTRL.PERCTRL is set to ONCE, a write to PRMM_PER_CTRL.PERCTRL == ONCE clears it. */
#define MC33774_PRMM_MEAS_STAT_PERRDY_SHIFT                  (0x8U)
#define MC33774_PRMM_MEAS_STAT_PERRDY_MASK                   (0x100U)
#define MC33774_PRMM_MEAS_STAT_PERRDY_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_PERRDY_SHIFT)) & MC33774_PRMM_MEAS_STAT_PERRDY_MASK))

/* Enumerated value NO_DATA: No data available */
#define MC33774_PRMM_MEAS_STAT_PERRDY_NO_DATA_ENUM_VAL       (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33774_PRMM_MEAS_STAT_PERRDY_DATA_ENUM_VAL          (1U)

/* Field SYNCRDY: Synchronous measurement data is ready for readout, the bit is cleared by a read into the safety result range. */
#define MC33774_PRMM_MEAS_STAT_SYNCRDY_SHIFT                 (0x9U)
#define MC33774_PRMM_MEAS_STAT_SYNCRDY_MASK                  (0x200U)
#define MC33774_PRMM_MEAS_STAT_SYNCRDY_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_SYNCRDY_SHIFT)) & MC33774_PRMM_MEAS_STAT_SYNCRDY_MASK))

/* Enumerated value NO_DATA: No data available */
#define MC33774_PRMM_MEAS_STAT_SYNCRDY_NO_DATA_ENUM_VAL      (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33774_PRMM_MEAS_STAT_SYNCRDY_DATA_ENUM_VAL         (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_PRMM_MEAS_STAT_RESERVED1_SHIFT               (0xAU)
#define MC33774_PRMM_MEAS_STAT_RESERVED1_MASK                (0xC00U)
#define MC33774_PRMM_MEAS_STAT_RESERVED1_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_RESERVED1_SHIFT)) & MC33774_PRMM_MEAS_STAT_RESERVED1_MASK))

/* Field SUPPLYFLT: Internal/external supply fault status */
#define MC33774_PRMM_MEAS_STAT_SUPPLYFLT_SHIFT               (0xCU)
#define MC33774_PRMM_MEAS_STAT_SUPPLYFLT_MASK                (0x1000U)
#define MC33774_PRMM_MEAS_STAT_SUPPLYFLT_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_SUPPLYFLT_SHIFT)) & MC33774_PRMM_MEAS_STAT_SUPPLYFLT_MASK))

/* Enumerated value NO_FLT: No supply error detected */
#define MC33774_PRMM_MEAS_STAT_SUPPLYFLT_NO_FLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Supply error detected */
#define MC33774_PRMM_MEAS_STAT_SUPPLYFLT_FAULT_ENUM_VAL      (1U)

/* Field ANAFLT: Analog fault status */
#define MC33774_PRMM_MEAS_STAT_ANAFLT_SHIFT                  (0xDU)
#define MC33774_PRMM_MEAS_STAT_ANAFLT_MASK                   (0x2000U)
#define MC33774_PRMM_MEAS_STAT_ANAFLT_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_ANAFLT_SHIFT)) & MC33774_PRMM_MEAS_STAT_ANAFLT_MASK))

/* Enumerated value NO_FLT: No analog fault detected */
#define MC33774_PRMM_MEAS_STAT_ANAFLT_NO_FLT_ENUM_VAL        (0U)

/* Enumerated value FAULT: Analog fault detected */
#define MC33774_PRMM_MEAS_STAT_ANAFLT_FAULT_ENUM_VAL         (1U)

/* Field COMFLT: Communication fault status */
#define MC33774_PRMM_MEAS_STAT_COMFLT_SHIFT                  (0xEU)
#define MC33774_PRMM_MEAS_STAT_COMFLT_MASK                   (0x4000U)
#define MC33774_PRMM_MEAS_STAT_COMFLT_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_COMFLT_SHIFT)) & MC33774_PRMM_MEAS_STAT_COMFLT_MASK))

/* Enumerated value NO_FLT: No communication fault detected */
#define MC33774_PRMM_MEAS_STAT_COMFLT_NO_FLT_ENUM_VAL        (0U)

/* Enumerated value FAULT: Communication fault detected. */
#define MC33774_PRMM_MEAS_STAT_COMFLT_FAULT_ENUM_VAL         (1U)

/* Field MEASFLT: Measurement fault status */
#define MC33774_PRMM_MEAS_STAT_MEASFLT_SHIFT                 (0xFU)
#define MC33774_PRMM_MEAS_STAT_MEASFLT_MASK                  (0x8000U)
#define MC33774_PRMM_MEAS_STAT_MEASFLT_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_MEAS_STAT_MEASFLT_SHIFT)) & MC33774_PRMM_MEAS_STAT_MEASFLT_MASK))

/* Enumerated value NO_FLT: No measurement fault detected */
#define MC33774_PRMM_MEAS_STAT_MEASFLT_NO_FLT_ENUM_VAL       (0U)

/* Enumerated value FAULT: Measurement fault detected */
#define MC33774_PRMM_MEAS_STAT_MEASFLT_FAULT_ENUM_VAL        (1U)

/* --------------------------------------------------------------------------
 * PRMM_APP_VC_CNT (read-only):application measurement VC sample count number
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC_CNT_OFFSET                       (0x183FU)
#define MC33774_PRMM_APP_VC_CNT_RW_MASK                      (0x0U)
#define MC33774_PRMM_APP_VC_CNT_RD_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC_CNT_WR_MASK                      (0x0U)
#define MC33774_PRMM_APP_VC_CNT_MW_MASK                      (0x0U)
#define MC33774_PRMM_APP_VC_CNT_RA_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC_CNT_POR_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC_CNT_POR_VAL                      (0x0U)

/* Field NUM: Number of samples used for Application result. */
#define MC33774_PRMM_APP_VC_CNT_NUM_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC_CNT_NUM_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC_CNT_NUM_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC_CNT_NUM_SHIFT)) & MC33774_PRMM_APP_VC_CNT_NUM_MASK))

/* Enumerated value LOW: Zero or insufficient samples, VC Application results are invalid. */
#define MC33774_PRMM_APP_VC_CNT_NUM_LOW_ENUM_VAL             (0U)

/* Enumerated value OVERRUN: Sample counter overrun, VC Application results are invalid. */
#define MC33774_PRMM_APP_VC_CNT_NUM_OVERRUN_ENUM_VAL         (65535U)

/* --------------------------------------------------------------------------
 * PRMM_APP_VC0 (read-only):application measurement result cell 0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC0_OFFSET                          (0x1840U)
#define MC33774_PRMM_APP_VC0_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC0_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC0_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC0_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC0_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC0_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC0_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 0 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC0_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC0_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC0_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC0_VALUE_SHIFT)) & MC33774_PRMM_APP_VC0_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC1 (read-only):application measurement result cell 1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC1_OFFSET                          (0x1841U)
#define MC33774_PRMM_APP_VC1_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC1_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC1_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC1_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC1_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC1_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC1_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 1 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC1_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC1_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC1_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC1_VALUE_SHIFT)) & MC33774_PRMM_APP_VC1_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC2 (read-only):application measurement result cell 2
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC2_OFFSET                          (0x1842U)
#define MC33774_PRMM_APP_VC2_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC2_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC2_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC2_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC2_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC2_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC2_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 2 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC2_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC2_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC2_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC2_VALUE_SHIFT)) & MC33774_PRMM_APP_VC2_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC3 (read-only):application measurement result cell 3
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC3_OFFSET                          (0x1843U)
#define MC33774_PRMM_APP_VC3_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC3_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC3_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC3_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC3_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC3_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC3_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 3 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC3_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC3_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC3_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC3_VALUE_SHIFT)) & MC33774_PRMM_APP_VC3_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC4 (read-only):application measurement result cell 4
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC4_OFFSET                          (0x1844U)
#define MC33774_PRMM_APP_VC4_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC4_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC4_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC4_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC4_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC4_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC4_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 4 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC4_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC4_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC4_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC4_VALUE_SHIFT)) & MC33774_PRMM_APP_VC4_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC5 (read-only):application measurement result cell 5
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC5_OFFSET                          (0x1845U)
#define MC33774_PRMM_APP_VC5_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC5_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC5_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC5_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC5_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC5_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC5_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 5 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC5_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC5_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC5_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC5_VALUE_SHIFT)) & MC33774_PRMM_APP_VC5_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC6 (read-only):application measurement result cell 6
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC6_OFFSET                          (0x1846U)
#define MC33774_PRMM_APP_VC6_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC6_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC6_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC6_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC6_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC6_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC6_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 6 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC6_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC6_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC6_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC6_VALUE_SHIFT)) & MC33774_PRMM_APP_VC6_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC7 (read-only):application measurement result cell 7
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC7_OFFSET                          (0x1847U)
#define MC33774_PRMM_APP_VC7_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC7_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC7_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC7_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC7_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC7_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC7_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 7 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC7_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC7_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC7_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC7_VALUE_SHIFT)) & MC33774_PRMM_APP_VC7_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC8 (read-only):application measurement result cell 8
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC8_OFFSET                          (0x1848U)
#define MC33774_PRMM_APP_VC8_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC8_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC8_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC8_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC8_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC8_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC8_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 8 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC8_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC8_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC8_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC8_VALUE_SHIFT)) & MC33774_PRMM_APP_VC8_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC9 (read-only):application measurement result cell 9
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC9_OFFSET                          (0x1849U)
#define MC33774_PRMM_APP_VC9_RW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC9_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_APP_VC9_WR_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC9_MW_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC9_RA_MASK                         (0x0U)
#define MC33774_PRMM_APP_VC9_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC9_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 9 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC9_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_APP_VC9_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_APP_VC9_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC9_VALUE_SHIFT)) & MC33774_PRMM_APP_VC9_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC10 (read-only):application measurement result cell 10
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC10_OFFSET                         (0x184AU)
#define MC33774_PRMM_APP_VC10_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC10_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC10_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC10_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC10_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC10_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC10_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 10 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC10_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC10_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC10_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC10_VALUE_SHIFT)) & MC33774_PRMM_APP_VC10_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC11 (read-only):application measurement result cell 11
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC11_OFFSET                         (0x184BU)
#define MC33774_PRMM_APP_VC11_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC11_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC11_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC11_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC11_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC11_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC11_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 11 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC11_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC11_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC11_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC11_VALUE_SHIFT)) & MC33774_PRMM_APP_VC11_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC12 (read-only):application measurement result cell 12
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC12_OFFSET                         (0x184CU)
#define MC33774_PRMM_APP_VC12_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC12_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC12_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC12_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC12_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC12_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC12_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 12 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC12_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC12_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC12_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC12_VALUE_SHIFT)) & MC33774_PRMM_APP_VC12_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC13 (read-only):application measurement result cell 13
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC13_OFFSET                         (0x184DU)
#define MC33774_PRMM_APP_VC13_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC13_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC13_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC13_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC13_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC13_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC13_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 13 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC13_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC13_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC13_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC13_VALUE_SHIFT)) & MC33774_PRMM_APP_VC13_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC14 (read-only):application measurement result cell 14
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC14_OFFSET                         (0x184EU)
#define MC33774_PRMM_APP_VC14_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC14_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC14_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC14_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC14_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC14_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC14_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 14 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC14_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC14_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC14_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC14_VALUE_SHIFT)) & MC33774_PRMM_APP_VC14_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC15 (read-only):application measurement result cell 15
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC15_OFFSET                         (0x184FU)
#define MC33774_PRMM_APP_VC15_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC15_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC15_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC15_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC15_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC15_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC15_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 15 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC15_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC15_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC15_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC15_VALUE_SHIFT)) & MC33774_PRMM_APP_VC15_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC16 (read-only):application measurement result cell 16
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC16_OFFSET                         (0x1850U)
#define MC33774_PRMM_APP_VC16_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC16_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC16_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC16_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC16_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC16_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC16_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 16 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC16_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC16_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC16_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC16_VALUE_SHIFT)) & MC33774_PRMM_APP_VC16_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_VC17 (read-only):application measurement result cell 17
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_VC17_OFFSET                         (0x1851U)
#define MC33774_PRMM_APP_VC17_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC17_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_VC17_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC17_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC17_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_VC17_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_VC17_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 17 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_VC17_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_VC17_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_VC17_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_VC17_VALUE_SHIFT)) & MC33774_PRMM_APP_VC17_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_AINA (read-only):application measurement result AINA
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_AINA_OFFSET                         (0x1852U)
#define MC33774_PRMM_APP_AINA_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AINA_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_AINA_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_AINA_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AINA_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_AINA_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_AINA_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AINA at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_AINA_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_AINA_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_AINA_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_AINA_VALUE_SHIFT)) & MC33774_PRMM_APP_AINA_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_AIN0 (read-only):application measurement result AIN0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_AIN0_OFFSET                         (0x1853U)
#define MC33774_PRMM_APP_AIN0_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN0_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_AIN0_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN0_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN0_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN0_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_AIN0_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN0 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_AIN0_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_AIN0_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_AIN0_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_AIN0_VALUE_SHIFT)) & MC33774_PRMM_APP_AIN0_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_AIN1 (read-only):application measurement result AIN1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_AIN1_OFFSET                         (0x1854U)
#define MC33774_PRMM_APP_AIN1_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN1_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_AIN1_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN1_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN1_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN1_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_AIN1_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN1 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_AIN1_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_AIN1_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_AIN1_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_AIN1_VALUE_SHIFT)) & MC33774_PRMM_APP_AIN1_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_AIN2 (read-only):application measurement result AIN2
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_AIN2_OFFSET                         (0x1855U)
#define MC33774_PRMM_APP_AIN2_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN2_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_AIN2_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN2_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN2_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN2_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_AIN2_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN2 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_AIN2_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_AIN2_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_AIN2_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_AIN2_VALUE_SHIFT)) & MC33774_PRMM_APP_AIN2_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_APP_AIN3 (read-only):application measurement result AIN3
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_APP_AIN3_OFFSET                         (0x1856U)
#define MC33774_PRMM_APP_AIN3_RW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN3_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_APP_AIN3_WR_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN3_MW_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN3_RA_MASK                        (0x0U)
#define MC33774_PRMM_APP_AIN3_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_APP_AIN3_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN3 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_APP_AIN3_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_APP_AIN3_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_APP_AIN3_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_APP_AIN3_VALUE_SHIFT)) & MC33774_PRMM_APP_AIN3_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_NUM (read-only):measurement period number of the primary periodic results
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_NUM_OFFSET                          (0x185FU)
#define MC33774_PRMM_PER_NUM_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_NUM_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_NUM_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_NUM_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_NUM_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_NUM_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_NUM_POR_VAL                         (0x0U)

/* Field NUM: Number of the periodic cycle in which the primary periodic results have been created. The value is incremented for each periodic cycle executed. The counting wraps at its limit. */
#define MC33774_PRMM_PER_NUM_NUM_SHIFT                       (0x0U)
#define MC33774_PRMM_PER_NUM_NUM_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_NUM_NUM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_NUM_NUM_SHIFT)) & MC33774_PRMM_PER_NUM_NUM_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC0 (read-only):periodic measurement result cell 0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC0_OFFSET                          (0x1860U)
#define MC33774_PRMM_PER_VC0_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC0_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC0_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC0_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC0_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC0_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC0_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 0 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC0_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC0_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC0_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC0_VALUE_SHIFT)) & MC33774_PRMM_PER_VC0_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC1 (read-only):periodic measurement result cell 1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC1_OFFSET                          (0x1861U)
#define MC33774_PRMM_PER_VC1_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC1_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC1_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC1_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC1_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC1_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC1_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 1 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC1_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC1_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC1_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC1_VALUE_SHIFT)) & MC33774_PRMM_PER_VC1_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC2 (read-only):periodic measurement result cell 2
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC2_OFFSET                          (0x1862U)
#define MC33774_PRMM_PER_VC2_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC2_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC2_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC2_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC2_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC2_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC2_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 2 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC2_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC2_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC2_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC2_VALUE_SHIFT)) & MC33774_PRMM_PER_VC2_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC3 (read-only):periodic measurement result cell 3
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC3_OFFSET                          (0x1863U)
#define MC33774_PRMM_PER_VC3_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC3_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC3_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC3_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC3_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC3_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC3_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 3 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC3_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC3_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC3_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC3_VALUE_SHIFT)) & MC33774_PRMM_PER_VC3_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC4 (read-only):periodic measurement result cell 4
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC4_OFFSET                          (0x1864U)
#define MC33774_PRMM_PER_VC4_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC4_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC4_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC4_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC4_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC4_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC4_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 4 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC4_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC4_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC4_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC4_VALUE_SHIFT)) & MC33774_PRMM_PER_VC4_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC5 (read-only):periodic measurement result cell 5
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC5_OFFSET                          (0x1865U)
#define MC33774_PRMM_PER_VC5_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC5_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC5_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC5_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC5_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC5_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC5_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 5 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC5_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC5_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC5_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC5_VALUE_SHIFT)) & MC33774_PRMM_PER_VC5_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC6 (read-only):periodic measurement result cell 6
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC6_OFFSET                          (0x1866U)
#define MC33774_PRMM_PER_VC6_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC6_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC6_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC6_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC6_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC6_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC6_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 6 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC6_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC6_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC6_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC6_VALUE_SHIFT)) & MC33774_PRMM_PER_VC6_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC7 (read-only):periodic measurement result cell 7
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC7_OFFSET                          (0x1867U)
#define MC33774_PRMM_PER_VC7_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC7_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC7_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC7_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC7_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC7_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC7_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 7 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC7_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC7_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC7_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC7_VALUE_SHIFT)) & MC33774_PRMM_PER_VC7_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC8 (read-only):periodic measurement result cell 8
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC8_OFFSET                          (0x1868U)
#define MC33774_PRMM_PER_VC8_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC8_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC8_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC8_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC8_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC8_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC8_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 8 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC8_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC8_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC8_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC8_VALUE_SHIFT)) & MC33774_PRMM_PER_VC8_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC9 (read-only):periodic measurement result cell 9
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC9_OFFSET                          (0x1869U)
#define MC33774_PRMM_PER_VC9_RW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC9_RD_MASK                         (0xFFFFU)
#define MC33774_PRMM_PER_VC9_WR_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC9_MW_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC9_RA_MASK                         (0x0U)
#define MC33774_PRMM_PER_VC9_POR_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC9_POR_VAL                         (0x8000U)

/* Field VALUE: Measured voltage of cell 9 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC9_VALUE_SHIFT                     (0x0U)
#define MC33774_PRMM_PER_VC9_VALUE_MASK                      (0xFFFFU)
#define MC33774_PRMM_PER_VC9_VALUE_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC9_VALUE_SHIFT)) & MC33774_PRMM_PER_VC9_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC10 (read-only):periodic measurement result cell 10
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC10_OFFSET                         (0x186AU)
#define MC33774_PRMM_PER_VC10_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC10_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC10_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC10_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC10_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC10_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC10_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 10 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC10_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC10_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC10_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC10_VALUE_SHIFT)) & MC33774_PRMM_PER_VC10_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC11 (read-only):periodic measurement result cell 11
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC11_OFFSET                         (0x186BU)
#define MC33774_PRMM_PER_VC11_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC11_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC11_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC11_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC11_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC11_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC11_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 11 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC11_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC11_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC11_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC11_VALUE_SHIFT)) & MC33774_PRMM_PER_VC11_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC12 (read-only):periodic measurement result cell 12
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC12_OFFSET                         (0x186CU)
#define MC33774_PRMM_PER_VC12_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC12_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC12_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC12_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC12_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC12_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC12_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 12 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC12_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC12_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC12_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC12_VALUE_SHIFT)) & MC33774_PRMM_PER_VC12_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC13 (read-only):periodic measurement result cell 13
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC13_OFFSET                         (0x186DU)
#define MC33774_PRMM_PER_VC13_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC13_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC13_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC13_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC13_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC13_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC13_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 13 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC13_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC13_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC13_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC13_VALUE_SHIFT)) & MC33774_PRMM_PER_VC13_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC14 (read-only):periodic measurement result cell 14
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC14_OFFSET                         (0x186EU)
#define MC33774_PRMM_PER_VC14_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC14_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC14_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC14_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC14_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC14_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC14_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 14 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC14_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC14_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC14_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC14_VALUE_SHIFT)) & MC33774_PRMM_PER_VC14_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC15 (read-only):periodic measurement result cell 15
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC15_OFFSET                         (0x186FU)
#define MC33774_PRMM_PER_VC15_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC15_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC15_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC15_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC15_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC15_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC15_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 15 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC15_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC15_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC15_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC15_VALUE_SHIFT)) & MC33774_PRMM_PER_VC15_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC16 (read-only):periodic measurement result cell 16
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC16_OFFSET                         (0x1870U)
#define MC33774_PRMM_PER_VC16_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC16_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC16_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC16_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC16_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC16_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC16_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 16 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC16_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC16_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC16_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC16_VALUE_SHIFT)) & MC33774_PRMM_PER_VC16_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VC17 (read-only):periodic measurement result cell 17
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VC17_OFFSET                         (0x1871U)
#define MC33774_PRMM_PER_VC17_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC17_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VC17_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC17_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC17_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VC17_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VC17_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 17 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VC17_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VC17_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VC17_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VC17_VALUE_SHIFT)) & MC33774_PRMM_PER_VC17_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_AINA (read-only):periodic measurement result AINA
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_AINA_OFFSET                         (0x1872U)
#define MC33774_PRMM_PER_AINA_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AINA_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_AINA_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_AINA_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AINA_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_AINA_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_AINA_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AINA of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_AINA_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_AINA_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_AINA_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_AINA_VALUE_SHIFT)) & MC33774_PRMM_PER_AINA_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_AIN0 (read-only):periodic measurement result AIN0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_AIN0_OFFSET                         (0x1873U)
#define MC33774_PRMM_PER_AIN0_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN0_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_AIN0_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN0_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN0_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN0_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_AIN0_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN0 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_AIN0_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_AIN0_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_AIN0_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_AIN0_VALUE_SHIFT)) & MC33774_PRMM_PER_AIN0_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_AIN1 (read-only):periodic measurement result AIN1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_AIN1_OFFSET                         (0x1874U)
#define MC33774_PRMM_PER_AIN1_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN1_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_AIN1_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN1_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN1_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN1_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_AIN1_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN1 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_AIN1_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_AIN1_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_AIN1_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_AIN1_VALUE_SHIFT)) & MC33774_PRMM_PER_AIN1_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_AIN2 (read-only):periodic measurement result AIN2
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_AIN2_OFFSET                         (0x1875U)
#define MC33774_PRMM_PER_AIN2_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN2_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_AIN2_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN2_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN2_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN2_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_AIN2_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN2 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_AIN2_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_AIN2_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_AIN2_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_AIN2_VALUE_SHIFT)) & MC33774_PRMM_PER_AIN2_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_AIN3 (read-only):periodic measurement result AIN3
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_AIN3_OFFSET                         (0x1876U)
#define MC33774_PRMM_PER_AIN3_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN3_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_AIN3_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN3_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN3_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_AIN3_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_AIN3_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN3 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_AIN3_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_AIN3_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_AIN3_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_AIN3_VALUE_SHIFT)) & MC33774_PRMM_PER_AIN3_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_PRMTEMP (read-only):periodic measurement result primary device temperature
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_PRMTEMP_OFFSET                      (0x1877U)
#define MC33774_PRMM_PER_PRMTEMP_RW_MASK                     (0x0U)
#define MC33774_PRMM_PER_PRMTEMP_RD_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_PRMTEMP_WR_MASK                     (0x0U)
#define MC33774_PRMM_PER_PRMTEMP_MW_MASK                     (0x0U)
#define MC33774_PRMM_PER_PRMTEMP_RA_MASK                     (0x0U)
#define MC33774_PRMM_PER_PRMTEMP_POR_MASK                    (0xFFFFU)
#define MC33774_PRMM_PER_PRMTEMP_POR_VAL                     (0x8000U)

/* Field VALUE: Measured value of primary temperature sensor of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_PRMTEMP_VALUE_SHIFT                 (0x0U)
#define MC33774_PRMM_PER_PRMTEMP_VALUE_MASK                  (0xFFFFU)
#define MC33774_PRMM_PER_PRMTEMP_VALUE_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_PRMTEMP_VALUE_SHIFT)) & MC33774_PRMM_PER_PRMTEMP_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_SECVREF (read-only):periodic measurement result secondary voltage reference
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_SECVREF_OFFSET                      (0x1878U)
#define MC33774_PRMM_PER_SECVREF_RW_MASK                     (0x0U)
#define MC33774_PRMM_PER_SECVREF_RD_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_SECVREF_WR_MASK                     (0x0U)
#define MC33774_PRMM_PER_SECVREF_MW_MASK                     (0x0U)
#define MC33774_PRMM_PER_SECVREF_RA_MASK                     (0x0U)
#define MC33774_PRMM_PER_SECVREF_POR_MASK                    (0xFFFFU)
#define MC33774_PRMM_PER_SECVREF_POR_VAL                     (0x8000U)

/* Field VALUE: Measured voltage of secondary reference voltage of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_SECVREF_VALUE_SHIFT                 (0x0U)
#define MC33774_PRMM_PER_SECVREF_VALUE_MASK                  (0xFFFFU)
#define MC33774_PRMM_PER_SECVREF_VALUE_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_SECVREF_VALUE_SHIFT)) & MC33774_PRMM_PER_SECVREF_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VAUX (read-only):periodic measurement result auxiliary supply voltage
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VAUX_OFFSET                         (0x1879U)
#define MC33774_PRMM_PER_VAUX_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VAUX_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VAUX_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VAUX_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VAUX_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VAUX_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VAUX_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of VAUX of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VAUX_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VAUX_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VAUX_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VAUX_VALUE_SHIFT)) & MC33774_PRMM_PER_VAUX_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_PER_VDDC (read-only):periodic measurement result VDDC
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_PER_VDDC_OFFSET                         (0x187AU)
#define MC33774_PRMM_PER_VDDC_RW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VDDC_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_PER_VDDC_WR_MASK                        (0x0U)
#define MC33774_PRMM_PER_VDDC_MW_MASK                        (0x0U)
#define MC33774_PRMM_PER_VDDC_RA_MASK                        (0x0U)
#define MC33774_PRMM_PER_VDDC_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_PER_VDDC_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of VDDC of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_PER_VDDC_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_PER_VDDC_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_PER_VDDC_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_PER_VDDC_VALUE_SHIFT)) & MC33774_PRMM_PER_VDDC_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_NUM (read-only):measurement period number of the synchronous results.
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_NUM_OFFSET                         (0x187FU)
#define MC33774_PRMM_SYNC_NUM_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_NUM_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_NUM_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_NUM_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_NUM_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_NUM_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_NUM_POR_VAL                        (0x0U)

/* Field NUM: Number of the synchronous cycle in which the synchronous results have been created. The value is incremented for each synchronous cycle executed. The counting wraps at its limit. */
#define MC33774_PRMM_SYNC_NUM_NUM_SHIFT                      (0x0U)
#define MC33774_PRMM_SYNC_NUM_NUM_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_NUM_NUM_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_NUM_NUM_SHIFT)) & MC33774_PRMM_SYNC_NUM_NUM_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC0 (read-only):synchronous measurement result cell 0
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC0_OFFSET                         (0x1880U)
#define MC33774_PRMM_SYNC_VC0_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC0_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC0_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC0_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC0_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC0_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC0_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 0 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC0_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC0_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC0_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC0_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC0_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC1 (read-only):synchronous measurement result cell 1
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC1_OFFSET                         (0x1881U)
#define MC33774_PRMM_SYNC_VC1_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC1_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC1_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC1_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC1_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC1_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC1_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 1 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC1_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC1_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC1_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC1_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC1_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC2 (read-only):synchronous measurement result cell 2
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC2_OFFSET                         (0x1882U)
#define MC33774_PRMM_SYNC_VC2_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC2_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC2_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC2_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC2_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC2_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC2_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 2 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC2_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC2_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC2_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC2_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC2_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC3 (read-only):synchronous measurement result cell 3
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC3_OFFSET                         (0x1883U)
#define MC33774_PRMM_SYNC_VC3_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC3_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC3_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC3_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC3_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC3_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC3_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 3 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC3_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC3_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC3_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC3_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC3_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC4 (read-only):synchronous measurement result cell 4
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC4_OFFSET                         (0x1884U)
#define MC33774_PRMM_SYNC_VC4_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC4_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC4_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC4_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC4_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC4_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC4_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 4 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC4_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC4_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC4_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC4_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC4_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC5 (read-only):synchronous measurement result cell 5
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC5_OFFSET                         (0x1885U)
#define MC33774_PRMM_SYNC_VC5_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC5_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC5_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC5_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC5_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC5_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC5_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 5 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC5_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC5_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC5_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC5_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC5_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC6 (read-only):synchronous measurement result cell 6
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC6_OFFSET                         (0x1886U)
#define MC33774_PRMM_SYNC_VC6_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC6_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC6_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC6_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC6_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC6_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC6_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 6 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC6_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC6_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC6_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC6_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC6_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC7 (read-only):synchronous measurement result cell 7
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC7_OFFSET                         (0x1887U)
#define MC33774_PRMM_SYNC_VC7_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC7_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC7_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC7_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC7_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC7_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC7_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 7 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC7_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC7_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC7_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC7_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC7_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC8 (read-only):synchronous measurement result cell 8
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC8_OFFSET                         (0x1888U)
#define MC33774_PRMM_SYNC_VC8_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC8_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC8_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC8_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC8_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC8_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC8_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 8 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC8_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC8_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC8_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC8_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC8_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC9 (read-only):synchronous measurement result cell 9
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC9_OFFSET                         (0x1889U)
#define MC33774_PRMM_SYNC_VC9_RW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC9_RD_MASK                        (0xFFFFU)
#define MC33774_PRMM_SYNC_VC9_WR_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC9_MW_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC9_RA_MASK                        (0x0U)
#define MC33774_PRMM_SYNC_VC9_POR_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC9_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 9 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC9_VALUE_SHIFT                    (0x0U)
#define MC33774_PRMM_SYNC_VC9_VALUE_MASK                     (0xFFFFU)
#define MC33774_PRMM_SYNC_VC9_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC9_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC9_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC10 (read-only):synchronous measurement result cell 10
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC10_OFFSET                        (0x188AU)
#define MC33774_PRMM_SYNC_VC10_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC10_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC10_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC10_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC10_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC10_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC10_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 10 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC10_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC10_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC10_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC10_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC10_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC11 (read-only):synchronous measurement result cell 11
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC11_OFFSET                        (0x188BU)
#define MC33774_PRMM_SYNC_VC11_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC11_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC11_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC11_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC11_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC11_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC11_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 11 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC11_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC11_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC11_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC11_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC11_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC12 (read-only):synchronous measurement result cell 12
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC12_OFFSET                        (0x188CU)
#define MC33774_PRMM_SYNC_VC12_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC12_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC12_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC12_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC12_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC12_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC12_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 12 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC12_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC12_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC12_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC12_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC12_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC13 (read-only):synchronous measurement result cell 13
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC13_OFFSET                        (0x188DU)
#define MC33774_PRMM_SYNC_VC13_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC13_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC13_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC13_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC13_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC13_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC13_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 13 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC13_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC13_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC13_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC13_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC13_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC14 (read-only):synchronous measurement result cell 14
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC14_OFFSET                        (0x188EU)
#define MC33774_PRMM_SYNC_VC14_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC14_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC14_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC14_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC14_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC14_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC14_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 14 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC14_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC14_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC14_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC14_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC14_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC15 (read-only):synchronous measurement result cell 15
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC15_OFFSET                        (0x188FU)
#define MC33774_PRMM_SYNC_VC15_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC15_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC15_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC15_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC15_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC15_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC15_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 15 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC15_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC15_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC15_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC15_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC15_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC16 (read-only):synchronous measurement result cell 16
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC16_OFFSET                        (0x1890U)
#define MC33774_PRMM_SYNC_VC16_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC16_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC16_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC16_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC16_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC16_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC16_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 16 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC16_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC16_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC16_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC16_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC16_VALUE_MASK))

/* --------------------------------------------------------------------------
 * PRMM_SYNC_VC17 (read-only):synchronous measurement result cell 17
 * -------------------------------------------------------------------------- */
#define MC33774_PRMM_SYNC_VC17_OFFSET                        (0x1891U)
#define MC33774_PRMM_SYNC_VC17_RW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC17_RD_MASK                       (0xFFFFU)
#define MC33774_PRMM_SYNC_VC17_WR_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC17_MW_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC17_RA_MASK                       (0x0U)
#define MC33774_PRMM_SYNC_VC17_POR_MASK                      (0xFFFFU)
#define MC33774_PRMM_SYNC_VC17_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 17 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_PRMM_SYNC_VC17_VALUE_SHIFT                   (0x0U)
#define MC33774_PRMM_SYNC_VC17_VALUE_MASK                    (0xFFFFU)
#define MC33774_PRMM_SYNC_VC17_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_PRMM_SYNC_VC17_VALUE_SHIFT)) & MC33774_PRMM_SYNC_VC17_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_CFG (read-write):general measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_CFG_OFFSET                              (0x1C00U)
#define MC33774_SECM_CFG_RW_MASK                             (0xFFFFU)
#define MC33774_SECM_CFG_RD_MASK                             (0xFFFFU)
#define MC33774_SECM_CFG_WR_MASK                             (0xFFFFU)
#define MC33774_SECM_CFG_MW_MASK                             (0x0U)
#define MC33774_SECM_CFG_RA_MASK                             (0x0U)
#define MC33774_SECM_CFG_POR_MASK                            (0xFFFFU)
#define MC33774_SECM_CFG_POR_VAL                             (0x0U)

/* Field MEASEN: Enable the data acquisition. Setting this bit to zero initiates a result clear and invalidate action (this includes resetting all ready bits).
This bit is cleared when entering Sleep mode. Cyclic measurements are always executed, regardless of the value of this bit.
Balancing is not stopped automatically (if in Active mode), as it would be permanently inhibited while measurement is active.
If balancing shall be paused, please do so via the balancing control. */
#define MC33774_SECM_CFG_MEASEN_SHIFT                        (0x0U)
#define MC33774_SECM_CFG_MEASEN_MASK                         (0x1U)
#define MC33774_SECM_CFG_MEASEN_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_SECM_CFG_MEASEN_SHIFT)) & MC33774_SECM_CFG_MEASEN_MASK))

/* Enumerated value DISABLED: Data acquisition disabled */
#define MC33774_SECM_CFG_MEASEN_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Data acquisition enabled */
#define MC33774_SECM_CFG_MEASEN_ENABLED_ENUM_VAL             (1U)

/* Field BALPAUSECYCMODEN: Enable balancing auto pause. This delays the start of measurements after entering Cyclic mode until the auto pause counter has elapsed. This field has no effect in secondary measurement. */
#define MC33774_SECM_CFG_BALPAUSECYCMODEN_SHIFT              (0x1U)
#define MC33774_SECM_CFG_BALPAUSECYCMODEN_MASK               (0x2U)
#define MC33774_SECM_CFG_BALPAUSECYCMODEN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SECM_CFG_BALPAUSECYCMODEN_SHIFT)) & MC33774_SECM_CFG_BALPAUSECYCMODEN_MASK))

/* Enumerated value DISABLED: auto pause for balancing is disabled. */
#define MC33774_SECM_CFG_BALPAUSECYCMODEN_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: auto pause for balancing is enabled. Measurements are started when the auto pause counter is elapsed. */
#define MC33774_SECM_CFG_BALPAUSECYCMODEN_ENABLED_ENUM_VAL   (1U)

/* Field BALPAUSELEN: Pause of balancing before measurement cycle is executed. An on-going balancing pause operation is not influenced by a change of this value. 1 LSB = 10us. */
#define MC33774_SECM_CFG_BALPAUSELEN_SHIFT                   (0x2U)
#define MC33774_SECM_CFG_BALPAUSELEN_MASK                    (0xFFFCU)
#define MC33774_SECM_CFG_BALPAUSELEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_CFG_BALPAUSELEN_SHIFT)) & MC33774_SECM_CFG_BALPAUSELEN_MASK))

/* Enumerated value NO_PAUSE: No Pause. */
#define MC33774_SECM_CFG_BALPAUSELEN_NO_PAUSE_ENUM_VAL       (0U)

/* Enumerated value PAUSE_10u: Pause = 10 us */
#define MC33774_SECM_CFG_BALPAUSELEN_PAUSE_10U_ENUM_VAL      (1U)

/* Enumerated value MAX: Maximum pause = 163830 us = 163 ms */
#define MC33774_SECM_CFG_BALPAUSELEN_MAX_ENUM_VAL            (16383U)

/* --------------------------------------------------------------------------
 * SECM_APP_CTRL (write-only):application measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_APP_CTRL_OFFSET                         (0x1C01U)
#define MC33774_SECM_APP_CTRL_RW_MASK                        (0x0U)
#define MC33774_SECM_APP_CTRL_RD_MASK                        (0x0U)
#define MC33774_SECM_APP_CTRL_WR_MASK                        (0x83FFU)
#define MC33774_SECM_APP_CTRL_MW_MASK                        (0x0U)
#define MC33774_SECM_APP_CTRL_RA_MASK                        (0x0U)
#define MC33774_SECM_APP_CTRL_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_APP_CTRL_POR_VAL                        (0x0U)

/* Field CAPVC: Trigger the balancing auto pause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access.
In primary: Capture the application measurement value of the cell terminal measurements. */
#define MC33774_SECM_APP_CTRL_CAPVC_SHIFT                    (0x0U)
#define MC33774_SECM_APP_CTRL_CAPVC_MASK                     (0x1U)
#define MC33774_SECM_APP_CTRL_CAPVC_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPVC_SHIFT)) & MC33774_SECM_APP_CTRL_CAPVC_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPVC_NO_CAP_ENUM_VAL          (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPVC_CAP_ENUM_VAL             (1U)

/* Field CAPAINA: Trigger the balancing auto pause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access.
In primary: Capture the application measurement value of the AINA voltage measurement. */
#define MC33774_SECM_APP_CTRL_CAPAINA_SHIFT                  (0x1U)
#define MC33774_SECM_APP_CTRL_CAPAINA_MASK                   (0x2U)
#define MC33774_SECM_APP_CTRL_CAPAINA_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAINA_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAINA_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAINA_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAINA_CAP_ENUM_VAL           (1U)

/* Field CAPAIN0: Trigger the balancing auto pause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access.
In primary: Capture the application measurement value of the aux0 terminal measurement. */
#define MC33774_SECM_APP_CTRL_CAPAIN0_SHIFT                  (0x2U)
#define MC33774_SECM_APP_CTRL_CAPAIN0_MASK                   (0x4U)
#define MC33774_SECM_APP_CTRL_CAPAIN0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN0_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN0_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN0_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN0_CAP_ENUM_VAL           (1U)

/* Field CAPAIN1: Trigger the balancing auto pause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access.
In primary: Capture the application measurement value of the aux1 terminal measurement. */
#define MC33774_SECM_APP_CTRL_CAPAIN1_SHIFT                  (0x3U)
#define MC33774_SECM_APP_CTRL_CAPAIN1_MASK                   (0x8U)
#define MC33774_SECM_APP_CTRL_CAPAIN1_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN1_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN1_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN1_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN1_CAP_ENUM_VAL           (1U)

/* Field CAPAIN2: Trigger the balancing auto pause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access.
In primary: Capture the application measurement value of the aux2 terminal measurement. */
#define MC33774_SECM_APP_CTRL_CAPAIN2_SHIFT                  (0x4U)
#define MC33774_SECM_APP_CTRL_CAPAIN2_MASK                   (0x10U)
#define MC33774_SECM_APP_CTRL_CAPAIN2_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN2_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN2_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN2_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN2_CAP_ENUM_VAL           (1U)

/* Field CAPAIN3: Trigger the balancing auto pause if set in combination with the PAUSEBAL bit. Needed to keep primary and secondary measurement synchron when used via the ALLM access.
In primary: Capture the application measurement value of the aux3 terminal measurement. */
#define MC33774_SECM_APP_CTRL_CAPAIN3_SHIFT                  (0x5U)
#define MC33774_SECM_APP_CTRL_CAPAIN3_MASK                   (0x20U)
#define MC33774_SECM_APP_CTRL_CAPAIN3_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN3_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN3_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN3_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN3_CAP_ENUM_VAL           (1U)

/* Field CAPAIN4: Capture the application measurement value of the aux4 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33774_SECM_APP_CTRL_CAPAIN4_SHIFT                  (0x6U)
#define MC33774_SECM_APP_CTRL_CAPAIN4_MASK                   (0x40U)
#define MC33774_SECM_APP_CTRL_CAPAIN4_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN4_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN4_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN4_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN4_CAP_ENUM_VAL           (1U)

/* Field CAPAIN5: Capture the application measurement value of the aux5 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33774_SECM_APP_CTRL_CAPAIN5_SHIFT                  (0x7U)
#define MC33774_SECM_APP_CTRL_CAPAIN5_MASK                   (0x80U)
#define MC33774_SECM_APP_CTRL_CAPAIN5_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN5_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN5_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN5_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN5_CAP_ENUM_VAL           (1U)

/* Field CAPAIN6: Capture the application measurement value of the aux6 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33774_SECM_APP_CTRL_CAPAIN6_SHIFT                  (0x8U)
#define MC33774_SECM_APP_CTRL_CAPAIN6_MASK                   (0x100U)
#define MC33774_SECM_APP_CTRL_CAPAIN6_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN6_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN6_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN6_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN6_CAP_ENUM_VAL           (1U)

/* Field CAPAIN7: Capture the application measurement value of the aux7 terminal measurement. The values are now readable via the app_result register. This bit is only available in the secondary measurement chain. */
#define MC33774_SECM_APP_CTRL_CAPAIN7_SHIFT                  (0x9U)
#define MC33774_SECM_APP_CTRL_CAPAIN7_MASK                   (0x200U)
#define MC33774_SECM_APP_CTRL_CAPAIN7_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_CAPAIN7_SHIFT)) & MC33774_SECM_APP_CTRL_CAPAIN7_MASK))

/* Enumerated value NO_CAP: Measurements are not captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN7_NO_CAP_ENUM_VAL        (0U)

/* Enumerated value CAP: Measurements are captured. */
#define MC33774_SECM_APP_CTRL_CAPAIN7_CAP_ENUM_VAL           (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_APP_CTRL_RESERVED0_SHIFT                (0xAU)
#define MC33774_SECM_APP_CTRL_RESERVED0_MASK                 (0x7C00U)
#define MC33774_SECM_APP_CTRL_RESERVED0_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_RESERVED0_SHIFT)) & MC33774_SECM_APP_CTRL_RESERVED0_MASK))

/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the auto pause timer has elapsed. This field has no effect in secondary measurement. */
#define MC33774_SECM_APP_CTRL_PAUSEBAL_SHIFT                 (0xFU)
#define MC33774_SECM_APP_CTRL_PAUSEBAL_MASK                  (0x8000U)
#define MC33774_SECM_APP_CTRL_PAUSEBAL_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_CTRL_PAUSEBAL_SHIFT)) & MC33774_SECM_APP_CTRL_PAUSEBAL_MASK))

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33774_SECM_APP_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL     (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33774_SECM_APP_CTRL_PAUSEBAL_PAUSE_ENUM_VAL        (1U)

/* --------------------------------------------------------------------------
 * SECM_PER_CTRL (read-write):periodic measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_CTRL_OFFSET                         (0x1C02U)
#define MC33774_SECM_PER_CTRL_RW_MASK                        (0x11FFU)
#define MC33774_SECM_PER_CTRL_RD_MASK                        (0x11FFU)
#define MC33774_SECM_PER_CTRL_WR_MASK                        (0x11FFU)
#define MC33774_SECM_PER_CTRL_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_CTRL_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_CTRL_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_CTRL_POR_VAL                        (0x10U)

/* Field PERLEN: Number of measurements for one periodic measurement. The minimum is 16. Writing a value lower than 16 leads to a 16 in the register. */
#define MC33774_SECM_PER_CTRL_PERLEN_SHIFT                   (0x0U)
#define MC33774_SECM_PER_CTRL_PERLEN_MASK                    (0x1FFU)
#define MC33774_SECM_PER_CTRL_PERLEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_CTRL_PERLEN_SHIFT)) & MC33774_SECM_PER_CTRL_PERLEN_MASK))

/* Enumerated value PER_16: minimum value = 16 measurements per period */
#define MC33774_SECM_PER_CTRL_PERLEN_PER_16_ENUM_VAL         (16U)

/* Enumerated value PER_17: 17 measurements per period */
#define MC33774_SECM_PER_CTRL_PERLEN_PER_17_ENUM_VAL         (17U)

/* Enumerated value PER_MAX: maximum value = 511 measurements per period */
#define MC33774_SECM_PER_CTRL_PERLEN_PER_MAX_ENUM_VAL        (511U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_PER_CTRL_RESERVED0_SHIFT                (0x9U)
#define MC33774_SECM_PER_CTRL_RESERVED0_MASK                 (0xE00U)
#define MC33774_SECM_PER_CTRL_RESERVED0_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_CTRL_RESERVED0_SHIFT)) & MC33774_SECM_PER_CTRL_RESERVED0_MASK))

/* Field PERCTRL: Control the periodic result behavior. */
#define MC33774_SECM_PER_CTRL_PERCTRL_SHIFT                  (0xCU)
#define MC33774_SECM_PER_CTRL_PERCTRL_MASK                   (0x1000U)
#define MC33774_SECM_PER_CTRL_PERCTRL_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_CTRL_PERCTRL_SHIFT)) & MC33774_SECM_PER_CTRL_PERCTRL_MASK))

/* Enumerated value AUTO: Periodic results are automatically updated */
#define MC33774_SECM_PER_CTRL_PERCTRL_AUTO_ENUM_VAL          (0U)

/* Enumerated value ONCE: Periodic results are updated once with the last results. (each write updates the results). */
#define MC33774_SECM_PER_CTRL_PERCTRL_ONCE_ENUM_VAL          (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_PER_CTRL_RESERVED1_SHIFT                (0xDU)
#define MC33774_SECM_PER_CTRL_RESERVED1_MASK                 (0xE000U)
#define MC33774_SECM_PER_CTRL_RESERVED1_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_CTRL_RESERVED1_SHIFT)) & MC33774_SECM_PER_CTRL_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_CTRL (read-write):synchronous measurement control
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_CTRL_OFFSET                        (0x1C03U)
#define MC33774_SECM_SYNC_CTRL_RW_MASK                       (0x7C00U)
#define MC33774_SECM_SYNC_CTRL_RD_MASK                       (0x7C00U)
#define MC33774_SECM_SYNC_CTRL_WR_MASK                       (0xFC03U)
#define MC33774_SECM_SYNC_CTRL_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_CTRL_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_CTRL_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_CTRL_POR_VAL                       (0x7C00U)

/* Field SYNCCYC: Start a synchronous measurement cycle. In this cycle the CT and CB voltages are measured and stored as matching pairs.
If no VB channel is enabled or if set during a running synchronous measurement cycle or a running Fast VB cycle, the set is ignored. Read as zero. */
#define MC33774_SECM_SYNC_CTRL_SYNCCYC_SHIFT                 (0x0U)
#define MC33774_SECM_SYNC_CTRL_SYNCCYC_MASK                  (0x1U)
#define MC33774_SECM_SYNC_CTRL_SYNCCYC_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_CTRL_SYNCCYC_SHIFT)) & MC33774_SECM_SYNC_CTRL_SYNCCYC_MASK))

/* Enumerated value NO_START: No new start a synchronous measurement cycle. */
#define MC33774_SECM_SYNC_CTRL_SYNCCYC_NO_START_ENUM_VAL     (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33774_SECM_SYNC_CTRL_SYNCCYC_STATUS_ENUM_VAL       (0U)

/* Enumerated value START: Start a synchronous measurement cycle. */
#define MC33774_SECM_SYNC_CTRL_SYNCCYC_START_ENUM_VAL        (1U)

/* Field FASTVB: Start a Fast VB measurement cycle. Read as zero. */
#define MC33774_SECM_SYNC_CTRL_FASTVB_SHIFT                  (0x1U)
#define MC33774_SECM_SYNC_CTRL_FASTVB_MASK                   (0x2U)
#define MC33774_SECM_SYNC_CTRL_FASTVB_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_CTRL_FASTVB_SHIFT)) & MC33774_SECM_SYNC_CTRL_FASTVB_MASK))

/* Enumerated value NO_FAST: No new start of a fast VB measurement cycle. */
#define MC33774_SECM_SYNC_CTRL_FASTVB_NO_FAST_ENUM_VAL       (0U)

/* Enumerated value STATUS: Read as zero. */
#define MC33774_SECM_SYNC_CTRL_FASTVB_STATUS_ENUM_VAL        (0U)

/* Enumerated value FAST: Start a new fast VB measurement cycle. */
#define MC33774_SECM_SYNC_CTRL_FASTVB_FAST_ENUM_VAL          (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_SYNC_CTRL_RESERVED0_SHIFT               (0x2U)
#define MC33774_SECM_SYNC_CTRL_RESERVED0_MASK                (0x3FCU)
#define MC33774_SECM_SYNC_CTRL_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_CTRL_RESERVED0_SHIFT)) & MC33774_SECM_SYNC_CTRL_RESERVED0_MASK))

/* Field VBOLNUM: VB number for which the open load detection is enabled. 0 - 17 = channel for which the open load detection is enabled.
18 - 29 = reserved (no open load detection mechanism is enabled). 30 = the open load detection is enabled for the currently measured channel. */
#define MC33774_SECM_SYNC_CTRL_VBOLNUM_SHIFT                 (0xAU)
#define MC33774_SECM_SYNC_CTRL_VBOLNUM_MASK                  (0x7C00U)
#define MC33774_SECM_SYNC_CTRL_VBOLNUM_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_CTRL_VBOLNUM_SHIFT)) & MC33774_SECM_SYNC_CTRL_VBOLNUM_MASK))

/* Enumerated value DISABLED: Open-load detection is disabled */
#define MC33774_SECM_SYNC_CTRL_VBOLNUM_DISABLED_ENUM_VAL     (31U)

/* Field PAUSEBAL: Pause the balancing during this capture cycle. If balancing was not paused before, the start of data capture is delayed until the auto pause timer has elapsed. If no capture cycle is started this bit is ignored. */
#define MC33774_SECM_SYNC_CTRL_PAUSEBAL_SHIFT                (0xFU)
#define MC33774_SECM_SYNC_CTRL_PAUSEBAL_MASK                 (0x8000U)
#define MC33774_SECM_SYNC_CTRL_PAUSEBAL_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_CTRL_PAUSEBAL_SHIFT)) & MC33774_SECM_SYNC_CTRL_PAUSEBAL_MASK))

/* Enumerated value NO_PAUSE: Continue with balancing. */
#define MC33774_SECM_SYNC_CTRL_PAUSEBAL_NO_PAUSE_ENUM_VAL    (0U)

/* Enumerated value PAUSE: Pause the balancing during this capture cycle. */
#define MC33774_SECM_SYNC_CTRL_PAUSEBAL_PAUSE_ENUM_VAL       (1U)

/* --------------------------------------------------------------------------
 * SECM_VB_CFG0 (read-write):balance voltage measurement enable
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_VB_CFG0_OFFSET                          (0x1C08U)
#define MC33774_SECM_VB_CFG0_RW_MASK                         (0xFFFFU)
#define MC33774_SECM_VB_CFG0_RD_MASK                         (0xFFFFU)
#define MC33774_SECM_VB_CFG0_WR_MASK                         (0xFFFFU)
#define MC33774_SECM_VB_CFG0_MW_MASK                         (0x0U)
#define MC33774_SECM_VB_CFG0_RA_MASK                         (0x0U)
#define MC33774_SECM_VB_CFG0_POR_MASK                        (0xFFFFU)
#define MC33774_SECM_VB_CFG0_POR_VAL                         (0x0U)

/* Field VB0EN: Enable measurement of balance voltage 0. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB0EN_SHIFT                     (0x0U)
#define MC33774_SECM_VB_CFG0_VB0EN_MASK                      (0x1U)
#define MC33774_SECM_VB_CFG0_VB0EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB0EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB0EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB0EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB0EN_ENABLED_ENUM_VAL          (1U)

/* Field VB1EN: Enable measurement of balance voltage 1. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB1EN_SHIFT                     (0x1U)
#define MC33774_SECM_VB_CFG0_VB1EN_MASK                      (0x2U)
#define MC33774_SECM_VB_CFG0_VB1EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB1EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB1EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB1EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB1EN_ENABLED_ENUM_VAL          (1U)

/* Field VB2EN: Enable measurement of balance voltage 2. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB2EN_SHIFT                     (0x2U)
#define MC33774_SECM_VB_CFG0_VB2EN_MASK                      (0x4U)
#define MC33774_SECM_VB_CFG0_VB2EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB2EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB2EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB2EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB2EN_ENABLED_ENUM_VAL          (1U)

/* Field VB3EN: Enable measurement of balance voltage 3. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB3EN_SHIFT                     (0x3U)
#define MC33774_SECM_VB_CFG0_VB3EN_MASK                      (0x8U)
#define MC33774_SECM_VB_CFG0_VB3EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB3EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB3EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB3EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB3EN_ENABLED_ENUM_VAL          (1U)

/* Field VB4EN: Enable measurement of balance voltage 4. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB4EN_SHIFT                     (0x4U)
#define MC33774_SECM_VB_CFG0_VB4EN_MASK                      (0x10U)
#define MC33774_SECM_VB_CFG0_VB4EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB4EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB4EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB4EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB4EN_ENABLED_ENUM_VAL          (1U)

/* Field VB5EN: Enable measurement of balance voltage 5. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB5EN_SHIFT                     (0x5U)
#define MC33774_SECM_VB_CFG0_VB5EN_MASK                      (0x20U)
#define MC33774_SECM_VB_CFG0_VB5EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB5EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB5EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB5EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB5EN_ENABLED_ENUM_VAL          (1U)

/* Field VB6EN: Enable measurement of balance voltage 6. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB6EN_SHIFT                     (0x6U)
#define MC33774_SECM_VB_CFG0_VB6EN_MASK                      (0x40U)
#define MC33774_SECM_VB_CFG0_VB6EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB6EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB6EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB6EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB6EN_ENABLED_ENUM_VAL          (1U)

/* Field VB7EN: Enable measurement of balance voltage 7. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB7EN_SHIFT                     (0x7U)
#define MC33774_SECM_VB_CFG0_VB7EN_MASK                      (0x80U)
#define MC33774_SECM_VB_CFG0_VB7EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB7EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB7EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB7EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB7EN_ENABLED_ENUM_VAL          (1U)

/* Field VB8EN: Enable measurement of balance voltage 8. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB8EN_SHIFT                     (0x8U)
#define MC33774_SECM_VB_CFG0_VB8EN_MASK                      (0x100U)
#define MC33774_SECM_VB_CFG0_VB8EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB8EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB8EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB8EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB8EN_ENABLED_ENUM_VAL          (1U)

/* Field VB9EN: Enable measurement of balance voltage 9. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB9EN_SHIFT                     (0x9U)
#define MC33774_SECM_VB_CFG0_VB9EN_MASK                      (0x200U)
#define MC33774_SECM_VB_CFG0_VB9EN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB9EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB9EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB9EN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB9EN_ENABLED_ENUM_VAL          (1U)

/* Field VB10EN: Enable measurement of balance voltage 10. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB10EN_SHIFT                    (0xAU)
#define MC33774_SECM_VB_CFG0_VB10EN_MASK                     (0x400U)
#define MC33774_SECM_VB_CFG0_VB10EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB10EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB10EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB10EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB10EN_ENABLED_ENUM_VAL         (1U)

/* Field VB11EN: Enable measurement of balance voltage 11. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB11EN_SHIFT                    (0xBU)
#define MC33774_SECM_VB_CFG0_VB11EN_MASK                     (0x800U)
#define MC33774_SECM_VB_CFG0_VB11EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB11EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB11EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB11EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB11EN_ENABLED_ENUM_VAL         (1U)

/* Field VB12EN: Enable measurement of balance voltage 12. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB12EN_SHIFT                    (0xCU)
#define MC33774_SECM_VB_CFG0_VB12EN_MASK                     (0x1000U)
#define MC33774_SECM_VB_CFG0_VB12EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB12EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB12EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB12EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB12EN_ENABLED_ENUM_VAL         (1U)

/* Field VB13EN: Enable measurement of balance voltage 13. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB13EN_SHIFT                    (0xDU)
#define MC33774_SECM_VB_CFG0_VB13EN_MASK                     (0x2000U)
#define MC33774_SECM_VB_CFG0_VB13EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB13EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB13EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB13EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB13EN_ENABLED_ENUM_VAL         (1U)

/* Field VB14EN: Enable measurement of balance voltage 14. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB14EN_SHIFT                    (0xEU)
#define MC33774_SECM_VB_CFG0_VB14EN_MASK                     (0x4000U)
#define MC33774_SECM_VB_CFG0_VB14EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB14EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB14EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB14EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB14EN_ENABLED_ENUM_VAL         (1U)

/* Field VB15EN: Enable measurement of balance voltage 15. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG0_VB15EN_SHIFT                    (0xFU)
#define MC33774_SECM_VB_CFG0_VB15EN_MASK                     (0x8000U)
#define MC33774_SECM_VB_CFG0_VB15EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG0_VB15EN_SHIFT)) & MC33774_SECM_VB_CFG0_VB15EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG0_VB15EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG0_VB15EN_ENABLED_ENUM_VAL         (1U)

/* --------------------------------------------------------------------------
 * SECM_VB_CFG1 (read-write):balance voltage measurement enable
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_VB_CFG1_OFFSET                          (0x1C09U)
#define MC33774_SECM_VB_CFG1_RW_MASK                         (0x3U)
#define MC33774_SECM_VB_CFG1_RD_MASK                         (0x3U)
#define MC33774_SECM_VB_CFG1_WR_MASK                         (0x3U)
#define MC33774_SECM_VB_CFG1_MW_MASK                         (0x0U)
#define MC33774_SECM_VB_CFG1_RA_MASK                         (0x0U)
#define MC33774_SECM_VB_CFG1_POR_MASK                        (0xFFFFU)
#define MC33774_SECM_VB_CFG1_POR_VAL                         (0x0U)

/* Field VB16EN: Enable measurement of balance voltage 16. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG1_VB16EN_SHIFT                    (0x0U)
#define MC33774_SECM_VB_CFG1_VB16EN_MASK                     (0x1U)
#define MC33774_SECM_VB_CFG1_VB16EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG1_VB16EN_SHIFT)) & MC33774_SECM_VB_CFG1_VB16EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG1_VB16EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG1_VB16EN_ENABLED_ENUM_VAL         (1U)

/* Field VB17EN: Enable measurement of balance voltage 17. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_VB_CFG1_VB17EN_SHIFT                    (0x1U)
#define MC33774_SECM_VB_CFG1_VB17EN_MASK                     (0x2U)
#define MC33774_SECM_VB_CFG1_VB17EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG1_VB17EN_SHIFT)) & MC33774_SECM_VB_CFG1_VB17EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_VB_CFG1_VB17EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled */
#define MC33774_SECM_VB_CFG1_VB17EN_ENABLED_ENUM_VAL         (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_VB_CFG1_RESERVED0_SHIFT                 (0x2U)
#define MC33774_SECM_VB_CFG1_RESERVED0_MASK                  (0xFFFCU)
#define MC33774_SECM_VB_CFG1_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VB_CFG1_RESERVED0_SHIFT)) & MC33774_SECM_VB_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * SECM_AIN_CFG (read-write):measurement enables for extra channel
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_AIN_CFG_OFFSET                          (0x1C0AU)
#define MC33774_SECM_AIN_CFG_RW_MASK                         (0xFF8FU)
#define MC33774_SECM_AIN_CFG_RD_MASK                         (0xFF8FU)
#define MC33774_SECM_AIN_CFG_WR_MASK                         (0xFF8FU)
#define MC33774_SECM_AIN_CFG_MW_MASK                         (0x0U)
#define MC33774_SECM_AIN_CFG_RA_MASK                         (0x0U)
#define MC33774_SECM_AIN_CFG_POR_MASK                        (0xFFFFU)
#define MC33774_SECM_AIN_CFG_POR_VAL                         (0x80U)

/* Field AIN4EN: Enable measurement of AIN4. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_AIN4EN_SHIFT                    (0x0U)
#define MC33774_SECM_AIN_CFG_AIN4EN_MASK                     (0x1U)
#define MC33774_SECM_AIN_CFG_AIN4EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_AIN4EN_SHIFT)) & MC33774_SECM_AIN_CFG_AIN4EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_AIN_CFG_AIN4EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_SECM_AIN_CFG_AIN4EN_ENABLED_ENUM_VAL         (1U)

/* Field AIN5EN: Enable measurement of AIN5. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_AIN5EN_SHIFT                    (0x1U)
#define MC33774_SECM_AIN_CFG_AIN5EN_MASK                     (0x2U)
#define MC33774_SECM_AIN_CFG_AIN5EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_AIN5EN_SHIFT)) & MC33774_SECM_AIN_CFG_AIN5EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_AIN_CFG_AIN5EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_SECM_AIN_CFG_AIN5EN_ENABLED_ENUM_VAL         (1U)

/* Field AIN6EN: Enable measurement of AIN6. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_AIN6EN_SHIFT                    (0x2U)
#define MC33774_SECM_AIN_CFG_AIN6EN_MASK                     (0x4U)
#define MC33774_SECM_AIN_CFG_AIN6EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_AIN6EN_SHIFT)) & MC33774_SECM_AIN_CFG_AIN6EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_AIN_CFG_AIN6EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_SECM_AIN_CFG_AIN6EN_ENABLED_ENUM_VAL         (1U)

/* Field AIN7EN: Enable measurement of AIN7. Changes to this bit during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_AIN7EN_SHIFT                    (0x3U)
#define MC33774_SECM_AIN_CFG_AIN7EN_MASK                     (0x8U)
#define MC33774_SECM_AIN_CFG_AIN7EN_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_AIN7EN_SHIFT)) & MC33774_SECM_AIN_CFG_AIN7EN_MASK))

/* Enumerated value DISABLED: Measurement disabled */
#define MC33774_SECM_AIN_CFG_AIN7EN_DISABLED_ENUM_VAL        (0U)

/* Enumerated value ENABLED: Measurement enabled. If a GPIO output function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in the GPIO output enable bit. */
#define MC33774_SECM_AIN_CFG_AIN7EN_ENABLED_ENUM_VAL         (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_AIN_CFG_RESERVED0_SHIFT                 (0x4U)
#define MC33774_SECM_AIN_CFG_RESERVED0_MASK                  (0x70U)
#define MC33774_SECM_AIN_CFG_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_RESERVED0_SHIFT)) & MC33774_SECM_AIN_CFG_RESERVED0_MASK))

/* Field FLTAPPINV: Invalidate AINx application results in case of fault. */
#define MC33774_SECM_AIN_CFG_FLTAPPINV_SHIFT                 (0x7U)
#define MC33774_SECM_AIN_CFG_FLTAPPINV_MASK                  (0x80U)
#define MC33774_SECM_AIN_CFG_FLTAPPINV_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_FLTAPPINV_SHIFT)) & MC33774_SECM_AIN_CFG_FLTAPPINV_MASK))

/* Enumerated value VALID: AINx application results are not invalidated in case of a fault */
#define MC33774_SECM_AIN_CFG_FLTAPPINV_VALID_ENUM_VAL        (0U)

/* Enumerated value INVALID: AINx application results are invalidated when a fault is detected. */
#define MC33774_SECM_AIN_CFG_FLTAPPINV_INVALID_ENUM_VAL      (1U)

/* Field RATIOMETRICAIN4: Reference selection for AIN4. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_SHIFT           (0x8U)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_MASK            (0x300U)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_SHIFT)) & MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_MASK))

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_VDDC_ENUM_VAL   (3U)

/* Field RATIOMETRICAIN5: Reference selection for AIN5. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_SHIFT           (0xAU)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_MASK            (0xC00U)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_SHIFT)) & MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_MASK))

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_VDDC_ENUM_VAL   (3U)

/* Field RATIOMETRICAIN6: Reference selection for AIN6. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_SHIFT           (0xCU)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_MASK            (0x3000U)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_SHIFT)) & MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_MASK))

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_VDDC_ENUM_VAL   (3U)

/* Field RATIOMETRICAIN7: Reference selection for AIN7. Changes to these bits during active measurement can lead to undefined results. */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_SHIFT           (0xEU)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_MASK            (0xC000U)
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_SHIFT)) & MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_MASK))

/* Enumerated value SECVREF: Absolute (SECVREF) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_SECVREF_ENUM_VAL \
  (0U)

/* Enumerated value RESERVED: reserved */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_RESERVED_ENUM_VAL \
  (1U)

/* Enumerated value VAUX: Ratiometric (VAUX) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_VAUX_ENUM_VAL   (2U)

/* Enumerated value VDDC: Ratiometric (VDDC) */
#define MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_VDDC_ENUM_VAL   (3U)

/* --------------------------------------------------------------------------
 * SECM_AIN_OL_CFG (read-write):AINx open-load detection enable
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_AIN_OL_CFG_OFFSET                       (0x1C0BU)
#define MC33774_SECM_AIN_OL_CFG_RW_MASK                      (0xFU)
#define MC33774_SECM_AIN_OL_CFG_RD_MASK                      (0xFU)
#define MC33774_SECM_AIN_OL_CFG_WR_MASK                      (0xFU)
#define MC33774_SECM_AIN_OL_CFG_MW_MASK                      (0x0U)
#define MC33774_SECM_AIN_OL_CFG_RA_MASK                      (0x0U)
#define MC33774_SECM_AIN_OL_CFG_POR_MASK                     (0xFFFFU)
#define MC33774_SECM_AIN_OL_CFG_POR_VAL                      (0x0U)

/* Field AIN4EN: open-load detection circuit for AIN4 */
#define MC33774_SECM_AIN_OL_CFG_AIN4EN_SHIFT                 (0x0U)
#define MC33774_SECM_AIN_OL_CFG_AIN4EN_MASK                  (0x1U)
#define MC33774_SECM_AIN_OL_CFG_AIN4EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_OL_CFG_AIN4EN_SHIFT)) & MC33774_SECM_AIN_OL_CFG_AIN4EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN4EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN4EN_ENABLED_ENUM_VAL      (1U)

/* Field AIN5EN: open-load detection circuit for AIN5 */
#define MC33774_SECM_AIN_OL_CFG_AIN5EN_SHIFT                 (0x1U)
#define MC33774_SECM_AIN_OL_CFG_AIN5EN_MASK                  (0x2U)
#define MC33774_SECM_AIN_OL_CFG_AIN5EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_OL_CFG_AIN5EN_SHIFT)) & MC33774_SECM_AIN_OL_CFG_AIN5EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN5EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN5EN_ENABLED_ENUM_VAL      (1U)

/* Field AIN6EN: open-load detection circuit for AIN6 */
#define MC33774_SECM_AIN_OL_CFG_AIN6EN_SHIFT                 (0x2U)
#define MC33774_SECM_AIN_OL_CFG_AIN6EN_MASK                  (0x4U)
#define MC33774_SECM_AIN_OL_CFG_AIN6EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_OL_CFG_AIN6EN_SHIFT)) & MC33774_SECM_AIN_OL_CFG_AIN6EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN6EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN6EN_ENABLED_ENUM_VAL      (1U)

/* Field AIN7EN: open-load detection circuit for AIN7 */
#define MC33774_SECM_AIN_OL_CFG_AIN7EN_SHIFT                 (0x3U)
#define MC33774_SECM_AIN_OL_CFG_AIN7EN_MASK                  (0x8U)
#define MC33774_SECM_AIN_OL_CFG_AIN7EN_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_OL_CFG_AIN7EN_SHIFT)) & MC33774_SECM_AIN_OL_CFG_AIN7EN_MASK))

/* Enumerated value DISABLED: Disable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN7EN_DISABLED_ENUM_VAL     (0U)

/* Enumerated value ENABLED: Enable the open-load detection circuit. */
#define MC33774_SECM_AIN_OL_CFG_AIN7EN_ENABLED_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_AIN_OL_CFG_RESERVED0_SHIFT              (0x4U)
#define MC33774_SECM_AIN_OL_CFG_RESERVED0_MASK               (0xFFF0U)
#define MC33774_SECM_AIN_OL_CFG_RESERVED0_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SECM_AIN_OL_CFG_RESERVED0_SHIFT)) & MC33774_SECM_AIN_OL_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * SECM_VBUF_CFG (read-write):voltage buffer enable
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_VBUF_CFG_OFFSET                         (0x1C0CU)
#define MC33774_SECM_VBUF_CFG_RW_MASK                        (0x3U)
#define MC33774_SECM_VBUF_CFG_RD_MASK                        (0x3U)
#define MC33774_SECM_VBUF_CFG_WR_MASK                        (0x3U)
#define MC33774_SECM_VBUF_CFG_MW_MASK                        (0x0U)
#define MC33774_SECM_VBUF_CFG_RA_MASK                        (0x0U)
#define MC33774_SECM_VBUF_CFG_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_VBUF_CFG_POR_VAL                        (0x3U)

/* Field VAUXEN: Enable the voltage buffer for secondary VAUX measurement. */
#define MC33774_SECM_VBUF_CFG_VAUXEN_SHIFT                   (0x0U)
#define MC33774_SECM_VBUF_CFG_VAUXEN_MASK                    (0x1U)
#define MC33774_SECM_VBUF_CFG_VAUXEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VBUF_CFG_VAUXEN_SHIFT)) & MC33774_SECM_VBUF_CFG_VAUXEN_MASK))

/* Enumerated value DISABLED: Voltage buffer for VAUX is disabled. */
#define MC33774_SECM_VBUF_CFG_VAUXEN_DISABLED_ENUM_VAL       (0U)

/* Enumerated value ENABLED: Voltage buffer for VAUX is enabled. */
#define MC33774_SECM_VBUF_CFG_VAUXEN_ENABLED_ENUM_VAL        (1U)

/* Field VDDCEN: Enable the voltage buffer for secondary VDDC measurement. */
#define MC33774_SECM_VBUF_CFG_VDDCEN_SHIFT                   (0x1U)
#define MC33774_SECM_VBUF_CFG_VDDCEN_MASK                    (0x2U)
#define MC33774_SECM_VBUF_CFG_VDDCEN_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VBUF_CFG_VDDCEN_SHIFT)) & MC33774_SECM_VBUF_CFG_VDDCEN_MASK))

/* Enumerated value DISABLED: Voltage buffer for VDDC is disabled. */
#define MC33774_SECM_VBUF_CFG_VDDCEN_DISABLED_ENUM_VAL       (0U)

/* Enumerated value ENABLED: Voltage buffer for VDDC is enabled. */
#define MC33774_SECM_VBUF_CFG_VDDCEN_ENABLED_ENUM_VAL        (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_VBUF_CFG_RESERVED0_SHIFT                (0x2U)
#define MC33774_SECM_VBUF_CFG_RESERVED0_MASK                 (0xFFFCU)
#define MC33774_SECM_VBUF_CFG_RESERVED0_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_SECM_VBUF_CFG_RESERVED0_SHIFT)) & MC33774_SECM_VBUF_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * SECM_CAL_CRC (read-write):CRC over calibration data
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_CAL_CRC_OFFSET                          (0x1C20U)
#define MC33774_SECM_CAL_CRC_RW_MASK                         (0xFFFFU)
#define MC33774_SECM_CAL_CRC_RD_MASK                         (0xFFFFU)
#define MC33774_SECM_CAL_CRC_WR_MASK                         (0xFFFFU)
#define MC33774_SECM_CAL_CRC_MW_MASK                         (0x0U)
#define MC33774_SECM_CAL_CRC_RA_MASK                         (0x0U)
#define MC33774_SECM_CAL_CRC_POR_MASK                        (0xFFFFU)
#define MC33774_SECM_CAL_CRC_POR_VAL                         (0x0U)

/* Field CRC: CRC over calibration data. The CRC calculation runs automatically every time when a synchronous measurement cycle is started and when the calibration data is read from the NVM. */
#define MC33774_SECM_CAL_CRC_CRC_SHIFT                       (0x0U)
#define MC33774_SECM_CAL_CRC_CRC_MASK                        (0xFFFFU)
#define MC33774_SECM_CAL_CRC_CRC_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SECM_CAL_CRC_CRC_SHIFT)) & MC33774_SECM_CAL_CRC_CRC_MASK))

/* Enumerated value CALIBCRC: The expected value of the calibration CRC. */
#define MC33774_SECM_CAL_CRC_CRC_CALIBCRC_ENUM_VAL           (48879U)

/* --------------------------------------------------------------------------
 * SECM_CFG_CRC (read-only):CRC over configuration values
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_CFG_CRC_OFFSET                          (0x1C21U)
#define MC33774_SECM_CFG_CRC_RW_MASK                         (0x0U)
#define MC33774_SECM_CFG_CRC_RD_MASK                         (0xFFFFU)
#define MC33774_SECM_CFG_CRC_WR_MASK                         (0x0U)
#define MC33774_SECM_CFG_CRC_MW_MASK                         (0x0U)
#define MC33774_SECM_CFG_CRC_RA_MASK                         (0x0U)
#define MC33774_SECM_CFG_CRC_POR_MASK                        (0xFFFFU)
#define MC33774_SECM_CFG_CRC_POR_VAL                         (0x0U)

/* Field CRC: This CRC value is recalculated with any write to a covered register. The updated CRC value is available latest 100us after the last write.
The CRC value is application specific and must be re-calculated by the MCU. The used polynomial is: 0xD175 (+1) = X^16 + X^15 + X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1.
Following registers are included:  SECM_CFG, SECM_PER_CTRL, SECM_VB_CFG0, SECM_VB_CFG1, SECM_AIN_CFG, SECM_VBUF_CFG. */
#define MC33774_SECM_CFG_CRC_CRC_SHIFT                       (0x0U)
#define MC33774_SECM_CFG_CRC_CRC_MASK                        (0xFFFFU)
#define MC33774_SECM_CFG_CRC_CRC_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SECM_CFG_CRC_CRC_SHIFT)) & MC33774_SECM_CFG_CRC_CRC_MASK))

/* --------------------------------------------------------------------------
 * SECM_MEAS_STAT (read-only):measurement status
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_MEAS_STAT_OFFSET                        (0x1C3EU)
#define MC33774_SECM_MEAS_STAT_RW_MASK                       (0x0U)
#define MC33774_SECM_MEAS_STAT_RD_MASK                       (0xF70FU)
#define MC33774_SECM_MEAS_STAT_WR_MASK                       (0x0U)
#define MC33774_SECM_MEAS_STAT_MW_MASK                       (0x0U)
#define MC33774_SECM_MEAS_STAT_RA_MASK                       (0x0U)
#define MC33774_SECM_MEAS_STAT_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_MEAS_STAT_POR_VAL                       (0x0U)

/* Field APPRDYAIN4: A new AIN4 application result can be requested / captured. */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN4_SHIFT              (0x0U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN4_MASK               (0x1U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN4_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_APPRDYAIN4_SHIFT)) & MC33774_SECM_MEAS_STAT_APPRDYAIN4_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN4_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN4_DATA_ENUM_VAL      (1U)

/* Field APPRDYAIN5: A new AIN5 application result can be requested / captured. */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN5_SHIFT              (0x1U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN5_MASK               (0x2U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN5_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_APPRDYAIN5_SHIFT)) & MC33774_SECM_MEAS_STAT_APPRDYAIN5_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN5_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN5_DATA_ENUM_VAL      (1U)

/* Field APPRDYAIN6: A new AIN6 application result can be requested / captured. */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN6_SHIFT              (0x2U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN6_MASK               (0x4U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN6_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_APPRDYAIN6_SHIFT)) & MC33774_SECM_MEAS_STAT_APPRDYAIN6_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN6_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN6_DATA_ENUM_VAL      (1U)

/* Field APPRDYAIN7: A new AIN7 application result can be requested / captured. */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN7_SHIFT              (0x3U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN7_MASK               (0x8U)
#define MC33774_SECM_MEAS_STAT_APPRDYAIN7_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_APPRDYAIN7_SHIFT)) & MC33774_SECM_MEAS_STAT_APPRDYAIN7_MASK))

/* Enumerated value NO_DATA: No data available (<16 sample) */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN7_NO_DATA_ENUM_VAL   (0U)

/* Enumerated value DATA: Data can be captured (>=16 samples are captured). */
#define MC33774_SECM_MEAS_STAT_APPRDYAIN7_DATA_ENUM_VAL      (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_MEAS_STAT_RESERVED0_SHIFT               (0x4U)
#define MC33774_SECM_MEAS_STAT_RESERVED0_MASK                (0xF0U)
#define MC33774_SECM_MEAS_STAT_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_RESERVED0_SHIFT)) & MC33774_SECM_MEAS_STAT_RESERVED0_MASK))

/* Field PERRDY: New periodic result data has been created (depending on the periodic update mode, they might need to be requested),
the bit is cleared by a read to any register in the range SECM_PER_AIN4 to SECM_PER_NPNISENSE if SECM_PER_CTRL.PERCTRL is set to AUTO. If SECM_PER_CTRL.PERCTRL is set to ONCE, a write to SECM_PER_CTRL.PERCTRL == ONCE clears it. */
#define MC33774_SECM_MEAS_STAT_PERRDY_SHIFT                  (0x8U)
#define MC33774_SECM_MEAS_STAT_PERRDY_MASK                   (0x100U)
#define MC33774_SECM_MEAS_STAT_PERRDY_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_PERRDY_SHIFT)) & MC33774_SECM_MEAS_STAT_PERRDY_MASK))

/* Enumerated value NO_DATA: No data available */
#define MC33774_SECM_MEAS_STAT_PERRDY_NO_DATA_ENUM_VAL       (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33774_SECM_MEAS_STAT_PERRDY_DATA_ENUM_VAL          (1U)

/* Field SYNCRDY: Synchronous measurement data is ready for readout, the bit is cleared by a read to any register in the range SECM_SYNC_VB0 to SECM_SYNC_VB17 or if a fast VB measurement cycle is completed. */
#define MC33774_SECM_MEAS_STAT_SYNCRDY_SHIFT                 (0x9U)
#define MC33774_SECM_MEAS_STAT_SYNCRDY_MASK                  (0x200U)
#define MC33774_SECM_MEAS_STAT_SYNCRDY_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_SYNCRDY_SHIFT)) & MC33774_SECM_MEAS_STAT_SYNCRDY_MASK))

/* Enumerated value NO_DATA: No data available */
#define MC33774_SECM_MEAS_STAT_SYNCRDY_NO_DATA_ENUM_VAL      (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33774_SECM_MEAS_STAT_SYNCRDY_DATA_ENUM_VAL         (1U)

/* Field FASTVBRDY: Fast VB measurement data is ready for readout, the bit is cleared by a read to any register in the range SECM_SYNC_VB0 to SECM_SYNC_VB17 or if a synchronous measurement cycle is completed. */
#define MC33774_SECM_MEAS_STAT_FASTVBRDY_SHIFT               (0xAU)
#define MC33774_SECM_MEAS_STAT_FASTVBRDY_MASK                (0x400U)
#define MC33774_SECM_MEAS_STAT_FASTVBRDY_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_FASTVBRDY_SHIFT)) & MC33774_SECM_MEAS_STAT_FASTVBRDY_MASK))

/* Enumerated value NO_DATA: No data available */
#define MC33774_SECM_MEAS_STAT_FASTVBRDY_NO_DATA_ENUM_VAL    (0U)

/* Enumerated value DATA: Sample data available. */
#define MC33774_SECM_MEAS_STAT_FASTVBRDY_DATA_ENUM_VAL       (1U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_SECM_MEAS_STAT_RESERVED1_SHIFT               (0xBU)
#define MC33774_SECM_MEAS_STAT_RESERVED1_MASK                (0x800U)
#define MC33774_SECM_MEAS_STAT_RESERVED1_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_RESERVED1_SHIFT)) & MC33774_SECM_MEAS_STAT_RESERVED1_MASK))

/* Field SUPPLYFLT: Internal/external supply fault status */
#define MC33774_SECM_MEAS_STAT_SUPPLYFLT_SHIFT               (0xCU)
#define MC33774_SECM_MEAS_STAT_SUPPLYFLT_MASK                (0x1000U)
#define MC33774_SECM_MEAS_STAT_SUPPLYFLT_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_SUPPLYFLT_SHIFT)) & MC33774_SECM_MEAS_STAT_SUPPLYFLT_MASK))

/* Enumerated value NO_FLT: No supply error detected */
#define MC33774_SECM_MEAS_STAT_SUPPLYFLT_NO_FLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Supply error detected */
#define MC33774_SECM_MEAS_STAT_SUPPLYFLT_FAULT_ENUM_VAL      (1U)

/* Field ANAFLT: Analog fault status */
#define MC33774_SECM_MEAS_STAT_ANAFLT_SHIFT                  (0xDU)
#define MC33774_SECM_MEAS_STAT_ANAFLT_MASK                   (0x2000U)
#define MC33774_SECM_MEAS_STAT_ANAFLT_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_ANAFLT_SHIFT)) & MC33774_SECM_MEAS_STAT_ANAFLT_MASK))

/* Enumerated value NO_FLT: No analog fault detected */
#define MC33774_SECM_MEAS_STAT_ANAFLT_NO_FLT_ENUM_VAL        (0U)

/* Enumerated value FAULT: Analog fault detected */
#define MC33774_SECM_MEAS_STAT_ANAFLT_FAULT_ENUM_VAL         (1U)

/* Field COMFLT: Communication fault status */
#define MC33774_SECM_MEAS_STAT_COMFLT_SHIFT                  (0xEU)
#define MC33774_SECM_MEAS_STAT_COMFLT_MASK                   (0x4000U)
#define MC33774_SECM_MEAS_STAT_COMFLT_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_COMFLT_SHIFT)) & MC33774_SECM_MEAS_STAT_COMFLT_MASK))

/* Enumerated value NO_FLT: No communication fault detected */
#define MC33774_SECM_MEAS_STAT_COMFLT_NO_FLT_ENUM_VAL        (0U)

/* Enumerated value FAULT: Communication fault detected. */
#define MC33774_SECM_MEAS_STAT_COMFLT_FAULT_ENUM_VAL         (1U)

/* Field MEASFLT: Measurement fault status */
#define MC33774_SECM_MEAS_STAT_MEASFLT_SHIFT                 (0xFU)
#define MC33774_SECM_MEAS_STAT_MEASFLT_MASK                  (0x8000U)
#define MC33774_SECM_MEAS_STAT_MEASFLT_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_MEAS_STAT_MEASFLT_SHIFT)) & MC33774_SECM_MEAS_STAT_MEASFLT_MASK))

/* Enumerated value NO_FLT: No measurement fault detected */
#define MC33774_SECM_MEAS_STAT_MEASFLT_NO_FLT_ENUM_VAL       (0U)

/* Enumerated value FAULT: Measurement fault detected */
#define MC33774_SECM_MEAS_STAT_MEASFLT_FAULT_ENUM_VAL        (1U)

/* --------------------------------------------------------------------------
 * SECM_APP_AIN4 (read-only):application measurement result AIN4
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_APP_AIN4_OFFSET                         (0x1C53U)
#define MC33774_SECM_APP_AIN4_RW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN4_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_APP_AIN4_WR_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN4_MW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN4_RA_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN4_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_APP_AIN4_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN4 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_APP_AIN4_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_APP_AIN4_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_APP_AIN4_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_AIN4_VALUE_SHIFT)) & MC33774_SECM_APP_AIN4_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_APP_AIN5 (read-only):application measurement result AIN5
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_APP_AIN5_OFFSET                         (0x1C54U)
#define MC33774_SECM_APP_AIN5_RW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN5_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_APP_AIN5_WR_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN5_MW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN5_RA_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN5_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_APP_AIN5_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN5 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_APP_AIN5_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_APP_AIN5_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_APP_AIN5_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_AIN5_VALUE_SHIFT)) & MC33774_SECM_APP_AIN5_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_APP_AIN6 (read-only):application measurement result AIN6
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_APP_AIN6_OFFSET                         (0x1C55U)
#define MC33774_SECM_APP_AIN6_RW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN6_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_APP_AIN6_WR_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN6_MW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN6_RA_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN6_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_APP_AIN6_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN6 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_APP_AIN6_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_APP_AIN6_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_APP_AIN6_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_AIN6_VALUE_SHIFT)) & MC33774_SECM_APP_AIN6_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_APP_AIN7 (read-only):application measurement result AIN7
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_APP_AIN7_OFFSET                         (0x1C56U)
#define MC33774_SECM_APP_AIN7_RW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN7_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_APP_AIN7_WR_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN7_MW_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN7_RA_MASK                        (0x0U)
#define MC33774_SECM_APP_AIN7_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_APP_AIN7_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN7 at the last application capture as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_APP_AIN7_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_APP_AIN7_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_APP_AIN7_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_APP_AIN7_VALUE_SHIFT)) & MC33774_SECM_APP_AIN7_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_NUM (read-only):measurement period number of the secondary periodic results
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_NUM_OFFSET                          (0x1C5FU)
#define MC33774_SECM_PER_NUM_RW_MASK                         (0x0U)
#define MC33774_SECM_PER_NUM_RD_MASK                         (0xFFFFU)
#define MC33774_SECM_PER_NUM_WR_MASK                         (0x0U)
#define MC33774_SECM_PER_NUM_MW_MASK                         (0x0U)
#define MC33774_SECM_PER_NUM_RA_MASK                         (0x0U)
#define MC33774_SECM_PER_NUM_POR_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_NUM_POR_VAL                         (0x0U)

/* Field NUM: Number of the periodic cycle in which the secondary periodic results have been created. The value is incremented for each periodic cycle executed. The counting wraps at its limit. */
#define MC33774_SECM_PER_NUM_NUM_SHIFT                       (0x0U)
#define MC33774_SECM_PER_NUM_NUM_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_NUM_NUM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_NUM_NUM_SHIFT)) & MC33774_SECM_PER_NUM_NUM_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_AIN4 (read-only):periodic measurement result AIN4
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_AIN4_OFFSET                         (0x1C73U)
#define MC33774_SECM_PER_AIN4_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN4_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_AIN4_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN4_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN4_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN4_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_AIN4_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN4 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_AIN4_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_AIN4_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_AIN4_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_AIN4_VALUE_SHIFT)) & MC33774_SECM_PER_AIN4_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_AIN5 (read-only):periodic measurement result AIN5
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_AIN5_OFFSET                         (0x1C74U)
#define MC33774_SECM_PER_AIN5_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN5_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_AIN5_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN5_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN5_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN5_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_AIN5_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN5 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_AIN5_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_AIN5_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_AIN5_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_AIN5_VALUE_SHIFT)) & MC33774_SECM_PER_AIN5_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_AIN6 (read-only):periodic measurement result AIN6
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_AIN6_OFFSET                         (0x1C75U)
#define MC33774_SECM_PER_AIN6_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN6_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_AIN6_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN6_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN6_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN6_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_AIN6_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN6 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_AIN6_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_AIN6_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_AIN6_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_AIN6_VALUE_SHIFT)) & MC33774_SECM_PER_AIN6_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_AIN7 (read-only):periodic measurement result AIN7
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_AIN7_OFFSET                         (0x1C76U)
#define MC33774_SECM_PER_AIN7_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN7_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_AIN7_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN7_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN7_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_AIN7_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_AIN7_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of AIN7 of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_AIN7_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_AIN7_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_AIN7_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_AIN7_VALUE_SHIFT)) & MC33774_SECM_PER_AIN7_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_SECTEMP (read-only):periodic measurement result secondary device temperature
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_SECTEMP_OFFSET                      (0x1C77U)
#define MC33774_SECM_PER_SECTEMP_RW_MASK                     (0x0U)
#define MC33774_SECM_PER_SECTEMP_RD_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_SECTEMP_WR_MASK                     (0x0U)
#define MC33774_SECM_PER_SECTEMP_MW_MASK                     (0x0U)
#define MC33774_SECM_PER_SECTEMP_RA_MASK                     (0x0U)
#define MC33774_SECM_PER_SECTEMP_POR_MASK                    (0xFFFFU)
#define MC33774_SECM_PER_SECTEMP_POR_VAL                     (0x8000U)

/* Field VALUE: Measured temperature of secondary temperature sensor of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_SECTEMP_VALUE_SHIFT                 (0x0U)
#define MC33774_SECM_PER_SECTEMP_VALUE_MASK                  (0xFFFFU)
#define MC33774_SECM_PER_SECTEMP_VALUE_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_SECTEMP_VALUE_SHIFT)) & MC33774_SECM_PER_SECTEMP_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_PRMVREF (read-only):periodic measurement result primary voltage reference
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_PRMVREF_OFFSET                      (0x1C78U)
#define MC33774_SECM_PER_PRMVREF_RW_MASK                     (0x0U)
#define MC33774_SECM_PER_PRMVREF_RD_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_PRMVREF_WR_MASK                     (0x0U)
#define MC33774_SECM_PER_PRMVREF_MW_MASK                     (0x0U)
#define MC33774_SECM_PER_PRMVREF_RA_MASK                     (0x0U)
#define MC33774_SECM_PER_PRMVREF_POR_MASK                    (0xFFFFU)
#define MC33774_SECM_PER_PRMVREF_POR_VAL                     (0x8000U)

/* Field VALUE: Measured voltage of the primary voltage reference of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_PRMVREF_VALUE_SHIFT                 (0x0U)
#define MC33774_SECM_PER_PRMVREF_VALUE_MASK                  (0xFFFFU)
#define MC33774_SECM_PER_PRMVREF_VALUE_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_PRMVREF_VALUE_SHIFT)) & MC33774_SECM_PER_PRMVREF_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_VAUX (read-only):periodic measurement result auxiliary supply voltage
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_VAUX_OFFSET                         (0x1C79U)
#define MC33774_SECM_PER_VAUX_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_VAUX_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_VAUX_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_VAUX_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_VAUX_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_VAUX_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_VAUX_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of VAUX of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_VAUX_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_VAUX_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_VAUX_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_VAUX_VALUE_SHIFT)) & MC33774_SECM_PER_VAUX_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_VBAT (read-only):periodic measurement result VBAT
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_VBAT_OFFSET                         (0x1C7AU)
#define MC33774_SECM_PER_VBAT_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_VBAT_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_VBAT_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_VBAT_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_VBAT_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_VBAT_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_VBAT_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of VBAT of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_VBAT_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_VBAT_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_VBAT_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_VBAT_VALUE_SHIFT)) & MC33774_SECM_PER_VBAT_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_VDDA (read-only):periodic measurement result VDDA
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_VDDA_OFFSET                         (0x1C7BU)
#define MC33774_SECM_PER_VDDA_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDA_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_VDDA_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDA_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDA_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDA_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_VDDA_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of VDDA of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_VDDA_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_VDDA_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_VDDA_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_VDDA_VALUE_SHIFT)) & MC33774_SECM_PER_VDDA_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_VDDC (read-only):periodic measurement result VDDC
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_VDDC_OFFSET                         (0x1C7CU)
#define MC33774_SECM_PER_VDDC_RW_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDC_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_PER_VDDC_WR_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDC_MW_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDC_RA_MASK                        (0x0U)
#define MC33774_SECM_PER_VDDC_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_PER_VDDC_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of VDDC of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_VDDC_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_PER_VDDC_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_PER_VDDC_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_VDDC_VALUE_SHIFT)) & MC33774_SECM_PER_VDDC_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_PER_NPNISENSE (read-only):periodic measurement result NPN current sensor
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_PER_NPNISENSE_OFFSET                    (0x1C7EU)
#define MC33774_SECM_PER_NPNISENSE_RW_MASK                   (0x0U)
#define MC33774_SECM_PER_NPNISENSE_RD_MASK                   (0xFFFFU)
#define MC33774_SECM_PER_NPNISENSE_WR_MASK                   (0x0U)
#define MC33774_SECM_PER_NPNISENSE_MW_MASK                   (0x0U)
#define MC33774_SECM_PER_NPNISENSE_RA_MASK                   (0x0U)
#define MC33774_SECM_PER_NPNISENSE_POR_MASK                  (0xFFFFU)
#define MC33774_SECM_PER_NPNISENSE_POR_VAL                   (0x8000U)

/* Field VALUE: Measured voltage of NPN current sensor of the periodic cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_PER_NPNISENSE_VALUE_SHIFT               (0x0U)
#define MC33774_SECM_PER_NPNISENSE_VALUE_MASK                (0xFFFFU)
#define MC33774_SECM_PER_NPNISENSE_VALUE_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_SECM_PER_NPNISENSE_VALUE_SHIFT)) & MC33774_SECM_PER_NPNISENSE_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_NUM (read-only):measurement number of the secondary synchronous results
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_NUM_OFFSET                         (0x1C7FU)
#define MC33774_SECM_SYNC_NUM_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_NUM_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_NUM_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_NUM_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_NUM_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_NUM_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_NUM_POR_VAL                        (0x0U)

/* Field NUM: Number of the synchronous cycle in which the secondary results have been created. The value is incremented for each synchronous cycle executed. The counting wraps at its limit. The value is not incremented for FASTVB cycle. */
#define MC33774_SECM_SYNC_NUM_NUM_SHIFT                      (0x0U)
#define MC33774_SECM_SYNC_NUM_NUM_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_NUM_NUM_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_NUM_NUM_SHIFT)) & MC33774_SECM_SYNC_NUM_NUM_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB0 (read-only):synchronous measurement result from balancing pins cell 0.
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB0_OFFSET                         (0x1C80U)
#define MC33774_SECM_SYNC_VB0_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB0_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB0_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB0_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB0_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB0_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB0_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 0 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB0_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB0_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB0_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB0_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB0_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB1 (read-only):synchronous measurement result from balancing pins cell 1
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB1_OFFSET                         (0x1C81U)
#define MC33774_SECM_SYNC_VB1_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB1_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB1_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB1_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB1_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB1_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB1_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 1 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB1_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB1_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB1_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB1_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB1_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB2 (read-only):synchronous measurement result from balancing pins cell 2
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB2_OFFSET                         (0x1C82U)
#define MC33774_SECM_SYNC_VB2_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB2_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB2_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB2_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB2_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB2_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB2_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 2 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB2_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB2_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB2_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB2_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB2_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB3 (read-only):synchronous measurement result from balancing pins cell 3
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB3_OFFSET                         (0x1C83U)
#define MC33774_SECM_SYNC_VB3_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB3_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB3_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB3_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB3_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB3_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB3_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 3 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB3_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB3_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB3_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB3_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB3_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB4 (read-only):synchronous measurement result from balancing pins cell 4
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB4_OFFSET                         (0x1C84U)
#define MC33774_SECM_SYNC_VB4_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB4_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB4_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB4_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB4_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB4_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB4_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 4 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB4_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB4_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB4_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB4_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB4_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB5 (read-only):synchronous measurement result from balancing pins cell 5
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB5_OFFSET                         (0x1C85U)
#define MC33774_SECM_SYNC_VB5_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB5_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB5_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB5_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB5_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB5_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB5_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 5 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB5_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB5_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB5_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB5_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB5_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB6 (read-only):synchronous measurement result from balancing pins cell 6
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB6_OFFSET                         (0x1C86U)
#define MC33774_SECM_SYNC_VB6_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB6_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB6_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB6_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB6_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB6_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB6_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 6 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB6_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB6_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB6_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB6_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB6_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB7 (read-only):synchronous measurement result from balancing pins cell 7
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB7_OFFSET                         (0x1C87U)
#define MC33774_SECM_SYNC_VB7_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB7_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB7_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB7_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB7_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB7_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB7_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 7 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB7_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB7_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB7_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB7_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB7_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB8 (read-only):synchronous measurement result from balancing pins cell 8
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB8_OFFSET                         (0x1C88U)
#define MC33774_SECM_SYNC_VB8_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB8_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB8_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB8_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB8_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB8_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB8_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 8 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB8_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB8_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB8_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB8_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB8_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB9 (read-only):synchronous measurement result from balancing pins cell 9
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB9_OFFSET                         (0x1C89U)
#define MC33774_SECM_SYNC_VB9_RW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB9_RD_MASK                        (0xFFFFU)
#define MC33774_SECM_SYNC_VB9_WR_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB9_MW_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB9_RA_MASK                        (0x0U)
#define MC33774_SECM_SYNC_VB9_POR_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB9_POR_VAL                        (0x8000U)

/* Field VALUE: Measured voltage of cell 9 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB9_VALUE_SHIFT                    (0x0U)
#define MC33774_SECM_SYNC_VB9_VALUE_MASK                     (0xFFFFU)
#define MC33774_SECM_SYNC_VB9_VALUE_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB9_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB9_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB10 (read-only):synchronous measurement result from balancing pins cell 10
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB10_OFFSET                        (0x1C8AU)
#define MC33774_SECM_SYNC_VB10_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB10_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB10_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB10_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB10_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB10_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB10_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 10 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB10_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB10_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB10_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB10_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB10_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB11 (read-only):synchronous measurement result from balancing pins cell 11
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB11_OFFSET                        (0x1C8BU)
#define MC33774_SECM_SYNC_VB11_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB11_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB11_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB11_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB11_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB11_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB11_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 11 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB11_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB11_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB11_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB11_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB11_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB12 (read-only):synchronous measurement result from balancing pins cell 12
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB12_OFFSET                        (0x1C8CU)
#define MC33774_SECM_SYNC_VB12_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB12_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB12_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB12_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB12_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB12_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB12_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 12 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB12_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB12_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB12_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB12_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB12_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB13 (read-only):synchronous measurement result from balancing pins cell 13
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB13_OFFSET                        (0x1C8DU)
#define MC33774_SECM_SYNC_VB13_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB13_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB13_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB13_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB13_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB13_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB13_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 13 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB13_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB13_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB13_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB13_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB13_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB14 (read-only):synchronous measurement result from balancing pins cell 14
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB14_OFFSET                        (0x1C8EU)
#define MC33774_SECM_SYNC_VB14_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB14_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB14_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB14_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB14_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB14_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB14_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 14 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB14_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB14_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB14_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB14_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB14_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB15 (read-only):synchronous measurement result from balancing pins cell 15
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB15_OFFSET                        (0x1C8FU)
#define MC33774_SECM_SYNC_VB15_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB15_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB15_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB15_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB15_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB15_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB15_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 15 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB15_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB15_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB15_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB15_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB15_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB16 (read-only):synchronous measurement result from balancing pins cell 16
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB16_OFFSET                        (0x1C90U)
#define MC33774_SECM_SYNC_VB16_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB16_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB16_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB16_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB16_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB16_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB16_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 16 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB16_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB16_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB16_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB16_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB16_VALUE_MASK))

/* --------------------------------------------------------------------------
 * SECM_SYNC_VB17 (read-only):synchronous measurement result from balancing pins cell 17
 * -------------------------------------------------------------------------- */
#define MC33774_SECM_SYNC_VB17_OFFSET                        (0x1C91U)
#define MC33774_SECM_SYNC_VB17_RW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB17_RD_MASK                       (0xFFFFU)
#define MC33774_SECM_SYNC_VB17_WR_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB17_MW_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB17_RA_MASK                       (0x0U)
#define MC33774_SECM_SYNC_VB17_POR_MASK                      (0xFFFFU)
#define MC33774_SECM_SYNC_VB17_POR_VAL                       (0x8000U)

/* Field VALUE: Measured voltage of cell 17 of the last synchronous cycle as signed integer. A read to this register sets its content to invalid (8000h). */
#define MC33774_SECM_SYNC_VB17_VALUE_SHIFT                   (0x0U)
#define MC33774_SECM_SYNC_VB17_VALUE_MASK                    (0xFFFFU)
#define MC33774_SECM_SYNC_VB17_VALUE_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_SECM_SYNC_VB17_VALUE_SHIFT)) & MC33774_SECM_SYNC_VB17_VALUE_MASK))

/* --------------------------------------------------------------------------
 * I2C_CFG (read-write):I2C configuration
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_CFG_OFFSET                               (0xC00U)
#define MC33774_I2C_CFG_RW_MASK                              (0x7U)
#define MC33774_I2C_CFG_RD_MASK                              (0x7U)
#define MC33774_I2C_CFG_WR_MASK                              (0x7U)
#define MC33774_I2C_CFG_MW_MASK                              (0x0U)
#define MC33774_I2C_CFG_RA_MASK                              (0x0U)
#define MC33774_I2C_CFG_POR_MASK                             (0xFFFFU)
#define MC33774_I2C_CFG_POR_VAL                              (0x0U)

/* Field EN: Enable I2C interface. If the I2C interface is disabled while it is active, a stop condition is created and the bus is released.
When enabling this bit the GPIO to which the I2C lines are connected are switched to the I2C function (input receiver active and open-drain output function). */
#define MC33774_I2C_CFG_EN_SHIFT                             (0x0U)
#define MC33774_I2C_CFG_EN_MASK                              (0x1U)
#define MC33774_I2C_CFG_EN_U16(x)                            (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CFG_EN_SHIFT)) & MC33774_I2C_CFG_EN_MASK))

/* Enumerated value DISABLED: Interface disabled */
#define MC33774_I2C_CFG_EN_DISABLED_ENUM_VAL                 (0U)

/* Enumerated value ENABLED: Interface enabled */
#define MC33774_I2C_CFG_EN_ENABLED_ENUM_VAL                  (1U)

/* Field CLKSEL: I2C clock selection */
#define MC33774_I2C_CFG_CLKSEL_SHIFT                         (0x1U)
#define MC33774_I2C_CFG_CLKSEL_MASK                          (0x6U)
#define MC33774_I2C_CFG_CLKSEL_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CFG_CLKSEL_SHIFT)) & MC33774_I2C_CFG_CLKSEL_MASK))

/* Enumerated value F_100k: Clock is 100 kHz */
#define MC33774_I2C_CFG_CLKSEL_F_100K_ENUM_VAL               (0U)

/* Enumerated value F_400k: Clock is 400 kHz */
#define MC33774_I2C_CFG_CLKSEL_F_400K_ENUM_VAL               (1U)

/* Enumerated value F_1000k: Clock is 1000 kHz */
#define MC33774_I2C_CFG_CLKSEL_F_1000K_ENUM_VAL              (2U)

/* Enumerated value RESERVED: Reserved. Do not use. */
#define MC33774_I2C_CFG_CLKSEL_RESERVED_ENUM_VAL             (3U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_I2C_CFG_RESERVED0_SHIFT                      (0x3U)
#define MC33774_I2C_CFG_RESERVED0_MASK                       (0xFFF8U)
#define MC33774_I2C_CFG_RESERVED0_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CFG_RESERVED0_SHIFT)) & MC33774_I2C_CFG_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * I2C_CTRL (read-write):I2C control
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_CTRL_OFFSET                              (0xC01U)
#define MC33774_I2C_CTRL_RW_MASK                             (0x3F7FU)
#define MC33774_I2C_CTRL_RD_MASK                             (0x3F7FU)
#define MC33774_I2C_CTRL_WR_MASK                             (0x3F7FU)
#define MC33774_I2C_CTRL_MW_MASK                             (0x0U)
#define MC33774_I2C_CTRL_RA_MASK                             (0x0U)
#define MC33774_I2C_CTRL_POR_MASK                            (0xFFFFU)
#define MC33774_I2C_CTRL_POR_VAL                             (0x0U)

/* Field START: Start the I2C transmission, by setting the number of bytes (including Dev. Address to be transmitted/read) */
#define MC33774_I2C_CTRL_START_SHIFT                         (0x0U)
#define MC33774_I2C_CTRL_START_MASK                          (0x3FU)
#define MC33774_I2C_CTRL_START_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CTRL_START_SHIFT)) & MC33774_I2C_CTRL_START_MASK))

/* Enumerated value SEND_1: Send one byte */
#define MC33774_I2C_CTRL_START_SEND_1_ENUM_VAL               (1U)

/* Enumerated value SEND_36: Send 36 bytes */
#define MC33774_I2C_CTRL_START_SEND_36_ENUM_VAL              (36U)

/* Enumerated value SEND_MAX: Send 36 bytes */
#define MC33774_I2C_CTRL_START_SEND_MAX_ENUM_VAL             (37U)

/* Field STPAFTER: Send a stop condition after the last byte. */
#define MC33774_I2C_CTRL_STPAFTER_SHIFT                      (0x6U)
#define MC33774_I2C_CTRL_STPAFTER_MASK                       (0x40U)
#define MC33774_I2C_CTRL_STPAFTER_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CTRL_STPAFTER_SHIFT)) & MC33774_I2C_CTRL_STPAFTER_MASK))

/* Enumerated value NO_STOP: No stop condition sent after last byte */
#define MC33774_I2C_CTRL_STPAFTER_NO_STOP_ENUM_VAL           (0U)

/* Enumerated value STOP: Stop condition sent after last byte */
#define MC33774_I2C_CTRL_STPAFTER_STOP_ENUM_VAL              (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_I2C_CTRL_RESERVED0_SHIFT                     (0x7U)
#define MC33774_I2C_CTRL_RESERVED0_MASK                      (0x80U)
#define MC33774_I2C_CTRL_RESERVED0_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CTRL_RESERVED0_SHIFT)) & MC33774_I2C_CTRL_RESERVED0_MASK))

/* Field RDAFTER: Switch to read (Repeated Start Condition after byte) 0 = off */
#define MC33774_I2C_CTRL_RDAFTER_SHIFT                       (0x8U)
#define MC33774_I2C_CTRL_RDAFTER_MASK                        (0x3F00U)
#define MC33774_I2C_CTRL_RDAFTER_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CTRL_RDAFTER_SHIFT)) & MC33774_I2C_CTRL_RDAFTER_MASK))

/* Enumerated value NO_READ: No switch to read. */
#define MC33774_I2C_CTRL_RDAFTER_NO_READ_ENUM_VAL            (0U)

/* Enumerated value READ_1: Switch to read after 1 byte */
#define MC33774_I2C_CTRL_RDAFTER_READ_1_ENUM_VAL             (1U)

/* Enumerated value READ_36: Switch to read after 36 bytes */
#define MC33774_I2C_CTRL_RDAFTER_READ_36_ENUM_VAL            (36U)

/* Enumerated value RESERVED: Reserved. Do not use. */
#define MC33774_I2C_CTRL_RDAFTER_RESERVED_ENUM_VAL           (37U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_I2C_CTRL_RESERVED1_SHIFT                     (0xEU)
#define MC33774_I2C_CTRL_RESERVED1_MASK                      (0xC000U)
#define MC33774_I2C_CTRL_RESERVED1_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_I2C_CTRL_RESERVED1_SHIFT)) & MC33774_I2C_CTRL_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * I2C_STAT (read-only):I2C status
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_STAT_OFFSET                              (0xC02U)
#define MC33774_I2C_STAT_RW_MASK                             (0x0U)
#define MC33774_I2C_STAT_RD_MASK                             (0x3F0FU)
#define MC33774_I2C_STAT_WR_MASK                             (0x0U)
#define MC33774_I2C_STAT_MW_MASK                             (0x0U)
#define MC33774_I2C_STAT_RA_MASK                             (0x0U)
#define MC33774_I2C_STAT_POR_MASK                            (0xFFFFU)
#define MC33774_I2C_STAT_POR_VAL                             (0x0U)

/* Field PENDING: I2C execution pending */
#define MC33774_I2C_STAT_PENDING_SHIFT                       (0x0U)
#define MC33774_I2C_STAT_PENDING_MASK                        (0x1U)
#define MC33774_I2C_STAT_PENDING_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_STAT_PENDING_SHIFT)) & MC33774_I2C_STAT_PENDING_MASK))

/* Enumerated value NO_TRX: No transfer is in execution, data registers can be accessed */
#define MC33774_I2C_STAT_PENDING_NO_TRX_ENUM_VAL             (0U)

/* Enumerated value TRX: A transfer is in execution, no access to the data registers is allowed */
#define MC33774_I2C_STAT_PENDING_TRX_ENUM_VAL                (1U)

/* Field ACTIVE: I2C transmission active */
#define MC33774_I2C_STAT_ACTIVE_SHIFT                        (0x1U)
#define MC33774_I2C_STAT_ACTIVE_MASK                         (0x2U)
#define MC33774_I2C_STAT_ACTIVE_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_STAT_ACTIVE_SHIFT)) & MC33774_I2C_STAT_ACTIVE_MASK))

/* Enumerated value NO_TRX: No transaction is ongoing. */
#define MC33774_I2C_STAT_ACTIVE_NO_TRX_ENUM_VAL              (0U)

/* Enumerated value TRX: A transaction is ongoing (no STOP condition so far), bus is held with SCL low */
#define MC33774_I2C_STAT_ACTIVE_TRX_ENUM_VAL                 (1U)

/* Field NACKRCV: NACK received */
#define MC33774_I2C_STAT_NACKRCV_SHIFT                       (0x2U)
#define MC33774_I2C_STAT_NACKRCV_MASK                        (0x4U)
#define MC33774_I2C_STAT_NACKRCV_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_STAT_NACKRCV_SHIFT)) & MC33774_I2C_STAT_NACKRCV_MASK))

/* Enumerated value NO_NACK: No NACK was received */
#define MC33774_I2C_STAT_NACKRCV_NO_NACK_ENUM_VAL            (0U)

/* Enumerated value NACK: A NACK was received */
#define MC33774_I2C_STAT_NACKRCV_NACK_ENUM_VAL               (1U)

/* Field ARBLOST: Wrong data bit */
#define MC33774_I2C_STAT_ARBLOST_SHIFT                       (0x3U)
#define MC33774_I2C_STAT_ARBLOST_MASK                        (0x8U)
#define MC33774_I2C_STAT_ARBLOST_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_STAT_ARBLOST_SHIFT)) & MC33774_I2C_STAT_ARBLOST_MASK))

/* Enumerated value NO_FLT: No wrong data bits detected */
#define MC33774_I2C_STAT_ARBLOST_NO_FLT_ENUM_VAL             (0U)

/* Enumerated value FAULT: A wrong data bit was detected */
#define MC33774_I2C_STAT_ARBLOST_FAULT_ENUM_VAL              (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_I2C_STAT_RESERVED0_SHIFT                     (0x4U)
#define MC33774_I2C_STAT_RESERVED0_MASK                      (0xF0U)
#define MC33774_I2C_STAT_RESERVED0_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_I2C_STAT_RESERVED0_SHIFT)) & MC33774_I2C_STAT_RESERVED0_MASK))

/* Field LEN: number of bytes transferred until NACK received */
#define MC33774_I2C_STAT_LEN_SHIFT                           (0x8U)
#define MC33774_I2C_STAT_LEN_MASK                            (0x3F00U)
#define MC33774_I2C_STAT_LEN_U16(x)                          (((uint16_t)(((uint16_t)(x) << MC33774_I2C_STAT_LEN_SHIFT)) & MC33774_I2C_STAT_LEN_MASK))

/* Enumerated value NACK_0: No bytes transmitted until NACK was received */
#define MC33774_I2C_STAT_LEN_NACK_0_ENUM_VAL                 (0U)

/* Enumerated value NACK_1: 1 byte transmitted until NACK was received */
#define MC33774_I2C_STAT_LEN_NACK_1_ENUM_VAL                 (1U)

/* Enumerated value NACK_36: 36 bytes transmitted until NACK was received */
#define MC33774_I2C_STAT_LEN_NACK_36_ENUM_VAL                (36U)

/* Enumerated value RESERVED: Reserved. Not used. */
#define MC33774_I2C_STAT_LEN_RESERVED_ENUM_VAL               (37U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_I2C_STAT_RESERVED1_SHIFT                     (0xEU)
#define MC33774_I2C_STAT_RESERVED1_MASK                      (0xC000U)
#define MC33774_I2C_STAT_RESERVED1_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_I2C_STAT_RESERVED1_SHIFT)) & MC33774_I2C_STAT_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA0 (read-write):I2C data register 0
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA0_OFFSET                             (0xC04U)
#define MC33774_I2C_DATA0_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA0_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA0_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA0_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA0_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA0_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA0_POR_VAL                            (0x0U)

/* Field BYTE0: I2C data byte 0 (for example device address) */
#define MC33774_I2C_DATA0_BYTE0_SHIFT                        (0x0U)
#define MC33774_I2C_DATA0_BYTE0_MASK                         (0xFFU)
#define MC33774_I2C_DATA0_BYTE0_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA0_BYTE0_SHIFT)) & MC33774_I2C_DATA0_BYTE0_MASK))

/* Field BYTE1: I2C data byte 1 (for example data or sub address) */
#define MC33774_I2C_DATA0_BYTE1_SHIFT                        (0x8U)
#define MC33774_I2C_DATA0_BYTE1_MASK                         (0xFF00U)
#define MC33774_I2C_DATA0_BYTE1_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA0_BYTE1_SHIFT)) & MC33774_I2C_DATA0_BYTE1_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA1 (read-write):I2C data register 1
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA1_OFFSET                             (0xC05U)
#define MC33774_I2C_DATA1_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA1_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA1_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA1_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA1_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA1_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA1_POR_VAL                            (0x0U)

/* Field BYTE2: I2C data byte 2 */
#define MC33774_I2C_DATA1_BYTE2_SHIFT                        (0x0U)
#define MC33774_I2C_DATA1_BYTE2_MASK                         (0xFFU)
#define MC33774_I2C_DATA1_BYTE2_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA1_BYTE2_SHIFT)) & MC33774_I2C_DATA1_BYTE2_MASK))

/* Field BYTE3: I2C data byte 3 */
#define MC33774_I2C_DATA1_BYTE3_SHIFT                        (0x8U)
#define MC33774_I2C_DATA1_BYTE3_MASK                         (0xFF00U)
#define MC33774_I2C_DATA1_BYTE3_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA1_BYTE3_SHIFT)) & MC33774_I2C_DATA1_BYTE3_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA2 (read-write):I2C data register 2
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA2_OFFSET                             (0xC06U)
#define MC33774_I2C_DATA2_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA2_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA2_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA2_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA2_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA2_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA2_POR_VAL                            (0x0U)

/* Field BYTE4: I2C data byte 4 */
#define MC33774_I2C_DATA2_BYTE4_SHIFT                        (0x0U)
#define MC33774_I2C_DATA2_BYTE4_MASK                         (0xFFU)
#define MC33774_I2C_DATA2_BYTE4_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA2_BYTE4_SHIFT)) & MC33774_I2C_DATA2_BYTE4_MASK))

/* Field BYTE5: I2C data byte 5 */
#define MC33774_I2C_DATA2_BYTE5_SHIFT                        (0x8U)
#define MC33774_I2C_DATA2_BYTE5_MASK                         (0xFF00U)
#define MC33774_I2C_DATA2_BYTE5_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA2_BYTE5_SHIFT)) & MC33774_I2C_DATA2_BYTE5_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA3 (read-write):I2C data register 3
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA3_OFFSET                             (0xC07U)
#define MC33774_I2C_DATA3_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA3_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA3_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA3_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA3_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA3_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA3_POR_VAL                            (0x0U)

/* Field BYTE6: I2C data byte 6 */
#define MC33774_I2C_DATA3_BYTE6_SHIFT                        (0x0U)
#define MC33774_I2C_DATA3_BYTE6_MASK                         (0xFFU)
#define MC33774_I2C_DATA3_BYTE6_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA3_BYTE6_SHIFT)) & MC33774_I2C_DATA3_BYTE6_MASK))

/* Field BYTE7: I2C data byte 7 */
#define MC33774_I2C_DATA3_BYTE7_SHIFT                        (0x8U)
#define MC33774_I2C_DATA3_BYTE7_MASK                         (0xFF00U)
#define MC33774_I2C_DATA3_BYTE7_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA3_BYTE7_SHIFT)) & MC33774_I2C_DATA3_BYTE7_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA4 (read-write):I2C data register 4
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA4_OFFSET                             (0xC08U)
#define MC33774_I2C_DATA4_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA4_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA4_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA4_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA4_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA4_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA4_POR_VAL                            (0x0U)

/* Field BYTE8: I2C data byte 8 */
#define MC33774_I2C_DATA4_BYTE8_SHIFT                        (0x0U)
#define MC33774_I2C_DATA4_BYTE8_MASK                         (0xFFU)
#define MC33774_I2C_DATA4_BYTE8_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA4_BYTE8_SHIFT)) & MC33774_I2C_DATA4_BYTE8_MASK))

/* Field BYTE9: I2C data byte 9 */
#define MC33774_I2C_DATA4_BYTE9_SHIFT                        (0x8U)
#define MC33774_I2C_DATA4_BYTE9_MASK                         (0xFF00U)
#define MC33774_I2C_DATA4_BYTE9_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA4_BYTE9_SHIFT)) & MC33774_I2C_DATA4_BYTE9_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA5 (read-write):I2C data register 5
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA5_OFFSET                             (0xC09U)
#define MC33774_I2C_DATA5_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA5_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA5_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA5_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA5_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA5_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA5_POR_VAL                            (0x0U)

/* Field BYTE10: I2C data byte 10 */
#define MC33774_I2C_DATA5_BYTE10_SHIFT                       (0x0U)
#define MC33774_I2C_DATA5_BYTE10_MASK                        (0xFFU)
#define MC33774_I2C_DATA5_BYTE10_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA5_BYTE10_SHIFT)) & MC33774_I2C_DATA5_BYTE10_MASK))

/* Field BYTE11: I2C data byte 11 */
#define MC33774_I2C_DATA5_BYTE11_SHIFT                       (0x8U)
#define MC33774_I2C_DATA5_BYTE11_MASK                        (0xFF00U)
#define MC33774_I2C_DATA5_BYTE11_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA5_BYTE11_SHIFT)) & MC33774_I2C_DATA5_BYTE11_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA6 (read-write):I2C data register 6
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA6_OFFSET                             (0xC0AU)
#define MC33774_I2C_DATA6_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA6_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA6_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA6_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA6_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA6_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA6_POR_VAL                            (0x0U)

/* Field BYTE12: I2C data byte 12 */
#define MC33774_I2C_DATA6_BYTE12_SHIFT                       (0x0U)
#define MC33774_I2C_DATA6_BYTE12_MASK                        (0xFFU)
#define MC33774_I2C_DATA6_BYTE12_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA6_BYTE12_SHIFT)) & MC33774_I2C_DATA6_BYTE12_MASK))

/* Field BYTE13: I2C data byte 13 */
#define MC33774_I2C_DATA6_BYTE13_SHIFT                       (0x8U)
#define MC33774_I2C_DATA6_BYTE13_MASK                        (0xFF00U)
#define MC33774_I2C_DATA6_BYTE13_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA6_BYTE13_SHIFT)) & MC33774_I2C_DATA6_BYTE13_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA7 (read-write):I2C data register 7
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA7_OFFSET                             (0xC0BU)
#define MC33774_I2C_DATA7_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA7_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA7_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA7_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA7_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA7_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA7_POR_VAL                            (0x0U)

/* Field BYTE14: I2C data byte 14 */
#define MC33774_I2C_DATA7_BYTE14_SHIFT                       (0x0U)
#define MC33774_I2C_DATA7_BYTE14_MASK                        (0xFFU)
#define MC33774_I2C_DATA7_BYTE14_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA7_BYTE14_SHIFT)) & MC33774_I2C_DATA7_BYTE14_MASK))

/* Field BYTE15: I2C data byte 15 */
#define MC33774_I2C_DATA7_BYTE15_SHIFT                       (0x8U)
#define MC33774_I2C_DATA7_BYTE15_MASK                        (0xFF00U)
#define MC33774_I2C_DATA7_BYTE15_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA7_BYTE15_SHIFT)) & MC33774_I2C_DATA7_BYTE15_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA8 (read-write):I2C data register 8
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA8_OFFSET                             (0xC0CU)
#define MC33774_I2C_DATA8_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA8_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA8_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA8_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA8_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA8_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA8_POR_VAL                            (0x0U)

/* Field BYTE16: I2C data byte 16 */
#define MC33774_I2C_DATA8_BYTE16_SHIFT                       (0x0U)
#define MC33774_I2C_DATA8_BYTE16_MASK                        (0xFFU)
#define MC33774_I2C_DATA8_BYTE16_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA8_BYTE16_SHIFT)) & MC33774_I2C_DATA8_BYTE16_MASK))

/* Field BYTE17: I2C data byte 17 */
#define MC33774_I2C_DATA8_BYTE17_SHIFT                       (0x8U)
#define MC33774_I2C_DATA8_BYTE17_MASK                        (0xFF00U)
#define MC33774_I2C_DATA8_BYTE17_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA8_BYTE17_SHIFT)) & MC33774_I2C_DATA8_BYTE17_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA9 (read-write):I2C data register 9
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA9_OFFSET                             (0xC0DU)
#define MC33774_I2C_DATA9_RW_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA9_RD_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA9_WR_MASK                            (0xFFFFU)
#define MC33774_I2C_DATA9_MW_MASK                            (0x0U)
#define MC33774_I2C_DATA9_RA_MASK                            (0x0U)
#define MC33774_I2C_DATA9_POR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA9_POR_VAL                            (0x0U)

/* Field BYTE18: I2C data byte 18 */
#define MC33774_I2C_DATA9_BYTE18_SHIFT                       (0x0U)
#define MC33774_I2C_DATA9_BYTE18_MASK                        (0xFFU)
#define MC33774_I2C_DATA9_BYTE18_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA9_BYTE18_SHIFT)) & MC33774_I2C_DATA9_BYTE18_MASK))

/* Field BYTE19: I2C data byte 19 */
#define MC33774_I2C_DATA9_BYTE19_SHIFT                       (0x8U)
#define MC33774_I2C_DATA9_BYTE19_MASK                        (0xFF00U)
#define MC33774_I2C_DATA9_BYTE19_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA9_BYTE19_SHIFT)) & MC33774_I2C_DATA9_BYTE19_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA10 (read-write):I2C data register 10
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA10_OFFSET                            (0xC0EU)
#define MC33774_I2C_DATA10_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA10_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA10_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA10_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA10_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA10_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA10_POR_VAL                           (0x0U)

/* Field BYTE20: I2C data byte 20 */
#define MC33774_I2C_DATA10_BYTE20_SHIFT                      (0x0U)
#define MC33774_I2C_DATA10_BYTE20_MASK                       (0xFFU)
#define MC33774_I2C_DATA10_BYTE20_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA10_BYTE20_SHIFT)) & MC33774_I2C_DATA10_BYTE20_MASK))

/* Field BYTE21: I2C data byte 21 */
#define MC33774_I2C_DATA10_BYTE21_SHIFT                      (0x8U)
#define MC33774_I2C_DATA10_BYTE21_MASK                       (0xFF00U)
#define MC33774_I2C_DATA10_BYTE21_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA10_BYTE21_SHIFT)) & MC33774_I2C_DATA10_BYTE21_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA11 (read-write):I2C data register 11
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA11_OFFSET                            (0xC0FU)
#define MC33774_I2C_DATA11_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA11_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA11_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA11_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA11_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA11_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA11_POR_VAL                           (0x0U)

/* Field BYTE22: I2C data byte 22 */
#define MC33774_I2C_DATA11_BYTE22_SHIFT                      (0x0U)
#define MC33774_I2C_DATA11_BYTE22_MASK                       (0xFFU)
#define MC33774_I2C_DATA11_BYTE22_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA11_BYTE22_SHIFT)) & MC33774_I2C_DATA11_BYTE22_MASK))

/* Field BYTE23: I2C data byte 23 */
#define MC33774_I2C_DATA11_BYTE23_SHIFT                      (0x8U)
#define MC33774_I2C_DATA11_BYTE23_MASK                       (0xFF00U)
#define MC33774_I2C_DATA11_BYTE23_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA11_BYTE23_SHIFT)) & MC33774_I2C_DATA11_BYTE23_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA12 (read-write):I2C data register 12
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA12_OFFSET                            (0xC10U)
#define MC33774_I2C_DATA12_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA12_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA12_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA12_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA12_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA12_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA12_POR_VAL                           (0x0U)

/* Field BYTE24: I2C data byte 24 */
#define MC33774_I2C_DATA12_BYTE24_SHIFT                      (0x0U)
#define MC33774_I2C_DATA12_BYTE24_MASK                       (0xFFU)
#define MC33774_I2C_DATA12_BYTE24_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA12_BYTE24_SHIFT)) & MC33774_I2C_DATA12_BYTE24_MASK))

/* Field BYTE25: I2C data byte 25 */
#define MC33774_I2C_DATA12_BYTE25_SHIFT                      (0x8U)
#define MC33774_I2C_DATA12_BYTE25_MASK                       (0xFF00U)
#define MC33774_I2C_DATA12_BYTE25_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA12_BYTE25_SHIFT)) & MC33774_I2C_DATA12_BYTE25_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA13 (read-write):I2C data register 13
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA13_OFFSET                            (0xC11U)
#define MC33774_I2C_DATA13_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA13_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA13_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA13_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA13_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA13_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA13_POR_VAL                           (0x0U)

/* Field BYTE26: I2C data byte 26 */
#define MC33774_I2C_DATA13_BYTE26_SHIFT                      (0x0U)
#define MC33774_I2C_DATA13_BYTE26_MASK                       (0xFFU)
#define MC33774_I2C_DATA13_BYTE26_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA13_BYTE26_SHIFT)) & MC33774_I2C_DATA13_BYTE26_MASK))

/* Field BYTE27: I2C data byte 27 */
#define MC33774_I2C_DATA13_BYTE27_SHIFT                      (0x8U)
#define MC33774_I2C_DATA13_BYTE27_MASK                       (0xFF00U)
#define MC33774_I2C_DATA13_BYTE27_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA13_BYTE27_SHIFT)) & MC33774_I2C_DATA13_BYTE27_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA14 (read-write):I2C data register 14
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA14_OFFSET                            (0xC12U)
#define MC33774_I2C_DATA14_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA14_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA14_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA14_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA14_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA14_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA14_POR_VAL                           (0x0U)

/* Field BYTE28: I2C data byte 28 */
#define MC33774_I2C_DATA14_BYTE28_SHIFT                      (0x0U)
#define MC33774_I2C_DATA14_BYTE28_MASK                       (0xFFU)
#define MC33774_I2C_DATA14_BYTE28_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA14_BYTE28_SHIFT)) & MC33774_I2C_DATA14_BYTE28_MASK))

/* Field BYTE29: I2C data byte 29 */
#define MC33774_I2C_DATA14_BYTE29_SHIFT                      (0x8U)
#define MC33774_I2C_DATA14_BYTE29_MASK                       (0xFF00U)
#define MC33774_I2C_DATA14_BYTE29_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA14_BYTE29_SHIFT)) & MC33774_I2C_DATA14_BYTE29_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA15 (read-write):I2C data register 15
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA15_OFFSET                            (0xC13U)
#define MC33774_I2C_DATA15_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA15_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA15_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA15_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA15_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA15_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA15_POR_VAL                           (0x0U)

/* Field BYTE30: I2C data byte 30 */
#define MC33774_I2C_DATA15_BYTE30_SHIFT                      (0x0U)
#define MC33774_I2C_DATA15_BYTE30_MASK                       (0xFFU)
#define MC33774_I2C_DATA15_BYTE30_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA15_BYTE30_SHIFT)) & MC33774_I2C_DATA15_BYTE30_MASK))

/* Field BYTE31: I2C data byte 31 */
#define MC33774_I2C_DATA15_BYTE31_SHIFT                      (0x8U)
#define MC33774_I2C_DATA15_BYTE31_MASK                       (0xFF00U)
#define MC33774_I2C_DATA15_BYTE31_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA15_BYTE31_SHIFT)) & MC33774_I2C_DATA15_BYTE31_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA16 (read-write):I2C data register 16
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA16_OFFSET                            (0xC14U)
#define MC33774_I2C_DATA16_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA16_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA16_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA16_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA16_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA16_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA16_POR_VAL                           (0x0U)

/* Field BYTE32: I2C data byte 32 */
#define MC33774_I2C_DATA16_BYTE32_SHIFT                      (0x0U)
#define MC33774_I2C_DATA16_BYTE32_MASK                       (0xFFU)
#define MC33774_I2C_DATA16_BYTE32_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA16_BYTE32_SHIFT)) & MC33774_I2C_DATA16_BYTE32_MASK))

/* Field BYTE33: I2C data byte 33 */
#define MC33774_I2C_DATA16_BYTE33_SHIFT                      (0x8U)
#define MC33774_I2C_DATA16_BYTE33_MASK                       (0xFF00U)
#define MC33774_I2C_DATA16_BYTE33_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA16_BYTE33_SHIFT)) & MC33774_I2C_DATA16_BYTE33_MASK))

/* --------------------------------------------------------------------------
 * I2C_DATA17 (read-write):I2C data register 17
 * -------------------------------------------------------------------------- */
#define MC33774_I2C_DATA17_OFFSET                            (0xC15U)
#define MC33774_I2C_DATA17_RW_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA17_RD_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA17_WR_MASK                           (0xFFFFU)
#define MC33774_I2C_DATA17_MW_MASK                           (0x0U)
#define MC33774_I2C_DATA17_RA_MASK                           (0x0U)
#define MC33774_I2C_DATA17_POR_MASK                          (0xFFFFU)
#define MC33774_I2C_DATA17_POR_VAL                           (0x0U)

/* Field BYTE34: I2C data byte 34 */
#define MC33774_I2C_DATA17_BYTE34_SHIFT                      (0x0U)
#define MC33774_I2C_DATA17_BYTE34_MASK                       (0xFFU)
#define MC33774_I2C_DATA17_BYTE34_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA17_BYTE34_SHIFT)) & MC33774_I2C_DATA17_BYTE34_MASK))

/* Field BYTE35: I2C data byte 35 */
#define MC33774_I2C_DATA17_BYTE35_SHIFT                      (0x8U)
#define MC33774_I2C_DATA17_BYTE35_MASK                       (0xFF00U)
#define MC33774_I2C_DATA17_BYTE35_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_I2C_DATA17_BYTE35_SHIFT)) & MC33774_I2C_DATA17_BYTE35_MASK))

/* --------------------------------------------------------------------------
 * GPIO_CFG0 (read-write):GPIO configuration 0
 * -------------------------------------------------------------------------- */
#define MC33774_GPIO_CFG0_OFFSET                             (0x800U)
#define MC33774_GPIO_CFG0_RW_MASK                            (0xFFFFU)
#define MC33774_GPIO_CFG0_RD_MASK                            (0xFFFFU)
#define MC33774_GPIO_CFG0_WR_MASK                            (0xFFFFU)
#define MC33774_GPIO_CFG0_MW_MASK                            (0x0U)
#define MC33774_GPIO_CFG0_RA_MASK                            (0x0U)
#define MC33774_GPIO_CFG0_POR_MASK                           (0xFFFFU)
#define MC33774_GPIO_CFG0_POR_VAL                            (0x0U)

/* Field INPEN0: Enable the input for GPIO0. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN0_SHIFT                       (0x0U)
#define MC33774_GPIO_CFG0_INPEN0_MASK                        (0x1U)
#define MC33774_GPIO_CFG0_INPEN0_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN0_SHIFT)) & MC33774_GPIO_CFG0_INPEN0_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN0_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN0_ENABLED_ENUM_VAL            (1U)

/* Field INPEN1: Enable the input for GPIO1. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN1_SHIFT                       (0x1U)
#define MC33774_GPIO_CFG0_INPEN1_MASK                        (0x2U)
#define MC33774_GPIO_CFG0_INPEN1_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN1_SHIFT)) & MC33774_GPIO_CFG0_INPEN1_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN1_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN1_ENABLED_ENUM_VAL            (1U)

/* Field INPEN2: Enable the input for GPIO2. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN2_SHIFT                       (0x2U)
#define MC33774_GPIO_CFG0_INPEN2_MASK                        (0x4U)
#define MC33774_GPIO_CFG0_INPEN2_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN2_SHIFT)) & MC33774_GPIO_CFG0_INPEN2_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN2_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN2_ENABLED_ENUM_VAL            (1U)

/* Field INPEN3: Enable the input for GPIO3. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN3_SHIFT                       (0x3U)
#define MC33774_GPIO_CFG0_INPEN3_MASK                        (0x8U)
#define MC33774_GPIO_CFG0_INPEN3_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN3_SHIFT)) & MC33774_GPIO_CFG0_INPEN3_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN3_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN3_ENABLED_ENUM_VAL            (1U)

/* Field INPEN4: Enable the input for GPIO4. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN4_SHIFT                       (0x4U)
#define MC33774_GPIO_CFG0_INPEN4_MASK                        (0x10U)
#define MC33774_GPIO_CFG0_INPEN4_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN4_SHIFT)) & MC33774_GPIO_CFG0_INPEN4_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN4_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN4_ENABLED_ENUM_VAL            (1U)

/* Field INPEN5: Enable the input for GPIO5. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN5_SHIFT                       (0x5U)
#define MC33774_GPIO_CFG0_INPEN5_MASK                        (0x20U)
#define MC33774_GPIO_CFG0_INPEN5_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN5_SHIFT)) & MC33774_GPIO_CFG0_INPEN5_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN5_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN5_ENABLED_ENUM_VAL            (1U)

/* Field INPEN6: Enable the input for GPIO6. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN6_SHIFT                       (0x6U)
#define MC33774_GPIO_CFG0_INPEN6_MASK                        (0x40U)
#define MC33774_GPIO_CFG0_INPEN6_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN6_SHIFT)) & MC33774_GPIO_CFG0_INPEN6_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN6_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN6_ENABLED_ENUM_VAL            (1U)

/* Field INPEN7: Enable the input for GPIO7. If a special function requires digital input, the according receiver is enabled automatically. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_INPEN7_SHIFT                       (0x7U)
#define MC33774_GPIO_CFG0_INPEN7_MASK                        (0x80U)
#define MC33774_GPIO_CFG0_INPEN7_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_INPEN7_SHIFT)) & MC33774_GPIO_CFG0_INPEN7_MASK))

/* Enumerated value DISABLED: Input is disabled */
#define MC33774_GPIO_CFG0_INPEN7_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Input is enabled */
#define MC33774_GPIO_CFG0_INPEN7_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN0: Enable the output of the GPIO0. */
#define MC33774_GPIO_CFG0_OUTEN0_SHIFT                       (0x8U)
#define MC33774_GPIO_CFG0_OUTEN0_MASK                        (0x100U)
#define MC33774_GPIO_CFG0_OUTEN0_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN0_SHIFT)) & MC33774_GPIO_CFG0_OUTEN0_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN0_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN0_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN1: Enable the output of the GPIO1. */
#define MC33774_GPIO_CFG0_OUTEN1_SHIFT                       (0x9U)
#define MC33774_GPIO_CFG0_OUTEN1_MASK                        (0x200U)
#define MC33774_GPIO_CFG0_OUTEN1_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN1_SHIFT)) & MC33774_GPIO_CFG0_OUTEN1_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN1_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN1_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN2: Enable the output of the GPIO2. */
#define MC33774_GPIO_CFG0_OUTEN2_SHIFT                       (0xAU)
#define MC33774_GPIO_CFG0_OUTEN2_MASK                        (0x400U)
#define MC33774_GPIO_CFG0_OUTEN2_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN2_SHIFT)) & MC33774_GPIO_CFG0_OUTEN2_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN2_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN2_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN3: Enable the output of the GPIO3. */
#define MC33774_GPIO_CFG0_OUTEN3_SHIFT                       (0xBU)
#define MC33774_GPIO_CFG0_OUTEN3_MASK                        (0x800U)
#define MC33774_GPIO_CFG0_OUTEN3_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN3_SHIFT)) & MC33774_GPIO_CFG0_OUTEN3_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN3_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN3_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN4: Enable the output of the GPIO4. */
#define MC33774_GPIO_CFG0_OUTEN4_SHIFT                       (0xCU)
#define MC33774_GPIO_CFG0_OUTEN4_MASK                        (0x1000U)
#define MC33774_GPIO_CFG0_OUTEN4_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN4_SHIFT)) & MC33774_GPIO_CFG0_OUTEN4_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN4_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN4_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN5: Enable the output of the GPIO5. */
#define MC33774_GPIO_CFG0_OUTEN5_SHIFT                       (0xDU)
#define MC33774_GPIO_CFG0_OUTEN5_MASK                        (0x2000U)
#define MC33774_GPIO_CFG0_OUTEN5_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN5_SHIFT)) & MC33774_GPIO_CFG0_OUTEN5_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN5_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN5_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN6: Enable the output of the GPIO6. */
#define MC33774_GPIO_CFG0_OUTEN6_SHIFT                       (0xEU)
#define MC33774_GPIO_CFG0_OUTEN6_MASK                        (0x4000U)
#define MC33774_GPIO_CFG0_OUTEN6_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN6_SHIFT)) & MC33774_GPIO_CFG0_OUTEN6_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN6_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN6_ENABLED_ENUM_VAL            (1U)

/* Field OUTEN7: Enable the output of the GPIO7. */
#define MC33774_GPIO_CFG0_OUTEN7_SHIFT                       (0xFU)
#define MC33774_GPIO_CFG0_OUTEN7_MASK                        (0x8000U)
#define MC33774_GPIO_CFG0_OUTEN7_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG0_OUTEN7_SHIFT)) & MC33774_GPIO_CFG0_OUTEN7_MASK))

/* Enumerated value DISABLED: Output is disabled */
#define MC33774_GPIO_CFG0_OUTEN7_DISABLED_ENUM_VAL           (0U)

/* Enumerated value ENABLED: Output is enabled. If an analog measurement function is enabled on this GPIO, the GPIO output is automatically disabled. This is not reflected in this bit. */
#define MC33774_GPIO_CFG0_OUTEN7_ENABLED_ENUM_VAL            (1U)


/* --------------------------------------------------------------------------
 * GPIO_CFG1 (read-write):GPIO configuration 1
 * -------------------------------------------------------------------------- */
#define MC33774_GPIO_CFG1_OFFSET                             (0x801U)
#define MC33774_GPIO_CFG1_RW_MASK                            (0xFFU)
#define MC33774_GPIO_CFG1_RD_MASK                            (0xFFU)
#define MC33774_GPIO_CFG1_WR_MASK                            (0xFFU)
#define MC33774_GPIO_CFG1_MW_MASK                            (0x0U)
#define MC33774_GPIO_CFG1_RA_MASK                            (0x0U)
#define MC33774_GPIO_CFG1_POR_MASK                           (0xFFFFU)
#define MC33774_GPIO_CFG1_POR_VAL                            (0x0U)

/* Field ODEN0: Open Drain enable, GPIO0. */
#define MC33774_GPIO_CFG1_ODEN0_SHIFT                        (0x0U)
#define MC33774_GPIO_CFG1_ODEN0_MASK                         (0x1U)
#define MC33774_GPIO_CFG1_ODEN0_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN0_SHIFT)) & MC33774_GPIO_CFG1_ODEN0_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN0_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN0_ENABLED_ENUM_VAL             (1U)

/* Field ODEN1: Open Drain enable, GPIO1. */
#define MC33774_GPIO_CFG1_ODEN1_SHIFT                        (0x1U)
#define MC33774_GPIO_CFG1_ODEN1_MASK                         (0x2U)
#define MC33774_GPIO_CFG1_ODEN1_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN1_SHIFT)) & MC33774_GPIO_CFG1_ODEN1_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN1_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN1_ENABLED_ENUM_VAL             (1U)

/* Field ODEN2: Open Drain enable, GPIO2. */
#define MC33774_GPIO_CFG1_ODEN2_SHIFT                        (0x2U)
#define MC33774_GPIO_CFG1_ODEN2_MASK                         (0x4U)
#define MC33774_GPIO_CFG1_ODEN2_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN2_SHIFT)) & MC33774_GPIO_CFG1_ODEN2_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN2_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN2_ENABLED_ENUM_VAL             (1U)

/* Field ODEN3: Open Drain enable, GPIO3. */
#define MC33774_GPIO_CFG1_ODEN3_SHIFT                        (0x3U)
#define MC33774_GPIO_CFG1_ODEN3_MASK                         (0x8U)
#define MC33774_GPIO_CFG1_ODEN3_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN3_SHIFT)) & MC33774_GPIO_CFG1_ODEN3_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN3_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN3_ENABLED_ENUM_VAL             (1U)

/* Field ODEN4: Open Drain enable, GPIO4. */
#define MC33774_GPIO_CFG1_ODEN4_SHIFT                        (0x4U)
#define MC33774_GPIO_CFG1_ODEN4_MASK                         (0x10U)
#define MC33774_GPIO_CFG1_ODEN4_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN4_SHIFT)) & MC33774_GPIO_CFG1_ODEN4_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN4_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN4_ENABLED_ENUM_VAL             (1U)

/* Field ODEN5: Open Drain enable, GPIO5. */
#define MC33774_GPIO_CFG1_ODEN5_SHIFT                        (0x5U)
#define MC33774_GPIO_CFG1_ODEN5_MASK                         (0x20U)
#define MC33774_GPIO_CFG1_ODEN5_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN5_SHIFT)) & MC33774_GPIO_CFG1_ODEN5_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN5_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN5_ENABLED_ENUM_VAL             (1U)

/* Field ODEN6: Open Drain enable, GPIO6. */
#define MC33774_GPIO_CFG1_ODEN6_SHIFT                        (0x6U)
#define MC33774_GPIO_CFG1_ODEN6_MASK                         (0x40U)
#define MC33774_GPIO_CFG1_ODEN6_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN6_SHIFT)) & MC33774_GPIO_CFG1_ODEN6_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN6_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN6_ENABLED_ENUM_VAL             (1U)

/* Field ODEN7: Open Drain enable, GPIO7. */
#define MC33774_GPIO_CFG1_ODEN7_SHIFT                        (0x7U)
#define MC33774_GPIO_CFG1_ODEN7_MASK                         (0x80U)
#define MC33774_GPIO_CFG1_ODEN7_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_ODEN7_SHIFT)) & MC33774_GPIO_CFG1_ODEN7_MASK))

/* Enumerated value DISABLED: Open Drain disabled */
#define MC33774_GPIO_CFG1_ODEN7_DISABLED_ENUM_VAL            (0U)

/* Enumerated value ENABLED: Open Drain enabled */
#define MC33774_GPIO_CFG1_ODEN7_ENABLED_ENUM_VAL             (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_GPIO_CFG1_RESERVED0_SHIFT                    (0x8U)
#define MC33774_GPIO_CFG1_RESERVED0_MASK                     (0xFF00U)
#define MC33774_GPIO_CFG1_RESERVED0_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_CFG1_RESERVED0_SHIFT)) & MC33774_GPIO_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * GPIO_OUT (read-write):GPIO output
 * -------------------------------------------------------------------------- */
#define MC33774_GPIO_OUT_OFFSET                              (0x802U)
#define MC33774_GPIO_OUT_RW_MASK                             (0xFFU)
#define MC33774_GPIO_OUT_RD_MASK                             (0xFFU)
#define MC33774_GPIO_OUT_WR_MASK                             (0xFFU)
#define MC33774_GPIO_OUT_MW_MASK                             (0x0U)
#define MC33774_GPIO_OUT_RA_MASK                             (0x0U)
#define MC33774_GPIO_OUT_POR_MASK                            (0xFFFFU)
#define MC33774_GPIO_OUT_POR_VAL                             (0x0U)

/* Field OUT0: Set the output level of the gpio function for GPIO0. */
#define MC33774_GPIO_OUT_OUT0_SHIFT                          (0x0U)
#define MC33774_GPIO_OUT_OUT0_MASK                           (0x1U)
#define MC33774_GPIO_OUT_OUT0_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT0_SHIFT)) & MC33774_GPIO_OUT_OUT0_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT0_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT0_HIGH_ENUM_VAL                  (1U)

/* Field OUT1: Set the output level of the gpio function for GPIO1. */
#define MC33774_GPIO_OUT_OUT1_SHIFT                          (0x1U)
#define MC33774_GPIO_OUT_OUT1_MASK                           (0x2U)
#define MC33774_GPIO_OUT_OUT1_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT1_SHIFT)) & MC33774_GPIO_OUT_OUT1_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT1_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT1_HIGH_ENUM_VAL                  (1U)

/* Field OUT2: Set the output level of the gpio function for GPIO2. */
#define MC33774_GPIO_OUT_OUT2_SHIFT                          (0x2U)
#define MC33774_GPIO_OUT_OUT2_MASK                           (0x4U)
#define MC33774_GPIO_OUT_OUT2_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT2_SHIFT)) & MC33774_GPIO_OUT_OUT2_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT2_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT2_HIGH_ENUM_VAL                  (1U)

/* Field OUT3: Set the output level of the gpio function for GPIO3. */
#define MC33774_GPIO_OUT_OUT3_SHIFT                          (0x3U)
#define MC33774_GPIO_OUT_OUT3_MASK                           (0x8U)
#define MC33774_GPIO_OUT_OUT3_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT3_SHIFT)) & MC33774_GPIO_OUT_OUT3_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT3_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT3_HIGH_ENUM_VAL                  (1U)

/* Field OUT4: Set the output level of the gpio function for GPIO4. */
#define MC33774_GPIO_OUT_OUT4_SHIFT                          (0x4U)
#define MC33774_GPIO_OUT_OUT4_MASK                           (0x10U)
#define MC33774_GPIO_OUT_OUT4_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT4_SHIFT)) & MC33774_GPIO_OUT_OUT4_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT4_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT4_HIGH_ENUM_VAL                  (1U)

/* Field OUT5: Set the output level of the gpio function for GPIO5. */
#define MC33774_GPIO_OUT_OUT5_SHIFT                          (0x5U)
#define MC33774_GPIO_OUT_OUT5_MASK                           (0x20U)
#define MC33774_GPIO_OUT_OUT5_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT5_SHIFT)) & MC33774_GPIO_OUT_OUT5_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT5_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT5_HIGH_ENUM_VAL                  (1U)

/* Field OUT6: Set the output level of the gpio function for GPIO6. */
#define MC33774_GPIO_OUT_OUT6_SHIFT                          (0x6U)
#define MC33774_GPIO_OUT_OUT6_MASK                           (0x40U)
#define MC33774_GPIO_OUT_OUT6_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT6_SHIFT)) & MC33774_GPIO_OUT_OUT6_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT6_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT6_HIGH_ENUM_VAL                  (1U)

/* Field OUT7: Set the output level of the gpio function for GPIO7. */
#define MC33774_GPIO_OUT_OUT7_SHIFT                          (0x7U)
#define MC33774_GPIO_OUT_OUT7_MASK                           (0x80U)
#define MC33774_GPIO_OUT_OUT7_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_OUT7_SHIFT)) & MC33774_GPIO_OUT_OUT7_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_OUT_OUT7_LOW_ENUM_VAL                   (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_OUT_OUT7_HIGH_ENUM_VAL                  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_GPIO_OUT_RESERVED0_SHIFT                     (0x8U)
#define MC33774_GPIO_OUT_RESERVED0_MASK                      (0xFF00U)
#define MC33774_GPIO_OUT_RESERVED0_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_OUT_RESERVED0_SHIFT)) & MC33774_GPIO_OUT_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * GPIO_IN (read-only):GPIO input
 * -------------------------------------------------------------------------- */
#define MC33774_GPIO_IN_OFFSET                               (0x804U)
#define MC33774_GPIO_IN_RW_MASK                              (0x0U)
#define MC33774_GPIO_IN_RD_MASK                              (0xFFFFU)
#define MC33774_GPIO_IN_WR_MASK                              (0x0U)
#define MC33774_GPIO_IN_MW_MASK                              (0x0U)
#define MC33774_GPIO_IN_RA_MASK                              (0xFF00U)
#define MC33774_GPIO_IN_POR_MASK                             (0xFFFFU)
#define MC33774_GPIO_IN_POR_VAL                              (0x0U)

/* Field IN0: Read the level of the gpio function of GPIO0. */
#define MC33774_GPIO_IN_IN0_SHIFT                            (0x0U)
#define MC33774_GPIO_IN_IN0_MASK                             (0x1U)
#define MC33774_GPIO_IN_IN0_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN0_SHIFT)) & MC33774_GPIO_IN_IN0_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN0_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN0_HIGH_ENUM_VAL                    (1U)

/* Field IN1: Read the level of the gpio function of GPIO1. */
#define MC33774_GPIO_IN_IN1_SHIFT                            (0x1U)
#define MC33774_GPIO_IN_IN1_MASK                             (0x2U)
#define MC33774_GPIO_IN_IN1_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN1_SHIFT)) & MC33774_GPIO_IN_IN1_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN1_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN1_HIGH_ENUM_VAL                    (1U)

/* Field IN2: Read the level of the gpio function of GPIO2. */
#define MC33774_GPIO_IN_IN2_SHIFT                            (0x2U)
#define MC33774_GPIO_IN_IN2_MASK                             (0x4U)
#define MC33774_GPIO_IN_IN2_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN2_SHIFT)) & MC33774_GPIO_IN_IN2_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN2_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN2_HIGH_ENUM_VAL                    (1U)

/* Field IN3: Read the level of the gpio function of GPIO3. */
#define MC33774_GPIO_IN_IN3_SHIFT                            (0x3U)
#define MC33774_GPIO_IN_IN3_MASK                             (0x8U)
#define MC33774_GPIO_IN_IN3_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN3_SHIFT)) & MC33774_GPIO_IN_IN3_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN3_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN3_HIGH_ENUM_VAL                    (1U)

/* Field IN4: Read the level of the gpio function of GPIO4. */
#define MC33774_GPIO_IN_IN4_SHIFT                            (0x4U)
#define MC33774_GPIO_IN_IN4_MASK                             (0x10U)
#define MC33774_GPIO_IN_IN4_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN4_SHIFT)) & MC33774_GPIO_IN_IN4_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN4_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN4_HIGH_ENUM_VAL                    (1U)

/* Field IN5: Read the level of the gpio function of GPIO5. */
#define MC33774_GPIO_IN_IN5_SHIFT                            (0x5U)
#define MC33774_GPIO_IN_IN5_MASK                             (0x20U)
#define MC33774_GPIO_IN_IN5_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN5_SHIFT)) & MC33774_GPIO_IN_IN5_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN5_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN5_HIGH_ENUM_VAL                    (1U)

/* Field IN6: Read the level of the gpio function of GPIO6. */
#define MC33774_GPIO_IN_IN6_SHIFT                            (0x6U)
#define MC33774_GPIO_IN_IN6_MASK                             (0x40U)
#define MC33774_GPIO_IN_IN6_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN6_SHIFT)) & MC33774_GPIO_IN_IN6_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN6_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN6_HIGH_ENUM_VAL                    (1U)

/* Field IN7: Read the level of the gpio function of GPIO7. */
#define MC33774_GPIO_IN_IN7_SHIFT                            (0x7U)
#define MC33774_GPIO_IN_IN7_MASK                             (0x80U)
#define MC33774_GPIO_IN_IN7_U16(x)                           (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_IN7_SHIFT)) & MC33774_GPIO_IN_IN7_MASK))

/* Enumerated value LOW: GPIO is low */
#define MC33774_GPIO_IN_IN7_LOW_ENUM_VAL                     (0U)

/* Enumerated value HIGH: GPIO is high */
#define MC33774_GPIO_IN_IN7_HIGH_ENUM_VAL                    (1U)

/* Field HIGHDET0: High value on GPIO0. */
#define MC33774_GPIO_IN_HIGHDET0_SHIFT                       (0x8U)
#define MC33774_GPIO_IN_HIGHDET0_MASK                        (0x100U)
#define MC33774_GPIO_IN_HIGHDET0_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET0_SHIFT)) & MC33774_GPIO_IN_HIGHDET0_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET0_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET0_HIGH_ENUM_VAL               (1U)

/* Field HIGHDET1: High value on GPIO1. */
#define MC33774_GPIO_IN_HIGHDET1_SHIFT                       (0x9U)
#define MC33774_GPIO_IN_HIGHDET1_MASK                        (0x200U)
#define MC33774_GPIO_IN_HIGHDET1_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET1_SHIFT)) & MC33774_GPIO_IN_HIGHDET1_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET1_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET1_HIGH_ENUM_VAL               (1U)

/* Field HIGHDET2: High value on GPIO2. */
#define MC33774_GPIO_IN_HIGHDET2_SHIFT                       (0xAU)
#define MC33774_GPIO_IN_HIGHDET2_MASK                        (0x400U)
#define MC33774_GPIO_IN_HIGHDET2_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET2_SHIFT)) & MC33774_GPIO_IN_HIGHDET2_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET2_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET2_HIGH_ENUM_VAL               (1U)

/* Field HIGHDET3: High value on GPIO3. */
#define MC33774_GPIO_IN_HIGHDET3_SHIFT                       (0xBU)
#define MC33774_GPIO_IN_HIGHDET3_MASK                        (0x800U)
#define MC33774_GPIO_IN_HIGHDET3_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET3_SHIFT)) & MC33774_GPIO_IN_HIGHDET3_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET3_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET3_HIGH_ENUM_VAL               (1U)

/* Field HIGHDET4: High value on GPIO4. */
#define MC33774_GPIO_IN_HIGHDET4_SHIFT                       (0xCU)
#define MC33774_GPIO_IN_HIGHDET4_MASK                        (0x1000U)
#define MC33774_GPIO_IN_HIGHDET4_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET4_SHIFT)) & MC33774_GPIO_IN_HIGHDET4_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET4_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET4_HIGH_ENUM_VAL               (1U)

/* Field HIGHDET5: High value on GPIO5. */
#define MC33774_GPIO_IN_HIGHDET5_SHIFT                       (0xDU)
#define MC33774_GPIO_IN_HIGHDET5_MASK                        (0x2000U)
#define MC33774_GPIO_IN_HIGHDET5_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET5_SHIFT)) & MC33774_GPIO_IN_HIGHDET5_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET5_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET5_HIGH_ENUM_VAL               (1U)

/* Field HIGHDET6: High value on GPIO6. */
#define MC33774_GPIO_IN_HIGHDET6_SHIFT                       (0xEU)
#define MC33774_GPIO_IN_HIGHDET6_MASK                        (0x4000U)
#define MC33774_GPIO_IN_HIGHDET6_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET6_SHIFT)) & MC33774_GPIO_IN_HIGHDET6_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET6_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET6_HIGH_ENUM_VAL               (1U)

/* Field HIGHDET7: High value on GPIO7. */
#define MC33774_GPIO_IN_HIGHDET7_SHIFT                       (0xFU)
#define MC33774_GPIO_IN_HIGHDET7_MASK                        (0x8000U)
#define MC33774_GPIO_IN_HIGHDET7_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_GPIO_IN_HIGHDET7_SHIFT)) & MC33774_GPIO_IN_HIGHDET7_MASK))

/* Enumerated value NO_HIGH: No high level observed */
#define MC33774_GPIO_IN_HIGHDET7_NO_HIGH_ENUM_VAL            (0U)

/* Enumerated value HIGH: High level observed. */
#define MC33774_GPIO_IN_HIGHDET7_HIGH_ENUM_VAL               (1U)

/* --------------------------------------------------------------------------
 * BAL_GLOB_CFG (read-write):The global balancing configuration register is used to configure the balancing modes.
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_GLOB_CFG_OFFSET                          (0x1000U)
#define MC33774_BAL_GLOB_CFG_RW_MASK                         (0x73FU)
#define MC33774_BAL_GLOB_CFG_RD_MASK                         (0x73FU)
#define MC33774_BAL_GLOB_CFG_WR_MASK                         (0x73FU)
#define MC33774_BAL_GLOB_CFG_MW_MASK                         (0x0U)
#define MC33774_BAL_GLOB_CFG_RA_MASK                         (0x0U)
#define MC33774_BAL_GLOB_CFG_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_GLOB_CFG_POR_VAL                         (0x0U)

/* Field BALEN: Enables the balancing activity. This bit is cleared in case of a balancing timeout or if an enabled global under-voltage condition is reached.
All channel individual counters are stopped if zero. The emergency discharge works without setting this bit. */
#define MC33774_BAL_GLOB_CFG_BALEN_SHIFT                     (0x0U)
#define MC33774_BAL_GLOB_CFG_BALEN_MASK                      (0x1U)
#define MC33774_BAL_GLOB_CFG_BALEN_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_BALEN_SHIFT)) & MC33774_BAL_GLOB_CFG_BALEN_MASK))

/* Enumerated value DISABLED: Balancing is disabled. */
#define MC33774_BAL_GLOB_CFG_BALEN_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing is enabled. */
#define MC33774_BAL_GLOB_CFG_BALEN_ENABLED_ENUM_VAL          (1U)

/* Field TMRBALEN: Enables the timer based balancing feature. All channel individual counters are stopped if zero. */
#define MC33774_BAL_GLOB_CFG_TMRBALEN_SHIFT                  (0x1U)
#define MC33774_BAL_GLOB_CFG_TMRBALEN_MASK                   (0x2U)
#define MC33774_BAL_GLOB_CFG_TMRBALEN_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_TMRBALEN_SHIFT)) & MC33774_BAL_GLOB_CFG_TMRBALEN_MASK))

/* Enumerated value INDEPENDENT: Balancing is independent of the cell balancing timer. */
#define MC33774_BAL_GLOB_CFG_TMRBALEN_INDEPENDENT_ENUM_VAL   (0U)

/* Enumerated value STOP: Balancing for all cells will be stopped when cell balancing timer expires. */
#define MC33774_BAL_GLOB_CFG_TMRBALEN_STOP_ENUM_VAL          (1U)

/* Field CHUV0BALEN: Enables the voltage based balancing for the individual channel. Balancing stops once each individual channel reaches the under-voltage threshold. */
#define MC33774_BAL_GLOB_CFG_CHUV0BALEN_SHIFT                (0x2U)
#define MC33774_BAL_GLOB_CFG_CHUV0BALEN_MASK                 (0x4U)
#define MC33774_BAL_GLOB_CFG_CHUV0BALEN_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_CHUV0BALEN_SHIFT)) & MC33774_BAL_GLOB_CFG_CHUV0BALEN_MASK))

/* Enumerated value INDEPENDENT: Balancing is independent of the cell undervoltage threshold. */
#define MC33774_BAL_GLOB_CFG_CHUV0BALEN_INDEPENDENT_ENUM_VAL \
  (0U)

/* Enumerated value STOP: Balancing for the individual cells stops once the cell undervoltage threshold is reached. */
#define MC33774_BAL_GLOB_CFG_CHUV0BALEN_STOP_ENUM_VAL        (1U)

/* Field GLOBUV1BALEN: Enables the Global undervoltage based balancing feature. */
#define MC33774_BAL_GLOB_CFG_GLOBUV1BALEN_SHIFT              (0x3U)
#define MC33774_BAL_GLOB_CFG_GLOBUV1BALEN_MASK               (0x8U)
#define MC33774_BAL_GLOB_CFG_GLOBUV1BALEN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_GLOBUV1BALEN_SHIFT)) & MC33774_BAL_GLOB_CFG_GLOBUV1BALEN_MASK))

/* Enumerated value INDEPENDENT: Balancing is independent of the global undervoltage threshold. */
#define MC33774_BAL_GLOB_CFG_GLOBUV1BALEN_INDEPENDENT_ENUM_VAL \
  (0U)

/* Enumerated value STOP: Balancing for all cells stops once the global undervoltage threshold is reached by any cell. */
#define MC33774_BAL_GLOB_CFG_GLOBUV1BALEN_STOP_ENUM_VAL      (1U)

/* Field TEMPMODBALEN: Enables the temperature modulated balancing. After an over-temperature condition the balancing is halted until an under-temperature condition is detected. */
#define MC33774_BAL_GLOB_CFG_TEMPMODBALEN_SHIFT              (0x4U)
#define MC33774_BAL_GLOB_CFG_TEMPMODBALEN_MASK               (0x10U)
#define MC33774_BAL_GLOB_CFG_TEMPMODBALEN_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_TEMPMODBALEN_SHIFT)) & MC33774_BAL_GLOB_CFG_TEMPMODBALEN_MASK))

/* Enumerated value NOTEMPMOD: Balancing is not temperature modulated. */
#define MC33774_BAL_GLOB_CFG_TEMPMODBALEN_NOTEMPMOD_ENUM_VAL \
  (0U)

/* Enumerated value TEMPMOD: Balancing is temperature modulated. */
#define MC33774_BAL_GLOB_CFG_TEMPMODBALEN_TEMPMOD_ENUM_VAL   (1U)

/* Field CCMBALEN: Enables the constant current balancing. When active the product adapts automatically the PWM duty cycle of the activated balancing channels
based on their primary periodic measurement results to limit the balancing current variation due to cell voltage variation. */
#define MC33774_BAL_GLOB_CFG_CCMBALEN_SHIFT                  (0x5U)
#define MC33774_BAL_GLOB_CFG_CCMBALEN_MASK                   (0x20U)
#define MC33774_BAL_GLOB_CFG_CCMBALEN_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_CCMBALEN_SHIFT)) & MC33774_BAL_GLOB_CFG_CCMBALEN_MASK))

/* Enumerated value NOCCM: Constant Current Balancing is not active. */
#define MC33774_BAL_GLOB_CFG_CCMBALEN_NOCCM_ENUM_VAL         (0U)

/* Enumerated value CCM: Constant Current Balancing is active. */
#define MC33774_BAL_GLOB_CFG_CCMBALEN_CCM_ENUM_VAL           (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_GLOB_CFG_RESERVED0_SHIFT                 (0x6U)
#define MC33774_BAL_GLOB_CFG_RESERVED0_MASK                  (0xC0U)
#define MC33774_BAL_GLOB_CFG_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_RESERVED0_SHIFT)) & MC33774_BAL_GLOB_CFG_RESERVED0_MASK))

/* Field TEMPSRC: Selects the source channel (AINx) for temperature modulated balancing. The MSB is ignored. */
#define MC33774_BAL_GLOB_CFG_TEMPSRC_SHIFT                   (0x8U)
#define MC33774_BAL_GLOB_CFG_TEMPSRC_MASK                    (0x700U)
#define MC33774_BAL_GLOB_CFG_TEMPSRC_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_TEMPSRC_SHIFT)) & MC33774_BAL_GLOB_CFG_TEMPSRC_MASK))

/* Enumerated value AIN0: Selects AIN0 as source for temperature measurement. */
#define MC33774_BAL_GLOB_CFG_TEMPSRC_AIN0_ENUM_VAL           (0U)

/* Enumerated value AIN1: Selects AIN1 as source for temperature measurement. */
#define MC33774_BAL_GLOB_CFG_TEMPSRC_AIN1_ENUM_VAL           (1U)

/* Enumerated value AIN2: Selects AIN2 as source for temperature measurement. */
#define MC33774_BAL_GLOB_CFG_TEMPSRC_AIN2_ENUM_VAL           (2U)

/* Enumerated value AIN3: Selects AIN3 as source for temperature measurement. */
#define MC33774_BAL_GLOB_CFG_TEMPSRC_AIN3_ENUM_VAL           (3U)

/* Field reserved1: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_GLOB_CFG_RESERVED1_SHIFT                 (0xBU)
#define MC33774_BAL_GLOB_CFG_RESERVED1_MASK                  (0xF800U)
#define MC33774_BAL_GLOB_CFG_RESERVED1_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_CFG_RESERVED1_SHIFT)) & MC33774_BAL_GLOB_CFG_RESERVED1_MASK))

/* --------------------------------------------------------------------------
 * BAL_GLOB_TO_TMR (read-write):The Global Balancing timeout timer register is used to configure the maximum balancing time for all balancing activities to make sure that in case of fault the balancing switches are switched OFF.
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_GLOB_TO_TMR_OFFSET                       (0x1001U)
#define MC33774_BAL_GLOB_TO_TMR_RW_MASK                      (0xFFFFU)
#define MC33774_BAL_GLOB_TO_TMR_RD_MASK                      (0xFFFFU)
#define MC33774_BAL_GLOB_TO_TMR_WR_MASK                      (0xFFFFU)
#define MC33774_BAL_GLOB_TO_TMR_MW_MASK                      (0x0U)
#define MC33774_BAL_GLOB_TO_TMR_RA_MASK                      (0x0U)
#define MC33774_BAL_GLOB_TO_TMR_POR_MASK                     (0xFFFFU)
#define MC33774_BAL_GLOB_TO_TMR_POR_VAL                      (0x0U)

/* Field TOTIME: Balancing timeout value, used for normal balancing. The value of this field represents the current counter value when read. The BAL_GLOB_CFG.BALEN is cleared when zero is reached.
The counter saturates at zero. It counts down regardless of the balancing enable state as long as its value is non-zero. */
#define MC33774_BAL_GLOB_TO_TMR_TOTIME_SHIFT                 (0x0U)
#define MC33774_BAL_GLOB_TO_TMR_TOTIME_MASK                  (0xFFFFU)
#define MC33774_BAL_GLOB_TO_TMR_TOTIME_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_TO_TMR_TOTIME_SHIFT)) & MC33774_BAL_GLOB_TO_TMR_TOTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is expired */
#define MC33774_BAL_GLOB_TO_TMR_TOTIME_EXPIRED_ENUM_VAL      (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_GLOB_TO_TMR_TOTIME_BALTIME_ENUM_VAL      (1U)

/* Enumerated value MAX: Maximum balancing time = 655350 seconds = approximately 182 hours = approximately 7.6 days */
#define MC33774_BAL_GLOB_TO_TMR_TOTIME_MAX_ENUM_VAL          (65535U)

/* --------------------------------------------------------------------------
 * BAL_CH_CFG0 (read-write):balancing channel individual enable channel 0 - 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_CH_CFG0_OFFSET                           (0x1002U)
#define MC33774_BAL_CH_CFG0_RW_MASK                          (0xFFFFU)
#define MC33774_BAL_CH_CFG0_RD_MASK                          (0xFFFFU)
#define MC33774_BAL_CH_CFG0_WR_MASK                          (0xFFFFU)
#define MC33774_BAL_CH_CFG0_MW_MASK                          (0x0U)
#define MC33774_BAL_CH_CFG0_RA_MASK                          (0x0U)
#define MC33774_BAL_CH_CFG0_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_CH_CFG0_POR_VAL                          (0x0U)

/* Field CHEN0: Enable balancing for channel 0. The bit is cleared by the device in case of: a) a detected over-current condition on channel 0.
b) a detected and enabled individual under-voltage condition for channel 0. c) the channel timer of channel 0 (BAL_TMR_CH0) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN0_SHIFT                      (0x0U)
#define MC33774_BAL_CH_CFG0_CHEN0_MASK                       (0x1U)
#define MC33774_BAL_CH_CFG0_CHEN0_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN0_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN0_MASK))

/* Enumerated value DISABLED: Balancing for Channel 0 is disabled. The balancing timer for Channel 0 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN0_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 0 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN0_ENABLED_ENUM_VAL           (1U)

/* Field CHEN1: Enable balancing for channel 1. The bit is cleared by the device in case of: a) a detected over-current condition on channel 1.
b) a detected and enabled individual under-voltage condition for channel 1. c) the channel timer of channel 1 (BAL_TMR_CH1) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN1_SHIFT                      (0x1U)
#define MC33774_BAL_CH_CFG0_CHEN1_MASK                       (0x2U)
#define MC33774_BAL_CH_CFG0_CHEN1_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN1_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN1_MASK))

/* Enumerated value DISABLED: Balancing for Channel 1 is disabled. The balancing timer for Channel 1 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN1_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 1 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN1_ENABLED_ENUM_VAL           (1U)

/* Field CHEN2: Enable balancing for channel 2. The bit is cleared by the device in case of: a) a detected over-current condition on channel 2.
b) a detected and enabled individual under-voltage condition for channel 2. c) the channel timer of channel 2 (BAL_TMR_CH2) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN2_SHIFT                      (0x2U)
#define MC33774_BAL_CH_CFG0_CHEN2_MASK                       (0x4U)
#define MC33774_BAL_CH_CFG0_CHEN2_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN2_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN2_MASK))

/* Enumerated value DISABLED: Balancing for Channel 2 is disabled. The balancing timer for Channel 2 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN2_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 2 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN2_ENABLED_ENUM_VAL           (1U)

/* Field CHEN3: Enable balancing for channel 3. The bit is cleared by the device in case of: a) a detected over-current condition on channel 3.
b) a detected and enabled individual under-voltage condition for channel 3. c) the channel timer of channel 3 (BAL_TMR_CH3) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN3_SHIFT                      (0x3U)
#define MC33774_BAL_CH_CFG0_CHEN3_MASK                       (0x8U)
#define MC33774_BAL_CH_CFG0_CHEN3_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN3_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN3_MASK))

/* Enumerated value DISABLED: Balancing for Channel 3 is disabled. The balancing timer for Channel 3 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN3_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 3 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN3_ENABLED_ENUM_VAL           (1U)

/* Field CHEN4: Enable balancing for channel 4. The bit is cleared by the device in case of: a) a detected over-current condition on channel 4.
b) a detected and enabled individual under-voltage condition for channel 4. c) the channel timer of channel 4 (BAL_TMR_CH4) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN4_SHIFT                      (0x4U)
#define MC33774_BAL_CH_CFG0_CHEN4_MASK                       (0x10U)
#define MC33774_BAL_CH_CFG0_CHEN4_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN4_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN4_MASK))

/* Enumerated value DISABLED: Balancing for Channel 4 is disabled. The balancing timer for Channel 4 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN4_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 4 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN4_ENABLED_ENUM_VAL           (1U)

/* Field CHEN5: Enable balancing for channel 5. The bit is cleared by the device in case of: a) a detected over-current condition on channel 5.
b) a detected and enabled individual under-voltage condition for channel 5. c) the channel timer of channel 5 (BAL_TMR_CH5) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN5_SHIFT                      (0x5U)
#define MC33774_BAL_CH_CFG0_CHEN5_MASK                       (0x20U)
#define MC33774_BAL_CH_CFG0_CHEN5_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN5_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN5_MASK))

/* Enumerated value DISABLED: Balancing for Channel 5 is disabled. The balancing timer for Channel 5 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN5_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 5 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN5_ENABLED_ENUM_VAL           (1U)

/* Field CHEN6: Enable balancing for channel 6. The bit is cleared by the device in case of: a) a detected over-current condition on channel 6.
b) a detected and enabled individual under-voltage condition for channel 6. c) the channel timer of channel 6 (BAL_TMR_CH6) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN6_SHIFT                      (0x6U)
#define MC33774_BAL_CH_CFG0_CHEN6_MASK                       (0x40U)
#define MC33774_BAL_CH_CFG0_CHEN6_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN6_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN6_MASK))

/* Enumerated value DISABLED: Balancing for Channel 6 is disabled. The balancing timer for Channel 6 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN6_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 6 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN6_ENABLED_ENUM_VAL           (1U)

/* Field CHEN7: Enable balancing for channel 7. The bit is cleared by the device in case of: a) a detected over-current condition on channel 7.
b) a detected and enabled individual under-voltage condition for channel 7. c) the channel timer of channel 7 (BAL_TMR_CH7) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN7_SHIFT                      (0x7U)
#define MC33774_BAL_CH_CFG0_CHEN7_MASK                       (0x80U)
#define MC33774_BAL_CH_CFG0_CHEN7_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN7_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN7_MASK))

/* Enumerated value DISABLED: Balancing for Channel 7 is disabled. The balancing timer for Channel 7 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN7_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 7 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN7_ENABLED_ENUM_VAL           (1U)

/* Field CHEN8: Enable balancing for channel 8. The bit is cleared by the device in case of: a) a detected over-current condition on channel 8.
b) a detected and enabled individual under-voltage condition for channel 8. c) the channel timer of channel 8 (BAL_TMR_CH8) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN8_SHIFT                      (0x8U)
#define MC33774_BAL_CH_CFG0_CHEN8_MASK                       (0x100U)
#define MC33774_BAL_CH_CFG0_CHEN8_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN8_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN8_MASK))

/* Enumerated value DISABLED: Balancing for Channel 8 is disabled. The balancing timer for Channel 8 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN8_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 8 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN8_ENABLED_ENUM_VAL           (1U)

/* Field CHEN9: Enable balancing for channel 9. The bit is cleared by the device in case of: a) a detected over-current condition on channel 9.
b) a detected and enabled individual under-voltage condition for channel 9. c) the channel timer of channel 9 (BAL_TMR_CH9) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN9_SHIFT                      (0x9U)
#define MC33774_BAL_CH_CFG0_CHEN9_MASK                       (0x200U)
#define MC33774_BAL_CH_CFG0_CHEN9_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN9_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN9_MASK))

/* Enumerated value DISABLED: Balancing for Channel 9 is disabled. The balancing timer for Channel 9 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN9_DISABLED_ENUM_VAL          (0U)

/* Enumerated value ENABLED: Balancing for Channel 9 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN9_ENABLED_ENUM_VAL           (1U)

/* Field CHEN10: Enable balancing for channel 10. The bit is cleared by the device in case of: a) a detected over-current condition on channel 10.
b) a detected and enabled individual under-voltage condition for channel 10. c) the channel timer of channel 10 (BAL_TMR_CH10) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN10_SHIFT                     (0xAU)
#define MC33774_BAL_CH_CFG0_CHEN10_MASK                      (0x400U)
#define MC33774_BAL_CH_CFG0_CHEN10_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN10_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN10_MASK))

/* Enumerated value DISABLED: Balancing for Channel 10 is disabled. The balancing timer for Channel 10 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN10_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 10 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN10_ENABLED_ENUM_VAL          (1U)

/* Field CHEN11: Enable balancing for channel 11. The bit is cleared by the device in case of: a) a detected over-current condition on channel 11.
b) a detected and enabled individual under-voltage condition for channel 11. c) the channel timer of channel 11 (BAL_TMR_CH11) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN11_SHIFT                     (0xBU)
#define MC33774_BAL_CH_CFG0_CHEN11_MASK                      (0x800U)
#define MC33774_BAL_CH_CFG0_CHEN11_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN11_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN11_MASK))

/* Enumerated value DISABLED: Balancing for Channel 11 is disabled. The balancing timer for Channel 11 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN11_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 11 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN11_ENABLED_ENUM_VAL          (1U)

/* Field CHEN12: Enable balancing for channel 12. The bit is cleared by the device in case of: a) a detected over-current condition on channel 12.
b) a detected and enabled individual under-voltage condition for channel 12. c) the channel timer of channel 12 (BAL_TMR_CH12) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN12_SHIFT                     (0xCU)
#define MC33774_BAL_CH_CFG0_CHEN12_MASK                      (0x1000U)
#define MC33774_BAL_CH_CFG0_CHEN12_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN12_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN12_MASK))

/* Enumerated value DISABLED: Balancing for Channel 12 is disabled. The balancing timer for Channel 12 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN12_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 12 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN12_ENABLED_ENUM_VAL          (1U)

/* Field CHEN13: Enable balancing for channel 13. The bit is cleared by the device in case of: a) a detected over-current condition on channel 13.
b) a detected and enabled individual under-voltage condition for channel 13. c) the channel timer of channel 13 (BAL_TMR_CH13) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN13_SHIFT                     (0xDU)
#define MC33774_BAL_CH_CFG0_CHEN13_MASK                      (0x2000U)
#define MC33774_BAL_CH_CFG0_CHEN13_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN13_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN13_MASK))

/* Enumerated value DISABLED: Balancing for Channel 13 is disabled. The balancing timer for Channel 13 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN13_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 13 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN13_ENABLED_ENUM_VAL          (1U)

/* Field CHEN14: Enable balancing for channel 14. The bit is cleared by the device in case of: a) a detected over-current condition on channel 14.
b) a detected and enabled individual under-voltage condition for channel 14. c) the channel timer of channel 14 (BAL_TMR_CH14) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN14_SHIFT                     (0xEU)
#define MC33774_BAL_CH_CFG0_CHEN14_MASK                      (0x4000U)
#define MC33774_BAL_CH_CFG0_CHEN14_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN14_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN14_MASK))

/* Enumerated value DISABLED: Balancing for Channel 14 is disabled. The balancing timer for Channel 14 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN14_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 15 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN14_ENABLED_ENUM_VAL          (1U)

/* Field CHEN15: Enable balancing for channel 15. The bit is cleared by the device in case of: a) a detected over-current condition on channel 15.
b) a detected and enabled individual under-voltage condition for channel 15. c) the channel timer of channel 15 (BAL_TMR_CH15) is zero. */
#define MC33774_BAL_CH_CFG0_CHEN15_SHIFT                     (0xFU)
#define MC33774_BAL_CH_CFG0_CHEN15_MASK                      (0x8000U)
#define MC33774_BAL_CH_CFG0_CHEN15_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG0_CHEN15_SHIFT)) & MC33774_BAL_CH_CFG0_CHEN15_MASK))

/* Enumerated value DISABLED: Balancing for Channel 15 is disabled. The balancing timer for Channel 15 is stopped. */
#define MC33774_BAL_CH_CFG0_CHEN15_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 15 is enabled. */
#define MC33774_BAL_CH_CFG0_CHEN15_ENABLED_ENUM_VAL          (1U)

/* --------------------------------------------------------------------------
 * BAL_CH_CFG1 (read-write):balancing channel individual enable channel 16 - 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_CH_CFG1_OFFSET                           (0x1003U)
#define MC33774_BAL_CH_CFG1_RW_MASK                          (0x3U)
#define MC33774_BAL_CH_CFG1_RD_MASK                          (0x3U)
#define MC33774_BAL_CH_CFG1_WR_MASK                          (0x3U)
#define MC33774_BAL_CH_CFG1_MW_MASK                          (0x0U)
#define MC33774_BAL_CH_CFG1_RA_MASK                          (0x0U)
#define MC33774_BAL_CH_CFG1_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_CH_CFG1_POR_VAL                          (0x0U)

/* Field CHEN16: Enable balancing for channel 16. The bit is cleared by the device in case of: a) a detected over-current condition on channel 16.
b) a detected and enabled individual under-voltage condition for channel 16. c) the channel timer of channel 16 (BAL_TMR_CH16) is zero. */
#define MC33774_BAL_CH_CFG1_CHEN16_SHIFT                     (0x0U)
#define MC33774_BAL_CH_CFG1_CHEN16_MASK                      (0x1U)
#define MC33774_BAL_CH_CFG1_CHEN16_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG1_CHEN16_SHIFT)) & MC33774_BAL_CH_CFG1_CHEN16_MASK))

/* Enumerated value DISABLED: Balancing for Channel 16 is disabled. The balancing timer for Channel 16 is stopped. */
#define MC33774_BAL_CH_CFG1_CHEN16_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 16 is enabled. */
#define MC33774_BAL_CH_CFG1_CHEN16_ENABLED_ENUM_VAL          (1U)

/* Field CHEN17: Enable balancing for channel 17. The bit is cleared by the device in case of: a) a detected over-current condition on channel 17.
b) a detected and enabled individual under-voltage condition for channel 17. c) the channel timer of channel 17 (BAL_TMR_CH17) is zero. */
#define MC33774_BAL_CH_CFG1_CHEN17_SHIFT                     (0x1U)
#define MC33774_BAL_CH_CFG1_CHEN17_MASK                      (0x2U)
#define MC33774_BAL_CH_CFG1_CHEN17_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG1_CHEN17_SHIFT)) & MC33774_BAL_CH_CFG1_CHEN17_MASK))

/* Enumerated value DISABLED: Balancing for Channel 17 is disabled. The balancing timer for Channel 17 is stopped. */
#define MC33774_BAL_CH_CFG1_CHEN17_DISABLED_ENUM_VAL         (0U)

/* Enumerated value ENABLED: Balancing for Channel 17 is enabled. */
#define MC33774_BAL_CH_CFG1_CHEN17_ENABLED_ENUM_VAL          (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_CH_CFG1_RESERVED0_SHIFT                  (0x2U)
#define MC33774_BAL_CH_CFG1_RESERVED0_MASK                   (0xFFFCU)
#define MC33774_BAL_CH_CFG1_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_CFG1_RESERVED0_SHIFT)) & MC33774_BAL_CH_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PRE_TMR (read-write):pre-balancing timer
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PRE_TMR_OFFSET                           (0x1004U)
#define MC33774_BAL_PRE_TMR_RW_MASK                          (0xFFFFU)
#define MC33774_BAL_PRE_TMR_RD_MASK                          (0xFFFFU)
#define MC33774_BAL_PRE_TMR_WR_MASK                          (0xFFFFU)
#define MC33774_BAL_PRE_TMR_MW_MASK                          (0x0U)
#define MC33774_BAL_PRE_TMR_RA_MASK                          (0x0U)
#define MC33774_BAL_PRE_TMR_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PRE_TMR_POR_VAL                          (0x0U)

/* Field PREBALTIME: Downcounter which runs if BALEN is set. Inhibits the balancing and holds the individual channel timer. The value of this field represents the current counter value when read.
The counting saturates at 0 and activates the balancing. The BAL_GLOB_TO_TMR is not influenced by this timer. */
#define MC33774_BAL_PRE_TMR_PREBALTIME_SHIFT                 (0x0U)
#define MC33774_BAL_PRE_TMR_PREBALTIME_MASK                  (0xFFFFU)
#define MC33774_BAL_PRE_TMR_PREBALTIME_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PRE_TMR_PREBALTIME_SHIFT)) & MC33774_BAL_PRE_TMR_PREBALTIME_MASK))

/* Enumerated value EXPIRED: Pre-balancing time is expired. */
#define MC33774_BAL_PRE_TMR_PREBALTIME_EXPIRED_ENUM_VAL      (0U)

/* Enumerated value PREBAL: Pre-balancing time is set to PREBAL * 10 seconds */
#define MC33774_BAL_PRE_TMR_PREBALTIME_PREBAL_ENUM_VAL       (1U)

/* Enumerated value MAX: Maximum pre-balancing time = 655350 seconds = approximately 182 hours = approximately 7.6 days */
#define MC33774_BAL_PRE_TMR_PREBALTIME_MAX_ENUM_VAL          (65535U)

/* --------------------------------------------------------------------------
 * BAL_AUTO_DISCHRG_CTRL (read-write):emergency discharge enable
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_AUTO_DISCHRG_CTRL_OFFSET                 (0x1005U)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_RW_MASK                (0xFFFFU)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_RD_MASK                (0xFFFFU)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_WR_MASK                (0xFFFFU)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_MW_MASK                (0x0U)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_RA_MASK                (0x0U)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_POR_MASK               (0xFFFFU)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_POR_VAL                (0x2152U)

/* Field KEY: Key for enabling auto discharge. After enabling, discharge will continue until disable key is received. Other values than DEADh or 2152h have no influence on the device functionality. */
#define MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_SHIFT              (0x0U)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_MASK               (0xFFFFU)
#define MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_SHIFT)) & MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_MASK))

/* Enumerated value OTHERS: Other values will be ignored. */
#define MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_OTHERS_ENUM_VAL    (1U)

/* Enumerated value DISABLED: Disable key for auto discharge. */
#define MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_DISABLED_ENUM_VAL \
  (8530U)

/* Enumerated value ENABLED: Enable key for auto discharge. */
#define MC33774_BAL_AUTO_DISCHRG_CTRL_KEY_ENABLED_ENUM_VAL   (57005U)

/* --------------------------------------------------------------------------
 * BAL_SWITCH_MON_CFG0 (read-write):balancing switch monitoring enable
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_SWITCH_MON_CFG0_OFFSET                   (0x1006U)
#define MC33774_BAL_SWITCH_MON_CFG0_RW_MASK                  (0xFFFFU)
#define MC33774_BAL_SWITCH_MON_CFG0_RD_MASK                  (0xFFFFU)
#define MC33774_BAL_SWITCH_MON_CFG0_WR_MASK                  (0xFFFFU)
#define MC33774_BAL_SWITCH_MON_CFG0_MW_MASK                  (0x0U)
#define MC33774_BAL_SWITCH_MON_CFG0_RA_MASK                  (0x0U)
#define MC33774_BAL_SWITCH_MON_CFG0_POR_MASK                 (0xFFFFU)
#define MC33774_BAL_SWITCH_MON_CFG0_POR_VAL                  (0xFFFFU)

/* Field MONEN0: Enable balancing switch monitoring for channel 0. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN0_SHIFT             (0x0U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN0_MASK              (0x1U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN0_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN0_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN0_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 0 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN0_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 0 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN0_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN1: Enable balancing switch monitoring for channel 1. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN1_SHIFT             (0x1U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN1_MASK              (0x2U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN1_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN1_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN1_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 1 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN1_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 1 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN1_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN2: Enable balancing switch monitoring for channel 2. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN2_SHIFT             (0x2U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN2_MASK              (0x4U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN2_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN2_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN2_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 2 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN2_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 2 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN2_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN3: Enable balancing switch monitoring for channel 3. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN3_SHIFT             (0x3U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN3_MASK              (0x8U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN3_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN3_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN3_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 3 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN3_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 3 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN3_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN4: Enable balancing switch monitoring for channel 4. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN4_SHIFT             (0x4U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN4_MASK              (0x10U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN4_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN4_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN4_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 4 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN4_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 4 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN4_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN5: Enable balancing switch monitoring for channel 5. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN5_SHIFT             (0x5U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN5_MASK              (0x20U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN5_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN5_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN5_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 5 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN5_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 5 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN5_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN6: Enable balancing switch monitoring for channel 6. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN6_SHIFT             (0x6U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN6_MASK              (0x40U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN6_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN6_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN6_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 6 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN6_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 6 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN6_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN7: Enable balancing switch monitoring for channel 7. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN7_SHIFT             (0x7U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN7_MASK              (0x80U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN7_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN7_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN7_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 7 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN7_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 7 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN7_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN8: Enable balancing switch monitoring for channel 8. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN8_SHIFT             (0x8U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN8_MASK              (0x100U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN8_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN8_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN8_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 8 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN8_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 8 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN8_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN9: Enable balancing switch monitoring for channel 9. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN9_SHIFT             (0x9U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN9_MASK              (0x200U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN9_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN9_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN9_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 9 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN9_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 9 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN9_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN10: Enable balancing switch monitoring for channel 10. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN10_SHIFT            (0xAU)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN10_MASK             (0x400U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN10_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN10_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN10_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 10 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN10_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 10 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN10_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN11: Enable balancing switch monitoring for channel 11. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN11_SHIFT            (0xBU)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN11_MASK             (0x800U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN11_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN11_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN11_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 11 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN11_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 11 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN11_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN12: Enable balancing switch monitoring for channel 12. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN12_SHIFT            (0xCU)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN12_MASK             (0x1000U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN12_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN12_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN12_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 12 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN12_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 12 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN12_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN13: Enable balancing switch monitoring for channel 13. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN13_SHIFT            (0xDU)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN13_MASK             (0x2000U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN13_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN13_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN13_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 13 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN13_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 13 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN13_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN14: Enable balancing switch monitoring for channel 14. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN14_SHIFT            (0xEU)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN14_MASK             (0x4000U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN14_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN14_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN14_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 14 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN14_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 14 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN14_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN15: Enable balancing switch monitoring for channel 15. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN15_SHIFT            (0xFU)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN15_MASK             (0x8000U)
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN15_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG0_MONEN15_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG0_MONEN15_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 15 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN15_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 15 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG0_MONEN15_ENABLED_ENUM_VAL \
  (1U)

/* --------------------------------------------------------------------------
 * BAL_SWITCH_MON_CFG1 (read-write):balancing switch monitoring enable
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_SWITCH_MON_CFG1_OFFSET                   (0x1007U)
#define MC33774_BAL_SWITCH_MON_CFG1_RW_MASK                  (0x3U)
#define MC33774_BAL_SWITCH_MON_CFG1_RD_MASK                  (0x3U)
#define MC33774_BAL_SWITCH_MON_CFG1_WR_MASK                  (0x3U)
#define MC33774_BAL_SWITCH_MON_CFG1_MW_MASK                  (0x0U)
#define MC33774_BAL_SWITCH_MON_CFG1_RA_MASK                  (0x0U)
#define MC33774_BAL_SWITCH_MON_CFG1_POR_MASK                 (0xFFFFU)
#define MC33774_BAL_SWITCH_MON_CFG1_POR_VAL                  (0x3U)

/* Field MONEN16: Enable balancing switch monitoring for channel 16. */
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN16_SHIFT            (0x0U)
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN16_MASK             (0x1U)
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN16_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG1_MONEN16_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG1_MONEN16_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 16 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN16_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 16 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN16_ENABLED_ENUM_VAL \
  (1U)

/* Field MONEN17: Enable balancing switch monitoring for channel 17. */
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN17_SHIFT            (0x1U)
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN17_MASK             (0x2U)
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN17_U16(x)           (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG1_MONEN17_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG1_MONEN17_MASK))

/* Enumerated value DISABLED: Balancing switch monitoring for Channel 17 is disabled. */
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN17_DISABLED_ENUM_VAL \
  (0U)

/* Enumerated value ENABLED: Balancing switch monitoring for Channel 17 is enabled. */
#define MC33774_BAL_SWITCH_MON_CFG1_MONEN17_ENABLED_ENUM_VAL \
  (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_SWITCH_MON_CFG1_RESERVED0_SHIFT          (0x2U)
#define MC33774_BAL_SWITCH_MON_CFG1_RESERVED0_MASK           (0xFFFCU)
#define MC33774_BAL_SWITCH_MON_CFG1_RESERVED0_U16(x)         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_MON_CFG1_RESERVED0_SHIFT)) & MC33774_BAL_SWITCH_MON_CFG1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * FULL_PWM_CYCLE_VOLTAGE (read-write):full PWM cycle voltage
 * -------------------------------------------------------------------------- */
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_OFFSET                (0x1008U)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_RW_MASK               (0xFFFFU)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_RD_MASK               (0xFFFFU)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_WR_MASK               (0xFFFFU)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_MW_MASK               (0x0U)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_RA_MASK               (0x0U)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_POR_MASK              (0xFFFFU)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_POR_VAL               (0x0U)

/* Field FULLPWM: FULL PWM cycle voltage setting to set the cell voltage on which the balancing is operating at the maximum current.( ie : min operating cell voltage in the application) Setting format is the same than cell voltage measurement. */
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_FULLPWM_SHIFT         (0x0U)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_FULLPWM_MASK          (0xFFFFU)
#define MC33774_FULL_PWM_CYCLE_VOLTAGE_FULLPWM_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_FULL_PWM_CYCLE_VOLTAGE_FULLPWM_SHIFT)) & MC33774_FULL_PWM_CYCLE_VOLTAGE_FULLPWM_MASK))

/* --------------------------------------------------------------------------
 * BAL_CH_UV0_STAT0 (read-only):channel under-voltage balancing status channel 0 - 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_CH_UV0_STAT0_OFFSET                      (0x1009U)
#define MC33774_BAL_CH_UV0_STAT0_RW_MASK                     (0x0U)
#define MC33774_BAL_CH_UV0_STAT0_RD_MASK                     (0xFFFFU)
#define MC33774_BAL_CH_UV0_STAT0_WR_MASK                     (0x0U)
#define MC33774_BAL_CH_UV0_STAT0_MW_MASK                     (0x0U)
#define MC33774_BAL_CH_UV0_STAT0_RA_MASK                     (0xFFFFU)
#define MC33774_BAL_CH_UV0_STAT0_POR_MASK                    (0xFFFFU)
#define MC33774_BAL_CH_UV0_STAT0_POR_VAL                     (0x0U)

/* Field CH0: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 0. */
#define MC33774_BAL_CH_UV0_STAT0_CH0_SHIFT                   (0x0U)
#define MC33774_BAL_CH_UV0_STAT0_CH0_MASK                    (0x1U)
#define MC33774_BAL_CH_UV0_STAT0_CH0_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH0_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH0_MASK))

/* Enumerated value NOUV: Balancing of channel 0 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH0_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 0 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH0_UV_ENUM_VAL             (1U)

/* Field CH1: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 1. */
#define MC33774_BAL_CH_UV0_STAT0_CH1_SHIFT                   (0x1U)
#define MC33774_BAL_CH_UV0_STAT0_CH1_MASK                    (0x2U)
#define MC33774_BAL_CH_UV0_STAT0_CH1_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH1_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH1_MASK))

/* Enumerated value NOUV: Balancing of channel 1 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH1_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 1 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH1_UV_ENUM_VAL             (1U)

/* Field CH2: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 2. */
#define MC33774_BAL_CH_UV0_STAT0_CH2_SHIFT                   (0x2U)
#define MC33774_BAL_CH_UV0_STAT0_CH2_MASK                    (0x4U)
#define MC33774_BAL_CH_UV0_STAT0_CH2_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH2_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH2_MASK))

/* Enumerated value NOUV: Balancing of channel 2 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH2_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 2 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH2_UV_ENUM_VAL             (1U)

/* Field CH3: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 3. */
#define MC33774_BAL_CH_UV0_STAT0_CH3_SHIFT                   (0x3U)
#define MC33774_BAL_CH_UV0_STAT0_CH3_MASK                    (0x8U)
#define MC33774_BAL_CH_UV0_STAT0_CH3_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH3_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH3_MASK))

/* Enumerated value NOUV: Balancing of channel 3 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH3_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 3 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH3_UV_ENUM_VAL             (1U)

/* Field CH4: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 4. */
#define MC33774_BAL_CH_UV0_STAT0_CH4_SHIFT                   (0x4U)
#define MC33774_BAL_CH_UV0_STAT0_CH4_MASK                    (0x10U)
#define MC33774_BAL_CH_UV0_STAT0_CH4_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH4_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH4_MASK))

/* Enumerated value NOUV: Balancing of channel 4 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH4_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 4 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH4_UV_ENUM_VAL             (1U)

/* Field CH5: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 5. */
#define MC33774_BAL_CH_UV0_STAT0_CH5_SHIFT                   (0x5U)
#define MC33774_BAL_CH_UV0_STAT0_CH5_MASK                    (0x20U)
#define MC33774_BAL_CH_UV0_STAT0_CH5_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH5_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH5_MASK))

/* Enumerated value NOUV: Balancing of channel 5 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH5_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 5 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH5_UV_ENUM_VAL             (1U)

/* Field CH6: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 6. */
#define MC33774_BAL_CH_UV0_STAT0_CH6_SHIFT                   (0x6U)
#define MC33774_BAL_CH_UV0_STAT0_CH6_MASK                    (0x40U)
#define MC33774_BAL_CH_UV0_STAT0_CH6_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH6_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH6_MASK))

/* Enumerated value NOUV: Balancing of channel 6 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH6_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 6 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH6_UV_ENUM_VAL             (1U)

/* Field CH7: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 7. */
#define MC33774_BAL_CH_UV0_STAT0_CH7_SHIFT                   (0x7U)
#define MC33774_BAL_CH_UV0_STAT0_CH7_MASK                    (0x80U)
#define MC33774_BAL_CH_UV0_STAT0_CH7_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH7_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH7_MASK))

/* Enumerated value NOUV: Balancing of channel 7 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH7_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 7 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH7_UV_ENUM_VAL             (1U)

/* Field CH8: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 8. */
#define MC33774_BAL_CH_UV0_STAT0_CH8_SHIFT                   (0x8U)
#define MC33774_BAL_CH_UV0_STAT0_CH8_MASK                    (0x100U)
#define MC33774_BAL_CH_UV0_STAT0_CH8_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH8_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH8_MASK))

/* Enumerated value NOUV: Balancing of channel 8 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH8_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 8 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH8_UV_ENUM_VAL             (1U)

/* Field CH9: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 9. */
#define MC33774_BAL_CH_UV0_STAT0_CH9_SHIFT                   (0x9U)
#define MC33774_BAL_CH_UV0_STAT0_CH9_MASK                    (0x200U)
#define MC33774_BAL_CH_UV0_STAT0_CH9_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH9_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH9_MASK))

/* Enumerated value NOUV: Balancing of channel 9 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH9_NOUV_ENUM_VAL           (0U)

/* Enumerated value UV: Balancing of channel 9 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH9_UV_ENUM_VAL             (1U)

/* Field CH10: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 10. */
#define MC33774_BAL_CH_UV0_STAT0_CH10_SHIFT                  (0xAU)
#define MC33774_BAL_CH_UV0_STAT0_CH10_MASK                   (0x400U)
#define MC33774_BAL_CH_UV0_STAT0_CH10_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH10_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH10_MASK))

/* Enumerated value NOUV: Balancing of channel 10 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH10_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 10 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH10_UV_ENUM_VAL            (1U)

/* Field CH11: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 11. */
#define MC33774_BAL_CH_UV0_STAT0_CH11_SHIFT                  (0xBU)
#define MC33774_BAL_CH_UV0_STAT0_CH11_MASK                   (0x800U)
#define MC33774_BAL_CH_UV0_STAT0_CH11_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH11_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH11_MASK))

/* Enumerated value NOUV: Balancing of channel 11 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH11_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 11 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH11_UV_ENUM_VAL            (1U)

/* Field CH12: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 12. */
#define MC33774_BAL_CH_UV0_STAT0_CH12_SHIFT                  (0xCU)
#define MC33774_BAL_CH_UV0_STAT0_CH12_MASK                   (0x1000U)
#define MC33774_BAL_CH_UV0_STAT0_CH12_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH12_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH12_MASK))

/* Enumerated value NOUV: Balancing of channel 12 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH12_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 12 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH12_UV_ENUM_VAL            (1U)

/* Field CH13: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 13. */
#define MC33774_BAL_CH_UV0_STAT0_CH13_SHIFT                  (0xDU)
#define MC33774_BAL_CH_UV0_STAT0_CH13_MASK                   (0x2000U)
#define MC33774_BAL_CH_UV0_STAT0_CH13_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH13_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH13_MASK))

/* Enumerated value NOUV: Balancing of channel 13 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH13_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 13 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH13_UV_ENUM_VAL            (1U)

/* Field CH14: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 14. */
#define MC33774_BAL_CH_UV0_STAT0_CH14_SHIFT                  (0xEU)
#define MC33774_BAL_CH_UV0_STAT0_CH14_MASK                   (0x4000U)
#define MC33774_BAL_CH_UV0_STAT0_CH14_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH14_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH14_MASK))

/* Enumerated value NOUV: Balancing of channel 14 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH14_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 14 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH14_UV_ENUM_VAL            (1U)

/* Field CH15: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 15. */
#define MC33774_BAL_CH_UV0_STAT0_CH15_SHIFT                  (0xFU)
#define MC33774_BAL_CH_UV0_STAT0_CH15_MASK                   (0x8000U)
#define MC33774_BAL_CH_UV0_STAT0_CH15_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT0_CH15_SHIFT)) & MC33774_BAL_CH_UV0_STAT0_CH15_MASK))

/* Enumerated value NOUV: Balancing of channel 15 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH15_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 15 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT0_CH15_UV_ENUM_VAL            (1U)

/* --------------------------------------------------------------------------
 * BAL_CH_UV0_STAT1 (read-only):channel under-voltage balancing status channel 16 - 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_CH_UV0_STAT1_OFFSET                      (0x100AU)
#define MC33774_BAL_CH_UV0_STAT1_RW_MASK                     (0x0U)
#define MC33774_BAL_CH_UV0_STAT1_RD_MASK                     (0x3U)
#define MC33774_BAL_CH_UV0_STAT1_WR_MASK                     (0x0U)
#define MC33774_BAL_CH_UV0_STAT1_MW_MASK                     (0x0U)
#define MC33774_BAL_CH_UV0_STAT1_RA_MASK                     (0x3U)
#define MC33774_BAL_CH_UV0_STAT1_POR_MASK                    (0xFFFFU)
#define MC33774_BAL_CH_UV0_STAT1_POR_VAL                     (0x0U)

/* Field CH16: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 16. */
#define MC33774_BAL_CH_UV0_STAT1_CH16_SHIFT                  (0x0U)
#define MC33774_BAL_CH_UV0_STAT1_CH16_MASK                   (0x1U)
#define MC33774_BAL_CH_UV0_STAT1_CH16_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT1_CH16_SHIFT)) & MC33774_BAL_CH_UV0_STAT1_CH16_MASK))

/* Enumerated value NOUV: Balancing of channel 16 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT1_CH16_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 16 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT1_CH16_UV_ENUM_VAL            (1U)

/* Field CH17: Status bit, if a channel under-voltage condition was the reason for disabling individual balancing of channel 17. */
#define MC33774_BAL_CH_UV0_STAT1_CH17_SHIFT                  (0x1U)
#define MC33774_BAL_CH_UV0_STAT1_CH17_MASK                   (0x2U)
#define MC33774_BAL_CH_UV0_STAT1_CH17_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT1_CH17_SHIFT)) & MC33774_BAL_CH_UV0_STAT1_CH17_MASK))

/* Enumerated value NOUV: Balancing of channel 17 was not disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT1_CH17_NOUV_ENUM_VAL          (0U)

/* Enumerated value UV: Balancing of channel 17 was disabled due to under-voltage condition. */
#define MC33774_BAL_CH_UV0_STAT1_CH17_UV_ENUM_VAL            (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_CH_UV0_STAT1_RESERVED0_SHIFT             (0x2U)
#define MC33774_BAL_CH_UV0_STAT1_RESERVED0_MASK              (0xFFFCU)
#define MC33774_BAL_CH_UV0_STAT1_RESERVED0_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_CH_UV0_STAT1_RESERVED0_SHIFT)) & MC33774_BAL_CH_UV0_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_GLOB_UV1_STAT0 (read-only):global under-voltage balancing status channel 0 - 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_GLOB_UV1_STAT0_OFFSET                    (0x100BU)
#define MC33774_BAL_GLOB_UV1_STAT0_RW_MASK                   (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT0_RD_MASK                   (0xFFFFU)
#define MC33774_BAL_GLOB_UV1_STAT0_WR_MASK                   (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT0_MW_MASK                   (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT0_RA_MASK                   (0xFFFFU)
#define MC33774_BAL_GLOB_UV1_STAT0_POR_MASK                  (0xFFFFU)
#define MC33774_BAL_GLOB_UV1_STAT0_POR_VAL                   (0x0U)

/* Field CH0: Status bit, if a global under-voltage of channel 0 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH0_SHIFT                 (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH0_MASK                  (0x1U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH0_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH0_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 0. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH0_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 0. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH0_UV_ENUM_VAL           (1U)

/* Field CH1: Status bit, if a global under-voltage of channel 1 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH1_SHIFT                 (0x1U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH1_MASK                  (0x2U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH1_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH1_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH1_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 1. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH1_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 1. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH1_UV_ENUM_VAL           (1U)

/* Field CH2: Status bit, if a global under-voltage of channel 2 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH2_SHIFT                 (0x2U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH2_MASK                  (0x4U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH2_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH2_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH2_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 2. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH2_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 2. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH2_UV_ENUM_VAL           (1U)

/* Field CH3: Status bit, if a global under-voltage of channel 3 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH3_SHIFT                 (0x3U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH3_MASK                  (0x8U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH3_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH3_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH3_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 3. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH3_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 3. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH3_UV_ENUM_VAL           (1U)

/* Field CH4: Status bit, if a global under-voltage of channel 4 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH4_SHIFT                 (0x4U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH4_MASK                  (0x10U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH4_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH4_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH4_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 4. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH4_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 4. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH4_UV_ENUM_VAL           (1U)

/* Field CH5: Status bit, if a global under-voltage of channel 5 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH5_SHIFT                 (0x5U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH5_MASK                  (0x20U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH5_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH5_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH5_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 5. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH5_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 5. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH5_UV_ENUM_VAL           (1U)

/* Field CH6: Status bit, if a global under-voltage of channel 6 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH6_SHIFT                 (0x6U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH6_MASK                  (0x40U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH6_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH6_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH6_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 6. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH6_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 6. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH6_UV_ENUM_VAL           (1U)

/* Field CH7: Status bit, if a global under-voltage of channel 7 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH7_SHIFT                 (0x7U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH7_MASK                  (0x80U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH7_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH7_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH7_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 7. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH7_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 7. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH7_UV_ENUM_VAL           (1U)

/* Field CH8: Status bit, if a global under-voltage of channel 8 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH8_SHIFT                 (0x8U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH8_MASK                  (0x100U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH8_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH8_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH8_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 8. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH8_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 8. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH8_UV_ENUM_VAL           (1U)

/* Field CH9: Status bit, if a global under-voltage of channel 9 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH9_SHIFT                 (0x9U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH9_MASK                  (0x200U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH9_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH9_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH9_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 9. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH9_NOUV_ENUM_VAL         (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 9. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH9_UV_ENUM_VAL           (1U)

/* Field CH10: Status bit, if a global under-voltage of channel 10 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH10_SHIFT                (0xAU)
#define MC33774_BAL_GLOB_UV1_STAT0_CH10_MASK                 (0x400U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH10_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH10_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH10_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 10. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH10_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 10. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH10_UV_ENUM_VAL          (1U)

/* Field CH11: Status bit, if a global under-voltage of channel 11 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH11_SHIFT                (0xBU)
#define MC33774_BAL_GLOB_UV1_STAT0_CH11_MASK                 (0x800U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH11_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH11_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH11_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 11. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH11_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 11. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH11_UV_ENUM_VAL          (1U)

/* Field CH12: Status bit, if a global under-voltage of channel 12 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH12_SHIFT                (0xCU)
#define MC33774_BAL_GLOB_UV1_STAT0_CH12_MASK                 (0x1000U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH12_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH12_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH12_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 12. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH12_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 12. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH12_UV_ENUM_VAL          (1U)

/* Field CH13: Status bit, if a global under-voltage of channel 13 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH13_SHIFT                (0xDU)
#define MC33774_BAL_GLOB_UV1_STAT0_CH13_MASK                 (0x2000U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH13_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH13_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH13_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 13. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH13_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 13. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH13_UV_ENUM_VAL          (1U)

/* Field CH14: Status bit, if a global under-voltage of channel 14 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH14_SHIFT                (0xEU)
#define MC33774_BAL_GLOB_UV1_STAT0_CH14_MASK                 (0x4000U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH14_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH14_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH14_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 14. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH14_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 14. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH14_UV_ENUM_VAL          (1U)

/* Field CH15: Status bit, if a global under-voltage of channel 15 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH15_SHIFT                (0xFU)
#define MC33774_BAL_GLOB_UV1_STAT0_CH15_MASK                 (0x8000U)
#define MC33774_BAL_GLOB_UV1_STAT0_CH15_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT0_CH15_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT0_CH15_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 15. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH15_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 15. */
#define MC33774_BAL_GLOB_UV1_STAT0_CH15_UV_ENUM_VAL          (1U)

/* --------------------------------------------------------------------------
 * BAL_GLOB_UV1_STAT1 (read-only):global under-voltage balancing status channel 16 - 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_GLOB_UV1_STAT1_OFFSET                    (0x100CU)
#define MC33774_BAL_GLOB_UV1_STAT1_RW_MASK                   (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT1_RD_MASK                   (0x3U)
#define MC33774_BAL_GLOB_UV1_STAT1_WR_MASK                   (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT1_MW_MASK                   (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT1_RA_MASK                   (0x3U)
#define MC33774_BAL_GLOB_UV1_STAT1_POR_MASK                  (0xFFFFU)
#define MC33774_BAL_GLOB_UV1_STAT1_POR_VAL                   (0x0U)

/* Field CH16: Status bit, if a global under-voltage of channel 16 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT1_CH16_SHIFT                (0x0U)
#define MC33774_BAL_GLOB_UV1_STAT1_CH16_MASK                 (0x1U)
#define MC33774_BAL_GLOB_UV1_STAT1_CH16_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT1_CH16_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT1_CH16_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 16. */
#define MC33774_BAL_GLOB_UV1_STAT1_CH16_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 16. */
#define MC33774_BAL_GLOB_UV1_STAT1_CH16_UV_ENUM_VAL          (1U)

/* Field CH17: Status bit, if a global under-voltage of channel 17 condition was the reason for disabling the global balancing. */
#define MC33774_BAL_GLOB_UV1_STAT1_CH17_SHIFT                (0x1U)
#define MC33774_BAL_GLOB_UV1_STAT1_CH17_MASK                 (0x2U)
#define MC33774_BAL_GLOB_UV1_STAT1_CH17_U16(x)               (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT1_CH17_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT1_CH17_MASK))

/* Enumerated value NOUV: Balancing was not disabled due to global under-voltage condition of channel 17. */
#define MC33774_BAL_GLOB_UV1_STAT1_CH17_NOUV_ENUM_VAL        (0U)

/* Enumerated value UV: Balancing was disabled due to global under-voltage condition of channel 17. */
#define MC33774_BAL_GLOB_UV1_STAT1_CH17_UV_ENUM_VAL          (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_GLOB_UV1_STAT1_RESERVED0_SHIFT           (0x2U)
#define MC33774_BAL_GLOB_UV1_STAT1_RESERVED0_MASK            (0xFFFCU)
#define MC33774_BAL_GLOB_UV1_STAT1_RESERVED0_U16(x)          (((uint16_t)(((uint16_t)(x) << MC33774_BAL_GLOB_UV1_STAT1_RESERVED0_SHIFT)) & MC33774_BAL_GLOB_UV1_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_STAT0 (read-only):logical balancing channel status channel 0 - 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_STAT0_OFFSET                             (0x100DU)
#define MC33774_BAL_STAT0_RW_MASK                            (0x0U)
#define MC33774_BAL_STAT0_RD_MASK                            (0xFFFFU)
#define MC33774_BAL_STAT0_WR_MASK                            (0x0U)
#define MC33774_BAL_STAT0_MW_MASK                            (0x0U)
#define MC33774_BAL_STAT0_RA_MASK                            (0x0U)
#define MC33774_BAL_STAT0_POR_MASK                           (0xFFFFU)
#define MC33774_BAL_STAT0_POR_VAL                            (0x0U)

/* Field CH0: Balancing channel 0 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH0_SHIFT                          (0x0U)
#define MC33774_BAL_STAT0_CH0_MASK                           (0x1U)
#define MC33774_BAL_STAT0_CH0_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH0_SHIFT)) & MC33774_BAL_STAT0_CH0_MASK))

/* Enumerated value INACTIVE: Balancing for channel 0 inactive. */
#define MC33774_BAL_STAT0_CH0_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 0 active. */
#define MC33774_BAL_STAT0_CH0_ACTIVE_ENUM_VAL                (1U)

/* Field CH1: Balancing channel 1 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH1_SHIFT                          (0x1U)
#define MC33774_BAL_STAT0_CH1_MASK                           (0x2U)
#define MC33774_BAL_STAT0_CH1_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH1_SHIFT)) & MC33774_BAL_STAT0_CH1_MASK))

/* Enumerated value INACTIVE: Balancing for channel 1 inactive. */
#define MC33774_BAL_STAT0_CH1_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 1 active. */
#define MC33774_BAL_STAT0_CH1_ACTIVE_ENUM_VAL                (1U)

/* Field CH2: Balancing channel 2 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH2_SHIFT                          (0x2U)
#define MC33774_BAL_STAT0_CH2_MASK                           (0x4U)
#define MC33774_BAL_STAT0_CH2_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH2_SHIFT)) & MC33774_BAL_STAT0_CH2_MASK))

/* Enumerated value INACTIVE: Balancing for channel 2 inactive. */
#define MC33774_BAL_STAT0_CH2_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 2 active. */
#define MC33774_BAL_STAT0_CH2_ACTIVE_ENUM_VAL                (1U)

/* Field CH3: Balancing channel 3 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH3_SHIFT                          (0x3U)
#define MC33774_BAL_STAT0_CH3_MASK                           (0x8U)
#define MC33774_BAL_STAT0_CH3_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH3_SHIFT)) & MC33774_BAL_STAT0_CH3_MASK))

/* Enumerated value INACTIVE: Balancing for channel 3 inactive. */
#define MC33774_BAL_STAT0_CH3_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 3 active. */
#define MC33774_BAL_STAT0_CH3_ACTIVE_ENUM_VAL                (1U)

/* Field CH4: Balancing channel 4 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH4_SHIFT                          (0x4U)
#define MC33774_BAL_STAT0_CH4_MASK                           (0x10U)
#define MC33774_BAL_STAT0_CH4_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH4_SHIFT)) & MC33774_BAL_STAT0_CH4_MASK))

/* Enumerated value INACTIVE: Balancing for channel 4 inactive. */
#define MC33774_BAL_STAT0_CH4_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 4 active. */
#define MC33774_BAL_STAT0_CH4_ACTIVE_ENUM_VAL                (1U)

/* Field CH5: Balancing channel 5 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH5_SHIFT                          (0x5U)
#define MC33774_BAL_STAT0_CH5_MASK                           (0x20U)
#define MC33774_BAL_STAT0_CH5_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH5_SHIFT)) & MC33774_BAL_STAT0_CH5_MASK))

/* Enumerated value INACTIVE: Balancing for channel 5 inactive. */
#define MC33774_BAL_STAT0_CH5_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 5 active. */
#define MC33774_BAL_STAT0_CH5_ACTIVE_ENUM_VAL                (1U)

/* Field CH6: Balancing channel 6 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH6_SHIFT                          (0x6U)
#define MC33774_BAL_STAT0_CH6_MASK                           (0x40U)
#define MC33774_BAL_STAT0_CH6_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH6_SHIFT)) & MC33774_BAL_STAT0_CH6_MASK))

/* Enumerated value INACTIVE: Balancing for channel 6 inactive. */
#define MC33774_BAL_STAT0_CH6_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 6 active. */
#define MC33774_BAL_STAT0_CH6_ACTIVE_ENUM_VAL                (1U)

/* Field CH7: Balancing channel 7 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH7_SHIFT                          (0x7U)
#define MC33774_BAL_STAT0_CH7_MASK                           (0x80U)
#define MC33774_BAL_STAT0_CH7_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH7_SHIFT)) & MC33774_BAL_STAT0_CH7_MASK))

/* Enumerated value INACTIVE: Balancing for channel 7 inactive. */
#define MC33774_BAL_STAT0_CH7_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 7 active. */
#define MC33774_BAL_STAT0_CH7_ACTIVE_ENUM_VAL                (1U)

/* Field CH8: Balancing channel 8 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH8_SHIFT                          (0x8U)
#define MC33774_BAL_STAT0_CH8_MASK                           (0x100U)
#define MC33774_BAL_STAT0_CH8_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH8_SHIFT)) & MC33774_BAL_STAT0_CH8_MASK))

/* Enumerated value INACTIVE: Balancing for channel 8 inactive. */
#define MC33774_BAL_STAT0_CH8_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 8 active. */
#define MC33774_BAL_STAT0_CH8_ACTIVE_ENUM_VAL                (1U)

/* Field CH9: Balancing channel 9 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH9_SHIFT                          (0x9U)
#define MC33774_BAL_STAT0_CH9_MASK                           (0x200U)
#define MC33774_BAL_STAT0_CH9_U16(x)                         (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH9_SHIFT)) & MC33774_BAL_STAT0_CH9_MASK))

/* Enumerated value INACTIVE: Balancing for channel 9 inactive. */
#define MC33774_BAL_STAT0_CH9_INACTIVE_ENUM_VAL              (0U)

/* Enumerated value ACTIVE: Balancing for channel 9 active. */
#define MC33774_BAL_STAT0_CH9_ACTIVE_ENUM_VAL                (1U)

/* Field CH10: Balancing channel 10 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH10_SHIFT                         (0xAU)
#define MC33774_BAL_STAT0_CH10_MASK                          (0x400U)
#define MC33774_BAL_STAT0_CH10_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH10_SHIFT)) & MC33774_BAL_STAT0_CH10_MASK))

/* Enumerated value INACTIVE: Balancing for channel 10 inactive. */
#define MC33774_BAL_STAT0_CH10_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 10 active. */
#define MC33774_BAL_STAT0_CH10_ACTIVE_ENUM_VAL               (1U)

/* Field CH11: Balancing channel 11 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH11_SHIFT                         (0xBU)
#define MC33774_BAL_STAT0_CH11_MASK                          (0x800U)
#define MC33774_BAL_STAT0_CH11_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH11_SHIFT)) & MC33774_BAL_STAT0_CH11_MASK))

/* Enumerated value INACTIVE: Balancing for channel 11 inactive. */
#define MC33774_BAL_STAT0_CH11_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 11 active. */
#define MC33774_BAL_STAT0_CH11_ACTIVE_ENUM_VAL               (1U)

/* Field CH12: Balancing channel 12 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH12_SHIFT                         (0xCU)
#define MC33774_BAL_STAT0_CH12_MASK                          (0x1000U)
#define MC33774_BAL_STAT0_CH12_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH12_SHIFT)) & MC33774_BAL_STAT0_CH12_MASK))

/* Enumerated value INACTIVE: Balancing for channel 12 inactive. */
#define MC33774_BAL_STAT0_CH12_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 12 active. */
#define MC33774_BAL_STAT0_CH12_ACTIVE_ENUM_VAL               (1U)

/* Field CH13: Balancing channel 13 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH13_SHIFT                         (0xDU)
#define MC33774_BAL_STAT0_CH13_MASK                          (0x2000U)
#define MC33774_BAL_STAT0_CH13_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH13_SHIFT)) & MC33774_BAL_STAT0_CH13_MASK))

/* Enumerated value INACTIVE: Balancing for channel 13 inactive. */
#define MC33774_BAL_STAT0_CH13_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 13 active. */
#define MC33774_BAL_STAT0_CH13_ACTIVE_ENUM_VAL               (1U)

/* Field CH14: Balancing channel 14 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH14_SHIFT                         (0xEU)
#define MC33774_BAL_STAT0_CH14_MASK                          (0x4000U)
#define MC33774_BAL_STAT0_CH14_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH14_SHIFT)) & MC33774_BAL_STAT0_CH14_MASK))

/* Enumerated value INACTIVE: Balancing for channel 14 inactive. */
#define MC33774_BAL_STAT0_CH14_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 14 active. */
#define MC33774_BAL_STAT0_CH14_ACTIVE_ENUM_VAL               (1U)

/* Field CH15: Balancing channel 15 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT0_CH15_SHIFT                         (0xFU)
#define MC33774_BAL_STAT0_CH15_MASK                          (0x8000U)
#define MC33774_BAL_STAT0_CH15_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT0_CH15_SHIFT)) & MC33774_BAL_STAT0_CH15_MASK))

/* Enumerated value INACTIVE: Balancing for channel 15 inactive. */
#define MC33774_BAL_STAT0_CH15_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 15 active. */
#define MC33774_BAL_STAT0_CH15_ACTIVE_ENUM_VAL               (1U)

/* --------------------------------------------------------------------------
 * BAL_STAT1 (read-only):logical balancing channel status channel 16 - 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_STAT1_OFFSET                             (0x100EU)
#define MC33774_BAL_STAT1_RW_MASK                            (0x0U)
#define MC33774_BAL_STAT1_RD_MASK                            (0x3U)
#define MC33774_BAL_STAT1_WR_MASK                            (0x0U)
#define MC33774_BAL_STAT1_MW_MASK                            (0x0U)
#define MC33774_BAL_STAT1_RA_MASK                            (0x0U)
#define MC33774_BAL_STAT1_POR_MASK                           (0xFFFFU)
#define MC33774_BAL_STAT1_POR_VAL                            (0x0U)

/* Field CH16: Balancing channel 16 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT1_CH16_SHIFT                         (0x0U)
#define MC33774_BAL_STAT1_CH16_MASK                          (0x1U)
#define MC33774_BAL_STAT1_CH16_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT1_CH16_SHIFT)) & MC33774_BAL_STAT1_CH16_MASK))

/* Enumerated value INACTIVE: Balancing for channel 16 inactive. */
#define MC33774_BAL_STAT1_CH16_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 16 active. */
#define MC33774_BAL_STAT1_CH16_ACTIVE_ENUM_VAL               (1U)

/* Field CH17: Balancing channel 17 status (without PWM and odd/even switching) */
#define MC33774_BAL_STAT1_CH17_SHIFT                         (0x1U)
#define MC33774_BAL_STAT1_CH17_MASK                          (0x2U)
#define MC33774_BAL_STAT1_CH17_U16(x)                        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT1_CH17_SHIFT)) & MC33774_BAL_STAT1_CH17_MASK))

/* Enumerated value INACTIVE: Balancing for channel 17 inactive. */
#define MC33774_BAL_STAT1_CH17_INACTIVE_ENUM_VAL             (0U)

/* Enumerated value ACTIVE: Balancing for channel 17 active. */
#define MC33774_BAL_STAT1_CH17_ACTIVE_ENUM_VAL               (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_STAT1_RESERVED0_SHIFT                    (0x2U)
#define MC33774_BAL_STAT1_RESERVED0_MASK                     (0xFFFCU)
#define MC33774_BAL_STAT1_RESERVED0_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT1_RESERVED0_SHIFT)) & MC33774_BAL_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_STAT2 (read-only):balancing status
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_STAT2_OFFSET                             (0x100FU)
#define MC33774_BAL_STAT2_RW_MASK                            (0x0U)
#define MC33774_BAL_STAT2_RD_MASK                            (0xC00FU)
#define MC33774_BAL_STAT2_WR_MASK                            (0x0U)
#define MC33774_BAL_STAT2_MW_MASK                            (0x0U)
#define MC33774_BAL_STAT2_RA_MASK                            (0xC000U)
#define MC33774_BAL_STAT2_POR_MASK                           (0xFFFFU)
#define MC33774_BAL_STAT2_POR_VAL                            (0x0U)

/* Field PREBALTMR: Pre-Balancing status */
#define MC33774_BAL_STAT2_PREBALTMR_SHIFT                    (0x0U)
#define MC33774_BAL_STAT2_PREBALTMR_MASK                     (0x1U)
#define MC33774_BAL_STAT2_PREBALTMR_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT2_PREBALTMR_SHIFT)) & MC33774_BAL_STAT2_PREBALTMR_MASK))

/* Enumerated value INACTIVE: No pre-balancing timer active. */
#define MC33774_BAL_STAT2_PREBALTMR_INACTIVE_ENUM_VAL        (0U)

/* Enumerated value ACTIVE: Pre-balancing timer active (Balancing is inhibited). */
#define MC33774_BAL_STAT2_PREBALTMR_ACTIVE_ENUM_VAL          (1U)

/* Field TEMPBALINHIBIT: Temperature balancing status */
#define MC33774_BAL_STAT2_TEMPBALINHIBIT_SHIFT               (0x1U)
#define MC33774_BAL_STAT2_TEMPBALINHIBIT_MASK                (0x2U)
#define MC33774_BAL_STAT2_TEMPBALINHIBIT_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT2_TEMPBALINHIBIT_SHIFT)) & MC33774_BAL_STAT2_TEMPBALINHIBIT_MASK))

/* Enumerated value INACTIVE: Temperature based balancing control allows balancing. */
#define MC33774_BAL_STAT2_TEMPBALINHIBIT_INACTIVE_ENUM_VAL   (0U)

/* Enumerated value ACTIVE: Temperature based balancing control inhibits balancing. */
#define MC33774_BAL_STAT2_TEMPBALINHIBIT_ACTIVE_ENUM_VAL     (1U)

/* Field AUTODISCHRG: Auto discharge status */
#define MC33774_BAL_STAT2_AUTODISCHRG_SHIFT                  (0x2U)
#define MC33774_BAL_STAT2_AUTODISCHRG_MASK                   (0x4U)
#define MC33774_BAL_STAT2_AUTODISCHRG_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT2_AUTODISCHRG_SHIFT)) & MC33774_BAL_STAT2_AUTODISCHRG_MASK))

/* Enumerated value INACTIVE: Auto discharge inactive */
#define MC33774_BAL_STAT2_AUTODISCHRG_INACTIVE_ENUM_VAL      (0U)

/* Enumerated value ACTIVE: Auto discharge active */
#define MC33774_BAL_STAT2_AUTODISCHRG_ACTIVE_ENUM_VAL        (1U)

/* Field BALPROT: Balancing protection status */
#define MC33774_BAL_STAT2_BALPROT_SHIFT                      (0x3U)
#define MC33774_BAL_STAT2_BALPROT_MASK                       (0x8U)
#define MC33774_BAL_STAT2_BALPROT_U16(x)                     (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT2_BALPROT_SHIFT)) & MC33774_BAL_STAT2_BALPROT_MASK))

/* Enumerated value INACTIVE: Balancing protection allows balancing. */
#define MC33774_BAL_STAT2_BALPROT_INACTIVE_ENUM_VAL          (0U)

/* Enumerated value ACTIVE: Balancing protection inhibits balancing. */
#define MC33774_BAL_STAT2_BALPROT_ACTIVE_ENUM_VAL            (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_STAT2_RESERVED0_SHIFT                    (0x4U)
#define MC33774_BAL_STAT2_RESERVED0_MASK                     (0x3FF0U)
#define MC33774_BAL_STAT2_RESERVED0_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT2_RESERVED0_SHIFT)) & MC33774_BAL_STAT2_RESERVED0_MASK))

/* Field BALPROTFLG: Balancing protection flag. This bit is set when the BALPROT is ACTIVE. */
#define MC33774_BAL_STAT2_BALPROTFLG_SHIFT                   (0xEU)
#define MC33774_BAL_STAT2_BALPROTFLG_MASK                    (0x4000U)
#define MC33774_BAL_STAT2_BALPROTFLG_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT2_BALPROTFLG_SHIFT)) & MC33774_BAL_STAT2_BALPROTFLG_MASK))

/* Enumerated value NOOCCURENCE: Balancing protection was not active. */
#define MC33774_BAL_STAT2_BALPROTFLG_NOOCCURENCE_ENUM_VAL    (0U)

/* Enumerated value OCCURRED: Balancing protection was active. */
#define MC33774_BAL_STAT2_BALPROTFLG_OCCURRED_ENUM_VAL       (1U)

/* Field BALRDY: The ready bit is set after the cell balancing operation is finished.
Reasons for this are that the last BAL_CH_EN.CHx has been cleared by hardware or the BAL_GLOB_CFG.BALEN has been cleared by hardware. With setting of BAL_GLOB_CFG.BALEN this bit is cleared. */
#define MC33774_BAL_STAT2_BALRDY_SHIFT                       (0xFU)
#define MC33774_BAL_STAT2_BALRDY_MASK                        (0x8000U)
#define MC33774_BAL_STAT2_BALRDY_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_STAT2_BALRDY_SHIFT)) & MC33774_BAL_STAT2_BALRDY_MASK))

/* Enumerated value ONGOING: Balancing operation in progress. */
#define MC33774_BAL_STAT2_BALRDY_ONGOING_ENUM_VAL            (0U)

/* Enumerated value FINISHED: Balancing operation finished. */
#define MC33774_BAL_STAT2_BALRDY_FINISHED_ENUM_VAL           (1U)

/* --------------------------------------------------------------------------
 * BAL_SWITCH_STAT0 (read-only):physical balancing channel status channel 0 - 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_SWITCH_STAT0_OFFSET                      (0x1010U)
#define MC33774_BAL_SWITCH_STAT0_RW_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT0_RD_MASK                     (0xFFFFU)
#define MC33774_BAL_SWITCH_STAT0_WR_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT0_MW_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT0_RA_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT0_POR_MASK                    (0xFFFFU)
#define MC33774_BAL_SWITCH_STAT0_POR_VAL                     (0x0U)

/* Field CH0: Balancing FET status channel 0 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH0_SHIFT                   (0x0U)
#define MC33774_BAL_SWITCH_STAT0_CH0_MASK                    (0x1U)
#define MC33774_BAL_SWITCH_STAT0_CH0_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH0_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH0_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH0_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH0_CLOSED_ENUM_VAL         (1U)

/* Field CH1: Balancing FET status channel 1 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH1_SHIFT                   (0x1U)
#define MC33774_BAL_SWITCH_STAT0_CH1_MASK                    (0x2U)
#define MC33774_BAL_SWITCH_STAT0_CH1_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH1_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH1_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH1_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH1_CLOSED_ENUM_VAL         (1U)

/* Field CH2: Balancing FET status channel 2 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH2_SHIFT                   (0x2U)
#define MC33774_BAL_SWITCH_STAT0_CH2_MASK                    (0x4U)
#define MC33774_BAL_SWITCH_STAT0_CH2_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH2_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH2_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH2_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH2_CLOSED_ENUM_VAL         (1U)

/* Field CH3: Balancing FET status channel 3 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH3_SHIFT                   (0x3U)
#define MC33774_BAL_SWITCH_STAT0_CH3_MASK                    (0x8U)
#define MC33774_BAL_SWITCH_STAT0_CH3_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH3_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH3_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH3_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH3_CLOSED_ENUM_VAL         (1U)

/* Field CH4: Balancing FET status channel 4 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH4_SHIFT                   (0x4U)
#define MC33774_BAL_SWITCH_STAT0_CH4_MASK                    (0x10U)
#define MC33774_BAL_SWITCH_STAT0_CH4_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH4_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH4_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH4_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH4_CLOSED_ENUM_VAL         (1U)

/* Field CH5: Balancing FET status channel 5 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH5_SHIFT                   (0x5U)
#define MC33774_BAL_SWITCH_STAT0_CH5_MASK                    (0x20U)
#define MC33774_BAL_SWITCH_STAT0_CH5_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH5_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH5_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH5_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH5_CLOSED_ENUM_VAL         (1U)

/* Field CH6: Balancing FET status channel 6 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH6_SHIFT                   (0x6U)
#define MC33774_BAL_SWITCH_STAT0_CH6_MASK                    (0x40U)
#define MC33774_BAL_SWITCH_STAT0_CH6_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH6_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH6_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH6_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH6_CLOSED_ENUM_VAL         (1U)

/* Field CH7: Balancing FET status channel 7 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH7_SHIFT                   (0x7U)
#define MC33774_BAL_SWITCH_STAT0_CH7_MASK                    (0x80U)
#define MC33774_BAL_SWITCH_STAT0_CH7_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH7_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH7_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH7_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH7_CLOSED_ENUM_VAL         (1U)

/* Field CH8: Balancing FET status channel 8 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH8_SHIFT                   (0x8U)
#define MC33774_BAL_SWITCH_STAT0_CH8_MASK                    (0x100U)
#define MC33774_BAL_SWITCH_STAT0_CH8_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH8_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH8_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH8_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH8_CLOSED_ENUM_VAL         (1U)

/* Field CH9: Balancing FET status channel 9 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH9_SHIFT                   (0x9U)
#define MC33774_BAL_SWITCH_STAT0_CH9_MASK                    (0x200U)
#define MC33774_BAL_SWITCH_STAT0_CH9_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH9_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH9_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH9_OPEN_ENUM_VAL           (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH9_CLOSED_ENUM_VAL         (1U)

/* Field CH10: Balancing FET status channel 10 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH10_SHIFT                  (0xAU)
#define MC33774_BAL_SWITCH_STAT0_CH10_MASK                   (0x400U)
#define MC33774_BAL_SWITCH_STAT0_CH10_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH10_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH10_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH10_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH10_CLOSED_ENUM_VAL        (1U)

/* Field CH11: Balancing FET status channel 11 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH11_SHIFT                  (0xBU)
#define MC33774_BAL_SWITCH_STAT0_CH11_MASK                   (0x800U)
#define MC33774_BAL_SWITCH_STAT0_CH11_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH11_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH11_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH11_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH11_CLOSED_ENUM_VAL        (1U)

/* Field CH12: Balancing FET status channel 12 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH12_SHIFT                  (0xCU)
#define MC33774_BAL_SWITCH_STAT0_CH12_MASK                   (0x1000U)
#define MC33774_BAL_SWITCH_STAT0_CH12_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH12_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH12_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH12_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH12_CLOSED_ENUM_VAL        (1U)

/* Field CH13: Balancing FET status channel 13 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH13_SHIFT                  (0xDU)
#define MC33774_BAL_SWITCH_STAT0_CH13_MASK                   (0x2000U)
#define MC33774_BAL_SWITCH_STAT0_CH13_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH13_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH13_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH13_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH13_CLOSED_ENUM_VAL        (1U)

/* Field CH14: Balancing FET status channel 14 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH14_SHIFT                  (0xEU)
#define MC33774_BAL_SWITCH_STAT0_CH14_MASK                   (0x4000U)
#define MC33774_BAL_SWITCH_STAT0_CH14_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH14_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH14_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH14_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH14_CLOSED_ENUM_VAL        (1U)

/* Field CH15: Balancing FET status channel 15 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT0_CH15_SHIFT                  (0xFU)
#define MC33774_BAL_SWITCH_STAT0_CH15_MASK                   (0x8000U)
#define MC33774_BAL_SWITCH_STAT0_CH15_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT0_CH15_SHIFT)) & MC33774_BAL_SWITCH_STAT0_CH15_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT0_CH15_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT0_CH15_CLOSED_ENUM_VAL        (1U)

/* --------------------------------------------------------------------------
 * BAL_SWITCH_STAT1 (read-only):physical balancing channel status channel 16 - 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_SWITCH_STAT1_OFFSET                      (0x1011U)
#define MC33774_BAL_SWITCH_STAT1_RW_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT1_RD_MASK                     (0x3U)
#define MC33774_BAL_SWITCH_STAT1_WR_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT1_MW_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT1_RA_MASK                     (0x0U)
#define MC33774_BAL_SWITCH_STAT1_POR_MASK                    (0xFFFFU)
#define MC33774_BAL_SWITCH_STAT1_POR_VAL                     (0x0U)

/* Field CH16: Balancing FET status channel 16 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT1_CH16_SHIFT                  (0x0U)
#define MC33774_BAL_SWITCH_STAT1_CH16_MASK                   (0x1U)
#define MC33774_BAL_SWITCH_STAT1_CH16_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT1_CH16_SHIFT)) & MC33774_BAL_SWITCH_STAT1_CH16_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT1_CH16_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT1_CH16_CLOSED_ENUM_VAL        (1U)

/* Field CH17: Balancing FET status channel 17 This is the actual status (including odd/even activation and PWM duty cycle) from the switch monitor circuit. */
#define MC33774_BAL_SWITCH_STAT1_CH17_SHIFT                  (0x1U)
#define MC33774_BAL_SWITCH_STAT1_CH17_MASK                   (0x2U)
#define MC33774_BAL_SWITCH_STAT1_CH17_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT1_CH17_SHIFT)) & MC33774_BAL_SWITCH_STAT1_CH17_MASK))

/* Enumerated value OPEN: Balancing FET is open. */
#define MC33774_BAL_SWITCH_STAT1_CH17_OPEN_ENUM_VAL          (0U)

/* Enumerated value CLOSED: Balancing FET is closed. */
#define MC33774_BAL_SWITCH_STAT1_CH17_CLOSED_ENUM_VAL        (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_SWITCH_STAT1_RESERVED0_SHIFT             (0x2U)
#define MC33774_BAL_SWITCH_STAT1_RESERVED0_MASK              (0xFFFCU)
#define MC33774_BAL_SWITCH_STAT1_RESERVED0_U16(x)            (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_STAT1_RESERVED0_SHIFT)) & MC33774_BAL_SWITCH_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_SWITCH_FLT_STAT0 (read-only):balancing switch fault channel 0 - 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_SWITCH_FLT_STAT0_OFFSET                  (0x1012U)
#define MC33774_BAL_SWITCH_FLT_STAT0_RW_MASK                 (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT0_RD_MASK                 (0xFFFFU)
#define MC33774_BAL_SWITCH_FLT_STAT0_WR_MASK                 (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT0_MW_MASK                 (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT0_RA_MASK                 (0xFFFFU)
#define MC33774_BAL_SWITCH_FLT_STAT0_POR_MASK                (0xFFFFU)
#define MC33774_BAL_SWITCH_FLT_STAT0_POR_VAL                 (0x0U)

/* Field CH0: Balancing switch fault channel 0. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH0_SHIFT               (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH0_MASK                (0x1U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH0_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH0_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH0_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH0_FAULT_ENUM_VAL      (1U)

/* Field CH1: Balancing switch fault channel 1. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH1_SHIFT               (0x1U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH1_MASK                (0x2U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH1_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH1_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH1_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH1_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH1_FAULT_ENUM_VAL      (1U)

/* Field CH2: Balancing switch fault channel 2. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH2_SHIFT               (0x2U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH2_MASK                (0x4U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH2_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH2_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH2_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH2_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH2_FAULT_ENUM_VAL      (1U)

/* Field CH3: Balancing switch fault channel 3. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH3_SHIFT               (0x3U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH3_MASK                (0x8U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH3_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH3_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH3_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH3_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH3_FAULT_ENUM_VAL      (1U)

/* Field CH4: Balancing switch fault channel 4. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH4_SHIFT               (0x4U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH4_MASK                (0x10U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH4_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH4_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH4_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH4_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH4_FAULT_ENUM_VAL      (1U)

/* Field CH5: Balancing switch fault channel 5. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH5_SHIFT               (0x5U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH5_MASK                (0x20U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH5_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH5_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH5_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH5_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH5_FAULT_ENUM_VAL      (1U)

/* Field CH6: Balancing switch fault channel 6. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH6_SHIFT               (0x6U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH6_MASK                (0x40U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH6_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH6_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH6_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH6_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH6_FAULT_ENUM_VAL      (1U)

/* Field CH7: Balancing switch fault channel 7. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH7_SHIFT               (0x7U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH7_MASK                (0x80U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH7_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH7_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH7_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH7_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH7_FAULT_ENUM_VAL      (1U)

/* Field CH8: Balancing switch fault channel 8. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH8_SHIFT               (0x8U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH8_MASK                (0x100U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH8_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH8_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH8_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH8_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH8_FAULT_ENUM_VAL      (1U)

/* Field CH9: Balancing switch fault channel 9. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH9_SHIFT               (0x9U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH9_MASK                (0x200U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH9_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH9_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH9_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH9_NOFLT_ENUM_VAL      (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH9_FAULT_ENUM_VAL      (1U)

/* Field CH10: Balancing switch fault channel 10. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH10_SHIFT              (0xAU)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH10_MASK               (0x400U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH10_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH10_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH10_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH10_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH10_FAULT_ENUM_VAL     (1U)

/* Field CH11: Balancing switch fault channel 11. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH11_SHIFT              (0xBU)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH11_MASK               (0x800U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH11_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH11_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH11_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH11_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH11_FAULT_ENUM_VAL     (1U)

/* Field CH12: Balancing switch fault channel 12. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH12_SHIFT              (0xCU)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH12_MASK               (0x1000U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH12_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH12_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH12_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH12_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH12_FAULT_ENUM_VAL     (1U)

/* Field CH13: Balancing switch fault channel 13. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH13_SHIFT              (0xDU)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH13_MASK               (0x2000U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH13_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH13_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH13_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH13_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH13_FAULT_ENUM_VAL     (1U)

/* Field CH14: Balancing switch fault channel 14. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH14_SHIFT              (0xEU)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH14_MASK               (0x4000U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH14_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH14_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH14_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH14_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH14_FAULT_ENUM_VAL     (1U)

/* Field CH15: Balancing switch fault channel 15. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH15_SHIFT              (0xFU)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH15_MASK               (0x8000U)
#define MC33774_BAL_SWITCH_FLT_STAT0_CH15_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT0_CH15_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT0_CH15_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH15_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT0_CH15_FAULT_ENUM_VAL     (1U)

/* --------------------------------------------------------------------------
 * BAL_SWITCH_FLT_STAT1 (read-only):balancing switch fault channel 16 - 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_SWITCH_FLT_STAT1_OFFSET                  (0x1013U)
#define MC33774_BAL_SWITCH_FLT_STAT1_RW_MASK                 (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT1_RD_MASK                 (0x3U)
#define MC33774_BAL_SWITCH_FLT_STAT1_WR_MASK                 (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT1_MW_MASK                 (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT1_RA_MASK                 (0x3U)
#define MC33774_BAL_SWITCH_FLT_STAT1_POR_MASK                (0xFFFFU)
#define MC33774_BAL_SWITCH_FLT_STAT1_POR_VAL                 (0x0U)

/* Field CH16: Balancing switch fault channel 16. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT1_CH16_SHIFT              (0x0U)
#define MC33774_BAL_SWITCH_FLT_STAT1_CH16_MASK               (0x1U)
#define MC33774_BAL_SWITCH_FLT_STAT1_CH16_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT1_CH16_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT1_CH16_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT1_CH16_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT1_CH16_FAULT_ENUM_VAL     (1U)

/* Field CH17: Balancing switch fault channel 17. Physical state of the Balancing circuit has differed from the expected one. This could be due to a broken switch, leakages or over current. */
#define MC33774_BAL_SWITCH_FLT_STAT1_CH17_SHIFT              (0x1U)
#define MC33774_BAL_SWITCH_FLT_STAT1_CH17_MASK               (0x2U)
#define MC33774_BAL_SWITCH_FLT_STAT1_CH17_U16(x)             (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT1_CH17_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT1_CH17_MASK))

/* Enumerated value NOFLT: No fault detected. */
#define MC33774_BAL_SWITCH_FLT_STAT1_CH17_NOFLT_ENUM_VAL     (0U)

/* Enumerated value FAULT: Wrong switch state has been detected. */
#define MC33774_BAL_SWITCH_FLT_STAT1_CH17_FAULT_ENUM_VAL     (1U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_SWITCH_FLT_STAT1_RESERVED0_SHIFT         (0x2U)
#define MC33774_BAL_SWITCH_FLT_STAT1_RESERVED0_MASK          (0xFFFCU)
#define MC33774_BAL_SWITCH_FLT_STAT1_RESERVED0_U16(x)        (((uint16_t)(((uint16_t)(x) << MC33774_BAL_SWITCH_FLT_STAT1_RESERVED0_SHIFT)) & MC33774_BAL_SWITCH_FLT_STAT1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH_ALL (write-only):virtual register, writes in parallel into BAL_TMR_CH0 up to BAL_TMR_CH17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH_ALL_OFFSET                        (0x101FU)
#define MC33774_BAL_TMR_CH_ALL_RW_MASK                       (0x0U)
#define MC33774_BAL_TMR_CH_ALL_RD_MASK                       (0x0U)
#define MC33774_BAL_TMR_CH_ALL_WR_MASK                       (0x3FFFU)
#define MC33774_BAL_TMR_CH_ALL_MW_MASK                       (0x0U)
#define MC33774_BAL_TMR_CH_ALL_RA_MASK                       (0x0U)
#define MC33774_BAL_TMR_CH_ALL_POR_MASK                      (0xFFFFU)
#define MC33774_BAL_TMR_CH_ALL_POR_VAL                       (0x0U)

/* Field BALTIME: Sets the balancing time for all channels. */
#define MC33774_BAL_TMR_CH_ALL_BALTIME_SHIFT                 (0x0U)
#define MC33774_BAL_TMR_CH_ALL_BALTIME_MASK                  (0x3FFFU)
#define MC33774_BAL_TMR_CH_ALL_BALTIME_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH_ALL_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH_ALL_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH_ALL_BALTIME_EXPIRED_ENUM_VAL      (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH_ALL_BALTIME_BALTIME_ENUM_VAL      (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH_ALL_BALTIME_MAX_ENUM_VAL          (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH_ALL_RESERVED0_SHIFT               (0xEU)
#define MC33774_BAL_TMR_CH_ALL_RESERVED0_MASK                (0xC000U)
#define MC33774_BAL_TMR_CH_ALL_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH_ALL_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH_ALL_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH0 (read-write):balancing timer channel 0
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH0_OFFSET                           (0x1020U)
#define MC33774_BAL_TMR_CH0_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH0_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH0_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH0_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH0_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH0_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH0_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 0 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH0_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH0_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH0_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH0_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH0_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH0_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH0_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH0_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH0_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH0_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH0_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH0_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH0_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH1 (read-write):balancing timer channel 1
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH1_OFFSET                           (0x1021U)
#define MC33774_BAL_TMR_CH1_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH1_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH1_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH1_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH1_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH1_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH1_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 1 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH1_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH1_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH1_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH1_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH1_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH1_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH1_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH1_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH1_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH1_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH1_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH1_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH2 (read-write):balancing timer channel 2
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH2_OFFSET                           (0x1022U)
#define MC33774_BAL_TMR_CH2_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH2_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH2_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH2_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH2_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH2_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH2_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 2 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH2_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH2_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH2_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH2_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH2_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH2_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH2_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH2_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH2_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH2_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH2_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH2_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH2_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH3 (read-write):balancing timer channel 3
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH3_OFFSET                           (0x1023U)
#define MC33774_BAL_TMR_CH3_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH3_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH3_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH3_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH3_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH3_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH3_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 3 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH3_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH3_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH3_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH3_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH3_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH3_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH3_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH3_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH3_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH3_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH3_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH3_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH3_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH4 (read-write):balancing timer channel 4
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH4_OFFSET                           (0x1024U)
#define MC33774_BAL_TMR_CH4_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH4_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH4_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH4_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH4_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH4_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH4_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 4 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH4_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH4_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH4_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH4_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH4_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH4_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH4_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH4_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH4_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH4_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH4_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH4_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH4_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH5 (read-write):balancing timer channel 5
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH5_OFFSET                           (0x1025U)
#define MC33774_BAL_TMR_CH5_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH5_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH5_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH5_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH5_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH5_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH5_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 5 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH5_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH5_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH5_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH5_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH5_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH5_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH5_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH5_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH5_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH5_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH5_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH5_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH5_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH6 (read-write):balancing timer channel 6
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH6_OFFSET                           (0x1026U)
#define MC33774_BAL_TMR_CH6_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH6_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH6_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH6_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH6_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH6_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH6_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 6 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH6_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH6_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH6_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH6_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH6_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH6_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH6_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH6_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH6_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH6_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH6_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH6_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH6_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH7 (read-write):balancing timer channel 7
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH7_OFFSET                           (0x1027U)
#define MC33774_BAL_TMR_CH7_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH7_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH7_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH7_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH7_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH7_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH7_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 7 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH7_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH7_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH7_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH7_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH7_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH7_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH7_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH7_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH7_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH7_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH7_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH7_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH7_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH8 (read-write):balancing timer channel 8
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH8_OFFSET                           (0x1028U)
#define MC33774_BAL_TMR_CH8_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH8_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH8_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH8_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH8_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH8_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH8_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 8 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH8_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH8_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH8_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH8_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH8_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH8_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH8_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH8_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH8_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH8_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH8_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH8_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH8_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH9 (read-write):balancing timer channel 9
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH9_OFFSET                           (0x1029U)
#define MC33774_BAL_TMR_CH9_RW_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH9_RD_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH9_WR_MASK                          (0x3FFFU)
#define MC33774_BAL_TMR_CH9_MW_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH9_RA_MASK                          (0x0U)
#define MC33774_BAL_TMR_CH9_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_TMR_CH9_POR_VAL                          (0x0U)

/* Field BALTIME: Balancing time for channel 9 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH9_BALTIME_SHIFT                    (0x0U)
#define MC33774_BAL_TMR_CH9_BALTIME_MASK                     (0x3FFFU)
#define MC33774_BAL_TMR_CH9_BALTIME_U16(x)                   (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH9_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH9_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH9_BALTIME_EXPIRED_ENUM_VAL         (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH9_BALTIME_BALTIME_ENUM_VAL         (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH9_BALTIME_MAX_ENUM_VAL             (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH9_RESERVED0_SHIFT                  (0xEU)
#define MC33774_BAL_TMR_CH9_RESERVED0_MASK                   (0xC000U)
#define MC33774_BAL_TMR_CH9_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH9_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH9_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH10 (read-write):balancing timer channel 10
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH10_OFFSET                          (0x102AU)
#define MC33774_BAL_TMR_CH10_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH10_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH10_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH10_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH10_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH10_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH10_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 10 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH10_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH10_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH10_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH10_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH10_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH10_BALTIME_EXPIRED_ENUM_VAL        (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH10_BALTIME_BALTIME_ENUM_VAL        (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH10_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH10_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH10_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH10_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH10_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH10_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH11 (read-write):balancing timer channel 11
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH11_OFFSET                          (0x102BU)
#define MC33774_BAL_TMR_CH11_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH11_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH11_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH11_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH11_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH11_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH11_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 11 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH11_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH11_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH11_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH11_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH11_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH11_BALTIME_EXPIRED_ENUM_VAL        (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH11_BALTIME_BALTIME_ENUM_VAL        (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH11_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH11_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH11_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH11_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH11_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH11_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH12 (read-write):balancing timer channel 12
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH12_OFFSET                          (0x102CU)
#define MC33774_BAL_TMR_CH12_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH12_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH12_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH12_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH12_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH12_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH12_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 12 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH12_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH12_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH12_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH12_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH12_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH12_BALTIME_EXPIRED_ENUM_VAL        (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH12_BALTIME_BALTIME_ENUM_VAL        (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH12_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH12_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH12_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH12_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH12_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH12_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH13 (read-write):balancing timer channel 13
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH13_OFFSET                          (0x102DU)
#define MC33774_BAL_TMR_CH13_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH13_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH13_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH13_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH13_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH13_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH13_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 13 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH13_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH13_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH13_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH13_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH13_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH13_BALTIME_EXPIRED_ENUM_VAL        (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH13_BALTIME_BALTIME_ENUM_VAL        (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH13_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH13_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH13_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH13_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH13_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH13_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH14 (read-write):balancing timer channel 14
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH14_OFFSET                          (0x102EU)
#define MC33774_BAL_TMR_CH14_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH14_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH14_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH14_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH14_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH14_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH14_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 14 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH14_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH14_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH14_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH14_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH14_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH14_BALTIME_EXPIRED_ENUM_VAL        (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH14_BALTIME_BALTIME_ENUM_VAL        (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH14_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH14_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH14_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH14_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH14_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH14_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH15 (read-write):balancing timer channel 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH15_OFFSET                          (0x102FU)
#define MC33774_BAL_TMR_CH15_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH15_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH15_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH15_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH15_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH15_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH15_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 15 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH15_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH15_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH15_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH15_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH15_BALTIME_MASK))

/* Enumerated value PWM0: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH15_BALTIME_PWM0_ENUM_VAL           (0U)

/* Enumerated value PWM1: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH15_BALTIME_PWM1_ENUM_VAL           (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH15_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH15_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH15_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH15_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH15_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH15_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH16 (read-write):balancing timer channel 16
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH16_OFFSET                          (0x1030U)
#define MC33774_BAL_TMR_CH16_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH16_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH16_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH16_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH16_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH16_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH16_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 16 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH16_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH16_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH16_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH16_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH16_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH16_BALTIME_EXPIRED_ENUM_VAL        (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH16_BALTIME_BALTIME_ENUM_VAL        (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH16_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH16_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH16_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH16_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH16_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH16_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_TMR_CH17 (read-write):balancing timer channel 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_TMR_CH17_OFFSET                          (0x1031U)
#define MC33774_BAL_TMR_CH17_RW_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH17_RD_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH17_WR_MASK                         (0x3FFFU)
#define MC33774_BAL_TMR_CH17_MW_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH17_RA_MASK                         (0x0U)
#define MC33774_BAL_TMR_CH17_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_TMR_CH17_POR_VAL                         (0x0U)

/* Field BALTIME: Balancing time for channel 17 The value of this field represents the current counter value when read.
The counting saturates at 0. If the value is zero, the balancing for this channel is stopped. The counting is only active if balancing is enabled, timer based balancing is enabled and the channel enable is set. */
#define MC33774_BAL_TMR_CH17_BALTIME_SHIFT                   (0x0U)
#define MC33774_BAL_TMR_CH17_BALTIME_MASK                    (0x3FFFU)
#define MC33774_BAL_TMR_CH17_BALTIME_U16(x)                  (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH17_BALTIME_SHIFT)) & MC33774_BAL_TMR_CH17_BALTIME_MASK))

/* Enumerated value EXPIRED: Balancing time is set to 0. */
#define MC33774_BAL_TMR_CH17_BALTIME_EXPIRED_ENUM_VAL        (0U)

/* Enumerated value BALTIME: Balancing time is set to BALTIME * 10 seconds */
#define MC33774_BAL_TMR_CH17_BALTIME_BALTIME_ENUM_VAL        (1U)

/* Enumerated value MAX: Sets maximum balancing time of 163830 seconds = approximately 45.5 hours. */
#define MC33774_BAL_TMR_CH17_BALTIME_MAX_ENUM_VAL            (16383U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_TMR_CH17_RESERVED0_SHIFT                 (0xEU)
#define MC33774_BAL_TMR_CH17_RESERVED0_MASK                  (0xC000U)
#define MC33774_BAL_TMR_CH17_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_TMR_CH17_RESERVED0_SHIFT)) & MC33774_BAL_TMR_CH17_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH_ALL (write-only):virtual register, writes in parallel into BAL_PWM_CH0 up to BAL_PWM_CH17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH_ALL_OFFSET                        (0x1032U)
#define MC33774_BAL_PWM_CH_ALL_RW_MASK                       (0x0U)
#define MC33774_BAL_PWM_CH_ALL_RD_MASK                       (0x0U)
#define MC33774_BAL_PWM_CH_ALL_WR_MASK                       (0xFFU)
#define MC33774_BAL_PWM_CH_ALL_MW_MASK                       (0x0U)
#define MC33774_BAL_PWM_CH_ALL_RA_MASK                       (0x0U)
#define MC33774_BAL_PWM_CH_ALL_POR_MASK                      (0xFFFFU)
#define MC33774_BAL_PWM_CH_ALL_POR_VAL                       (0xFFU)

/* Field PWM: Sets the balancing PWM for all channels. */
#define MC33774_BAL_PWM_CH_ALL_PWM_SHIFT                     (0x0U)
#define MC33774_BAL_PWM_CH_ALL_PWM_MASK                      (0xFFU)
#define MC33774_BAL_PWM_CH_ALL_PWM_U16(x)                    (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH_ALL_PWM_SHIFT)) & MC33774_BAL_PWM_CH_ALL_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH_ALL_PWM_DISABLED_ENUM_VAL         (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH_ALL_PWM_PWM50_ENUM_VAL            (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH_ALL_PWM_MAX_ENUM_VAL              (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH_ALL_RESERVED0_SHIFT               (0x8U)
#define MC33774_BAL_PWM_CH_ALL_RESERVED0_MASK                (0xFF00U)
#define MC33774_BAL_PWM_CH_ALL_RESERVED0_U16(x)              (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH_ALL_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH_ALL_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH0 (read-write):balancing PWM channel 0
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH0_OFFSET                           (0x1033U)
#define MC33774_BAL_PWM_CH0_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH0_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH0_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH0_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH0_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH0_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH0_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 0. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH0_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH0_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH0_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH0_PWM_SHIFT)) & MC33774_BAL_PWM_CH0_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH0_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH0_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH0_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH0_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH0_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH0_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH0_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH0_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH1 (read-write):balancing PWM channel 1
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH1_OFFSET                           (0x1034U)
#define MC33774_BAL_PWM_CH1_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH1_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH1_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH1_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH1_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH1_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH1_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 1. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH1_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH1_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH1_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH1_PWM_SHIFT)) & MC33774_BAL_PWM_CH1_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH1_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH1_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH1_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH1_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH1_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH1_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH1_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH1_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH2 (read-write):balancing PWM channel 2
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH2_OFFSET                           (0x1035U)
#define MC33774_BAL_PWM_CH2_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH2_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH2_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH2_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH2_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH2_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH2_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 2. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH2_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH2_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH2_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH2_PWM_SHIFT)) & MC33774_BAL_PWM_CH2_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH2_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH2_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH2_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH2_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH2_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH2_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH2_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH2_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH3 (read-write):balancing PWM channel 3
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH3_OFFSET                           (0x1036U)
#define MC33774_BAL_PWM_CH3_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH3_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH3_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH3_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH3_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH3_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH3_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 3. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH3_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH3_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH3_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH3_PWM_SHIFT)) & MC33774_BAL_PWM_CH3_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH3_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH3_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH3_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH3_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH3_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH3_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH3_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH3_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH4 (read-write):balancing PWM channel 4
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH4_OFFSET                           (0x1037U)
#define MC33774_BAL_PWM_CH4_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH4_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH4_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH4_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH4_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH4_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH4_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 4. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH4_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH4_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH4_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH4_PWM_SHIFT)) & MC33774_BAL_PWM_CH4_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH4_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH4_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH4_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH4_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH4_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH4_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH4_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH4_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH5 (read-write):balancing PWM channel 5
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH5_OFFSET                           (0x1038U)
#define MC33774_BAL_PWM_CH5_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH5_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH5_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH5_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH5_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH5_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH5_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 5. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH5_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH5_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH5_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH5_PWM_SHIFT)) & MC33774_BAL_PWM_CH5_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH5_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH5_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH5_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH5_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH5_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH5_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH5_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH5_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH6 (read-write):balancing PWM channel 6
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH6_OFFSET                           (0x1039U)
#define MC33774_BAL_PWM_CH6_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH6_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH6_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH6_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH6_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH6_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH6_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 6. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH6_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH6_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH6_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH6_PWM_SHIFT)) & MC33774_BAL_PWM_CH6_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH6_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH6_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH6_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH6_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH6_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH6_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH6_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH6_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH7 (read-write):balancing PWM channel 7
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH7_OFFSET                           (0x103AU)
#define MC33774_BAL_PWM_CH7_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH7_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH7_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH7_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH7_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH7_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH7_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 7. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH7_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH7_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH7_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH7_PWM_SHIFT)) & MC33774_BAL_PWM_CH7_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH7_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH7_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH7_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH7_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH7_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH7_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH7_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH7_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH8 (read-write):balancing PWM channel 8
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH8_OFFSET                           (0x103BU)
#define MC33774_BAL_PWM_CH8_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH8_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH8_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH8_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH8_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH8_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH8_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 8. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH8_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH8_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH8_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH8_PWM_SHIFT)) & MC33774_BAL_PWM_CH8_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH8_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH8_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH8_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH8_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH8_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH8_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH8_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH8_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH9 (read-write):balancing PWM channel 9
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH9_OFFSET                           (0x103CU)
#define MC33774_BAL_PWM_CH9_RW_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH9_RD_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH9_WR_MASK                          (0xFFU)
#define MC33774_BAL_PWM_CH9_MW_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH9_RA_MASK                          (0x0U)
#define MC33774_BAL_PWM_CH9_POR_MASK                         (0xFFFFU)
#define MC33774_BAL_PWM_CH9_POR_VAL                          (0xFFU)

/* Field PWM: Balancing PWM for channel 9. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH9_PWM_SHIFT                        (0x0U)
#define MC33774_BAL_PWM_CH9_PWM_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH9_PWM_U16(x)                       (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH9_PWM_SHIFT)) & MC33774_BAL_PWM_CH9_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH9_PWM_DISABLED_ENUM_VAL            (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH9_PWM_PWM50_ENUM_VAL               (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH9_PWM_MAX_ENUM_VAL                 (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH9_RESERVED0_SHIFT                  (0x8U)
#define MC33774_BAL_PWM_CH9_RESERVED0_MASK                   (0xFF00U)
#define MC33774_BAL_PWM_CH9_RESERVED0_U16(x)                 (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH9_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH9_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH10 (read-write):balancing PWM channel 10
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH10_OFFSET                          (0x103DU)
#define MC33774_BAL_PWM_CH10_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH10_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH10_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH10_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH10_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH10_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH10_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 10. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH10_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH10_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH10_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH10_PWM_SHIFT)) & MC33774_BAL_PWM_CH10_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH10_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH10_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH10_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH10_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH10_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH10_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH10_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH10_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH11 (read-write):balancing PWM channel 11
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH11_OFFSET                          (0x103EU)
#define MC33774_BAL_PWM_CH11_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH11_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH11_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH11_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH11_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH11_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH11_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 11. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH11_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH11_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH11_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH11_PWM_SHIFT)) & MC33774_BAL_PWM_CH11_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH11_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH11_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH11_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH11_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH11_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH11_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH11_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH11_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH12 (read-write):balancing PWM channel 12
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH12_OFFSET                          (0x103FU)
#define MC33774_BAL_PWM_CH12_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH12_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH12_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH12_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH12_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH12_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH12_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 12. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH12_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH12_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH12_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH12_PWM_SHIFT)) & MC33774_BAL_PWM_CH12_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH12_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH12_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH12_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH12_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH12_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH12_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH12_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH12_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH13 (read-write):balancing PWM channel 13
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH13_OFFSET                          (0x1040U)
#define MC33774_BAL_PWM_CH13_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH13_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH13_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH13_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH13_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH13_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH13_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 13. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH13_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH13_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH13_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH13_PWM_SHIFT)) & MC33774_BAL_PWM_CH13_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH13_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH13_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH13_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH13_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH13_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH13_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH13_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH13_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH14 (read-write):balancing PWM channel 14
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH14_OFFSET                          (0x1041U)
#define MC33774_BAL_PWM_CH14_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH14_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH14_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH14_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH14_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH14_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH14_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 14. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH14_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH14_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH14_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH14_PWM_SHIFT)) & MC33774_BAL_PWM_CH14_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH14_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH14_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH14_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH14_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH14_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH14_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH14_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH14_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH15 (read-write):balancing PWM channel 15
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH15_OFFSET                          (0x1042U)
#define MC33774_BAL_PWM_CH15_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH15_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH15_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH15_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH15_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH15_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH15_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 15. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH15_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH15_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH15_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH15_PWM_SHIFT)) & MC33774_BAL_PWM_CH15_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH15_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH15_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH15_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH15_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH15_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH15_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH15_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH15_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH16 (read-write):balancing PWM channel 16
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH16_OFFSET                          (0x1043U)
#define MC33774_BAL_PWM_CH16_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH16_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH16_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH16_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH16_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH16_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH16_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 16. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH16_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH16_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH16_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH16_PWM_SHIFT)) & MC33774_BAL_PWM_CH16_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH16_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH16_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH16_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH16_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH16_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH16_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH16_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH16_RESERVED0_MASK))

/* --------------------------------------------------------------------------
 * BAL_PWM_CH17 (read-write):balancing PWM channel 17
 * -------------------------------------------------------------------------- */
#define MC33774_BAL_PWM_CH17_OFFSET                          (0x1044U)
#define MC33774_BAL_PWM_CH17_RW_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH17_RD_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH17_WR_MASK                         (0xFFU)
#define MC33774_BAL_PWM_CH17_MW_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH17_RA_MASK                         (0x0U)
#define MC33774_BAL_PWM_CH17_POR_MASK                        (0xFFFFU)
#define MC33774_BAL_PWM_CH17_POR_VAL                         (0xFFU)

/* Field PWM: Balancing PWM for channel 17. The value of this field represents the current duty cycle conduction time applied on balancing FET of this channel. */
#define MC33774_BAL_PWM_CH17_PWM_SHIFT                       (0x0U)
#define MC33774_BAL_PWM_CH17_PWM_MASK                        (0xFFU)
#define MC33774_BAL_PWM_CH17_PWM_U16(x)                      (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH17_PWM_SHIFT)) & MC33774_BAL_PWM_CH17_PWM_MASK))

/* Enumerated value DISABLED: PWM duty cycle set to 0. */
#define MC33774_BAL_PWM_CH17_PWM_DISABLED_ENUM_VAL           (0U)

/* Enumerated value PWM50: PWM duty cycle set to 128/255 *100 %= 50%. */
#define MC33774_BAL_PWM_CH17_PWM_PWM50_ENUM_VAL              (128U)

/* Enumerated value MAX: PWM duty cycle set to 100%. */
#define MC33774_BAL_PWM_CH17_PWM_MAX_ENUM_VAL                (255U)

/* Field reserved0: This read-only field is reserved and always has the value 0. */
#define MC33774_BAL_PWM_CH17_RESERVED0_SHIFT                 (0x8U)
#define MC33774_BAL_PWM_CH17_RESERVED0_MASK                  (0xFF00U)
#define MC33774_BAL_PWM_CH17_RESERVED0_U16(x)                (((uint16_t)(((uint16_t)(x) << MC33774_BAL_PWM_CH17_RESERVED0_SHIFT)) & MC33774_BAL_PWM_CH17_RESERVED0_MASK))

#ifdef __cplusplus
}
#endif

#endif /* CDD_BCC_774A_REGS_H */
