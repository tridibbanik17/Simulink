/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef PHY_665A_COMM_H
#define PHY_665A_COMM_H

/**
*   @file CDD_Phy_665a_Common.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Phy_665a_Cfg.h"
#include "CDD_Bms_common_Cfg.h"
#if (PHY_665A_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "Gpt.h"
#include "CDD_Phy_665a_Types.h"
/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_COMMON_VENDOR_ID                    43
#define PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_COMMON_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_COMMON_SW_MAJOR_VERSION             1
#define PHY_665A_COMMON_SW_MINOR_VERSION             0
#define PHY_665A_COMMON_SW_PATCH_VERSION             2

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Gpt header file are of the same Autosar version */
    #if ((PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION != BMS_COMMON_AR_RELEASE_MAJOR_VERSION_CFG) || \
        (PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION != BMS_COMMON_AR_RELEASE_MINOR_VERSION_CFG))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Common.h and Bms_common_Cfg.h are different"
    #endif

    /* Check if current file and Gpt header file are of the same Autosar version */
    #if ((PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION != GPT_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION != GPT_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Common.h and Gpt.h are different"
    #endif

    #if (PHY_665A_DEV_ERROR_DETECT == STD_ON)
    /* Check if current file and Det header file are of the same Autosar version */
    #if ((PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION != DET_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION != DET_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Common.h and Det.h are different"
    #endif
    #endif
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same vendor */
#if (PHY_665A_COMMON_VENDOR_ID != PHY_665A_VENDOR_ID_CFG)
#error "CDD_Phy_665a_Common.h and CDD_Phy_665a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Autosar version */
#if ((PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (PHY_665A_COMMON_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of CDD_Phy_665a_Common.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Software version */
#if ((PHY_665A_COMMON_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_CFG) || \
     (PHY_665A_COMMON_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_CFG) || \
     (PHY_665A_COMMON_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of CDD_Phy_665a_Common.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_COMMON_VENDOR_ID != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_Common.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_COMMON_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_Common.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_COMMON_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_COMMON_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_COMMON_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_Common.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_COMMON_VENDOR_ID != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_Common.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_COMMON_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_COMMON_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_COMMON_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_Common.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_COMMON_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_COMMON_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_COMMON_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_Common.h and CDD_Phy_665a_Types.h are different"
#endif
/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/*
 * Macro used for abstracting the expected responses number in a TD
*/
#if (defined PHY_665A_NO_EXPECTED_RESPONSES)
#error PHY_665A_NO_EXPECTED_RESPONSES is already defined
#endif
#define PHY_665A_NO_EXPECTED_RESPONSES (0U)

/*
 * Macro used for abstracting the response arrays length used during initialization phase
*/
#if (defined PHY_665A_MAX_NO_RESP)
#error PHY_665A_MAX_NO_RESP is already defined
#endif
#define PHY_665A_MAX_NO_RESP 0x0AU

/*
 * Macro used for defining maximum number of slots that are present in the HW buffer of PHY_665A device  .
*/
#if (defined PHY_665A_TOTAL_NUMBER_HW_BUFFER_SLOTS)
#error PHY_665A_TOTAL_NUMBER_HW_BUFFER_SLOTS is already defined
#endif
#define PHY_665A_TOTAL_NUMBER_HW_BUFFER_SLOTS 0x1EU

/*
 * Macro used for defining the Zero number of elements in queue
*/
#if (defined PHY_665A_QUEUE_EMPTY)
#error PHY_665A_QUEUE_EMPTY is already defined
#endif
#define PHY_665A_QUEUE_EMPTY (0x0U)

/*
 * Macro for  checking if the the number of Req messages has a valid count.
*/
#if (defined PHY_665A_NO_MSG)
#error PHY_665A_NO_MSG is already defined
#endif
#define PHY_665A_NO_MSG 0x00U

/*
 * Macro defining the maximum SPI Job delay for a maximum length frame.
*/
#if (defined PHY_665A_SPI_FRAME_MAX_DELAY)
#error PHY_665A_SPI_FRAME_MAX_DELAY is already defined
#endif
#define PHY_665A_SPI_FRAME_MAX_DELAY 20U

/*
 * Macro used for single bit manipulation.
 */
#define PHY_665A_BIT_MSK        (0x01U)

/*
 * A Macro used for getting SPI variant GPT timer ticks from time in [us].
 */
#if (defined PHY_665A_GPT_SPI_TIMERTICKS)
#error PHY_665A_GPT_SPI_TIMERTICKS is already defined
#endif
#define PHY_665A_GPT_SPI_TIMERTICKS(ValueUs) ((ValueUs) * PHY_665A_SPI_GPT_CLOCK_TICKS_1US)

/*
 * A Macro used for getting CAN variant GPT timer ticks from time in [us].
 */
#if (defined PHY_665A_GPT_CAN_TIMERTICKS)
#error PHY_665A_GPT_CAN_TIMERTICKS is already defined
#endif
#define PHY_665A_GPT_CAN_TIMERTICKS(ValueUs) ((ValueUs) * PHY_665A_CAN_GPT_CLOCK_TICKS_1US)

/*
 * A Macro used for conferting SPI variant GPT ticks to time in [us].
 */
#if (defined PHY_665A_GPT_TIMER_TICKS_TO_US)
#error PHY_665A_GPT_TIMER_TICKS_TO_US is already defined
#endif
#define PHY_665A_GPT_TIMER_TICKS_TO_US(Ticks)\
(uint32)((Ticks)/(PHY_665A_SPI_GPT_CLOCK_TICKS_1US))

/*
 * The number of bits transferred per microsecond.
*/
#if (defined PHY_665A_TPL_REQ_PROT_SPEED_BITS_PER_US)
#error defined PHY_665A_TPL_REQ_PROT_SPEED_BITS_PER_US is already defined
#endif
#define PHY_665A_TPL_REQ_PROT_SPEED_BITS_PER_US      (0x02U)

/*Delay between reception of request by a node and then Tx of response,
  time to process the request and create response*/
#if (defined PHY_665A_PROCESSING_DELAY)
#error defined PHY_665A_PROCESSING_DELAY is already defined
#endif
#define PHY_665A_PROCESSING_DELAY                    (0x08U)

/*Forward delay for sending message from one node to another node*/
#if (defined PHY_665A_FORWARD_DELAY)
#error defined PHY_665A_FORWARD_DELAY is already defined
#endif
#define PHY_665A_FORWARD_DELAY                       (0x01U)

/*Interframe delay between 2 TPL messages*/
#if (defined PHY_665A_INTER_FRAME_DELAY)
#error defined PHY_665A_INTER_FRAME_DELAY is already defined
#endif
#define PHY_665A_INTER_FRAME_DELAY                   (0x08U)

/*Number of bits sent in one millisecond with a speed of 2 Mb/s*/
#if (defined PHY_665A_CAN2M_BITS_PER_MS)
#error defined PHY_665A_CAN2M_BITS_PER_MS is already defined
#endif
#define PHY_665A_CAN2M_BITS_PER_MS                   (0x07D0U)

/*Number of bits sent in one millisecond with a speed of 5 Mb/s*/
#if (defined PHY_665A_CAN5M_BITS_PER_MS)
#error defined PHY_665A_CAN5M_BITS_PER_MS is already defined
#endif
#define PHY_665A_CAN5M_BITS_PER_MS                   (0x1388U)

#if (defined PHY_665A_QUEUE_FLUSH_DELAY)
#error PHY_665A_QUEUE_FLUSH_DELAY is already defined
#endif
#define PHY_665A_QUEUE_FLUSH_DELAY                      (100U)

#if (defined PHY_665A_LAST_POSSIBLE_DEV_IDX_IN_CHAIN)
#error PHY_665A_LAST_POSSIBLE_DEV_IDX_IN_CHAIN is already defined
#endif
#define PHY_665A_LAST_POSSIBLE_DEV_IDX_IN_CHAIN          (62U)

#if (defined PHY_665A_SYNC_MAX_ALL_MSG_CNT)
#error PHY_665A_SYNC_MAX_ALL_MSG_CNT is already defined
#endif
#define PHY_665A_SYNC_MAX_ALL_MSG_CNT                    (29U)

#if (defined PHY_665A_SYS_EVH_CRC_DELAY)
#error PHY_665A_SYS_EVH_CRC_DELAY is already defined
#endif
#define PHY_665A_SYS_EVH_CRC_DELAY                      (100U)

#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_VALUE)
#error PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_VALUE is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_VALUE (2U)

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
typedef struct
{
    uint8 Enable[2];
    uint8 Rx[2];
    uint8 Madd[2];
    uint8 AllChain[2];
}Phy_665a_PortStatusType;

typedef struct
{
    uint8* PortIdQueuePtr;
    uint8* NumElemRemainingPtr;
    uint8 DeviceIdx;
}Phy_665a_PortIdQueueConfigType;

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

#define PHY_665A_START_SEC_VAR_CLEARED_BOOLEAN
#include "Phy_665a_MemMap.h"
extern volatile boolean Phy_665a_PhyIoProtectionFlag; /* Phy_665a_IOSendMessage protection from interrupt access. */
#define PHY_665A_STOP_SEC_VAR_CLEARED_BOOLEAN
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"
extern uint16 Phy_665a_SysCrc[2U];
extern uint16 Phy_665a_EvhCrc[2U];
#define PHY_665A_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/

#define PHY_665A_START_SEC_CODE
#include "Phy_665a_MemMap.h"

/*  Phy_665a_ExtractTplBitfields
 *
 * 
 *  extracts all tpl bitfields of message depending on encoding
 *
 *  \param[in]      TplEncoding
 *  \param[inout]   MsgPtr
 *  \param[inout]   TplMsgData
 *
 *  \returns void
 */
void Phy_665a_ExtractTplBitfields
(
    Phy_MsgInfoType TplEncoding,
    const uint16* MsgPtr,
    Phy_665a_TplIdentifiersType* TplMsgData
);

void Phy_665a_MemCpyBytewise
(
    void* DestMemPtr,
    void* SrcMemPtr,
    uint32 NumBytesCpy
);

void Phy_665a_MemSetBytewise
(
    void* DestMemPtr,
    uint8 Value,
    uint32 NumBytesSet
);

void Phy_665a_SetCancelStatusAllTds
(
   const Phy_665a_SwQueueType* QueueData
);

Std_ReturnType Phy_665a_CheckSyncHaltState(const Phy_TDType* TransactionDescriptor, Phy_665a_GlobalInfoType* pGlobalInfo);

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/* \ Phy_665a_PckInternalTpl3Msg
 *
 *  implementation for packing for TPL3 request messages in form of a .
 *
 *  \param[in]  Tpl3MsgInfo
 *
 *  \returns void
 *
 *  \remark{Synchronous}
 *
 */
extern void Phy_665a_PckInternalTpl3Msg(const Phy_665a_TplMsgInfoType *Tpl3Msg);

/* \ Phy_665a_CalcTpl3RespNum
 *
 *  implementation for function to calculate number of hextets present in a response message
 *  received as a result of successful read request.
 *
 *  \param[in]      RequestMsg
 *
 *  \returns NumofResp
 *
 *  \remark{Synchronous}
 *
 */
extern uint8 Phy_665a_CalcTpl3RespNum
(
    const uint16* RequestMsg
);

/* \ Phy_665a_UnPckInternalTpl3RespMsg
 *
 *  implementation for  function to unpack responses received as a result of successful read request
 *  and store their respective communication CRC in CrcArray and data in RegisterInfoArray.
 *  \param[in]      ResponsePtr
 *  \param[in]      RequestPtr
 *  \param[in]      RespLengthMatrix
 *  \param[out]     RegisterInfoArray
 *  \param[out]     CrcArray
 *
 *  \returns Std_ReturnType
 *
 *  \remark{Synchronous}
 *
 */
extern Std_ReturnType Phy_665a_UnPckInternalTpl3RespMsg
(
    const uint16* ResponsePtr,
    const uint16* RequestPtr,
    const Phy_665a_RespLengthType* RespLengthMatrix,
    uint16* RegisterInfoArray,
    uint16* CrcArray
);

/* \ Phy_665a_CalcTpl3RespLen
 *
 *  implementation for form a table containing number of resp and their repective length in hextets.
 *
 *  \param[in]      RequestMsg
 *  \param[in]      NumofResp
 *  \param[out]     RespLengthMatrix
 *
 *  \returns Std_ReturnType
 *
 *  \remark{Synchronous}
 *
 */
extern Std_ReturnType Phy_665a_CalcTpl3RespLen
(
    const uint16* RequestMsg,
    uint8 NumofResp,
    Phy_665a_RespLengthType* RespLengthMatrix
);

/* \ Phy_665a_CalculateTpl3Padd
 *
 *  implementation for calculating number of hextets required for padding in a response message
 *  for a read request, if number of register to be read is not divisible by number of
 *  register per transaction.
 *
 *  \param[in]  ReadRequestMsg
 *
 *  \returns uint8
 *
 *
 *  \remark{Synchronous}
 *
 */
extern uint8 Phy_665a_CalculateTpl3Padd
(
    const uint16* ReadRequestMsg
);

/* \ Phy_665a_CheckComCRC
 *
 *  implementation for calculating crc over PHY registers using generator polynomial
 *  0xD175 (+1) = X^16 + X^15 +X^13 + X^9 + X^7 + X^6 + X^5 + X^3 + X^1 + 1.
 *  \param[in]  NumResp
 *  \param[in]  RespLengthMatrix
 *  \param[in]  RqstPtr
 *  \param[in]  RespPtr
 *
 *  \returns Std_ReturnType
 *
 *
 *  \remark{Synchronous}
 *
 */

extern Std_ReturnType Phy_665a_CheckTpl3Crc
(
    uint8 NumResp,
    const Phy_665a_RespLengthType* RespLengthMatrix,
    const uint16* RqstPtr,
    const uint16* RespPtr
);
#else
Std_ReturnType Phy_665a_CheckTpl2Crc
(
        uint16* RespPtr
);
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

/* \ Phy_665a_CheckSysCRC
 *
 *  implementation for calculating crc over below registers
 *  SYS_COM_CFG,
 *  SYS_COM_TO_CFG, SYS_PORT0_CFG, SYS_
 *  PORT1_CFG, SYS_PORT2_CFG, SYS_PORT3_
 *  CFG, SYS_HOST_COM_CFG, SYS_SPI_CFG,
 *  SYS_CAN_CFG, SYS_UART_CFG, SYS_FLT_
 *  CFG, SYS_QUEUE_SIZE, SYS_REQ_QUEUE_
 *  CFG, SYS_RSP_QUEUE_CFG.
 *  and comparing this CRC value with received CRC
 *
 *  \param[in]  DeviceIdx
 *
 *  \returns Std_ReturnType
 *
 *
 *  \remark{Synchronous}
 *
 */
extern Std_ReturnType Phy_665a_CheckSysCRC
(
    uint8 DeviceIdx,
    Phy_665aMcuIfProtcol_Type McuIfProtocol
);

/* \ Phy_665a_CheckEvhCRC
 *
 *comparing calculated CRC value with received CRC
 *
 *  \param[in]  DeviceIdx
 *
 *  \returns Std_ReturnType
 */
Std_ReturnType Phy_665a_CheckEvhCRC
(
    uint8 DeviceIdx,
    Phy_665aMcuIfProtcol_Type McuIfProtocol
);

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
void Phy_665a_PckInternalTpl2Msg(const Phy_665a_TplMsgInfoType *Tpl2Msg);
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

#if (PHY_665A_DEV_ERROR_DETECT == STD_ON)
/**
 * @brief Stores the given error details into the corresponding error buffer.
 *
 * @param[in] Component The component that the error addresses (PHY_665A_SPI/PHY_665A_CAN).
 * @param[in] Source A value indicating the source of the error.
 * @param[in] ErrCode The error code.
 * @return Std_ReturnType 
 * @retval E_OK             Error code was buffered correctly.
 * @retval E_NOT_OK         Error code failed to be added to the buffer.
 */
void Phy_665a_LogError
(
    Phy_665aMcuIfProtcol_Type Component,
    uint8 Source,
    uint8 ErrCode
);

#endif /*(PHY_665A_DEV_ERROR_DETECT == STD_ON)*/

/**
 * @brief Calculates the timeout for a request.
 *
 * @param RequestPtr Request pointer.
 * @param ReqLenHex Request length.
 * @param GlobalDevInfoPtr Reference to the global device info.
 * @param AnalyzeReqPortCfgTpl Pointers to the analyze request port cfg APIs.
 * @return Std_ReturnType The return code.
 */
Std_ReturnType Phy_665a_CalculateRequestTimeout
(
    uint16* RequestPtr,
    uint8 ReqLenHex,
    Phy_665a_GlobalInfoType* GlobalDevInfoPtr
);

/*==================================================================================================
*                                         LOCAL FUNCTIONS
==================================================================================================*/

static inline uint8 Phy_665a_GetMaxReqPerBatch(uint8 RequestQueueSize)
{
    /* Return the number of requests that can fit in a batch */
    return (RequestQueueSize - (uint8)2U);
}

static inline uint8 Phy_665a_GetMaxRspPerBatch(uint8 RequestQueueSize)
{
    /* Return the limited value to half of the response queue + 5, i.e. (9 + 5 = 13) */
    return ((((uint8)PHY_665A_TOTAL_NUMBER_HW_BUFFER_SLOTS - RequestQueueSize) / (uint8)2U) + (uint8)5U);
}

static inline uint8 Phy_665a_GetSyncMaxRspPerBatch(uint8 RequestQueueSize)
{
    /* Return maximum number of responses per batch in a sync scenario */
    return ((uint8)PHY_665A_TOTAL_NUMBER_HW_BUFFER_SLOTS - RequestQueueSize + (uint8)2U);
}

static inline uint16 Phy_665a_ExtractGenericField(uint16 MsgData, uint16 FieldOffset, uint16 FieldMask)
{
    /* Perform bitfield shifting and masking on a provided data value */
    return ((MsgData >> FieldOffset) & FieldMask);
}

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
static inline uint8 Phy_665a_ExtractTpl2Cmd(const uint16* MsgPtr)
{
    /* Extract CMD bitfield from TPL2-type provided data */
    return (uint8)((((uint16)1U << (PHY_665A_TPL2_CMD_BITS)) - 1U) & (MsgPtr[2U] >> ((PHY_665A_TPL2_CMD_POSTION) - 1U)));
}

static inline uint8 Phy_665a_ExtractTpl2Cadd(const uint16* MsgPtr)
{
    /* Extract CADD bitfield from TPL2-type provided data */
    return (uint8)((((((uint16)1U << (PHY_665A_TPL2_CADD2_BITS)) - 1U) & (MsgPtr[1U] >> ((PHY_665A_TPL2_CADD2_POSTION) - 1U))) << 2U) | ((((uint16)1U << (PHY_665A_TPL2_CADD1_BITS)) - 1U) & (MsgPtr[2U] >> ((PHY_665A_TPL2_CADD1_POSTION) - 1U))));
}

static inline uint8 Phy_665a_ExtractTpl2Madd(const uint16* MsgPtr)
{
    /* Extract MADD bitfield from TPL2-type provided data */
    return (uint8)((((uint16)1U << (PHY_665A_TPL2_MADD_BITS)) - 1U) & (MsgPtr[1U] >> ((PHY_665A_TPL2_MADD_POSTION) - 1U)));
}

static inline uint8 Phy_665a_ExtractTpl2Dadd(const uint16* MsgPtr)
{
    /* Extract DADD bitfield from TPL2-type provided data */
    return (uint8)((((uint16)1U << (PHY_665A_TPL2_DADD_BITS)) - 1U) & (MsgPtr[1U] >> ((PHY_665A_TPL2_DADD_POSTION) - 1U)));
}

static inline uint16 Phy_665a_ExtractTpl2Radd(const uint16* MsgPtr)
{
    /* Extract RADD bitfield from TPL2-type provided data */
    return ((((uint16)1U << (PHY_665A_TPL2_RADD_BITS)) - 1U) & (MsgPtr[1U] >> ((PHY_665A_TPL2_RADD_POSTION) - 1U)));
}

static inline uint8 Phy_665a_ExtractTpl2NumReg(const uint16* MsgPtr)
{
    /* Extract NUMREG bitfield from TPL2-type provided data */
    return (uint8)((((uint16)1U << (PHY_665A_TPL2_NUMREG_BITS)) - 1U) & (MsgPtr[0U] >> ((PHY_665A_TPL2_NUMREG_POSTION) - 1U)));
}
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
static inline uint8 Phy_665a_ExtractTpl3Cmd(const uint16* MsgPtr)
{
    /* Extract CMD bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[0U] >> PHY_665A_TPL3_CMD_OFFSET) & PHY_665A_TPL3_CMD_MASK);
}

static inline uint8 Phy_665a_ExtractTpl3Cadd(const uint16* MsgPtr)
{
    /* Extract CADD bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[0U] >> PHY_665A_TPL3_CADD_OFFSET) & PHY_665A_TPL3_CADD_MASK);
}

static inline uint8 Phy_665a_ExtractTpl3Madd(const uint16* MsgPtr)
{
    /* Extract MADD bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[0U] >> PHY_665A_TPL3_MADD_OFFSET) & PHY_665A_TPL3_MADD_MASK);
}

static inline uint8 Phy_665a_ExtractTpl3Dadd(const uint16* MsgPtr)
{
    /* Extract DADD bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[0U] >> PHY_665A_TPL3_DADD_OFFSET) & PHY_665A_TPL3_DADD_MASK);
}

static inline uint16 Phy_665a_ExtractTpl3Radd(const uint16* MsgPtr)
{
    /* Extract RADD bitfield from TPL3-type provided data */
    return (uint16)((MsgPtr[1U] >> PHY_665A_TPL3_RADD_OFFSET) & PHY_665A_TPL3_RADD_MASK);
}

static inline uint8 Phy_665a_ExtractTpl3DataLen(const uint16* MsgPtr)
{
    /* Extract DATA LEN bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[1U] >> PHY_665A_TPL3_DATALEN_OFFSET) & PHY_665A_TPL3_DATALEN_MASK);
}

static inline uint8 Phy_665a_ExtractTpl3RespLen(const uint16* MsgPtr)
{
    /* Extract RESP LEN bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[2U] >> PHY_665A_TPL3_RESPLEN_OFFSET) & PHY_665A_TPL3_RESPLEN_MASK);
}

static inline uint8 Phy_665a_ExtractTpl3NumReg(const uint16* MsgPtr)
{
    /* Extract NUMREG bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[2U] >> PHY_665A_TPL3_NUMREG_OFFSET) & PHY_665A_TPL3_NUMREG_MASK);
}

static inline uint8 Phy_665a_ExtractTpl3Pad(const uint16* MsgPtr)
{
    /* Extract PAD bitfield from TPL3-type provided data */
    return (uint8)((MsgPtr[2U] >> PHY_665A_TPL3_PAD_OFFSET) & PHY_665A_TPL3_PAD_MASK);
}
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

Std_ReturnType Phy_665a_UpdateRamTable(uint8 PhyIndex, uint16 Radd, uint16 DataLen, const uint16* WriteData);


#define PHY_665A_STOP_SEC_CODE
#include "Phy_665a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* PHY_665A_COMM_H */
