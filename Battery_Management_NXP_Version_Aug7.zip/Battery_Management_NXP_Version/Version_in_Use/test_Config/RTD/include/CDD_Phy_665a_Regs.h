/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_REGS_H
#define CDD_PHY_665A_REGS_H

/**
*   @file CDD_Phy_665a_Regs.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Std_Types.h"

/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_REGS_VENDOR_ID                    43
#define PHY_665A_REGS_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_REGS_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_REGS_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_REGS_SW_MAJOR_VERSION             1
#define PHY_665A_REGS_SW_MINOR_VERSION             0
#define PHY_665A_REGS_SW_PATCH_VERSION             2

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((PHY_665A_REGS_AR_RELEASE_MAJOR_VERSION != STD_AR_RELEASE_MAJOR_VERSION) || \
         (PHY_665A_REGS_AR_RELEASE_MINOR_VERSION != STD_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Regs.h and StandardTypes.h are different"
    #endif
#endif

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/*SYS_CFG_CRC_REG*/
/*
 * Macro used for defining SYS_CFG_CRC register address.
*/
#if (defined PHY_665A_SYS_CFG_CRC_REG_ADDRESS)
#error PHY_665A_SYS_CFG_CRC_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_CFG_CRC_REG_ADDRESS                   0x00U

/*
 * Macro used for defining default value of SYS_CFG_CRC register.
*/
#if (defined PHY_665A_SYS_CFG_CRC_REG_DEFAULT)
#error PHY_665A_SYS_CFG_CRC_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_CFG_CRC_REG_DEFAULT             0x0000U
/*
 * Macro for offset for parameter CRC in SYS_CFG_CRC register .
*/
#if (defined PHY_665A_SYS_CFG_CRC_REG_CRC_OFFSET)
#error PHY_665A_SYS_CFG_CRC_REG_CRC_OFFSET is already defined
#endif
#define PHY_665A_SYS_CFG_CRC_REG_CRC_OFFSET                0x00

/*
 * Macro for length for parameter  in SYS_CFG_CRC register.
*/
#if (defined PHY_665A_SYS_CFG_CRC_REG_CRC_LEN)
#error PHY_665A_SYS_CFG_CRC_REG_CRC_LEN is already defined
#endif
#define PHY_665A_SYS_CFG_CRC_REG_CRC_LEN                   0x10

/*
 * Macro for mask for parameter CRC in SYS_CFG_CRC register .
*/
#if (defined PHY_665A_SYS_CFG_CRC_REG_CRC_MASK)
#error PHY_665A_SYS_CFG_CRC_REG_CRC_MASK is already defined
#endif
#define PHY_665A_SYS_CFG_CRC_REG_CRC_MASK                  0xFFFF

/*SYS_COM_CFG*/
/*
 * Macro used for defining SYS_COM_CFG register address.
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_ADDRESS)
#error PHY_665A_SYS_COM_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_ADDRESS                   0x1

/*
 * Macro used for defining default value of SYS_COM_CFG register.
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_DEFAULT)
#error PHY_665A_SYS_COM_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_DEFAULT             0x0001U

/*
 * Macro for offset for parameter Chain Address in SYS_COM_CFG register .
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_CADD_OFFSET)
#error PHY_665A_SYS_COM_CFG_REG_CADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_CADD_OFFSET               0x06

/*
 * Macro for length for parameter Chain Address in SYS_COM_CFG register .
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_CADD_LEN)
#error PHY_665A_SYS_COM_CFG_REG_CADD_LEN is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_CADD_LEN                  0x03

/*
 * Macro for mask for parameter Chain Address in SYS_COM_CFG register .
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_CADD_MASK)
#error PHY_665A_SYS_COM_CFG_REG_CADD_MASK is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_CADD_MASK                 0x07

/*
 * Macro for offset for parameter Device address in SYS_COM_CFG register .
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_DADD_OFFSET)
#error PHY_665A_SYS_COM_CFG_REG_DADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_DADD_OFFSET               0x00

/*
 * Macro for length for parameter Device address in SYS_COM_CFG register .
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_DADD_LEN)
#error PHY_665A_SYS_COM_CFG_REG_DADD_LEN is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_DADD_LEN                  0x06

/*
 * Macro for mask for parameter Device address in SYS_COM_CFG register .
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_DADD_MASK)
#error PHY_665A_SYS_COM_CFG_REG_DADD_MASK is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_DADD_MASK                 0x3F

/*
 * Macro for value of parameter Chain address in SYS_COM_CFG register.
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_CADD)
#error PHY_665A_SYS_COM_CFG_REG_CADD is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_CADD                      0x00

/*
 * Macro for value of parameter Device address in SYS_COM_CFG register.
*/
#if (defined PHY_665A_SYS_COM_CFG_REG_DADD)
#error PHY_665A_SYS_COM_CFG_REG_DADD is already defined
#endif
#define PHY_665A_SYS_COM_CFG_REG_DADD                      0x01

/*SYS_COM_TO_CFG*/
/*
 * Macro used for defining SYS_COM_TO_CFG register address.
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_ADDRESS)
#error PHY_665A_SYS_COM_TO_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_ADDRESS                0x2

/*
 * Macro used for defining default value of SYS_COM_TO_CFG register.
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_DEFAULT)
#error PHY_665A_SYS_COM_TO_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_DEFAULT          0x0064U

/*
 * Macro for offset for parameter COMTOMODE in SYS_COM_TO_CFG register .
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_OFFSET)
#error PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_OFFSET is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_OFFSET       0x08

/*
 * Macro for length for parameter COMTOMODE in SYS_COM_TO_CFG register.
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_LEN)
#error PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_LEN is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_LEN          0x08

/*
 * Macro for mask for parameter COMTOMODE in SYS_COM_TO_CFG register.
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_MASK)
#error PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_MASK is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_COMTOMODE_MASK         0xFF

/*
 * Macro for offset for parameter COMTO in SYS_COM_TO_CFG register.
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_COMTO_OFFSET)
#error PHY_665A_SYS_COM_TO_CFG_REG_COMTO_OFFSET is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_COMTO_OFFSET           0x00

/*
 * Macro for length for parameter COMTO in SYS_COM_TO_CFG register .
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_COMTO_LEN)
#error PHY_665A_SYS_COM_TO_CFG_REG_COMTO_LEN is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_COMTO_LEN              0x08

/*
 * Macro for mask for parameter COMTO in SYS_COM_TO_CFG register .
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_REG_COMTO_MASK)
#error PHY_665A_SYS_COM_TO_CFG_REG_COMTO_MASK is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_REG_COMTO_MASK             0xFF

/*
 * Macro for value for parameter COMTOMODE DISABLED in SYS_COM_TO_CFG register .
*/

#if (defined PHY_665A_SYS_COM_TO_CFG_COMTOMODE_DISABLED)
#error PHY_665A_SYS_COM_TO_CFG_COMTOMODE_DISABLED is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_COMTOMODE_DISABLED         0x5AU

/*
 * Macro for value for parameter COMTOMODE GOSLEEPONTO in SYS_COM_TO_CFG register .
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_COMTOMODE_GOSLEEPONTO)
#error PHY_665A_SYS_COM_TO_CFG_COMTOMODE_GOSLEEPONTO is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_COMTOMODE_GOSLEEPONTO      0xA5

/*
 * Macro for value for parameter COMTO T_MAX in SYS_COM_TO_CFG register .
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_COMTO_MAX)
#error PHY_665A_SYS_COM_TO_CFG_COMTO_MAX is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_COMTO_MAX                  0xFF

/*
 * Macro for value for parameter COMTO T_MIN in SYS_COM_TO_CFG register .
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_COMTO_MIN)
#error PHY_665A_SYS_COM_TO_CFG_COMTO_MIN is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_COMTO_MIN                  0x00

/*
 * Macro for value for parameter COMTO T_10m in SYS_COM_TO_CFG register .
*/
#if (defined PHY_665A_SYS_COM_TO_CFG_COMTO_DEFAULT)
#error PHY_665A_SYS_COM_TO_CFG_COMTO_DEFAULT is already defined
#endif
#define PHY_665A_SYS_COM_TO_CFG_COMTO_DEFAULT              0x64

/*SYS_MODE*/
/*
 * Macro used for defining SYS_MODE register address.
*/
#if (defined PHY_665A_SYS_MODE_REG_ADDRESS)
#error PHY_665A_SYS_MODE_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_MODE_REG_ADDRESS                      0x04U
/*
 * Macro used for defining default value of SYS_MODE register.
*/
#if (defined PHY_665A_SYS_MODE_REG_DEFAULT)
#error PHY_665A_SYS_MODE_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_MODE_REG_DEFAULT                      0x0000
/*
 * Macro for offset for parameter TARGETMODE in SYS_MODE register .
*/
#if (defined PHY_665A_SYS_MODE_REG_TARGETMODE_OFFSET)
#error PHY_665A_SYS_MODE_REG_TARGETMODE_OFFSET is already defined
#endif
#define PHY_665A_SYS_MODE_REG_TARGETMODE_OFFSET              (0U)

/*
 * Macro for mask for parameter TARGETMODE in SYS_MODE register .
*/
#if (defined PHY_665A_SYS_MODE_REG_TARGETMODE_MASK)
#error PHY_665A_SYS_MODE_REG_TARGETMODE_MASK is already defined
#endif
#define PHY_665A_SYS_MODE_REG_TARGETMODE_MASK              0x1F

/*
 * Macro for value for parameter TARGETMODE SLEEP in SYS_MODE register .
*/
#if (defined PHY_665A_SYS_MODE_REG_TARGETMODE_SLEEP)
#error PHY_665A_SYS_MODE_REG_TARGETMODE_SLEEP is already defined
#endif
#define PHY_665A_SYS_MODE_REG_TARGETMODE_SLEEP             0x0AU

/*
 * Macro for value for parameter TARGETMODE RESET in SYS_MODE register .
*/
#if (defined PHY_665A_SYS_MODE_REG_TARGETMODE_RESET)
#error PHY_665A_SYS_MODE_REG_TARGETMODE_RESET is already defined
#endif
#define PHY_665A_SYS_MODE_REG_TARGETMODE_RESET             0x14U

/*SYS_PORT0_CFG*/
/*
 * Macro used for defining SYS_PORT0_CFG register address.
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_ADDRESS)
#error PHY_665A_SYS_PORT0_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_ADDRESS                 0x6

/*
 * Macro used for defining default value of SYS_PORT0_CFG register.
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_DEFAULT)
#error PHY_665A_SYS_PORT0_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_DEFAULT          0x00AFU

/*
 * Macro for offset for parameter TIMEOUT in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_OFFSET)
#error PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_OFFSET          0x0A

/*
 * Macro for length for parameter TIMEOUT in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_LEN)
#error PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_LEN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_LEN             0x06

/*
 * Macro for mask for parameter TIMEOUT in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MASK)
#error PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MASK is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MASK            0x3F

/*
 * Macro for offset for parameter Chain address in SYS_PORT0_CFG register .
*/

#if (defined PHY_665A_SYS_PORT0_CFG_REG_CADD_OFFSET)
#error PHY_665A_SYS_PORT0_CFG_REG_CADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_CADD_OFFSET             0x07

/*
 * Macro for length for parameter Chain address in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_CADD_LEN)
#error PHY_665A_SYS_PORT0_CFG_REG_CADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_CADD_LEN                0x03

/*
 * Macro for mask for parameter Chain address in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_CADD_MASK)
#error PHY_665A_SYS_PORT0_CFG_REG_CADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_CADD_MASK               0x07U

/*
 * Macro for offset for parameter Master address in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_MADD_OFFSET)
#error PHY_665A_SYS_PORT0_CFG_REG_MADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_MADD_OFFSET             0x06

/*
 * Macro for length for parameter Master address in SYS_PORT0_CFG register .
*/

#if (defined PHY_665A_SYS_PORT0_CFG_REG_MADD_LEN)
#error PHY_665A_SYS_PORT0_CFG_REG_MADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_MADD_LEN                0x01

/*
 * Macro for mask for parameter Master address in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_MADD_MASK)
#error PHY_665A_SYS_PORT0_CFG_REG_MADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_MADD_MASK               0x01U

/*
 * Macro for offset for parameter PROTOCOL in SYS_PORT0_CFG register .
*/

#if (defined PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_OFFSET)
#error PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_OFFSET         0x05

/*
 * Macro for length for parameter PROTOCOL in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_LEN)
#error PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_LEN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_LEN            0x01

/*
 * Macro for mask for parameter PROTOCOL in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_MASK)
#error PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_MASK is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_MASK           0x01U

/*
 * Macro for offset for parameter ALLCHAINS in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_OFFSET)
#error PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_OFFSET        0x03

/*
 * Macro for length for parameter ALLCHAINS in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_LEN)
#error PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_LEN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_LEN           0x01

/*
 * Macro for mask for parameter ALLCHAINS in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_MASK)
#error PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_MASK is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_MASK          0x01U

/*
 * Macro for offset for parameter RX in SYS_PORT0_CFG register .
*/

#if (defined PHY_665A_SYS_PORT0_CFG_REG_RX_OFFSET)
#error PHY_665A_SYS_PORT0_CFG_REG_RX_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_RX_OFFSET               0x01

/*
 * Macro for length for parameter RX in SYS_PORT0_CFG register .
*/

#if (defined PHY_665A_SYS_PORT0_CFG_REG_RX_LEN)
#error PHY_665A_SYS_PORT0_CFG_REG_RX_LEN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_RX_LEN                  0x01

/*
 * Macro for mask for parameter RX in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_RX_MASK)
#error PHY_665A_SYS_PORT0_CFG_REG_RX_MASK is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_RX_MASK                 0x01U

/*
 * Macro for offset for parameter EN in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_EN_OFFSET)
#error PHY_665A_SYS_PORT0_CFG_REG_EN_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_EN_OFFSET               0x00

/*
 * Macro for length for parameter EN in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_EN_LEN)
#error PHY_665A_SYS_PORT0_CFG_REG_EN_LEN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_EN_LEN                  0x01

/*
 * Macro for mask for parameter EN in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_EN_MASK)
#error PHY_665A_SYS_PORT0_CFG_REG_EN_MASK is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_EN_MASK                 0x01U

/*
 * Macro for value for parameter TIMEOUT T_MAX in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MAX)
#error PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MAX is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MAX             0x3F

/*
 * Macro for value for parameter TIMEOUT T_MIN in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MIN)
#error PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MIN is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_MIN             0x01

/*
 * Macro for value for parameter TIMEOUT NONE in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_DISABLED)
#error PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_TIMEOUT_DISABLED        0x00

/*
 * Macro for value for parameter Chain address NONE in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_CADD_NONE)
#error PHY_665A_SYS_PORT0_CFG_REG_CADD_NONE is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_CADD_NONE               0x00

/*
 * Macro for value for parameter Chain address ALL in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_CADD_ALL)
#error PHY_665A_SYS_PORT0_CFG_REG_CADD_ALL is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_CADD_ALL                0x07

/*
 * Macro for value for parameter PROTOCOL TPL2 in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_TPL2)
#error PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_TPL2 is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_TPL2           0x00U

/*
 * Macro for value for parameter PROTOCOL TPL3 in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_TPL3)
#error PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_TPL3 is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_PROTOCOL_TPL3           0x01U

/*
 * Macro for value for parameter ALLCHAINS ENABLED  in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_ENABLED)
#error PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_ENABLED       0x01

/*
 * Macro for value for parameter ALLCHAINS DISABLED in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_DISABLED)
#error PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_ALLCHAINS_DISABLED      0x00

/*
 * Macro for value for parameter RX ENABLED in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_RX_ENABLED)
#error PHY_665A_SYS_PORT0_CFG_REG_RX_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_RX_ENABLED              0x01

/*
 * Macro for value for parameter RX DISABLED in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_RX_DISABLED)
#error PHY_665A_SYS_PORT0_CFG_REG_RX_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_RX_DISABLED             0x00

/*
 * Macro for value for parameter EN ENABLED in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_EN_ENABLED)
#error PHY_665A_SYS_PORT0_CFG_REG_EN_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_EN_ENABLED              0x01U

/*
 * Macro for value for parameter EN DISABLED in SYS_PORT0_CFG register .
*/
#if (defined PHY_665A_SYS_PORT0_CFG_REG_EN_DISABLED)
#error PHY_665A_SYS_PORT0_CFG_REG_EN_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT0_CFG_REG_EN_DISABLED             0x00

/*SYS_PORT1_CFG*/
/*
 * Macro used for defining SYS_PORT1_CFG register address.
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_ADDRESS)
#error PHY_665A_SYS_PORT1_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_ADDRESS                 0x7
/*
 * Macro used for defining default value of SYS_PORT1_CFG register.
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_DEFAULT)
#error PHY_665A_SYS_PORT1_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_DEFAULT                 0x012F
/*
 * Macro for offset for parameter TIMEOUT in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_OFFSET)
#error PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_OFFSET          0x0A

/*
 * Macro for length for parameter TIMEOUT in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_LEN)
#error PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_LEN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_LEN             0x06

/*
 * Macro for mask for parameter TIMEOUT in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MASK)
#error PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MASK is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MASK            0x3F

/*
 * Macro for offset for parameter Chain address in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_CADD_OFFSET)
#error PHY_665A_SYS_PORT1_CFG_REG_CADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_CADD_OFFSET             0x07

/*
 * Macro for length for parameter Chain address in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_CADD_LEN)
#error PHY_665A_SYS_PORT1_CFG_REG_CADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_CADD_LEN                0x03

/*
 * Macro for mask for parameter Chain address in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_CADD_MASK)
#error PHY_665A_SYS_PORT1_CFG_REG_CADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_CADD_MASK               0x07

/*
 * Macro for offset for parameter Master address in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_MADD_OFFSET)
#error PHY_665A_SYS_PORT1_CFG_REG_MADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_MADD_OFFSET             0x06

/*
 * Macro for length for parameter Master address in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_MADD_LEN)
#error PHY_665A_SYS_PORT1_CFG_REG_MADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_MADD_LEN                0x01

/*
 * Macro for mask for parameter Master address in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_MADD_MASK)
#error PHY_665A_SYS_PORT1_CFG_REG_MADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_MADD_MASK               0x01

/*
 * Macro for offset for parameter PROTOCOL in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_OFFSET)
#error PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_OFFSET         0x05

/*
 * Macro for length for parameter PROTOCOL in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_LEN)
#error PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_LEN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_LEN            0x01

/*
 * Macro for mask for parameter PROTOCOL in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_MASK)
#error PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_MASK is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_MASK           0x01

/*
 * Macro for offset for parameter ALLCHAINS in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_OFFSET)
#error PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_OFFSET        0x03

/*
 * Macro for length for parameter ALLCHAINS in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_LEN)
#error PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_LEN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_LEN           0x01

/*
 * Macro for mask for parameter ALLCHAINS in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_MASK)
#error PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_MASK is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_MASK          0x01

/*
 * Macro for offset for parameter RX in SYS_PORT1_CFG register .
*/

#if (defined PHY_665A_SYS_PORT1_CFG_REG_RX_OFFSET)
#error PHY_665A_SYS_PORT1_CFG_REG_RX_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_RX_OFFSET               0x01

/*
 * Macro for length for parameter RX in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_RX_LEN)
#error PHY_665A_SYS_PORT1_CFG_REG_RX_LEN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_RX_LEN                  0x01

/*
 * Macro for mask for parameter RX in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_RX_MASK)
#error PHY_665A_SYS_PORT1_CFG_REG_RX_MASK is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_RX_MASK                 0x01

/*
 * Macro for offset for parameter EN in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_EN_OFFSET)
#error PHY_665A_SYS_PORT1_CFG_REG_EN_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_EN_OFFSET               0x00

/*
 * Macro for length for parameter EN in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_EN_LEN)
#error PHY_665A_SYS_PORT1_CFG_REG_EN_LEN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_EN_LEN                  0x01

/*
 * Macro for mask for parameter EN in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_EN_MASK)
#error PHY_665A_SYS_PORT1_CFG_REG_EN_MASK is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_EN_MASK                 0x01

/*
 * Macro for value for parameter TIMEOUT T_MAX in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MAX)
#error PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MAX is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MAX             0x3F

/*
 * Macro for value for parameter TIMEOUT T_MIN in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MIN)
#error PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MIN is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_MIN             0x01

/*
 * Macro for value for parameter TIMEOUT NONE in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_DISABLED)
#error PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_TIMEOUT_DISABLED        0x00

/*
 * Macro for value for parameter Chain address NONE in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_CADD_NONE)
#error PHY_665A_SYS_PORT1_CFG_REG_CADD_NONE is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_CADD_NONE               0x00

/*
 * Macro for value for parameter Chain address ALL in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_CADD_ALL)
#error PHY_665A_SYS_PORT1_CFG_REG_CADD_ALL is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_CADD_ALL                0x07

/*
 * Macro for value for parameter PROTOCOL TPL2 in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_TPL2)
#error PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_TPL2 is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_TPL2           0x00

/*
 * Macro for value for parameter PROTOCOL TPL3 in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_TPL3)
#error PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_TPL3 is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_PROTOCOL_TPL3           0x01

/*
 * Macro for value for parameter ALLCHAINS ENABLED  in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_ENABLED)
#error PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_ENABLED       0x01

/*
 * Macro for value for parameter ALLCHAINS DISABLED in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_DISABLED)
#error PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_ALLCHAINS_DISABLED      0x00

/*
 * Macro for value for parameter RX ENABLED in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_RX_ENABLED)
#error PHY_665A_SYS_PORT1_CFG_REG_RX_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_RX_ENABLED              0x01

/*
 * Macro for value for parameter RX DISABLED in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_RX_DISABLED)
#error PHY_665A_SYS_PORT1_CFG_REG_RX_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_RX_DISABLED             0x00

/*
 * Macro for value for parameter EN ENABLED in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_EN_ENABLED)
#error PHY_665A_SYS_PORT1_CFG_REG_EN_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_EN_ENABLED              0x01

/*
 * Macro for value for parameter EN DISABLED in SYS_PORT1_CFG register .
*/
#if (defined PHY_665A_SYS_PORT1_CFG_REG_EN_DISABLED)
#error PHY_665A_SYS_PORT1_CFG_REG_EN_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT1_CFG_REG_EN_DISABLED             0x00

/*SYS_PORT2_CFG*/
/*
 * Macro used for defining SYS_PORT2_CFG register address.
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_ADDRESS)
#error PHY_665A_SYS_PORT2_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_ADDRESS                 0x8

/*
 * Macro used for defining default value of SYS_PORT2_CFG register.
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_DEFAULT)
#error PHY_665A_SYS_PORT2_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_DEFAULT                 0x01AF

/*
 * Macro for offset for parameter TIMEOUT in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_OFFSET)
#error PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_OFFSET          0x0A

/*
 * Macro for length for parameter TIMEOUT in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_LEN)
#error PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_LEN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_LEN             0x06

/*
 * Macro for mask for parameter TIMEOUT in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MASK)
#error PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MASK is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MASK            0x3F

/*
 * Macro for offset for parameter Chain address in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_CADD_OFFSET)
#error PHY_665A_SYS_PORT2_CFG_REG_CADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_CADD_OFFSET             0x07

/*
 * Macro for length for parameter Chain address in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_CADD_LEN)
#error PHY_665A_SYS_PORT2_CFG_REG_CADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_CADD_LEN                0x03

/*
 * Macro for mask for parameter Chain address in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_CADD_MASK)
#error PHY_665A_SYS_PORT2_CFG_REG_CADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_CADD_MASK               0x07

/*
 * Macro for offset for parameter Master address in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_MADD_OFFSET)
#error PHY_665A_SYS_PORT2_CFG_REG_MADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_MADD_OFFSET             0x06

/*
 * Macro for length for parameter Master address in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_MADD_LEN)
#error PHY_665A_SYS_PORT2_CFG_REG_MADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_MADD_LEN                0x01

/*
 * Macro for mask for parameter Master address in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_MADD_MASK)
#error PHY_665A_SYS_PORT2_CFG_REG_MADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_MADD_MASK               0x01

/*
 * Macro for offset for parameter PROTOCOL in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_OFFSET)
#error PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_OFFSET         0x05

/*
 * Macro for length for parameter PROTOCOL in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_LEN)
#error PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_LEN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_LEN            0x01

/*
 * Macro for mask for parameter PROTOCOL in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_MASK)
#error PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_MASK is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_MASK           0x01

/*
 * Macro for offset for parameter ALLCHAINS in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_OFFSET)
#error PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_OFFSET        0x03

/*
 * Macro for length for parameter ALLCHAINS in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_LEN)
#error PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_LEN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_LEN           0x01

/*
 * Macro for mask for parameter ALLCHAINS in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_MASK)
#error PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_MASK is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_MASK          0x01

/*
 * Macro for offset for parameter RX in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_RX_OFFSET)
#error PHY_665A_SYS_PORT2_CFG_REG_RX_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_RX_OFFSET               0x01

/*
 * Macro for length for parameter RX in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_RX_LEN)
#error PHY_665A_SYS_PORT2_CFG_REG_RX_LEN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_RX_LEN                  0x01

/*
 * Macro for mask for parameter RX in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_RX_MASK)
#error PHY_665A_SYS_PORT2_CFG_REG_RX_MASK is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_RX_MASK                 0x01

/*
 * Macro for offset for parameter EN in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_EN_OFFSET)
#error PHY_665A_SYS_PORT2_CFG_REG_EN_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_EN_OFFSET               0x00

/*
 * Macro for length for parameter EN in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_EN_LEN)
#error PHY_665A_SYS_PORT2_CFG_REG_EN_LEN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_EN_LEN                  0x01

/*
 * Macro for mask for parameter EN in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_EN_MASK)
#error PHY_665A_SYS_PORT2_CFG_REG_EN_MASK is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_EN_MASK                 0x01

/*
 * Macro for value for parameter TIMEOUT T_MAX in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MAX)
#error PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MAX is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MAX             0x3F

/*
 * Macro for value for parameter TIMEOUT T_MIN in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MIN)
#error PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MIN is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_MIN             0x01

/*
 * Macro for value for parameter TIMEOUT NONE in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_DISABLED)
#error PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_TIMEOUT_DISABLED        0x00

/*
 * Macro for value for parameter Chain address NONE in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_CADD_NONE)
#error PHY_665A_SYS_PORT2_CFG_REG_CADD_NONE is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_CADD_NONE               0x00

/*
 * Macro for value for parameter Chain address ALL in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_CADD_ALL)
#error PHY_665A_SYS_PORT2_CFG_REG_CADD_ALL is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_CADD_ALL                0x07

/*
 * Macro for value for parameter PROTOCOL TPL2 in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_TPL2)
#error PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_TPL2 is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_TPL2           0x00

/*
 * Macro for value for parameter PROTOCOL TPL3 in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_TPL3)
#error PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_TPL3 is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_PROTOCOL_TPL3           0x01

/*
 * Macro for value for parameter ALLCHAINS ENABLED  in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_ENABLED)
#error PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_ENABLED       0x01

/*
 * Macro for value for parameter ALLCHAINS DISABLED in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_DISABLED)
#error PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_ALLCHAINS_DISABLED      0x00

/*
 * Macro for value for parameter RX ENABLED in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_RX_ENABLED)
#error PHY_665A_SYS_PORT2_CFG_REG_RX_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_RX_ENABLED              0x01

/*
 * Macro for value for parameter RX DISABLED in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_RX_DISABLED)
#error PHY_665A_SYS_PORT2_CFG_REG_RX_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_RX_DISABLED             0x00

/*
 * Macro for value for parameter EN ENABLED in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_EN_ENABLED)
#error PHY_665A_SYS_PORT2_CFG_REG_EN_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_EN_ENABLED              0x01

/*
 * Macro for value for parameter EN DISABLED in SYS_PORT2_CFG register .
*/
#if (defined PHY_665A_SYS_PORT2_CFG_REG_EN_DISABLED)
#error PHY_665A_SYS_PORT2_CFG_REG_EN_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT2_CFG_REG_EN_DISABLED             0x00

/*SYS_PORT3_CFG*/
/*
 * Macro used for defining SYS_PORT3_CFG register address.
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_ADDRESS)
#error PHY_665A_SYS_PORT3_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_ADDRESS                 0x9

/*
 * Macro used for defining default value of SYS_PORT3_CFG register.
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_DEFAULT)
#error PHY_665A_SYS_PORT3_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_DEFAULT                 0x022F

/*
 * Macro for offset for parameter TIMEOUT in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_OFFSET)
#error PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_OFFSET          0x0A

/*
 * Macro for length for parameter TIMEOUT in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_LEN)
#error PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_LEN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_LEN             0x06

/*
 * Macro for mask for parameter TIMEOUT in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MASK)
#error PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MASK is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MASK            0x3F

/*
 * Macro for offset for parameter Chain address in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_CADD_OFFSET)
#error PHY_665A_SYS_PORT3_CFG_REG_CADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_CADD_OFFSET             0x07

/*
 * Macro for length for parameter Chain address in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_CADD_LEN)
#error PHY_665A_SYS_PORT3_CFG_REG_CADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_CADD_LEN                0x03

/*
 * Macro for mask for parameter Chain address in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_CADD_MASK)
#error PHY_665A_SYS_PORT3_CFG_REG_CADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_CADD_MASK               0x07

/*
 * Macro for offset for parameter Master address in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_MADD_OFFSET)
#error PHY_665A_SYS_PORT3_CFG_REG_MADD_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_MADD_OFFSET             0x06

/*
 * Macro for length for parameter Master address in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_MADD_LEN)
#error PHY_665A_SYS_PORT3_CFG_REG_MADD_LEN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_MADD_LEN                0x01

/*
 * Macro for mask for parameter Master address in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_MADD_MASK)
#error PHY_665A_SYS_PORT3_CFG_REG_MADD_MASK is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_MADD_MASK               0x01

/*
 * Macro for offset for parameter PROTOCOL in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_OFFSET)
#error PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_OFFSET         0x05

/*
 * Macro for length for parameter PROTOCOL in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_LEN)
#error PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_LEN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_LEN            0x01

/*
 * Macro for mask for parameter PROTOCOL in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_MASK)
#error PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_MASK is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_MASK           0x01

/*
 * Macro for offset for parameter ALLCHAINS in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_OFFSET)
#error PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_OFFSET        0x03

/*
 * Macro for length for parameter ALLCHAINS in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_LEN)
#error PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_LEN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_LEN           0x01

/*
 * Macro for mask for parameter ALLCHAINS in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_MASK)
#error PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_MASK is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_MASK          0x01

/*
 * Macro for offset for parameter RX in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_RX_OFFSET)
#error PHY_665A_SYS_PORT3_CFG_REG_RX_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_RX_OFFSET               0x01

/*
 * Macro for length for parameter RX in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_RX_LEN)
#error PHY_665A_SYS_PORT3_CFG_REG_RX_LEN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_RX_LEN                  0x01

/*
 * Macro for mask for parameter RX in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_RX_MASK)
#error PHY_665A_SYS_PORT3_CFG_REG_RX_MASK is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_RX_MASK                 0x01

/*
 * Macro for offset for parameter EN in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_EN_OFFSET)
#error PHY_665A_SYS_PORT3_CFG_REG_EN_OFFSET is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_EN_OFFSET               0x00

/*
 * Macro for length for parameter EN in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_EN_LEN)
#error PHY_665A_SYS_PORT3_CFG_REG_EN_LEN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_EN_LEN                  0x01

/*
 * Macro for mask for parameter EN in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_EN_MASK)
#error PHY_665A_SYS_PORT3_CFG_REG_EN_MASK is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_EN_MASK                 0x01

/*
 * Macro for value for parameter TIMEOUT T_MAX in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MAX)
#error PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MAX is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MAX             0x3F

/*
 * Macro for value for parameter TIMEOUT T_MIN in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MIN)
#error PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MIN is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_MIN             0x01

/*
 * Macro for value for parameter TIMEOUT NONE in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_DISABLED)
#error PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_TIMEOUT_DISABLED        0x00

/*
 * Macro for value for parameter Chain address NONE in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_CADD_NONE)
#error PHY_665A_SYS_PORT3_CFG_REG_CADD_NONE is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_CADD_NONE               0x00

/*
 * Macro for value for parameter Chain address ALL in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_CADD_ALL)
#error PHY_665A_SYS_PORT3_CFG_REG_CADD_ALL is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_CADD_ALL                0x07

/*
 * Macro for value for parameter PROTOCOL TPL2 in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_TPL2)
#error PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_TPL2 is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_TPL2           0x00

/*
 * Macro for value for parameter PROTOCOL TPL3 in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_TPL3)
#error PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_TPL3 is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_PROTOCOL_TPL3           0x01

/*
 * Macro for value for parameter ALLCHAINS ENABLED in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_ENABLED)
#error PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_ENABLED       0x01

/*
 * Macro for value for parameter ALLCHAINS DISABLED in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_DISABLED)
#error PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_ALLCHAINS_DISABLED      0x00

/*
 * Macro for value for parameter RX ENABLED in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_RX_ENABLED)
#error PHY_665A_SYS_PORT3_CFG_REG_RX_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_RX_ENABLED              0x01

/*
 * Macro for value for parameter RX DISABLED in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_RX_DISABLED)
#error PHY_665A_SYS_PORT3_CFG_REG_RX_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_RX_DISABLED             0x00

/*
 * Macro for value for parameter EN ENABLED in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_EN_ENABLED)
#error PHY_665A_SYS_PORT3_CFG_REG_EN_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_EN_ENABLED              0x01

/*
 * Macro for value for parameter EN DISABLED in SYS_PORT3_CFG register .
*/
#if (defined PHY_665A_SYS_PORT3_CFG_REG_EN_DISABLED)
#error PHY_665A_SYS_PORT3_CFG_REG_EN_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT3_CFG_REG_EN_DISABLED             0x00

/*SYS_HOST_COM_CFG*/
/*
 * Macro used for defining SYS_HOST_COM_CFG register address.
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_ADDRESS)
#error PHY_665A_SYS_HOST_COM_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_ADDRESS              0xA

/*
 * Macro used for defining default value of HOST_COM_CFG register.
*/
#if (defined PHY_665A_HOST_COM_CFG_REG_DEFAULT)
#error PHY_665A_HOST_COM_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_HOST_COM_CFG_REG_DEFAULT                 0x0500

/*
 * Macro for offset for parameter RSPTIME in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_OFFSET)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_OFFSET is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_OFFSET       0x08

/*
 * Macro for length for parameter RSPTIME in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_LEN)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_LEN is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_LEN          0x08

/*
 * Macro for mask for parameter RSPTIME in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_MASK)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_MASK is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_MASK         0xFF

/*
 * Macro for offset for parameter IGNORECRC in SYS_HOST_COM_CFG register .
*/

#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_OFFSET)
#error PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_OFFSET is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_OFFSET     0x07

/*
 * Macro for length for parameter IGNORECRC in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_LEN)
#error PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_LEN is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_LEN        0x01

/*
 * Macro for mask for parameter IGNORECRC in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_MASK)
#error PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_MASK is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_MASK       0x01

/*
 * Macro for offset for parameter RSPHOLDLVL in SYS_HOST_COM_CFG register .
*/

#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_OFFSET)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_OFFSET is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_OFFSET    0x06

/*
 * Macro for mask for parameter RSPHOLDLVL in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_LEN)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_LEN is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_LEN       0x01

/*
 * Macro for mask for parameter RSPHOLDLVL in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_MASK)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_MASK is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_MASK      0x01

/*
 * Macro for offset for parameter RSPHOLD in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_OFFSET)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_OFFSET is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_OFFSET       0x05

/*
 * Macro for length for parameter RSPHOLD in SYS_HOST_COM_CFG register .
*/

#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_LEN)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_LEN is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_LEN          0x01

/*
 * Macro for mask for parameter RSPHOLD in SYS_HOST_COM_CFG register .
*/

#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_MASK)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_MASK is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_MASK         0x01

/*
 * Macro for offset for parameter PINGPONG in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_OFFSET)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_OFFSET is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_OFFSET      0x04

/*
 * Macro for length for parameter PINGPONG in SYS_HOST_COM_CFG register .
*/

#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_LEN)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_LEN is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_LEN         0x01

/*
 * Macro for mask for parameter PINGPONG in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_MASK)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_MASK is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_MASK        0x01

/*
 * Macro for offset for parameter PADDING in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_OFFSET)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_OFFSET is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_OFFSET       0x01

/*
 * Macro for length for parameter PADDING in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_LEN)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_LEN is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_LEN          0x03

/*
 * Macro for mask for parameter PADDING in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_MASK)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_MASK is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_MASK         0x07

/*
 * Macro for offset for parameter PREFIX in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_OFFSET)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_OFFSET is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_OFFSET        0x00

/*
 * Macro for length for parameter PREFIX in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_LEN)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_LEN is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_LEN           0x01

/*
 * Macro for mask for parameter PREFIX in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_MASK)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_MASK is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_MASK          0x01

/*
 * Macro for Value for parameter RSPTIME  DISABLED in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_DISABLED)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_DISABLED is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_DISABLED     0x00

/*
 * Macro for Value for parameter RSPTIME  1US in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_1US)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_1US is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_1US          0x01

/*
 * Macro for Value for parameter RSPTIME  5US in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_5US)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_5US is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPTIME_5US          0x05

/*
 * Macro for Value for parameter IGNORECRC  ENABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_ENABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_ENABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_ENABLE     0x01

/*
 * Macro for Value for parameter IGNORECRC  DISABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_DISABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_DISABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_IGNORECRC_DISABLE    0x00

/*
 * Macro for Value for parameter RSPHOLDLVL  HIGH in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_HIGH)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_HIGH is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_HIGH      0x01

/*
 * Macro for Value for parameter RSPHOLDLVL  LOW in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_LOW)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_LOW is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLDLVL_LOW       0x00

/*
 * Macro for Value for parameter RSPHOLD  ENABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_ENABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_ENABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_ENABLE       0x01

/*
 * Macro for Value for parameter RSPHOLD  DISABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_DISABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_DISABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_RSPHOLD_DISABLE      0x00

/*
 * Macro for Value for parameter PINGPONG  ENABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_ENABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_ENABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_ENABLE      0x01

/*
 * Macro for Value for parameter PINGPONG  DISABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_DISABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_DISABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PINGPONG_DISABLE     0x00

/*
 * Macro for Value for parameter PADDING  DISABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_DISABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_DISABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDING_DISABLE      0x00

/*
 * Macro for Value for parameter PADDING  PAD64 in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD64)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD64 is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD64         0x01

/*
 * Macro for Value for parameter PADDING  PAD80 in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD80)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD80 is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD80         0x02

/*
 * Macro for Value for parameter PADDING  PAD96 in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD96)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD96 is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD96         0x03

/*
 * Macro for Value for parameter PADDING  PAD112 in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD112)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD112 is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PADDNG_PAD112        0x04

/*
 * Macro for Value for parameter PREFIX  ENABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_ENABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_ENABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_ENABLE        0x01

/*
 * Macro for Value for parameter PREFIX  DISABLE in SYS_HOST_COM_CFG register .
*/
#if (defined PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_DISABLE)
#error PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_DISABLE is already defined
#endif
#define PHY_665A_SYS_HOST_COM_CFG_REG_PREFIX_DISABLE       0x00

/*SYS_SPI_CFG*/
/*
 * Macro used for defining SYS_SPI_CFG register address.
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_ADDRESS)
#error PHY_665A_SYS_SPI_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_ADDRESS                   0xB

/*
 * Macro used for defining default value of SYS_SPI_CFG register.
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_DEFAULT)
#error PHY_665A_SYS_SPI_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_DEFAULT                 0x3000

/*
 * Macro for offset for parameter RSPSPIDIV in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_OFFSET)
#error PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_OFFSET is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_OFFSET         0x08

/*
 * Macro for length for parameter RSPSPIDIV in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_LEN)
#error PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_LEN is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_LEN            0x08

/*
 * Macro for mask for parameter RSPSPIDIV in SYS_SPI_CFG register .
*/

#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_MASK)
#error PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_MASK is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_MASK           0xFF

/*
 * Macro for offset for parameter FULLCYC in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_FULLCYC_OFFSET)
#error PHY_665A_SYS_SPI_CFG_REG_FULLCYC_OFFSET is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_FULLCYC_OFFSET           0x03

/*
 * Macro for length for parameter FULLCYC in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_FULLCYC_LEN)
#error PHY_665A_SYS_SPI_CFG_REG_FULLCYC_LEN is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_FULLCYC_LEN              0x01

/*
 * Macro for mask for parameter FULLCYC in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_FULLCYC_MASK)
#error PHY_665A_SYS_SPI_CFG_REG_FULLCYC_MASK is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_FULLCYC_MASK             0x01

/*
 * Macro for offset for parameter INTO in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_INTO_OFFSET)
#error PHY_665A_SYS_SPI_CFG_REG_INTO_OFFSET is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_INTO_OFFSET              0x02

/*
 * Macro for length for parameter INTO in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_INTO_LEN)
#error PHY_665A_SYS_SPI_CFG_REG_INTO_LEN is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_INTO_LEN                 0x01

/*
 * Macro for mask for parameter INTO in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_INTO_MASK)
#error PHY_665A_SYS_SPI_CFG_REG_INTO_MASK is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_INTO_MASK                0x01

/*
 * Macro for offset for parameter CHKRDEMPTY in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_OFFSET)
#error PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_OFFSET is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_OFFSET        0x01

/*
 * Macro for length for parameter CHKRDEMPTY in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_LEN)
#error PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_LEN is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_LEN           0x01

/*
 * Macro for mask for parameter CHKRDEMPTY in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_MASK)
#error PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_MASK is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_MASK          0x01

/*
 * Macro for offset for parameter RSPMST in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPMST_OFFSET)
#error PHY_665A_SYS_SPI_CFG_REG_RSPMST_OFFSET is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPMST_OFFSET            0x00

/*
 * Macro for length for parameter RSPMST in SYS_SPI_CFG register .
*/

#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPMST_LEN)
#error PHY_665A_SYS_SPI_CFG_REG_RSPMST_LEN is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPMST_LEN               0x01

/*
 * Macro for length for parameter RSPMST in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPMST_MASK)
#error PHY_665A_SYS_SPI_CFG_REG_RSPMST_MASK is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPMST_MASK              0x01

/*
 * Macro for value for parameter RSPSPIDIV MIN in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_MIN)
#error PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_MIN is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPSPIDIV_MIN            0x05

/*
 * Macro for value for parameter FULLCYC DISABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_FULLCYC_DISABLED)
#error PHY_665A_SYS_SPI_CFG_REG_FULLCYC_DISABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_FULLCYC_DISABLED         0x00

/*
 * Macro for value for parameter FULLCYC ENABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_FULLCYC_ENABLED)
#error PHY_665A_SYS_SPI_CFG_REG_FULLCYC_ENABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_FULLCYC_ENABLED          0x01

/*
 * Macro for value for parameter INTO DISABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_INTO_DISABLED)
#error PHY_665A_SYS_SPI_CFG_REG_INTO_DISABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_INTO_DISABLED            0x00

/*
 * Macro for value for parameter INTO ENABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_INTO_ENABLED)
#error PHY_665A_SYS_SPI_CFG_REG_INTO_ENABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_INTO_ENABLED             0x00

/*
 * Macro for value for parameter CHKRDEMPTY DISABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_DISABLED)
#error PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_DISABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_DISABLED      0x00

/*
 * Macro for value for parameter CHKRDEMPTY ENABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_ENABLED)
#error PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_ENABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_CHKRDEMPTY_ENABLED       0x01

/*
 * Macro for value for parameter RSPMST DISABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPMST_DISABLED)
#error PHY_665A_SYS_SPI_CFG_REG_RSPMST_DISABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPMST_DISABLED          0x00

/*
 * Macro for value for parameter RSPMST ENABLED in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_SPI_CFG_REG_RSPMST_ENABLED)
#error PHY_665A_SYS_SPI_CFG_REG_RSPMST_ENABLED is already defined
#endif
#define PHY_665A_SYS_SPI_CFG_REG_RSPMST_ENABLED           0x01

/*SYS_CAN_CFG*/
/*
 * Macro used for defining SYS_CAN_CFG register address.
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_ADDRESS)
#error PHY_665A_SYS_CAN_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_ADDRESS                   0xC

/*
 * Macro used for defining default value of SYS_CAN_CFG register.
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_DEFAULT)
#error PHY_665A_SYS_CAN_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_DEFAULT                 0x0000

/*
 * Macro for offset for parameter RSPPROT in SYS_CAN_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_RSPPROT_OFFSET)
#error PHY_665A_SYS_CAN_CFG_REG_RSPPROT_OFFSET is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_RSPPROT_OFFSET           0x03

/*
 * Macro for length for parameter RSPPROT in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_RSPPROT_LEN)
#error PHY_665A_SYS_CAN_CFG_REG_RSPPROT_LEN is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_RSPPROT_LEN              0x01

/*
 * Macro for mask for parameter RSPPROT in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_RSPPROT_MASK)
#error PHY_665A_SYS_CAN_CFG_REG_RSPPROT_MASK is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_RSPPROT_MASK             0x01

/*
 * Macro for offset for parameter CANDATSPD in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_OFFSET)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_OFFSET is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_OFFSET         0x00

/*
 * Macro for length for parameter CANDATSPD in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_LEN)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_LEN is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_LEN            0x03

/*
 * Macro for mask for parameter CANDATSPD in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_MASK)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_MASK is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_MASK           0x07

/*
 * Macro for  for parameter RSPPROT CANFD in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_RSPPROT_CANFD_RESP)
#error PHY_665A_SYS_CAN_CFG_REG_RSPPROT_CANFD_RESP is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_RSPPROT_CANFD_RESP       0x01

/*
 * Macro for value for parameter RSPPROT CAN in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_RSPPROT_CAN_RESP)
#error PHY_665A_SYS_CAN_CFG_REG_RSPPROT_CAN_RESP is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_RSPPROT_CAN_RESP         0x00

/*
 * Macro for value for parameter CANDATSPD CAN250 in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN250)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN250 is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN250         0x00

/*
 * Macro for value for parameter CANDATSPD CAN500 in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN500)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN500 is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN500         0x01

/*
 * Macro for value for parameter CANDATSPD CAN1M in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN1M)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN1M is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN1M          0x02

/*
 * Macro for value for parameter CANDATSPD CANM in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN2M)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN2M is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN2M          0x03

/*
 * Macro for value for parameter CANDATSPD CAN5M in SYS_SPI_CFG register .
*/
#if (defined PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN5M)
#error PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN5M is already defined
#endif
#define PHY_665A_SYS_CAN_CFG_REG_CANDATSPD_CAN5M          0x04

/*SYS_UART_CFG*/
/*
 * Macro used for defining SYS_UART_CFG register address.
*/

#if (defined PHY_665A_SYS_UART_CFG_REG_ADDRESS)
#error PHY_665A_SYS_UART_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_ADDRESS                  0x000D

/*
 * Macro used for defining default value of SYS_UART_CFG register.
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_DEFAULT)
#error PHY_665A_SYS_UART_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_DEFAULT                 0xC000

/*
 * Macro for offset for parameter RESYNCTO in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_RESYNCTO_OFFSET)
#error PHY_665A_SYS_UART_CFG_REG_RESYNCTO_OFFSET is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_RESYNCTO_OFFSET          0x0C

/*
 * Macro for length for parameter RESYNCTO in SYS_UART_CFG register .
*/

#if (defined PHY_665A_SYS_UART_CFG_REG_RESYNCTO_LEN)
#error PHY_665A_SYS_UART_CFG_REG_RESYNCTO_LEN is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_RESYNCTO_LEN             0x04

/*
 * Macro for mask for parameter RESYNCTO in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MASK)
#error PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MASK is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MASK            0x0F

/*
 * Macro for offset for parameter BAUDRATEDIV in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_OFFSET)
#error PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_OFFSET is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_OFFSET       0x00

/*
 * Macro for length for parameter BAUDRATEDIV in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_LEN)
#error PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_LEN is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_LEN          0x0C

/*
 * Macro for length for parameter BAUDRATEDIV in SYS_UART_CFG register .
*/

#if (defined PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MASK)
#error PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MASK is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MASK         0xFFF

/*
 * Macro for value for parameter RESYNCTO ZERO in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_RESYNCTO_ZERO)
#error PHY_665A_SYS_UART_CFG_REG_RESYNCTO_ZERO is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_RESYNCTO_ZERO            0x00

/*
 * Macro for value for parameter RESYNCTO MIN in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MIN)
#error PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MIN is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MIN             0x01

/*
 * Macro for value for parameter RESYNCTO 1MS in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_RESYNCTO_1MS)
#error PHY_665A_SYS_UART_CFG_REG_RESYNCTO_1MS is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_RESYNCTO_1MS             0x0C

/*
 * Macro for value for parameter RESYNCTO MAX in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MAX)
#error PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MAX is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_RESYNCTO_MAX             0x0F

/*
 * Macro for value for parameter RESYNCTO AUTORATE in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_AUTORATE)
#error PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_AUTORATE is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_AUTORATE     0x00

/*
 * Macro for value for parameter RESYNCTO MIN in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MIN)
#error PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MIN is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MIN          0x40

/*
 * Macro for value for parameter BAUDRATEDIV MAX in SYS_UART_CFG register .
*/
#if (defined PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MAX)
#error PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MAX is already defined
#endif
#define PHY_665A_SYS_UART_CFG_REG_BAUDRATEDIV_MAX          0xFFF

/*SYS_FLT_CFG*/
/*
 * Macro used for defining SYS_FLT_CFG register address.
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_ADDRESS)
#error PHY_665A_SYS_FLT_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_ADDRESS                   0x000E

/*
 * Macro used for defining default value of SYS_FLT_CFG register.
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_DEFAULT)
#error PHY_665A_SYS_FLT_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_DEFAULT                 0x1111

/*
 * Macro for offset for parameter RMUNEXP3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_OFFSET           0x0F

/*
 * Macro for length for parameter RMUNEXP3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_LEN              0x01

/*
 * Macro for length for parameter RMUNEXP3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_MASK             0x01

/*
 * Macro for offset for parameter RMINVCRC3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_OFFSET          0x0E

/*
 * Macro for length for parameter RMINVCRC3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_LEN             0x01


/*
 * Macro for length for parameter RMINVCRC3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_MASK            0x01

/*
 * Macro for offset for parameter CHECKUNEXP3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_OFFSET        0x0D

/*
 * Macro for length for parameter CHECKUNEXP3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_LEN           0x01

/*
 * Macro for length for parameter CHECKUNEXP3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_MASK          0x01

/*
 * Macro for offset for parameter CHECKCRC3 in SYS_FLT_CFG register .
*/

#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_OFFSET          0x0C

/*
 * Macro for length for parameter CHECKCRC3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_LEN             0x01

/*
 * Macro for mask for parameter CHECKCRC3 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_MASK            0x01

/*
 * Macro for offset for parameter RMUNEXP2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_OFFSET           0x0B

/*
 * Macro for length for parameter RMUNEXP2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_LEN              0x01

/*
 * Macro for mask for parameter RMUNEXP2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_MASK             0x01

/*
 * Macro for offset for parameter RMINVCRC2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_OFFSET          0x0A

/*
 * Macro for length for parameter RMINVCRC2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_LEN             0x01

/*
 * Macro for mask for parameter RMINVCRC2 in SYS_FLT_CFG register .
*/

#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_MASK            0x01
/*
 * Macro for offset for parameter CHECKUNEXP2 in SYS_FLT_CFG register .
*/

#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_OFFSET        0x09
/*
 * Macro for length for parameter CHECKUNEXP2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_LEN           0x01
/*
 * Macro for mask for parameter CHECKUNEXP2 in SYS_FLT_CFG register .
*/

#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_MASK          0x01
/*
 * Macro for offset for parameter CHECKCRC2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_OFFSET          0x08
/*
 * Macro for length for parameter CHECKCRC2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_LEN             0x01
/*
 * Macro for mask for parameter CHECKCRC2 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_MASK            0x01
/*
 * Macro for offset for parameter RMUNEXP1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_OFFSET           0x07
/*
 * Macro for length for parameter RMUNEXP1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_LEN              0x01
/*
 * Macro for mask for parameter RMUNEXP1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_MASK             0x01
/*
 * Macro for offset for parameter RMINVCRC1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_OFFSET          0x06
/*
 * Macro for length for parameter RMINVCRC1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_LEN             0x01
/*
 * Macro for mask for parameter RMINVCRC1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_MASK            0x01
/*
 * Macro for offset for parameter CHECKUNEXP1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_OFFSET        0x05
/*
 * Macro for length for parameter CHECKUNEXP1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_LEN           0x01

/*
 * Macro for mask for parameter CHECKUNEXP1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_MASK          0x01
/*
 * Macro for offset for parameter CHECKCRC1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_OFFSET          0x04
/*
 * Macro for length for parameter CHECKCRC1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_LEN             0x01
/*
 * Macro for mask for parameter CHECKCRC1 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_MASK            0x01
/*
 * Macro for offset for parameter RMUNEXP0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_OFFSET           0x03
/*
 * Macro for length for parameter RMUNEXP0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_LEN              0x01
/*
 * Macro for mask for parameter RMUNEXP0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_MASK             0x01
/*
 * Macro for offset for parameter RMINVCRC0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_OFFSET          0x02
/*
 * Macro for length for parameter RMINVCRC0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_LEN             0x01
/*
 * Macro for mask for parameter RMINVCRC0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_MASK            0x01
/*
 * Macro for offset for parameter CHECKUNEXP0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_OFFSET        0x01
/*
 * Macro for length for parameter CHECKUNEXP0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_LEN           0x01
/*
 * Macro for mask for parameter CHECKUNEXP0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_MASK          0x01
/*
 * Macro for offset for parameter CHECKCRC0 in SYS_FLT_CFG register .
*/

#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_OFFSET)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_OFFSET is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_OFFSET          0x00
/*
 * Macro for length for parameter CHECKCRC0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_LEN)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_LEN is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_LEN             0x01
/*
 * Macro for mask for parameter CHECKCRC0 in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_MASK)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_MASK is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_MASK            0x01
/*
 * Macro for value for parameter RMUNEXP3 ENABLED in SYS_FLT_CFG register .
*/

#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_ENABLED          0x01
/*
 * Macro for value for parameter RMUNEXP3 DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP3_DISABLED         0x00
/*
 * Macro for value for parameter RMINVCRC3  ENABLEDin SYS_FLT_CFG register .
*/

#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_ENABLED         0x01
/*
 * Macro for value for parameter RMINVCRC3  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC3_DISABLED        0x00
/*
 * Macro for value for parameter CHECKUNEXP3  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_ENABLED       0x01
/*
 * Macro for value for parameter CHECKUNEXP3  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP3_DISABLED      0x00
/*
 * Macro for value for parameter CHECKCRC3  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_ENABLED         0x01
/*
 * Macro for value for parameter CHECKCRC3  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC3_DISABLED        0x00
/*
 * Macro for value for parameter RMUNEXP2  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_ENABLED          0x01
/*
 * Macro for value for parameter RMUNEXP2  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP2_DISABLED         0x00
/*
 * Macro for value for parameter RMINVCRC2  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_ENABLED         0x01
/*
 * Macro for value for parameter RMINVCRC2  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC2_DISABLED        0x00
/*
 * Macro for value for parameter CHECKUNEXP2  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_ENABLED       0x01
/*
 * Macro for value for parameter CHECKUNEXP2  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP2_DISABLED      0x00
/*
 * Macro for value for parameter CHECKCRC2  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_ENABLED         0x01
/*
 * Macro for value for parameter CHECKCRC2  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC2_DISABLED        0x00
/*
 * Macro for value for parameter RMUNEXP1  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_ENABLED          0x01
/*
 * Macro for value for parameter RMUNEXP1  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP1_DISABLED         0x00
/*
 * Macro for value for parameter RMINVCRC1  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_ENABLED         0x01
/*
 * Macro for value for parameter RMINVCRC1  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC1_DISABLED        0x00
/*
 * Macro for value for parameter CHECKUNEXP1  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_ENABLED       0x01
/*
 * Macro for value for parameter CHECKUNEXP1  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP1_DISABLED      0x00
/*
 * Macro for value for parameter CHECKCRC1  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_ENABLED         0x01
/*
 * Macro for value for parameter CHECKCRC1  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC1_DISABLED        0x00
/*
 * Macro for value for parameter RMUNEXP0  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_ENABLED          0x01
/*
 * Macro for value for parameter RMUNEXP0  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMUNEXP0_DISABLED         0x00
/*
 * Macro for value for parameter RMINVCRC0  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_ENABLED         0x01
/*
 * Macro for value for parameter RMINVCRC0  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_RMINVCRC0_DISABLED        0x00
/*
 * Macro for value for parameter CHECKUNEXP0  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_ENABLED       0x01
/*
 * Macro for value for parameter CHECKUNEXP0  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKUNEXP0_DISABLED      0x00
/*
 * Macro for value for parameter CHECKCRC0  ENABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_ENABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_ENABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_ENABLED         0x01
/*
 * Macro for value for parameter CHECKCRC0  DISABLED in SYS_FLT_CFG register .
*/
#if (defined PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_DISABLED)
#error PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_DISABLED is already defined
#endif
#define PHY_665A_SYS_FLT_CFG_REG_CHECKCRC0_DISABLED        0x00

/*SYS_VERSION_REG*/
/*
 * Macro used for defining SYS_VERSION_REG register address.
*/
#if (defined PHY_665A_SYS_VERSION_REG_ADDRESS)
#error PHY_665A_SYS_VERSION_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_VERSION_REG_ADDRESS                   0x10

/*
 * Macro used for defining default value of SYS_VERSION_REG register.
*/
#if (defined PHY_665A_SYS_VERSION_REG_DEFAULT)
#error PHY_665A_SYS_VERSION_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_VERSION_REG_DEFAULT                 0x0100

/*SYS_UID_LOW_REG*/
/*
 * Macro used for defining SYS_UID_LOW_REG register address.
*/
#if (defined PHY_665A_SYS_UID_LOW_REG_ADDRESS)
#error PHY_665A_SYS_UID_LOW_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_UID_LOW_REG_ADDRESS                   0x11

/*
 * Macro used for defining default value of SYS_UID_LOW_REG register.
*/
#if (defined PHY_665A_SYS_UID_LOW_REG_DEFAULT)
#error PHY_665A_SYS_UID_LOW_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_UID_LOW_REG_DEFAULT                 0x0000

/*SYS_UID_MID_REG*/
/*
 * Macro used for defining SYS_UID_MID_REG register address.
*/
#if (defined PHY_665A_SYS_UID_MID_REG_ADDRESS)
#error PHY_665A_SYS_UID_MID_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_UID_MID_REG_ADDRESS                   0x12

/*
 * Macro used for defining default value of SYS_UID_MID_REG register.
*/
#if (defined PHY_665A_SYS_UID_MID_REG_DEFAULT)
#error PHY_665A_SYS_UID_MID_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_UID_MID_REG_DEFAULT                 0x0000

/*SYS_UID_HIGH_REG*/
/*
 * Macro used for defining SYS_UID_HIGH_REG register address.
*/
#if (defined PHY_665A_SYS_UID_HIGH_REG_ADDRESS)
#error PHY_665A_SYS_UID_HIGH_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_UID_HIGH_REG_ADDRESS                  0x13

/*
 * Macro used for defining default value of SYS_UID_HIGH_REG register.
*/
#if (defined PHY_665A_SYS_UID_HIGH_REG_DEFAULT)
#error PHY_665A_SYS_UID_HIGH_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_UID_HIGH_REG_DEFAULT                 0x0000

/*
 * Macro used for defining SYS_PROD_VER_REG register address.
*/
#if (defined PHY_665A_SYS_PROD_VER_REG_ADDRESS)
#error PHY_665A_SYS_PROD_VER_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_PROD_VER_REG_ADDRESS                  0x14

/*
 * Macro used for defining default value of SYS_PROD_VER_REG register.
*/
#if (defined PHY_665A_SYS_PROD_VER_REG_DEFAULT)
#error PHY_665A_SYS_PROD_VER_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_PROD_VER_REG_DEFAULT                 0x0100

/*SYS_QUEUE_SIZE_REG*/
/*
 * Macro used for defining SYS_QUEUE_SIZE_REG register address.
*/

#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_ADDRESS)
#error PHY_665A_SYS_QUEUE_SIZE_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_ADDRESS                0x18

/*
 * Macro used for defining default value of SYS_QUEUE_SIZE_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_DEFAULT)
#error PHY_665A_SYS_QUEUE_SIZE_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_DEFAULT                 0x000A

/*
 * Macro for offset for parameter RESERVED in SYS_QUEUE_SIZE_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_OFFSET)
#error PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_OFFSET is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_OFFSET        0x05

/*
 * Macro for length for parameter RESERVED in SYS_QUEUE_SIZE_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_LEN)
#error PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_LEN is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_LEN           0x0B

/*
 * Macro for length for parameter RESERVED in SYS_QUEUE_SIZE_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_MASK)
#error PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_MASK is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_RESERVED_MASK          0x7FF

/*
 * Macro for offset for parameter REQ in SYS_QUEUE_SIZE_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_REQ_OFFSET)
#error PHY_665A_SYS_QUEUE_SIZE_REG_REQ_OFFSET is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_REQ_OFFSET             0x00U

/*
 * Macro for length for parameter REQ in SYS_QUEUE_SIZE_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_REQ_LEN)
#error PHY_665A_SYS_QUEUE_SIZE_REG_REQ_LEN is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_REQ_LEN                0x05

/*
 * Macro for length for parameter REQ in SYS_QUEUE_SIZE_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_SIZE_REG_REQ_MASK)
#error PHY_665A_SYS_QUEUE_SIZE_REG_REQ_MASK is already defined
#endif
#define PHY_665A_SYS_QUEUE_SIZE_REG_REQ_MASK               0x1FU

/*SYS_REQ_QUEUE_CFG_REG*/
/*
 * Macro used for defining SYS_REQ_QUEUE_CFG_REG register address.
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_ADDRESS)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_ADDRESS             0x19

/*
 * Macro used for defining default value of SYS_REQ_QUEUE_CFG_REG register.
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_DEFAULT)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_DEFAULT                 0x0100

/*
 * Macro for offset for parameter RESERVED1 in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_OFFSET)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_OFFSET is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_OFFSET    0x0E

/*
 * Macro for length for parameter RESERVED1 in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_LEN)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_LEN is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_LEN       0x02

/*
 * Macro for length for parameter RESERVED1 in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_MASK)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_MASK is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED1_MASK      0x03

/*
 * Macro for offset for parameter HIGH in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_OFFSET)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_OFFSET is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_OFFSET         0x08

/*
 * Macro for length for parameter HIGH in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_LEN)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_LEN is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_LEN            0x06

/*
 * Macro for length for parameter HIGH in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_MASK)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_MASK is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_HIGH_MASK           0x3F

/*
 * Macro for offset for parameter RESERVED2 in SYS_REQ_QUEUE_CFG_REG register .
*/

#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_OFFSET)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_OFFSET is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_OFFSET    0x06

/*
 * Macro for length for parameter RESERVED2 in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_LEN)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_LEN is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_LEN       0x02

/*
 * Macro for length for parameter RESERVED2 in SYS_REQ_QUEUE_CFG_REG register .
*/

#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_MASK)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_MASK is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_RESERVED2_MASK      0x03

/*
 * Macro for offset for parameter LOW in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_OFFSET)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_OFFSET is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_OFFSET          0x00

/*
 * Macro for length for parameter LOW in SYS_REQ_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_LEN)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_LEN is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_LEN             0x06

/*
 * Macro for length for parameter LOW in SYS_REQ_QUEUE_CFG_REG register .
*/

#if (defined PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_MASK)
#error PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_MASK is already defined
#endif
#define PHY_665A_SYS_REQ_QUEUE_CFG_REG_LOW_MASK            0x3FU

/*SYS_RSP_QUEUE_CFG_REG*/
/*
 * Macro used for defining SYS_RSP_QUEUE_CFG_REG register address.
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_ADDRESS)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_ADDRESS             0x1A

/*
 * Macro used for defining default value of SYS_RSP_QUEUE_CFG_REG register.
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_DEFAULT)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_DEFAULT                 0x0100

/*
 * Macro for offset for parameter RESERVED1 in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_OFFSET)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_OFFSET is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_OFFSET    0x0E

/*
 * Macro for length for parameter RESERVED1 in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_LEN)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_LEN is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_LEN       0x02

/*
 * Macro for length for parameter RESERVED1 in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_MASK)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_MASK is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED1_MASK      0x03

/*
 * Macro for offset for parameter HIGH in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_OFFSET)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_OFFSET is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_OFFSET         0x08

/*
 * Macro for length for parameter HIGH in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_LEN)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_LEN is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_LEN            0x06

/*
 * Macro for length for parameter HIGH in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_MASK)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_MASK is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_HIGH_MASK           0x3F

/*
 * Macro for offset for parameter RESERVED2 in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_OFFSET)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_OFFSET is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_OFFSET    0x06

/*
 * Macro for length for parameter RESERVED2 in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_LEN)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_LEN is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_LEN       0x02

/*
 * Macro for length for parameter RESERVED2 in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_MASK)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_MASK is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_RESERVED2_MASK      0x03

/*
 * Macro for offset for parameter LOW in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_OFFSET)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_OFFSET is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_OFFSET          0x00

/*
 * Macro for length for parameter LOW in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_LEN)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_LEN is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_LEN             0x06

/*
 * Macro for length for parameter LOW in SYS_RSP_QUEUE_CFG_REG register .
*/
#if (defined PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_MASK)
#error PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_MASK is already defined
#endif
#define PHY_665A_SYS_RSP_QUEUE_CFG_REG_LOW_MASK            0x3F

/*SYS_QUEUE_CTRL_REG*/
/*
 * Macro used for defining SYS_QUEUE_CTRL_REG register address.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_ADDRESS)
#error PHY_665A_SYS_QUEUE_CTRL_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_ADDRESS                0x1BU

/*
 * Macro used for defining default value of SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_DEFAULT)
#error PHY_665A_SYS_QUEUE_CTRL_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_DEFAULT                 0x0000

/*
 * Macro for defining the offset for parameter CLEAR in SYS_QUEUE_CTRL_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_OFFSET)
#error PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_OFFSET is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_OFFSET          0x01

/*
 * Macro used for length for parameter CLEAR in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_LEN)
#error PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_LEN is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_LEN                 0x01

/*
 * Macro used for Mask for parameter CLEAR in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_MASK)
#error PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_MASK is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_MASK                 0x01

/*
 * Macro used for defining the value CLEAR for field CLEAR in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_FIELD_CLEAR)
#error PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_FIELD_CLEAR is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_FIELD_CLEAR                 0x01U

/*
 * Macro used for defining the value NOTHING for field CLEAR in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_NOTHING)
#error PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_NOTHING is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_CLEAR_NOTHING                 0x00

/*
 * Macro for defining the offset for parameter HOLD in SYS_QUEUE_CTRL_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_OFFSET)
#error PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_OFFSET is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_OFFSET          0x00

/*
 * Macro used for length for parameter HOLD in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_LEN)
#error PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_LEN is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_LEN                 0x01

/*
 * Macro used for Mask for parameter HOLD in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_MASK)
#error PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_MASK is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_MASK                 0x01

/*
 * Macro used for defining the value DISABLED for field HOLD in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_DISABLED)
#error PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_DISABLED is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_DISABLED                 0x00

/*
 * Macro used for defining the value ENABLED for field HOLD in SYS_QUEUE_CTRL_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_ENABLED)
#error PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_ENABLED is already defined
#endif
#define PHY_665A_SYS_QUEUE_CTRL_REG_HOLD_ENABLED                 0x01U

/*
 * Macro for value for parameter STAT in SYS_QUEUE_STAT_REG register .
*/
#if (defined PHY_665A_SYS_QUEUE_STAT_REG_ADDRESS)
#error PHY_665A_SYS_QUEUE_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_SYS_QUEUE_STAT_REG_ADDRESS                0x1C

/*
 * Macro used for defining default value of SYS_QUEUE_STAT_REG register.
*/
#if (defined PHY_665A_SYS_QUEUE_STAT_REG_DEFAULT)
#error PHY_665A_SYS_QUEUE_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_SYS_QUEUE_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_CFG_CRC register address.
*/

#if (defined PHY_665A_EVH_CFG_CRC_REG_ADDRESS)
#error PHY_665A_EVH_CFG_CRC_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_CFG_CRC_REG_ADDRESS                   0x20U

/*
 * Macro used for defining default value of EVH_CFG_CRC register.
*/
#if (defined PHY_665A_EVH_CFG_CRC_REG_DEFAULT)
#error PHY_665A_EVH_CFG_CRC_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_CFG_CRC_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT0_SEL register address.
*/
#if (defined PHY_665A_EVH_INT0_SEL_REG_ADDRESS)
#error PHY_665A_EVH_INT0_SEL_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT0_SEL_REG_ADDRESS                  0x21

/*
 * Macro used for defining default value of EVH_INT0_SEL register.
*/
#if (defined PHY_665A_EVH_INT0_SEL_REG_DEFAULT)
#error PHY_665A_EVH_INT0_SEL_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT0_SEL_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT1_SEL register address.
*/
#if (defined PHY_665A_EVH_INT1_SEL_REG_ADDRESS)
#error PHY_665A_EVH_INT1_SEL_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT1_SEL_REG_ADDRESS                  0x22

/*
 * Macro used for defining default value of EVH_INT1_SEL register.
*/
#if (defined PHY_665A_EVH_INT1_SEL_REG_DEFAULT)
#error PHY_665A_EVH_INT1_SEL_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT1_SEL_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT2_SEL register address.
*/
#if (defined PHY_665A_EVH_INT2_SEL_REG_ADDRESS)
#error PHY_665A_EVH_INT2_SEL_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT2_SEL_REG_ADDRESS                  0x23

/*
 * Macro used for defining default value of EVH_INT2_SEL register.
*/
#if (defined PHY_665A_EVH_INT2_SEL_REG_DEFAULT)
#error PHY_665A_EVH_INT2_SEL_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT2_SEL_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT3_SEL register address.
*/
#if (defined PHY_665A_EVH_INT3_SEL_REG_ADDRESS)
#error PHY_665A_EVH_INT3_SEL_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT3_SEL_REG_ADDRESS                  0x24

/*
 * Macro used for defining default value of EVH_INT3_SEL register.
*/
#if (defined PHY_665A_EVH_INT3_SEL_REG_DEFAULT)
#error PHY_665A_EVH_INT3_SEL_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT3_SEL_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT0_OUT_CFG register address.
*/
#if (defined PHY_665A_EVH_INT0_OUT_CFG_REG_ADDRESS)
#error PHY_665A_EVH_INT0_OUT_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT0_OUT_CFG_REG_ADDRESS              0x25

/*
 * Macro used for defining default value of EVH_INT0_OUT_CFG register.
*/
#if (defined PHY_665A_EVH_INT0_OUT_CFG_REG_DEFAULT)
#error PHY_665A_EVH_INT0_OUT_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT0_OUT_CFG_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT1_OUT_CFG register address.
*/
#if (defined PHY_665A_EVH_INT1_OUT_CFG_REG_ADDRESS)
#error PHY_665A_EVH_INT1_OUT_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT1_OUT_CFG_REG_ADDRESS              0x26

/*
 * Macro used for defining default value of EVH_INT1_OUT_CFG register.
*/
#if (defined PHY_665A_EVH_INT1_OUT_CFG_REG_DEFAULT)
#error PHY_665A_EVH_INT1_OUT_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT1_OUT_CFG_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT2_OUT_CFG register address.
*/
#if (defined PHY_665A_EVH_INT2_OUT_CFG_REG_ADDRESS)
#error PHY_665A_EVH_INT2_OUT_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT2_OUT_CFG_REG_ADDRESS              0x27

/*
 * Macro used for defining default value of EVH_INT2_OUT_CFG register.
*/
#if (defined PHY_665A_EVH_INT2_OUT_CFG_REG_DEFAULT)
#error PHY_665A_EVH_INT2_OUT_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT2_OUT_CFG_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_INT3_OUT_CFG register address.
*/
#if (defined PHY_665A_EVH_INT3_OUT_CFG_REG_ADDRESS)
#error PHY_665A_EVH_INT3_OUT_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_INT3_OUT_CFG_REG_ADDRESS              0x28

/*
 * Macro used for defining default value of EVH_INT3_OUT_CFG register.
*/
#if (defined PHY_665A_EVH_INT3_OUT_CFG_REG_DEFAULT)
#error PHY_665A_EVH_INT3_OUT_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_INT3_OUT_CFG_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_WAKEUP_CFG_REG register address.
*/
#if (defined PHY_665A_EVH_WAKEUP_CFG_REG_ADDRESS)
#error PHY_665A_EVH_WAKEUP_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_WAKEUP_CFG_REG_ADDRESS                0x29

/*
 * Macro used for defining default value of EVH_WAKEUP_CFG register.
*/
#if (defined PHY_665A_EVH_WAKEUP_CFG_REG_DEFAULT)
#error PHY_665A_EVH_WAKEUP_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_WAKEUP_CFG_REG_DEFAULT                 0x0010

/*
 * Macro used for defining EVH_WAKEUP_REASON_REG register address.
*/
#if (defined PHY_665A_EVH_WAKEUP_REASON_REG_ADDRESS)
#error PHY_665A_EVH_WAKEUP_REASON_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_WAKEUP_REASON_REG_ADDRESS             0x2E

/*
 * Macro used for defining default value of EVH_WAKEUP_REASON_REG register.
*/
#if (defined PHY_665A_EVH_WAKEUP_REASON_REG_DEFAULT)
#error PHY_665A_EVH_WAKEUP_REASON_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_WAKEUP_REASON_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_RST_REASON_REG register address.
*/
#if (defined PHY_665A_EVH_RST_REASON_REG_ADDRESS)
#error PHY_665A_EVH_RST_REASON_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_RST_REASON_REG_ADDRESS                0x2F

/*
 * Macro used for defining default value of EVH_RST_REASON_REG register.
*/
#if (defined PHY_665A_EVH_RST_REASON_REG_DEFAULT)
#error PHY_665A_EVH_RST_REASON_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_RST_REASON_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_QUEUE_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_QUEUE_STAT_REG_ADDRESS)
#error PHY_665A_EVH_QUEUE_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_QUEUE_STAT_REG_ADDRESS                0x30

/*
 * Macro used for defining default value of EVH_QUEUE_STAT_REG register.
*/
#if (defined PHY_665A_EVH_QUEUE_STAT_REG_DEFAULT)
#error PHY_665A_EVH_QUEUE_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_QUEUE_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_GRP_ERR_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_GRP_ERR_STAT_REG_ADDRESS)
#error PHY_665A_EVH_GRP_ERR_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_GRP_ERR_STAT_REG_ADDRESS              0x31

/*
 * Macro used for defining default value of EVH_GRP_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_GRP_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_GRP_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_GRP_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_GENERAL_ERR_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_GENERAL_ERR_STAT_REG_ADDRESS)
#error PHY_665A_EVH_GENERAL_ERR_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_GENERAL_ERR_STAT_REG_ADDRESS                   0x32

/*
 * Macro used for defining default value of EVH_GENERAL_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_GENERAL_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_GENERAL_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_GENERAL_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_MCUIF_ERR_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_MCUIF_ERR_STAT_REG_ADDRESS)
#error PHY_665A_EVH_MCUIF_ERR_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_MCUIF_ERR_STAT_REG_ADDRESS                     0x33

/*
 * Macro used for defining default value of EVH_MCUIF_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_MCUIF_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_MCUIF_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_MCUIF_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_TPL0_ERR_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_TPL0_ERR_STAT_REG_ADDRESS)
#error PHY_665A_EVH_TPL0_ERR_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_TPL0_ERR_STAT_REG_ADDRESS                      0x34

/*
 * Macro used for defining default value of EVH_TPL0_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_TPL0_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_TPL0_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_TPL0_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_TPL1_ERR_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_TPL1_ERR_STAT_REG_ADDRESS)
#error PHY_665A_EVH_TPL1_ERR_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_TPL1_ERR_STAT_REG_ADDRESS                      0x35

/*
 * Macro used for defining default value of EVH_TPL1_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_TPL1_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_TPL1_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_TPL1_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_TPL2_ERR_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_TPL2_ERR_STAT_REG_ADDRESS)
#error PHY_665A_EVH_TPL2_ERR_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_TPL2_ERR_STAT_REG_ADDRESS                      0x36

/*
 * Macro used for defining default value of EVH_TPL2_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_TPL2_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_TPL2_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_TPL2_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_TPL3_ERR_STAT_REG register address.
*/
#if (defined PHY_665A_EVH_TPL3_ERR_STAT_REG_ADDRESS)
#error PHY_665A_EVH_TPL3_ERR_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_TPL3_ERR_STAT_REG_ADDRESS                      0x37

/*
 * Macro used for defining default value of EVH_TPL3_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_TPL3_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_TPL3_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_TPL3_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining EVH_ACC_ERR_REG register address.
*/
#if (defined PHY_665A_EVH_ACC_ERR_REG_ADDRESS)
#error PHY_665A_EVH_ACC_ERR_REG_ADDRESS is already defined
#endif
#define PHY_665A_EVH_ACC_ERR_REG_ADDRESS                            0x38

/*
 * Macro used for defining default value of EVH_ACC_ERR_STAT_REG register.
*/
#if (defined PHY_665A_EVH_ACC_ERR_STAT_REG_DEFAULT)
#error PHY_665A_EVH_ACC_ERR_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_EVH_ACC_ERR_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining SCHED_CMD_REG register address.
*/
#if (defined PHY_665A_SCHED_CMD_REG_ADDRESS)
#error PHY_665A_SCHED_CMD_REG_ADDRESS is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_ADDRESS                              0x040U

/*
 * Macro used for defining default value of SCHED_CMD_REG register.
*/
#if (defined PHY_665A_SCHED_CMD_REG_DEFAULT)
#error PHY_665A_SCHED_CMD_REG_DEFAULT is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_DEFAULT                 0x0000

/*
 * Macro for offset for parameter EVENT in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_CMD_REG_EVENT_OFFSET)
#error PHY_665A_SCHED_CMD_REG_EVENT_OFFSET is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_EVENT_OFFSET                         0x0C

/*
 * Macro for length for parameter EVENT in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_CMD_REG_EVENT_LEN)
#error PHY_665A_SCHED_CMD_REG_EVENT_LEN is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_EVENT_LEN                            0x02

/*
 * Macro for mask for parameter EVENT in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_CMD_REG_EVENT_MASK)
#error PHY_665A_SCHED_CMD_REG_EVENT_MASK is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_EVENT_MASK                           0x03

/*
 * Macro for offset for parameter OPERAND in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_CMD_REG_OPERAND_OFFSET)
#error PHY_665A_SCHED_CMD_REG_OPERAND_OFFSET is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_OPERAND_OFFSET                       0x00

/*
 * Macro for length for parameter OPERAND in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_CMD_REG_OPERAND_LEN)
#error PHY_665A_SCHED_CMD_REG_OPERAND_LEN is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_OPERAND_LEN                          0x06

/*
 * Macro for mask for parameter OPERAND in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_CMD_REG_OPERAND_MASK)
#error PHY_665A_SCHED_CMD_REG_OPERAND_MASK is already defined
#endif
#define PHY_665A_SCHED_CMD_REG_OPERAND_MASK                         0x3F

/*
 * Macro for defining Low Level OPERAND in SCHED_CMD_REG register for SYNC Event.
*/
#if (defined PHY_665A_SCHED_CMD_SYNC_LOW_LEVEL_OPERAND)
#error PHY_665A_SCHED_CMD_SYNC_LOW_LEVEL_OPERAND is already defined
#endif
#define PHY_665A_SCHED_CMD_SYNC_LOW_LEVEL_OPERAND                       0x00

/*
 * Macro for defining High Level OPERAND in SCHED_CMD_REG register for SYNC Event.
*/
#if (defined PHY_665A_SCHED_CMD_SYNC_HIGH_LEVEL_OPERAND)
#error PHY_665A_SCHED_CMD_SYNC_HIGH_LEVEL_OPERAND is already defined
#endif
#define PHY_665A_SCHED_CMD_SYNC_HIGH_LEVEL_OPERAND                      0x01

/*
 * Macro for defining Falling Edge OPERAND in SCHED_CMD_REG register for SYNC Event.
*/
#if (defined PHY_665A_SCHED_CMD_SYNC_FALLING_EDGE_OPERAND)
#error PHY_665A_SCHED_CMD_SYNC_FALLING_EDGE_OPERAND is already defined
#endif
#define PHY_665A_SCHED_CMD_SYNC_FALLING_EDGE_OPERAND                    0x02

/*
 * Macro for defining Rising Edge OPERAND in SCHED_CMD_REG register for SYNC Event.
*/
#if (defined PHY_665A_SCHED_CMD_SYNC_RISING_EDGE_OPERAND)
#error PHY_665A_SCHED_CMD_SYNC_RISING_EDGE_OPERAND is already defined
#endif
#define PHY_665A_SCHED_CMD_SYNC_RISING_EDGE_OPERAND                     0x03U

/*
 * Macro for defining Command OPERAND in SCHED_CMD_REG register for SYNC Event.
*/
#if (defined PHY_665A_SCHED_CMD_SYNC_COMMAND_OPERAND)
#error PHY_665A_SCHED_CMD_SYNC_COMMAND_OPERAND is already defined
#endif
#define PHY_665A_SCHED_CMD_SYNC_COMMAND_OPERAND                          0x04U

/*
 * Macro used for defining SCHED_EVENT_REG register address.
*/
#if (defined PHY_665A_SCHED_EVENT_REG_ADDRESS)
#error PHY_665A_SCHED_EVENT_REG_ADDRESS is already defined
#endif
#define PHY_665A_SCHED_EVENT_REG_ADDRESS                   0x041U

/*
 * Macro used for defining default value of SCHED_EVENT_REG register.
*/
#if (defined PHY_665A_SCHED_EVENT_REG_DEFAULT)
#error PHY_665A_SCHED_EVENT_REG_DEFAULT is already defined
#endif
#define PHY_665A_SCHED_EVENT_REG_DEFAULT                 0x0000

/*
 * Macro for offset for parameter SYNC in SCHED_EVENT_REG register .
*/
#if (defined PHY_665A_SCHED_EVENT_REG_SYNC_OFFSET)
#error PHY_665A_SCHED_EVENT_REG_SYNC_OFFSET is already defined
#endif
#define PHY_665A_SCHED_EVENT_REG_SYNC_OFFSET                    0x00

/*
 * Macro for length for parameter SYNC in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_EVENT_REG_SYNC_LEN)
#error PHY_665A_SCHED_EVENT_REG_SYNC_LEN is already defined
#endif
#define PHY_665A_SCHED_EVENT_REG_SYNC_LEN                       0x01

/*
 * Macro for mask for parameter SYNC in SCHED_CMD_REG register .
*/
#if (defined PHY_665A_SCHED_EVENT_REG_SYNC_MASK)
#error PHY_665A_SCHED_EVENT_REG_SYNC_MASK is already defined
#endif
#define PHY_665A_SCHED_EVENT_REG_SYNC_MASK                      0x01
/*
 * Macro used for defining NO_EVENT value of SYNC bit field of SCHED_EVENT_REG register.
*/
#if (defined PHY_665A_SCHED_EVENT_REG_SYNC_NO_EVENT)
#error PHY_665A_SCHED_EVENT_REG_SYNC_NO_EVENT is already defined
#endif
#define PHY_665A_SCHED_EVENT_REG_SYNC_NO_EVENT                 0x00


/*
 * Macro used for defining EVENT value of SYNC bit field of SCHED_EVENT_REG register.
*/
#if (defined PHY_665A_SCHED_EVENT_REG_SYNC_EVENT)
#error PHY_665A_SCHED_EVENT_REG_SYNC_EVENT is already defined
#endif
#define PHY_665A_SCHED_EVENT_REG_SYNC_EVENT                 0x01U


/*
 * Macro used for defining SCHED_STAT_REG register address.
*/
#if (defined PHY_665A_SCHED_STAT_REG_ADDRESS)
#error PHY_665A_SCHED_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_SCHED_STAT_REG_ADDRESS                    0x042

/*
 * Macro used for defining default value of SCHED_STAT_REG register.
*/
#if (defined PHY_665A_SCHED_STAT_REG_DEFAULT)
#error PHY_665A_SCHED_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_SCHED_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining GPIO_CFG0_REG register address.
*/
#if (defined PHY_665A_GPIO_CFG0_REG_ADDRESS)
#error PHY_665A_GPIO_CFG0_REG_ADDRESS is already defined
#endif
#define PHY_665A_GPIO_CFG0_REG_ADDRESS                     0x50U

/*
 * Macro used for defining default value of GPIO_CFG0_REG register.
*/
#if (defined PHY_665A_GPIO_CFG0_REG_DEFAULT)
#error PHY_665A_GPIO_CFG0_REG_DEFAULT is already defined
#endif
#define PHY_665A_GPIO_CFG0_REG_DEFAULT                 0x0000

/*
 * Macro used for defining GPIO_CFG1_REG register address.
*/
#if (defined PHY_665A_GPIO_CFG1_REG_ADDRESS)
#error PHY_665A_GPIO_CFG1_REG_ADDRESS is already defined
#endif
#define PHY_665A_GPIO_CFG1_REG_ADDRESS                     0x51U

/*
 * Macro used for defining default value of GPIO_CFG1_REG register.
*/
#if (defined PHY_665A_GPIO_CFG1_REG_DEFAULT)
#error PHY_665A_GPIO_CFG1_REG_DEFAULT is already defined
#endif
#define PHY_665A_GPIO_CFG1_REG_DEFAULT                 0xFF00

/*
 * Macro used for defining GPIO_OUT_REG register address.
*/
#if (defined PHY_665A_GPIO_OUT_REG_ADDRESS)
#error PHY_665A_GPIO_OUT_REG_ADDRESS is already defined
#endif
#define PHY_665A_GPIO_OUT_REG_ADDRESS                      0x52U

/*
 * Macro used for defining default value of GPIO_OUT_REG register.
*/
#if (defined PHY_665A_GPIO_OUT_REG_DEFAULT)
#error PHY_665A_GPIO_OUT_REG_DEFAULT is already defined
#endif
#define PHY_665A_GPIO_OUT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining GPIO_IN_REG register address.
*/
#if (defined PHY_665A_GPIO_IN_REG_ADDRESS)
#error PHY_665A_GPIO_IN_REG_ADDRESS is already defined
#endif
#define PHY_665A_GPIO_IN_REG_ADDRESS                       0x54U

/*
 * Macro used for defining default value of GPIO_IN_REG register.
*/
#if (defined PHY_665A_GPIO_IN_REG_DEFAULT)
#error PHY_665A_GPIO_IN_REG_DEFAULT is already defined
#endif
#define PHY_665A_GPIO_IN_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_CFG_REG register address.
*/
#if (defined PHY_665A_I2C_CFG_REG_ADDRESS)
#error PHY_665A_I2C_CFG_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_CFG_REG_ADDRESS                       0x60

/*
 * Macro used for defining default value of I2C_CFG_REG register.
*/
#if (defined PHY_665A_I2C_CFG_REG_DEFAULT)
#error PHY_665A_I2C_CFG_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_CFG_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_CTRL_REG register address.
*/
#if (defined PHY_665A_I2C_CTRL_REG_ADDRESS)
#error PHY_665A_I2C_CTRL_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_CTRL_REG_ADDRESS                      0x61

/*
 * Macro used for defining default value of I2C_CTRL_REG register.
*/
#if (defined PHY_665A_I2C_CTRL_REG_DEFAULT)
#error PHY_665A_I2C_CTRL_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_CTRL_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_STAT_REG register address.
*/
#if (defined PHY_665A_I2C_STAT_REG_ADDRESS)
#error PHY_665A_I2C_STAT_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_STAT_REG_ADDRESS                      0x62

/*
 * Macro used for defining default value of I2C_STAT_REG register.
*/
#if (defined PHY_665A_I2C_STAT_REG_DEFAULT)
#error PHY_665A_I2C_STAT_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_STAT_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_DATA0_REG register address.
*/
#if (defined PHY_665A_I2C_DATA0_REG_ADDRESS)
#error PHY_665A_I2C_DATA0_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_DATA0_REG_ADDRESS                     0x64

/*
 * Macro used for defining default value of I2C_DATA0_REG register.
*/
#if (defined PHY_665A_I2C_DATA0_REG_DEFAULT)
#error PHY_665A_I2C_DATA0_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_DATA0_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_DATA1_REG register address.
*/
#if (defined PHY_665A_I2C_DATA1_REG_ADDRESS)
#error PHY_665A_I2C_DATA1_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_DATA1_REG_ADDRESS                     0x65

/*
 * Macro used for defining default value of I2C_DATA1_REG register.
*/
#if (defined PHY_665A_I2C_DATA1_REG_DEFAULT)
#error PHY_665A_I2C_DATA1_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_DATA1_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_DATA2_REG register address.
*/
#if (defined PHY_665A_I2C_DATA2_REG_ADDRESS)
#error PHY_665A_I2C_DATA2_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_DATA2_REG_ADDRESS                     0x66

/*
 * Macro used for defining default value of I2C_DATA2_REG register.
*/
#if (defined PHY_665A_I2C_DATA2_REG_DEFAULT)
#error PHY_665A_I2C_DATA2_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_DATA2_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_DATA3_REG register address.
*/
#if (defined PHY_665A_I2C_DATA3_REG_ADDRESS)
#error PHY_665A_I2C_DATA3_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_DATA3_REG_ADDRESS                     0x67

/*
 * Macro used for defining default value of I2C_DATA3_REG register.
*/
#if (defined PHY_665A_I2C_DATA3_REG_DEFAULT)
#error PHY_665A_I2C_DATA3_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_DATA3_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_DATA4_REG register address.
*/
#if (defined PHY_665A_I2C_DATA4_REG_ADDRESS)
#error PHY_665A_I2C_DATA4_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_DATA4_REG_ADDRESS                     0x68

/*
 * Macro used for defining default value of I2C_DATA4_REG register.
*/
#if (defined PHY_665A_I2C_DATA4_REG_DEFAULT)
#error PHY_665A_I2C_DATA4_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_DATA4_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_DATA5_REG register address.
*/
#if (defined PHY_665A_I2C_DATA5_REG_ADDRESS)
#error PHY_665A_I2C_DATA5_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_DATA5_REG_ADDRESS                     0x69

/*
 * Macro used for defining default value of I2C_DATA5_REG register.
*/
#if (defined PHY_665A_I2C_DATA5_REG_DEFAULT)
#error PHY_665A_I2C_DATA5_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_DATA5_REG_DEFAULT                 0x0000

/*
 * Macro used for defining I2C_DATA6_REG register address.
*/
#if (defined PHY_665A_I2C_DATA6_REG_ADDRESS)
#error PHY_665A_I2C_DATA6_REG_ADDRESS is already defined
#endif
#define PHY_665A_I2C_DATA6_REG_ADDRESS                     0x6A

/*
 * Macro used for defining default value of I2C_DATA5_REG register.
*/
#if (defined PHY_665A_I2C_DATA6_REG_DEFAULT)
#error PHY_665A_I2C_DATA6_REG_DEFAULT is already defined
#endif
#define PHY_665A_I2C_DATA6_REG_DEFAULT                 0x0000

/*
 * Macro used for defining default value of Can Trcv Low configuration register.
*/
#if (defined PHY_665A_TDCCR_L_ADDRESS)
#error PHY_665A_TDCCR_L_ADDRESS is already defined
#endif
#define PHY_665A_TDCCR_L_ADDRESS                     0x0074U

/*
 * Macro used for defining default value of Can Trcv Low configuration register setting Value.
*/
#if (defined PHY_665A_TDCCR_L_SETTING_VAL)
#error PHY_665A_TDCCR_L_SETTING_VAL is already defined
#endif
#define PHY_665A_TDCCR_L_SETTING_VAL                 0x0005U

/*
 * Macro used for defining default value of Can Trcv High configuration register.
*/
#if (defined PHY_665A_TDCCR_H_ADDRESS)
#error PHY_665A_TDCCR_H_ADDRESS is already defined
#endif
#define PHY_665A_TDCCR_H_ADDRESS                     0x0075U

/*
 * Macro used for defining default value of Can Trcv High configuration register setting Value.
*/
#if (defined PHY_665A_TDCCR_H_SETTING_VAL)
#error PHY_665A_TDCCR_H_SETTING_VAL is already defined
#endif
#define PHY_665A_TDCCR_H_SETTING_VAL                 0x8000U

/*
 * Macro used for defining HOLD_CMD_REG register address.
*/
#if (defined PHY_665A_HOLD_CMD_REG_ADDRESS)
#error PHY_665A_HOLD_CMD_REG_ADDRESS is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_ADDRESS                               0x007FU/*MAX REG ADDR, to be not used for Actual HW register*/

/*
 * Macro for offset for parameter TIMING OPERAND in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_OFFSET)
#error PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_OFFSET is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_OFFSET                         0x00

/*
 * Macro for length for parameter TIMING OPERAND in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_LEN)
#error PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_LEN is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_LEN                            0x0E

/*
 * Macro for mask for parameter TIMING OPERAND in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MASK)
#error PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MASK is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MASK                           0x7FFFU

/*
 * Macro for maximum value for parameter TIMING OPERAND in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MAX)
#error PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MAX is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MAX                            0x7FFFU

/*
 * Macro for minimum value for parameter TIMING OPERAND in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MIN)
#error PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MIN is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MIN                            0x0001U

/*
 * Macro for maximum value for parameter TIMING OPERAND in microsecond in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MAX_US)
#error PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MAX_US is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MAX_US                             0x31FF9CU

/*
 * Macro for minimum value for parameter TIMING OPERAND in microsecond in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MIN_US)
#error PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MIN_US is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_TIMING_OPERAND_MIN_US                             100UL

/*
 * Macro for offset for parameter HOLD TRIGGER STATE in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_OFFSET)
#error PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_OFFSET is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_OFFSET                         0x0FU

/*
 * Macro for length for parameter HOLD TRIGGER STATE in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_LEN)
#error PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_LEN is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_LEN                            0x01U

/*
 * Macro for mask for parameter HOLD TRIGGER STATE in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_MASK)
#error PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_MASK is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_STATE_MASK                           0x01U

/*
 * Macro for set value of field HOLD TRIGGER STATE in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_SET)
#error PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_SET is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_SET                          0x01U

/*
 * Macro for reset value of field HOLD TRIGGER STATE in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_NOT_SET)
#error PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_NOT_SET is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_HOLD_TRIGGER_NOT_SET                          0x00U

/*
 * Macro for offset for parameter RESERVED  in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_RESERVED_OFFSET)
#error PHY_665A_HOLD_CMD_REG_RESERVED_OFFSET is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_RESERVED_OFFSET                           0x0FU

/*
 * Macro for length for parameter RESERVED in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_RESERVED_LEN)
#error PHY_665A_HOLD_CMD_REG_RESERVED_LEN is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_RESERVED_LEN                              0x01U

/*
 * Macro for mask for parameter RESERVED in HOLD_CMD_REG register .
*/
#if (defined PHY_665A_HOLD_CMD_REG_RESERVED_MASK)
#error PHY_665A_HOLD_CMD_REG_RESERVED_MASK is already defined
#endif
#define PHY_665A_HOLD_CMD_REG_RESERVED_MASK                             0x01U

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*
 * A structure type  to hold the information about  each bitfield for register SYS_CFG_CRC_REG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16 SYS_CRC:16;

}PHY_665A_SYS_CFG_CRC_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_CFG_CRC_REG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_CFG_CRC_REG_BitType SYS_CFG_CRC_REG_Bits;

}PHY_665A_SYS_CFG_CRC_REG_Type;

/*SYS_COM_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_COM_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16 DADD:6;
    uint16 CADD:7;
    uint16 reserved:7;

}PHY_665A_SYS_COM_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_COM_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_COM_CFG_REG_BitType SYS_COM_CFG_REG_Bits;

}PHY_665A_SYS_COM_CFG_REG_Type;

/*SYS_COM_TO_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_COM_TO_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16 COMTO:8;
    uint16 COMTOMODE:8;

}PHY_665A_SYS_COM_TO_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_COM_TO_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_COM_TO_CFG_REG_BitType SYS_COM_TO_CFG_REG_Bits;

}PHY_665A_SYS_COM_TO_CFG_REG_Type;

/*SYS_MODE*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_MODE.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16 TARGETMODE:5;
    uint16 reserved:11;

}PHY_665A_SYS_MODE_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_MODE register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_MODE_REG_BitType SYS_MODE_REG_Bits;

}PHY_665A_SYS_MODE_REG_Type;

/*SYS_PORTx_CFG*/
/*
 * A structure type to hold the information about  each bitfield for registers SYS_PORTx_CFG. The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16 EN:1;
    uint16 RX:1;
    uint16 reserved1:1;
    uint16 ALLCHAINS:1;
    uint16 reserved2:1;
    uint16 PROTOCOL:1;
    uint16 MADD:1;
    uint16 CADD:3;
    uint16 TIMEOUT:6;

}PHY_665A_SYS_PORTx_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_PORT0_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_PORTx_CFG_REG_BitType SYS_PORTx_CFG_REG_Bits;

}PHY_665A_SYS_PORTx_CFG_REG_Type;

/*SYS_HOST_COM_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_HOST_COM_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  PREFIX:1;
    uint16  PADDING:3;
    uint16  PINGPONG:1;
    uint16  RSPHOLD:1;
    uint16  RSPHOLDLVL:1;
    uint16  IGNORECRC:1;
    uint16  RSPTIME:8;

}PHY_665A_SYS_HOST_COM_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_PORT1_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_HOST_COM_CFG_REG_BitType SYS_HOST_COM_CFG_REG_Bits;

}PHY_665A_SYS_HOST_COM_CFG_REG_Type;

/*SYS_SPI_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_SPI_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  RSPMST:1;
    uint16  CHKRDEMPTY:1;
    uint16  INTO:1;
    uint16  FULLCYC:1;
    uint16  reserved:4;
    uint16  RSPSPIDIV:8;

}PHY_665A_SYS_SPI_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_PORT1_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_SPI_CFG_REG_BitType SYS_SPI_CFG_REG_Bits;

}PHY_665A_SYS_SPI_CFG_REG_Type;



/*SYS_FLT_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_FLT_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  CHECKCRC0:1;
    uint16  CHECKUNEXP0:1;
    uint16  RMINVCRC0:1;
    uint16  RMUNEXP0:1;
    uint16  CHECKCRC1:1;
    uint16  CHECKUNEXP1:1;
    uint16  RMINVCRC1:1;
    uint16  RMUNEXP1:1;
    uint16  CHECKCRC2:1;
    uint16  CHECKUNEXP2:1;
    uint16  RMINVCRC2:1;
    uint16  RMUNEXP2:1;
    uint16  CHECKCRC3:1;
    uint16  CHECKUNEXP3:1;
    uint16  RMINVCRC3:1;
    uint16  RMUNEXP3:1;

}PHY_665A_SYS_FLT_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_PORT1_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_FLT_CFG_REG_BitType PHY_665A_SYS_FLT_CFG_REG_Bits;

}PHY_665A_SYS_FLT_CFG_REG_Type;

/*SYS_QUEUE_SIZE*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_QUEUE_SIZE.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  REQ:5;
    uint16  RESERVED:11;

}PHY_665A_SYS_QUEUE_SIZE_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_QUEUE_SIZE register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_QUEUE_SIZE_REG_BitType PHY_665A_SYS_QUEUE_SIZE_REG_Bits;

}PHY_665A_SYS_QUEUE_SIZE_REG_Type;

/*SYS_REQ_QUEUE_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_REQ_QUEUE_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  LOW:6;
    uint16  RESERVED2:2;
    uint16  HIGH:6;
    uint16  RESERVED1:2;

}PHY_665A_SYS_REQ_QUEUE_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_REQ_QUEUE_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_REQ_QUEUE_CFG_REG_BitType PHY_665A_SYS_REQ_QUEUE_CFG_REG_Bits;

}PHY_665A_SYS_REQ_QUEUE_CFG_REG_Type;

/*SYS_RESP_QUEUE_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_RESP_QUEUE_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  LOW:6;
    uint16  RESERVED2:2;
    uint16  HIGH:6;
    uint16  RESERVED1:2;

}PHY_665A_SYS_RESP_QUEUE_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_RESP_QUEUE_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_RESP_QUEUE_CFG_REG_BitType PHY_665A_SYS_RESP_QUEUE_CFG_REG_Bits;

}PHY_665A_SYS_RESP_QUEUE_CFG_REG_Type;


/*SYS_CAN_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_CAN_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  CANDATSPD:3;
    uint16  RSPPROT:1;
    uint16  RESERVED:12;

}PHY_665A_SYS_CAN_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_CAN_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_CAN_CFG_REG_BitType SYS_CAN_CFG_REG_Bits;

}PHY_665A_SYS_CAN_CFG_REG_Type;

/*SYS_UART_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_UART_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BAUDRATEDIV:12;
    uint16  RESYNCTO:4;

}PHY_665A_SYS_UART_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_UART_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_UART_CFG_REG_BitType SYS_UART_CFG_REG_Bits;

}PHY_665A_SYS_UART_CFG_REG_Type;

/*SYS_VERSION*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_VERSION.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  MREV:4;
    uint16  FREV:4;
    uint16  TYPE:8;

}PHY_665A_SYS_VERSION_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_VERSION register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_VERSION_REG_BitType SYS_VERSION_REG_Bits;

}PHY_665A_SYS_VERSION_REG_Type;

/*SYS_PROD_VER*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_PROD_VER.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  PATCH:4;
    uint16  MINOR:4;
    uint16  MAJOR:4;
    uint16  reserved:4;

}PHY_665A_SYS_PROD_VER_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_PROD_VER register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_PROD_VER_REG_BitType SYS_PROD_VER_REG_Bits;

}PHY_665A_SYS_PROD_VER_REG_Type;

/*SYS_QUEUE_CTRL*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_QUEUE_CTRL.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  HOLD:1;
    uint16  CLEAR:1;
    uint16  reserved:14;

}PHY_665A_SYS_QUEUE_CTRL_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_QUEUE_CTRL register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_QUEUE_CTRL_REG_BitType SYS_QUEUE_CTRL_REG_Bits;

}PHY_665A_SYS_QUEUE_CTRL_REG_Type;

/*SYS_QUEUE_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_QUEUE_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  REQ:6;
    uint16  reserved1:2;
    uint16  RSP:6;
    uint16  reserved2:2;

}PHY_665A_SYS_QUEUE_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_QUEUE_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_QUEUE_STAT_REG_BitType SYS_QUEUE_STAT_REG_Bits;

}PHY_665A_SYS_QUEUE_STAT_REG_Type;

/*SYS_UID_LOW*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_UID_LOW.The bit fields are used for storing and access
 * the register data information.
*/

typedef struct
{
    uint16  LOW:16;

}PHY_665A_SYS_UID_LOW_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_UID_LOW register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_UID_LOW_REG_BitType SYS_UID_LOW_REG_Bits;

}PHY_665A_SYS_UID_LOW_REG_Type;

/*SYS_UID_MID*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_UID_MID.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  MID:16;

}PHY_665A_SYS_UID_MID_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_UID_MID register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_UID_MID_REG_BitType SYS_UID_MID_REG_Bits;

}PHY_665A_SYS_UID_MID_REG_Type;

/*SYS_UID_HIGH*/
/*
 * A structure type  to hold the information about  each bitfield for register SYS_UID_HIGH.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  HIGH:16;

}PHY_665A_SYS_UID_HIGH_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SYS_UID_HIGH register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SYS_UID_HIGH_REG_BitType SYS_UID_HIGH_REG_Bits;

}PHY_665A_SYS_UID_HIGH_REG_Type;

/*EVH_CFG_CRC*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_CFG_CRC.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  EVH_CRC:16;

}PHY_665A_EVH_CFG_CRC_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_CFG_CRC register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_CFG_CRC_REG_BitType EVH_CFG_CRC_REG_Bits;

}PHY_665A_EVH_CFG_CRC_REG_Type;

/*EVH_INT0_SEL*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_INT0_SEL.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  REQQUEUELOW:1;
    uint16  REQQUEUEHIGH:1;
    uint16  RSPQUEUELOW:1;
    uint16  RSPQUEUEHIGH:1;
    uint16  REQQUEUENOTLOW:1;
    uint16  REQQUEUENOTHIGH:1;
    uint16  RSPQUEUENOTLOW:1;
    uint16  RSPQUEUENOTHIGH:1;
    uint16  GENERALERR:1;
    uint16  MCUIFERR:1;
    uint16  TPL0ERR:1;
    uint16  TPL1ERR:1;
    uint16  TPL2ERR:1;
    uint16  TPL3ERR:1;
    uint16  WAKE:1;
    uint16  reserved:1;

}PHY_665A_EVH_INT_SEL_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_INT0_SEL register.
*/

typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_INT_SEL_REG_BitType EVH_INTN_SEL_REG_Bits;

}PHY_665A_EVH_INT_SEL_REG_Type;

/*EVH_INT0_OUT_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_INT0_OUT_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  ENABLE:1;
    uint16  ACTIVELVL:1;
    uint16  PULSE:2;
    uint16  MAXACT:8;
    uint16  reserved:4;

}PHY_665A_EVH_INT0_OUT_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_INT0_OUT_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_INT0_OUT_CFG_REG_BitType EVH_INT0_OUT_CFG_REG_Bits;

}PHY_665A_EVH_INT0_OUT_CFG_REG_Type;

/*EVH_INT1_OUT_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_INT1_OUT_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  ENABLE:1;
    uint16  ACTIVELVL:1;
    uint16  PULSE:2;
    uint16  MAXACT:8;
    uint16  reserved:4;

}PHY_665A_EVH_INT1_OUT_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_INT1_OUT_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_INT1_OUT_CFG_REG_BitType EVH_INT1_OUT_CFG_REG_Bits;

}PHY_665A_EVH_INT1_OUT_CFG_REG_Type;

/*EVH_INT2_OUT_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_INT2_OUT_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  ENABLE:1;
    uint16  ACTIVELVL:1;
    uint16  PULSE:2;
    uint16  MAXACT:8;
    uint16  reserved:4;

}PHY_665A_EVH_INT2_OUT_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_INT2_OUT_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_INT2_OUT_CFG_REG_BitType EVH_INT2_OUT_CFG_REG_Bits;

}PHY_665A_EVH_INT2_OUT_CFG_REG_Type;

/*EVH_INT3_OUT_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_INT3_OUT_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  ENABLE:1;
    uint16  ACTIVELVL:1;
    uint16  PULSE:2;
    uint16  MAXACT:8;
    uint16  reserved:4;

}PHY_665A_EVH_INT3_OUT_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_INT3_OUT_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_INT3_OUT_CFG_REG_BitType EVH_INT3_OUT_CFG_REG_Bits;

}PHY_665A_EVH_INT3_OUT_CFG_REG_Type;

/*EVH_WAKEUP_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_WAKEUP_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  PORT0:1;
    uint16  PORT1:1;
    uint16  PORT2:1;
    uint16  PORT3:1;
    uint16  WAKEIN:1;
    uint16  reserved:1;
    uint16  WAKEUPMSG:1;

}PHY_665A_EVH_WAKEUP_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_WAKEUP_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_WAKEUP_CFG_REG_BitType EVH_WAKEUP_CFG_REG_Bits;

}PHY_665A_EVH_WAKEUP_CFG_REG_Type;

/*EVH_WAKEUP_REASON*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_WAKEUP_REASON.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  PORT0:1;
    uint16  PORT1:1;
    uint16  PORT2:1;
    uint16  PORT3:1;
    uint16  WAKEIN:1;
    uint16  SDATREQRXD:1;
    uint16  CSNREQ:1;
    uint16  reserved:9;

}PHY_665A_EVH_WAKEUP_REASON_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_WAKEUP_REASON register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_WAKEUP_REASON_REG_BitType EVH_WAKEUP_REASON_REG_Bits;

}PHY_665A_EVH_WAKEUP_REASON_REG_Type;

/*EVH_RST_REASON*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_RST_REASON.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  SOURCE:10;
    uint16  reserved:6;

}PHY_665A_EVH_RST_REASON_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_RST_REASON register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_RST_REASON_REG_BitType EVH_RST_REASON_REG_Bits;

}PHY_665A_EVH_RST_REASON_REG_Type;

/*EVH_QUEUE_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_QUEUE_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  REQQUEUELOW:1;
    uint16  REQQUEUEHIGH:1;
    uint16  RSPQUEUELOW:1;
    uint16  RSPQUEUEHIGH:1;
    uint16  reserved:12;

}PHY_665A_EVH_QUEUE_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_QUEUE_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_QUEUE_STAT_REG_BitType EVH_QUEUE_STAT_REG_Bits;

}PHY_665A_EVH_QUEUE_STAT_REG_Type;

/*EVH_GRP_ERR_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_GRP_ERR_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  GENERALERR:1;
    uint16  MCUIFERR:1;
    uint16  TPL0ERR:1;
    uint16  TPL1ERR:1;
    uint16  TPL2ERR:1;
    uint16  TPL3ERR:1;
    uint16  reserved:10;

}PHY_665A_EVH_GRP_ERR_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_GRP_ERR_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_GRP_ERR_STAT_REG_BitType EVH_GRP_ERR_STAT_REG_Bits;

}PHY_665A_EVH_GRP_ERR_STAT_REG_Type;

/*EVH_GENERAL_ERR_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_GENERAL_ERR_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  REQOVERRUN:1;
    uint16  RSPOVERRUN:1;
    uint16  VBATOV:1;
    uint16  VBATUV:1;
    uint16  VDDCUV:1;
    uint16  VDDDOV:1;
    uint16  VDDDUV:1;
    uint16  VDDIOUV:1;
    uint16  ACCESSERR:1;
    uint16  reserved:7;

}PHY_665A_EVH_GENERAL_ERR_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_GENERAL_ERR_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_GENERAL_ERR_STAT_REG_BitType EVH_GENERAL_ERR_STAT_REG_Bits;

}PHY_665A_EVH_GENERAL_ERR_STAT_REG_Type;

/*EVH_MCUIF_ERR*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_MCUIF_ERR.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  FRAMEERR:1;
    uint16  CRCERR:1;
    uint16  INVALID:1;
    uint16  CANTXACTERR:1;
    uint16  CANTXPASERR:1;
    uint16  CANTXBOFFERR:1;
    uint16  CANRXACTERR:1;
    uint16  CANRXPASERR:1;
    uint16  PREFIXERR:1;
    uint16  READONEMPTY:1;
    uint16  WRONGRSPSIZE:1;
    uint16  WRONGMSG:1;
    uint16  reserved:4;

}PHY_665A_EVH_MCUIF_ERR_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_MCUIF_ERR register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_MCUIF_ERR_STAT_REG_BitType EVH_MCUIF_ERR_STAT_REG_Bits;

}PHY_665A_EVH_MCUIF_ERR_STAT_REG_Type;

/*EVH_TPL0_ERR_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_TPL0_ERR_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  FRAMEERR:1;
    uint16  CRCERR:1;
    uint16  RSPTO:1;
    uint16  UNEXPECTED:1;
    uint16  reserved:12;

}PHY_665A_EVH_TPL0_ERR_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_TPL0_ERR_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_TPL0_ERR_STAT_REG_BitType EVH_TPL0_ERR_STAT_REG_Bits;

}PHY_665A_EVH_TPL0_ERR_STAT_REG_Type;

/*EVH_TPL1_ERR_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_TPL1_ERR_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  FRAMEERR:1;
    uint16  CRCERR:1;
    uint16  RSPTO:1;
    uint16  UNEXPECTED:1;
    uint16  reserved:12;

}PHY_665A_EVH_TPL1_ERR_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_TPL1_ERR_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_TPL1_ERR_STAT_REG_BitType EVH_TPL1_ERR_STAT_REG_Bits;

}PHY_665A_EVH_TPL1_ERR_STAT_REG_Type;

/*EVH_TPL2_ERR_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_TPL2_ERR_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  FRAMEERR:1;
    uint16  CRCERR:1;
    uint16  RSPTO:1;
    uint16  UNEXPECTED:1;
    uint16  reserved:12;

}PHY_665A_EVH_TPL2_ERR_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_TPL2_ERR_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_TPL2_ERR_STAT_REG_BitType EVH_TPL2_ERR_STAT_REG_Bits;

}PHY_665A_EVH_TPL2_ERR_STAT_REG_Type;

/*EVH_TPL3_ERR_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_TPL3_ERR_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  FRAMEERR:1;
    uint16  CRCERR:1;
    uint16  RSPTO:1;
    uint16  UNEXPECTED:1;
    uint16  reserved:12;

}PHY_665A_EVH_TPL3_ERR_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_TPL3_ERR_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_TPL3_ERR_STAT_REG_BitType EVH_TPL3_ERR_STAT_REG_Bits;

}PHY_665A_EVH_TPL3_ERR_STAT_REG_Type;

/*EVH_ACC_ERR*/
/*
 * A structure type  to hold the information about  each bitfield for register EVH_ACC_ERR.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  ERRADD:14;
    uint16  ERRACC:1;
    uint16  ERRSTAT:1;

}PHY_665A_EVH_ACC_ERR_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of EVH_ACC_ERR register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_EVH_ACC_ERR_REG_BitType EVH_ACC_ERR_REG_Bits;

}PHY_665A_EVH_ACC_ERR_REG_Type;

/*SCHED_CMD*/
/*
 * A structure type  to hold the information about  each bitfield for register SCHED_CMD.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  OPERAND:6;
    uint16  reserved1:6;
    uint16  EVENT:2;
    uint16  reserved2:2;

}PHY_665A_SCHED_CMD_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SCHED_CMD register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SCHED_CMD_REG_BitType SCHED_CMD_REG_Bits;

}PHY_665A_SCHED_CMD_REG_Type;

/*SCHED_EVENT*/
/*
 * A structure type  to hold the information about  each bitfield for register SCHED_EVENT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  SYNC:1;
    uint16  reserved:15;

}PHY_665A_SCHED_EVENT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SCHED_EVENT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SCHED_EVENT_REG_BitType SCHED_EVENT_REG_Bits;

}PHY_665A_SCHED_EVENT_REG_Type;

/*SCHED_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register SCHED_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  PORT0:1;
    uint16  PORT1:1;
    uint16  PORT2:1;
    uint16  PORT3:1;
    uint16  ALLCHAIN:1;
    uint16  SYNCPIN:1;
    uint16  reserved:10;

}PHY_665A_SCHED_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of SCHED_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_SCHED_STAT_REG_BitType SCHED_STAT_REG_Bits;

}PHY_665A_SCHED_STAT_REG_Type;

/*GPIO_CFG0*/
/*
 * A structure type  to hold the information about  each bitfield for register GPIO_CFG0.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  INPEN0:1;
    uint16  INPEN1:1;
    uint16  INPEN2:1;
    uint16  INPEN3:1;
    uint16  INPEN4:1;
    uint16  INPEN5:1;
    uint16  INPEN6:1;
    uint16  INPEN7:1;
    uint16  OUTEN0:1;
    uint16  OUTEN1:1;
    uint16  OUTEN2:1;
    uint16  OUTEN3:1;
    uint16  OUTEN4:1;
    uint16  OUTEN5:1;
    uint16  OUTEN6:1;
    uint16  OUTEN7:1;

}PHY_665A_GPIO_CFG0_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of GPIO_CFG0 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_GPIO_CFG0_REG_BitType GPIO_CFG0_REG_Bits;

}PHY_665A_GPIO_CFG0_REG_Type;

/*GPIO_CFG1*/
/*
 * A structure type  to hold the information about  each bitfield for register GPIO_CFG1.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  ODEN0:1;
    uint16  ODEN1:1;
    uint16  ODEN2:1;
    uint16  ODEN3:1;
    uint16  ODEN4:1;
    uint16  ODEN5:1;
    uint16  ODEN6:1;
    uint16  ODEN7:1;
    uint16  PDEN0:1;
    uint16  PDEN1:1;
    uint16  PDEN2:1;
    uint16  PDEN3:1;
    uint16  PDEN4:1;
    uint16  PDEN5:1;
    uint16  PDEN6:1;
    uint16  PDEN7:1;

}PHY_665A_GPIO_CFG1_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of GPIO_CFG1 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_GPIO_CFG1_REG_BitType GPIO_CFG1_REG_Bits;

}PHY_665A_GPIO_CFG1_REG_Type;

/*GPIO_OUT*/
/*
 * A structure type  to hold the information about  each bitfield for register GPIO_OUT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  OUT0:1;
    uint16  OUT1:1;
    uint16  OUT2:1;
    uint16  OUT3:1;
    uint16  OUT4:1;
    uint16  OUT5:1;
    uint16  OUT6:1;
    uint16  OUT7:1;
    uint16  reserved:8;

}PHY_665A_GPIO_OUT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of GPIO_OUT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_GPIO_OUT_REG_BitType GPIO_OUT_REG_Bits;

}PHY_665A_GPIO_OUT_REG_Type;

/*GPIO_IN*/
/*
 * A structure type  to hold the information about  each bitfield for register GPIO_IN.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  IN0:1;
    uint16  IN1:1;
    uint16  IN2:1;
    uint16  IN3:1;
    uint16  IN4:1;
    uint16  IN5:1;
    uint16  IN6:1;
    uint16  IN7:1;
    uint16  HIGHDET0:1;
    uint16  HIGHDET1:1;
    uint16  HIGHDET2:1;
    uint16  HIGHDET3:1;
    uint16  HIGHDET4:1;
    uint16  HIGHDET5:1;
    uint16  HIGHDET6:1;
    uint16  HIGHDET7:1;

}PHY_665A_GPIO_IN_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of GPIO_IN register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_GPIO_IN_REG_BitType GPIO_IN_REG_Bits;

}PHY_665A_GPIO_IN_REG_Type;

/*I2C_CFG*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_CFG.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  EN:1;
    uint16  CLKSEL:1;
    uint16  reserved:14;

}PHY_665A_I2C_CFG_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_CFG register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_CFG_REG_BitType I2C_CFG_REG_Bits;

}PHY_665A_I2C_CFG_REG_Type;

/*I2C_CTRL*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_CTRL.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  START:4;
    uint16  STPAFTER:1;
    uint16  reserved1:3;
    uint16  RDAFTER:4;
    uint16  reserved2:4;

}PHY_665A_I2C_CTRL_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_CTRL register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_CTRL_REG_BitType I2C_CTRL_REG_Bits;

}PHY_665A_I2C_CTRL_REG_Type;

/*I2C_STAT*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_STAT.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  PENDING:1;
    uint16  ACTIVE:1;
    uint16  NACKRCV:1;
    uint16  ARBLOST:1;
    uint16  reserved1:4;
    uint16  LEN:4;
    uint16  reserved2:4;

}PHY_665A_I2C_STAT_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_STAT register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_STAT_REG_BitType I2C_STAT_REG_Bits;

}PHY_665A_I2C_STAT_REG_Type;

/*I2C_DATA0*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_DATA0.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BYTE0:8;
    uint16  BYTE1:8;

}PHY_665A_I2C_DATA0_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_DATA0 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_DATA0_REG_BitType I2C_DATA0_REG_Bits;

}PHY_665A_I2C_DATA0_REG_Type;

/*I2C_DATA1*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_DATA1.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BYTE2:8;
    uint16  BYTE3:8;

}PHY_665A_I2C_DATA1_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_DATA1 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_DATA1_REG_BitType I2C_DATA1_REG_Bits;

}PHY_665A_I2C_DATA1_REG_Type;

/*I2C_DATA2*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_DATA2.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BYTE4:8;
    uint16  BYTE5:8;

}PHY_665A_I2C_DATA2_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_DATA2 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_DATA2_REG_BitType I2C_DATA2_REG_Bits;

}PHY_665A_I2C_DATA2_REG_Type;

/*I2C_DATA3*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_DATA3.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BYTE6:8;
    uint16  BYTE7:8;

}PHY_665A_I2C_DATA3_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_DATA3 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_DATA3_REG_BitType I2C_DATA3_REG_Bits;

}PHY_665A_I2C_DATA3_REG_Type;

/*I2C_DATA4*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_DATA4.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BYTE8:8;
    uint16  BYTE9:8;

}PHY_665A_I2C_DATA4_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_DATA4 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_DATA4_REG_BitType I2C_DATA4_REG_Bits;

}PHY_665A_I2C_DATA4_REG_Type;

/*I2C_DATA5*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_DATA5.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BYTE10:8;
    uint16  BYTE11:8;

}PHY_665A_I2C_DATA5_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_DATA5 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_DATA5_REG_BitType I2C_DATA5_REG_Bits;

}PHY_665A_I2C_DATA5_REG_Type;

/*I2C_DATA6*/
/*
 * A structure type  to hold the information about  each bitfield for register I2C_DATA6.The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16  BYTE12:8;
    uint16  BYTE13:8;

}PHY_665A_I2C_DATA6_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of I2C_DATA6 register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_I2C_DATA6_REG_BitType I2C_DATA6_REG_Bits;

}PHY_665A_I2C_DATA6_REG_Type;

/*
 * A structure type  to hold the information about  each bitfield for register HOLD_CMD register .The bit fields are used for storing and access
 * the register data information.
*/
typedef struct
{
    uint16 TIMINGOPERAND:15;
    uint16 HOLDTYPE:1;
}PHY_665A_HOLD_CMD_REG_BitType;
/*
 * An union type  to access the value of bit fields or complete register value of HOLD_CMD register.
*/
typedef union
{
    uint16 unsigned_access;
    sint16 signed_access;
    PHY_665A_HOLD_CMD_REG_BitType HOLD_CMD_REG_Bits;

}PHY_665A_HOLD_CMD_REG_Type;




/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif

/** @} */


#endif /* CDD_PHY_665A_REGS_H */
