/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_INTCAN_H
#define CDD_PHY_665A_INTCAN_H

/**
*   @file CDD_Phy_665a_IntCan.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Phy_665a_Cfg.h"
#include "CDD_Bms_common_Cfg.h"
#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
#include "CDD_Phy_665a_CanIf.h"
#endif
#include "Gpt.h"
#include "CDD_Phy_665a_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_INTCAN_VENDOR_ID                    43
#define PHY_665A_INTCAN_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_INTCAN_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_INTCAN_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_INTCAN_SW_MAJOR_VERSION             1
#define PHY_665A_INTCAN_SW_MINOR_VERSION             0
#define PHY_665A_INTCAN_SW_PATCH_VERSION             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Gpt header file are of the same Autosar version */
    #if ((PHY_665A_INTCAN_AR_RELEASE_MAJOR_VERSION != GPT_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_INTCAN_AR_RELEASE_MINOR_VERSION != GPT_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_IntCan.h and Gpt.h are different"
    #endif

    /* Check if current file and Gpt header file are of the same Autosar version */
    #if ((PHY_665A_INTCAN_AR_RELEASE_MAJOR_VERSION != BMS_COMMON_AR_RELEASE_MAJOR_VERSION_CFG) || \
        (PHY_665A_INTCAN_AR_RELEASE_MINOR_VERSION != BMS_COMMON_AR_RELEASE_MINOR_VERSION_CFG))
    #error "AutoSar Version Numbers of CDD_Phy_665a_IntCan.h and Bms_common_Cfg.h are different"
    #endif
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same vendor */
#if (PHY_665A_INTCAN_VENDOR_ID != PHY_665A_VENDOR_ID_CFG)
#error "CDD_Phy_665a_IntCan.h and CDD_Phy_665a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Autosar version */
#if ((PHY_665A_INTCAN_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (PHY_665A_INTCAN_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (PHY_665A_INTCAN_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of CDD_Phy_665a_IntCan.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Software version */
#if ((PHY_665A_INTCAN_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_CFG) || \
     (PHY_665A_INTCAN_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_CFG) || \
     (PHY_665A_INTCAN_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of CDD_Phy_665a_IntCan.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_INTCAN_VENDOR_ID != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_IntCan.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_INTCAN_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_INTCAN_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_INTCAN_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_IntCan.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_INTCAN_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_INTCAN_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_INTCAN_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_IntCan.h and CDD_Phy_665a_Types.h are different"
#endif

#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
/* Check if this header file and CDD_Phy_665a_CanIf.h are of the same vendor */
#if (PHY_665A_INTCAN_VENDOR_ID != PHY_665A_CANIF_VENDOR_ID)
#error "CDD_Phy_665a_IntCan.h and CDD_Phy_665a_CanIf.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_CanIf.h are of the same Autosar version */
#if ((PHY_665A_INTCAN_AR_RELEASE_MAJOR_VERSION != PHY_665A_CANIF_AR_RELEASE_MAJOR_VERSION) || \
     (PHY_665A_INTCAN_AR_RELEASE_MINOR_VERSION != PHY_665A_CANIF_AR_RELEASE_MINOR_VERSION) || \
     (PHY_665A_INTCAN_AR_RELEASE_REVISION_VERSION != PHY_665A_CANIF_AR_RELEASE_REVISION_VERSION))
#error "AutoSar Version Numbers of CDD_Phy_665a_IntCan.h and CDD_Phy_665a_CanIf.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_CanIf.h are of the same Software version */
#if ((PHY_665A_INTCAN_SW_MAJOR_VERSION != PHY_665A_CANIF_SW_MAJOR_VERSION) || \
     (PHY_665A_INTCAN_SW_MINOR_VERSION != PHY_665A_CANIF_SW_MINOR_VERSION) || \
     (PHY_665A_INTCAN_SW_PATCH_VERSION != PHY_665A_CANIF_SW_PATCH_VERSION))
#error "Software Version Numbers of CDD_Phy_665a_IntCan.h and CDD_Phy_665a_CanIf.h are different"
#endif
#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)*/
/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)

#if (defined PHY_665A_CAN_INIT_MAX_TIMEOUT)
#error PHY_665A_CAN_INIT_MAX_TIMEOUT is already defined
#endif
#define PHY_665A_CAN_INIT_MAX_TIMEOUT 0x32U

/*
 * Macro used for getting the Can Internal Request Sending cycle
*/
#if (defined PHY_665A_CAN_BUS_INTERNAL_TX_MSG_CYCLE)
#error PHY_665A_CAN_BUS_INTERNAL_TX_MSG_CYCLE is already defined
#endif
#define PHY_665A_CAN_BUS_INTERNAL_TX_MSG_CYCLE 0x12CU

/*
 * Macro used for defining  Maximum of common response buffer of CAN
*/
#if (defined PHY_665A_MAX_CAN_RESP_BUFF_SIZE)
#error PHY_665A_MAX_CAN_RESP_BUFF_SIZE is already defined
#endif
#define PHY_665A_MAX_CAN_RESP_BUFF_SIZE 0x32U

/*
 * Macro used for defining the maximum number of requests that can be sent per batch.
*/
#if (defined PHY_665A_CAN_COMMON_BUFFER_MAX_REQ_CNT)
#error PHY_665A_CAN_COMMON_BUFFER_MAX_REQ_CNT is already defined
#endif
#define PHY_665A_CAN_COMMON_BUFFER_MAX_REQ_CNT 0x0CU


#if (defined PHY_665A_GPT_CYCLE)
#error PHY_665A_GPT_CYCLE is already defined
#endif
#define PHY_665A_GPT_CYCLE 0x1F4U

#if (defined PHY_665A_XTAL_WAKEUP_DELAY)
#error PHY_665A_XTAL_WAKEUP_DELAY is already defined
#endif
#define PHY_665A_XTAL_WAKEUP_DELAY 0x0AF0U

#if (defined PHY_665A_CALC_PDU_FIELD_MASK)
#error PHY_665A_CALC_PDU_FIELD_MASK is already defined
#endif
#define PHY_665A_CALC_PDU_FIELD_MASK(PduFieldOffset,PduFieldLen)\
(0xFFFFU>>(sizeof(uint16)-(PduFieldLen)))<<(PduFieldOffset)

#if (defined PHY_665A_CAN_BAUD_RATE_BITS_MILLI_SEC_COEFF)
#error PHY_665A_CAN_BAUD_RATE_BITS_MILLI_SEC_COEFF is already defined
#endif
#define PHY_665A_CAN_BAUD_RATE_BITS_MILLI_SEC_COEFF 0x1F40U

#if (defined PHY_665A_CAN_TPL3_TIMEOUT_TOLERANCE)
#error PHY_665A_CAN_TPL3_TIMEOUT_TOLERANCE is already defined
#endif
#define PHY_665A_CAN_TPL3_TIMEOUT_TOLERANCE 0xC8U

#if (defined PHY_665A_CAN_BUS_INTER_FRAME_DELAY)
#error PHY_665A_CAN_BUS_INTER_FRAME_DELAY is already defined
#endif
#define PHY_665A_CAN_BUS_INTER_FRAME_DELAY 0x1F4U

#if (defined PHY_665A_CAN_BUS_INTERNAL_CRC_DELAY)
#error PHY_665A_CAN_BUS_INTERNAL_CRC_DELAY is already defined
#endif
#define PHY_665A_CAN_BUS_INTERNAL_CRC_DELAY 0x64U

#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED*/

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/
/*
 * enum  type used for holding  internal states of PHY_driver Intialization.
*/
typedef enum
{
    PHY_665A_DEVICE_NOT_AWAKE = 0,
    PHY_665A_DEVICE_AWAKE,
    PHY_665A_SYS_INIT,
    PHY_665A_CAN_INIT,
    PHY_665A_CAN_TRCV_LOW_INIT,
    PHY_665A_CAN_TRCV_HIGH_INIT,
    PHY_665A_HOST_COM_INIT,
    PHY_665A_READ_UID_TX,
    PHY_665A_READ_UID_RX,
    PHY_665A_TPL_PORT_INIT,
    PHY_665A_FILTER_INIT,
    PHY_665A_QUEUE_INIT,
    PHY_665A_READ_SYS_CRC_TX,
    PHY_665A_READ_SYS_CRC_RX,
    PHY_665A_EVH_INT_SEL_INIT,
    PHY_665A_EVH_INT_CFG_INIT,
    PHY_665A_EVH_WAKEUP_CFG,
    PHY_665A_READ_EVH_CRC_TX,
    PHY_665A_READ_EVH_CRC_RX,
    PHY_665A_GPIO_CFG_INIT,
    PHY_665A_I2C_CFG_INIT,
    PHY_665A_FINISH_INIT
} Phy_665a_InternalStatesType;
/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

#define PHY_665A_START_SEC_VAR_CLEARED_BOOLEAN
#include "Phy_665a_MemMap.h"
#if (PHY_665A_CAN_SUPPORT_ENABLED == STD_ON)
extern volatile boolean Phy_665a_CanIntQueueFlushProcessed;
extern volatile boolean Phy_665a_TdCanProcessingFlg;
extern boolean Phy_665a_TxFinishFlg;
extern boolean Phy_665a_RxFinishFlg;
#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)*/
#define PHY_665A_STOP_SEC_VAR_CLEARED_BOOLEAN
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_8
#include "Phy_665a_MemMap.h"
#if (PHY_665A_CAN_SUPPORT_ENABLED == STD_ON)
extern uint8 Phy_665a_BatchRecRespCnt;
extern uint8 Phy_665a_CanExpectedRespCnt;
extern uint8 Phy_665a_CanGlblRespBuffIdx;
extern uint8 Phy_665a_CanDevIdxVector[];
#endif
#define PHY_665A_STOP_SEC_VAR_CLEARED_8
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_16
#include "Phy_665a_MemMap.h"
/*Pointer to the address that indicates which request is needed to be processed*/
extern uint16* Phy_665a_CanBuffReqTraversePtr;
/*Pointer to the address where the response has to  be copied*/
extern uint16* Phy_665a_CanBuffRespTraversePtr;
#define PHY_665A_STOP_SEC_VAR_CLEARED_16
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Phy_665a_MemMap.h"
#if (PHY_665A_CAN_SUPPORT_ENABLED == STD_ON)
extern PduInfoType Phy_665a_CanSendPdu;
extern Phy_665a_SchedCmdInfoStructType Phy_665a_CanSchedTimeStruct;
#endif
#define PHY_665A_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_INIT_UNSPECIFIED
#include "Phy_665a_MemMap.h"
#if (PHY_665A_CAN_SUPPORT_ENABLED == STD_ON)
extern Phy_665a_GlobalInfoType Phy_665a_GlobalCanInfo;
#endif
#define PHY_665A_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Phy_665a_MemMap.h"

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/

#define PHY_665A_START_SEC_CODE
#include "Phy_665a_MemMap.h"

#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
Std_ReturnType Phy_665a_CanVariantInit
(
    void
);

void Phy_665a_CanVariantDeinit
(
    void
);

Std_ReturnType Phy_665a_CanVerifyDriverState
(
    void
);

#if (STD_ON == PHY_665A_CAN_SW_QUEUE_SUPPORT_ENABLED)
Std_ReturnType Phy_665a_EnQueueCan
(
    Phy_665a_QueueStructInfoType* ElementToQueuePtr
);

void Phy_665a_CanCancelAllTds
(
    void
);

void Phy_665a_DeQueueCan
(
    void
);
#endif /*(STD_ON == PHY_665A_CAN_SW_QUEUE_SUPPORT_ENABLED)*/

void Phy_665a_CanStartTimer
(
    uint32 TimerValue
);

void Phy_665a_CanStopTimer
(
    void
);

void Phy_665a_CanInitHandlerGpt
(
    void
);

void Phy_665a_CanInitHandlerRxIndication
(
    PduIdType RxPduId,
    const PduInfoType* PduInfoPtr
);

void Phy_665a_CanInternalTdHandlerGpt
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatusPtr
);

void Phy_665a_CanExternalTdHandlerGpt(Phy_TDType* TransactionDescriptor, Phy_ErrorStatusType* ErrorStatus);
void Phy_665a_CanSyncFailureHandler(uint8 DevIdx);
void Phy_665a_CanSyncNotStartedStateHandler(uint8 PhyIndex);
void Phy_665a_CanTdFailureHandler(Phy_TDType* TransactionDescriptor, Phy_ErrorStatusType* ErrorStatusPtr, Phy_ErrorStatusType ErrStatus);
void Phy_665a_CanTdTimeoutHandler(Phy_TDType* TransactionDescriptor, Phy_ErrorStatusType* ErrorStatusPtr, Phy_ErrorStatusType ErrStatus);

Std_ReturnType Phy_665a_IO_SendMessageCan
(
    Phy_TDType* TransactionDescriptor,
    Phy_ErrorStatusType* ErrorStatus
);

Std_ReturnType Phy_665a_PackCanMsgToPdu
(
    const uint16* ReqMsgPtr,
    uint8 RequestMsgLength
);

Std_ReturnType Phy_665a_CanSendExternalRequest(void);

void Phy_665a_CanGptStartTimer
(
    Gpt_ChannelType GptChannel,
    uint32 TimeUs
);

void Phy_665a_CanResetBatchCommonReqArrInfo(void);
void Phy_665a_CanResetTdParameters(void);

void Phy_665a_CanResetGlbVarForDeinit(void);

#if (STD_ON == PHY_665A_CAN_SW_QUEUE_SUPPORT_ENABLED)
void Phy_665a_CanDequeueGptTrigger
(
    void
);
#endif /*(STD_ON == PHY_665A_CAN_SW_QUEUE_SUPPORT_ENABLED)*/

Std_ReturnType Phy_665a_CheckRxPduId
(
    Phy_665a_CanIfRxPduCheckType* RxPduData
);

void Phy_665a_GptNotificationCan
(
    void
);

void Phy_665a_CanInternalTdHandlerRxIndication
(
    uint8 SduLenToCpy
);

void Phy_665a_CanExternalTdHandlerRxIndication
(
    uint8 SduLenToCpy
);

/*==================================================================================================
*                                         LOCAL FUNCTIONS
==================================================================================================*/

static inline uint32 Phy_665a_GptTimeUsToTicks(uint32 TimeUs)
{
    /* Return the number of GPT ticks for the provided time value */
    return (TimeUs * PHY_665A_CAN_GPT_CLOCK_TICKS_1US);
}

static inline uint8 Phy_665a_GetNumResp(uint8 NumReg, uint8 Nrt)
{
    /* Return the number of responses for a read request considering the number of registers per message */
    return (((uint8)((NumReg + 1U) % (Nrt + 1U))) == 0U) ?
           ((uint8)((NumReg + 1U) / (Nrt + 1U))) :
           ((uint8)((NumReg + 1U) / (Nrt + 1U)) + 1U);
}

static inline uint16 Phy_665a_ConvertSduBytesToHex(const uint8* SduBuffer, uint8 SduByteIterIdx)
{
    /* Returns a 16 bit word out of two consecutive bytes */
    return (((uint16)SduBuffer[SduByteIterIdx] << 8U) | (uint16)SduBuffer[SduByteIterIdx + 1U]);
}

#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)*/

#define PHY_665A_STOP_SEC_CODE
#include "Phy_665a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_INTCAN_H */

