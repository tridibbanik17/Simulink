/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef BMS_COMMON_TYPES_H
#define BMS_COMMON_TYPES_H

/**
*   @file    CDD_Bms_common_Types.h
*
*   @addtogroup CDD_BMS_COMMON
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "StandardTypes.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/

#define BMS_COMMON_TYPES_MODULE_ID                     255
#define BMS_COMMON_TYPES_VENDOR_ID                     43
#define BMS_COMMON_TYPES_AR_RELEASE_MAJOR_VERSION      4
#define BMS_COMMON_TYPES_AR_RELEASE_MINOR_VERSION      7
#define BMS_COMMON_TYPES_AR_RELEASE_REVISION_VERSION   0
#define BMS_COMMON_TYPES_SW_MAJOR_VERSION              1
#define BMS_COMMON_TYPES_SW_MINOR_VERSION              0
#define BMS_COMMON_TYPES_SW_PATCH_VERSION              2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((BMS_COMMON_TYPES_AR_RELEASE_MAJOR_VERSION != STD_AR_RELEASE_MAJOR_VERSION) || \
        (BMS_COMMON_TYPES_AR_RELEASE_MINOR_VERSION != STD_AR_RELEASE_MINOR_VERSION) \
        )
    #error "AutoSar Version Numbers of CDD_Bms_common_Types.h and StandardTypes.h are different"
    #endif
#endif
/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/
/**
* @brief The data that is present defaut in the TD
* @details The data that is present defaut in the TD
*/
#define BMS_COMMON_TD_OVERWRITE_VALUE 0U
/**
* @brief TPL3 maximum frame length
* @details TPL3 maximum frame length in words
*/
#define TPL3_FRAME_MAX_LENGTH 7U
/**
* @brief Loopback method 1
* @details Used to define the loopback method for each chain
*/
#define LOOPBACK_METHOD_1 1U
/**
* @brief Loopback method 2
* @details  L Used to define the loopback method for each chain
*/
#define LOOPBACK_METHOD_2 2U
/**
* @brief Phy 665 is used in the system
* @details Phy 665 is used in the system this will help generate the appropiate CDD_PhyIf
*/
#define PHY_665 0U
/**
* @brief Phy 664 is used in the system
* @details Phy 664 is used in the system this will help generate the appropiate CDD_PhyIf
*/
#define PHY_664 1U
/**
* @brief Phy 665 is used in the system
* @details Phy 665 is used in the system this will help generate the appropiate CDD_PhyIf
*/
#define PHY_DIRECTSPI 2U
/**
* @brief Minimum value for TD timeout
* @details Minimum value for TD timeout expressed in microseconds
*/
#define TD_TIMEOUT_MIN_VAL_U32  1U
/**
* @brief Maximum value for TD timeout
* @details Maximum value for TD timeout expressed in microseconds
*/
#define TD_TIMEOUT_MAX_VAL_U32  (uint32)2000000U
/**
* @brief Maximum value for Phy index
* @details Maximum value for phy index
*/
#define TD_PHYINDEX_MAX_VAL  255U

/**
* @brief Define number of  TPL2 device types.
* @details Define number of  TPL2 device types.
*/
#define BMS_NUMBER_OF_TPL2_MAX_DEVICES_TYPES      3U

/**
* @brief Define number of  TPL3 device types.
* @details Define number of  TPL3 device types.
*/
#define BMS_NUMBER_OF_TPL3_MAX_DEVICES_TYPES    5U

/*! @brief All Battery Cell Controller devices in TPL mode. */
#define BCC_ALL_DEVICE_TPL3    63U

/*! @brief All Battery Cell Controller chain in TPL mode. */
#define BCC_ALL_CHAIN_TPL3    7U
/*==================================================================================================
*                                            ENUMS
==================================================================================================*/
/** @brief Datatype for addressing the Phy device configuration */
typedef uint8 Phy_DeviceIdxType;
/**
 * @brief  Transaction Status
 *
 * Transaction Status is updated by PHY according to the transaction state machine
 * @implements Phy_TStatusInfoType_enum
 */
typedef enum
{
    PHY_TS_IDLE = 0u,     /**< Transaction is Idle */
    PHY_TS_PENDING = 1u,  /**< Driver is performing Transaction, Transaction is in progress */
    PHY_TS_QUEUED = 2u,   /**< An asynchronous transmit Request has been accepted, while actual transmission for the request has not started yet */
    PHY_TS_CANCELLED = 3u,/**< Transaction cancelled by user */
    PHY_TS_FAILED  = 4u,  /**< Transaction failed due to Error */
    PHY_TS_TIMEOUT = 5u,  /**< Transaction taking more time than expected */
    PHY_TS_FINISHED  = 6u /**< Transaction has been finished successfully */
} Phy_TStatusInfoType;

/**
*
*/
/**
 * @brief  Information about the Type of Messages in the buffer
 *
 * The enumeration contains the list of the supported types of the messages placed into the Request Buffer
 *
 *  @implements Phy_MsgInfoType_enum
 */
typedef enum
{
    PHY_TPL2_FIXED_48L = 0u,  /**< Bms - TPL2 (e.g MC33772C) */
    PHY_TPL3_FIXED_64L = 1u,  /**< Bms - TPL3 (e.g MC33775A) - CAN, Direct SPI */
    PHY_TPL3_VARIABLE = 2u    /**< Bms - TPL3 (e.g MC33775A) - SPI, CAN-FD */
} Phy_MsgInfoType;

/**
 * @brief  Information about the Type of Messages in the buffer
 *
 * The enumeration contains the list of the supported types of the messages placed into the Request Buffer
 *
 * @implements Phy_ErrorStatusType_enum
 */
typedef enum
{
    PHY_NO_ERROR = 0u,           /**< Default state for the Error Status */
    PHY_UNINITIALIZED = 1u,      /**< MC33665 SPI/CAN initalization failed */
    PHY_TPL_BUS_SLEEP = 2u,      /**< TBD */
    PHY_INVALID_REQUEST = 3u,    /**< Command not valid*/
    PHY_HW_ERROR = 4u,           /**< Generic communcation error on CAN/SPI*/
    PHY_SYNC_ERROR = 5u,         /**< All errors encountered in SYNC scernario*/
    PHY_SYNC_TRIGG_MISSING = 6u  /**< Trigger command is missing from TD */
} Phy_ErrorStatusType;
/**
 * @brief  Information about the Type of Messages in the buffer
 *
 * The enumeration contains the list of the supported types of the messages placed into the Request Buffer
 *
 * @implements Phy_EventType_enum
 */
typedef enum
{
    PHY_TIMER = 0u,        /**<TPL transmission is blocked for a specific time */
    PHY_SYNC = 1u,         /**<For MC33665A inserts a SYNC command for next message in TD */
    PHY_RSPQUEUEFREE = 2u, /**<TPL sending is blocked untill response queue reached an empty predefined level */
} Phy_EventType;

/**
 * @brief  Information about the Type of TPL protocols
 *
 * The enumeration contains the list of the supported TPL protocols
 *
 * @implements Phy_TplProtocolType_enum
 */
typedef enum
{
    PHY_TPL2 = 0u, /**<TPL2 protocol */
    PHY_TPL3 = 1u  /**<TPL3 protocol */
} Phy_TplProtocolType;

/**
 * @brief  Information about the Type of devices (CMUs/BJBs)
 *
 * The enumeration contains the list of the supported devices that can be connected in system
 */
typedef enum
{
    NO_DEVICE = 0u,          /**<NO device selected */
    TPL3_CMU_1,              /**<MC33775A */
    TPL3_CMU_2,              /**<MC33774A */
    TPL3_CMU_3,              /**<TBD */
    TPL3_CMU_4,              /**<TBD */
    TPL3_CMU_5,              /**<TBD */
    TPL3_BJB_1,              /**<TBD */
    TPL3_BJB_2,              /**<TBD */
    TPL3_BJB_3,              /**<TBD */
    TPL3_BJB_4,              /**<TBD */
    TPL3_BJB_5,              /**<TBD */
    TPL2_BJB_1,              /**<MC33772C */
    TPL2_BJB_2,              /**<TBD */
    TPL2_BJB_3,              /**<TBD */
}Bms_TypeOfDeviceType;

/**
 * @brief  Information about the MC33665 CAN variant
 *
 * The enumeration contains the list of the supported errors durring initalization phase
 *
 * @implements Phy_InitializationStateType_enum
 */
typedef enum
{
    PHY_INITIALIZATION_NOT_STARTED = 0u, /**<Device initilazation not started>*/
    PHY_INITIALIZATION_IN_PROGRESS = 1u, /**<Device initilazation in progress>*/
    PHY_INITIALIZATION_FINISHED = 2u,    /**<Device initilazation is finished on all devices on the CAN network>*/
    PHY_INITIALIZATION_FAILED = 3u,      /**<Reported if any MC33665SA device on CAN bus failed to initialize>*/
    PHY_INITIALIZATION_TIMED_OUT = 4u,   /**<Reported in case of communication timeout>*/
    PHY_INVALID_DEVICE = 5u              /**<Device configuration index is not valid>*/
} Phy_InitializationStateType;

/**
 * @brief  Information about the MC33665 CAN variant
 *
 * The enumeration contains the list of the supported errors durring initalization phase
 *
 * @implements Phy_SyncTrigType_enum
 */
typedef enum
{
    PHY_SYNC_SW_TRIG = 0u,   /**<Sync type SW >*/
    PHY_SYNC_HW_TRIG_PULSE,  /**<Sync type HW with notification pulse>*/
    PHY_SYNC_HW_TRIG_NOPULSE /**<Sync type HW without nt pulse>*/
} Phy_SyncTrigType;

/**
 * @brief  Information about Bms_TD_SetParamRuntime parameters types
 *
 * The enumeration contains the list of the supported errors durring initalization phase
 *
 * @implements Phy_RuntimeParamType_enum
 */
typedef enum
{
    PHY_SET_ENCODING = 0u,      /**<Parameter used as input for Bms_TD_SetParamRuntime to adjust TD encoding >*/
    PHY_SET_TIMEOUT,            /**<Parameter used as input for Bms_TD_SetParamRuntime to adjust TD timeout>*/
    PHY_SET_PHYINDEX            /**<Parameter used as input for Bms_TD_SetParamRuntime to adjust index of used phy>*/
} Phy_RuntimeParamType;

/*==================================================================================================
*                                STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
/** @brief Structure to store one or multiple messages
 *
 * @implements Phy_MsgBufferType_struct
 */
typedef struct
{
    uint16 *Data;       /**< Pointer to the messages (can be RAM or ROM) >*/
    uint16 MsgNum;      /**< Length of req lists (Number of Messages) >*/
    uint16 BufferSize;  /**< Exact size of buffer >*/
} Phy_MsgBufferType;

/** @brief Transaction Description Module
 *
 * @implements Phy_TDType_struct
 */
typedef struct
{
    Phy_MsgBufferType    Request;               /**< Request message buffer  >*/
    Phy_MsgBufferType    Response;              /**< Response message buffer  >*/
    Phy_MsgInfoType      Encoding;              /**< Type of Messages in the Request buffer. Used by PHY.DD to parse the messages in the Request. >*/
    uint16               ResponseMsgNumAct;     /**< Actual number of Messages received by the PHY.DD into the Response buffer.>*/
    Phy_TStatusInfoType  Status;                /**< The status of the Transaction processed by PHY.DD. >*/
    uint32               Timeout;               /**< Timeout value [1000, 65000]us with 1us resolution >*/
    Phy_DeviceIdxType    PhyIndex;              /**< Index of ephy devices used to send the TD >*/
} Phy_TDType;
/**
 * @brief   Bms transaction descriptor.
 *
 * @implements Bms_TDType_struct
 */
typedef struct
{
    Phy_TDType* PhyTD;              /**< @brief Pointer to the Phy transaction descriptor */
    uint16 MaxRequestBufSize;       /**< @brief The RAM size in 16-bit words of the request buffer​ */
    uint16 MaxResponseBufSize;      /**< @brief The RAM size in 16-bit words of the response buffer​ */
    uint32 DefaultTimeout;          /**< @brief Default timeout value [1000, 65000]us with 1us resolution */
} Bms_TDType;

/** @brief Phy HardwareSync runtime info
 *
 * @implements Phy_HwSyncDataType_struct
*/
typedef struct
{
    uint8 GpioPolarity;    /**< Gpio HW signaling first edge: STD_HIGH, STD_LOW */
    uint32 SyncHoldTime;   /**< Time amount for the system to wait for all SYNC data transfer */
} Phy_HwSyncDataType;

/**
 * @brief   Bms devices structure.
 *
 */
typedef struct
{
    Bms_TypeOfDeviceType    TypeOfDevice;       /**< @brief Type of device configured */
    uint8                   NumberOfDevices;    /**< @brief NUmber of devices of selected type configured in system*/
    uint8                   StartDeviceAddress; /**< @brief Start position of selected type of device in chain */
} BmsDeviceType;

/**
 * @brief   Bms TPL3 chain structure.
 *
 */
typedef struct
{
    uint8                   ChainID;                                            /**< @brief ID of configured chain */
    uint8                   LoopBackMethod;                                     /**< @brief Loopback method used for selected chain*/
    BmsDeviceType           DeviceList[BMS_NUMBER_OF_TPL3_MAX_DEVICES_TYPES];   /**< @brief List of configured devices in chain */
} BmsTpl3ChainConfigType;

/**
 * @brief   Bms TPL2 chain structure.
 *
 */

typedef struct
{
    uint8                   ChainID;                                            /**< @brief ID of configured chain */
    BmsDeviceType           DeviceList[BMS_NUMBER_OF_TPL2_MAX_DEVICES_TYPES];   /**< @brief List of configured devices in chain */
} BmsTpl2ChainConfigType;

/**
 * @brief   MemMapMirror structure. 
 * 
 */
typedef struct
{
    uint16*      RegMirrorAddress;       /**< @brief Pointer to an array containing addresses of registers to be written in memory map mirror */
    const uint16 *RegMirrorValues;  /**< @brief Pointer to an array containing values of registers to be written in memory map mirror */
    uint8        Size;                     /**< @brief Number of register to be updated in memory map mirror */
} Bms_MemMapMirrorType;


/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* BMS_COMMON_TYPES_H */
