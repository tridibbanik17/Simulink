/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_CBK_H
#define CDD_PHY_665A_CBK_H

/**
*   @file CDD_Phy_665a_Cbk.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Phy_665a_Cfg.h"
#include "CDD_Phy_665a_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_CBK_VENDOR_ID                    43
#define PHY_665A_CBK_AR_RELEASE_MAJOR_VERSION     4
#define PHY_665A_CBK_AR_RELEASE_MINOR_VERSION     7
#define PHY_665A_CBK_AR_RELEASE_REVISION_VERSION  0
#define PHY_665A_CBK_SW_MAJOR_VERSION             1
#define PHY_665A_CBK_SW_MINOR_VERSION             0
#define PHY_665A_CBK_SW_PATCH_VERSION             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same vendor */
#if (PHY_665A_CBK_VENDOR_ID != PHY_665A_VENDOR_ID_CFG)
#error "CDD_Phy_665a_Cbk.h and CDD_Phy_665a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Autosar version */
#if ((PHY_665A_CBK_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (PHY_665A_CBK_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (PHY_665A_CBK_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of CDD_Phy_665a_Cbk.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Software version */
#if ((PHY_665A_CBK_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_CFG) || \
     (PHY_665A_CBK_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_CFG) || \
     (PHY_665A_CBK_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of CDD_Phy_665a_Cbk.h and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_CBK_VENDOR_ID != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_Cbk.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_CBK_AR_RELEASE_MAJOR_VERSION != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_CBK_AR_RELEASE_MINOR_VERSION != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_CBK_AR_RELEASE_REVISION_VERSION != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_Cbk.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_CBK_SW_MAJOR_VERSION != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_CBK_SW_MINOR_VERSION != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_CBK_SW_PATCH_VERSION != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_Cbk.h and CDD_Phy_665a_Types.h are different"
#endif

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/

#define PHY_665A_START_SEC_CODE
#include "Phy_665a_MemMap.h"

#if (STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)
/*!
 * @brief Phy_665a SPI variant callback function used as GPT notification
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_GptNotificationSpi
(
    void
);

/*!
 * @brief Phy_665a callback function used as SPI EndOfSequence notification
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Shall be used for all sequences linked to SPI MASTER functionality
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_SpiTxSeqNotif
(
    void
);

/*!
 * @brief Phy_665a callback function used as SPI EndOfSequence notification
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *          - Shall be used only for the sequence linked to SPI SLAVE functionality
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_SpiRxSeqNotif
(
    void
);

#if (PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED == STD_ON)
/*!
 * @brief Phy_665a SPI variant callback function used as ICU channel notification
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_IcuReqQueueLowNotification
(
    void
);

#if (PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)
/*!
 * @brief Phy_665a SPI variant callback function used as ICU channel notification
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_IcuRspQueueHighNotification
(
    void
);
#endif /*(PHY_665A_SPI_VARIANT == PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)*/
#endif /* (PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED == STD_ON) */
#endif /*(STD_ON == PHY_665A_SPI_SUPPORT_ENABLED)*/

#if (STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)
/*!
 * @brief Phy_665a CAN variant callback function used as GPT notification
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       void
 * @param[out]      void
 * @param[inout]    void
 *
 * @return void
 */
void Phy_665a_GptNotificationCan
(
    void
);

/*!
 * @brief Phy_665a CAN variant callback function used for CanIf_TxConfirmation CDD callback
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]   CanTxPduId
 * @param[in]   Result
 * 
 * @return void
 */
void Phy_665a_TxConfirmation
(
    PduIdType CanTxPduId,
    Std_ReturnType Result
);

/*!
 * @brief Phy_665a CAN variant callback function used for CanIf_RxIndication CDD callback
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]   RxPduId
 * @param[in]   PduInfoPtr
 * 
 * @return void
 */
void Phy_665a_RxIndication
(
    PduIdType RxPduId,
    const PduInfoType* PduInfoPtr
);
#endif /*(STD_ON == PHY_665A_CAN_SUPPORT_ENABLED)*/
#define PHY_665A_STOP_SEC_CODE
#include "Phy_665a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_CBK_H */
