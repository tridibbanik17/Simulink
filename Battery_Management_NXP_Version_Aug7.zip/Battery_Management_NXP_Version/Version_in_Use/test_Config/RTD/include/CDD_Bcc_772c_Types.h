/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_BCC_772C_TYPES_H
#define CDD_BCC_772C_TYPES_H

/**
*   @file CDD_Bcc_772c_Types.h
*
*   @addtogroup  CDD_BCC_772C
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bms_common.h"
/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define BCC_772C_MODULE_ID_COM                    255
#define BCC_772C_VENDOR_ID_COM                    43
#define BCC_772C_AR_RELEASE_MAJOR_VERSION_COM     4
#define BCC_772C_AR_RELEASE_MINOR_VERSION_COM     7
#define BCC_772C_AR_RELEASE_REVISION_VERSION_COM  0
#define BCC_772C_SW_MAJOR_VERSION_COM             1
#define BCC_772C_SW_MINOR_VERSION_COM             0
#define BCC_772C_SW_PATCH_VERSION_COM             2

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Bms_common header file are of the same Autosar version */
    #if ((BCC_772C_AR_RELEASE_MAJOR_VERSION_COM != BMS_COMMON_AR_RELEASE_MAJOR_VERSION) || \
         (BCC_772C_AR_RELEASE_MINOR_VERSION_COM != BMS_COMMON_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Bcc_772c_Types.h and CDD_Bms_common.h are different"
    #endif
#endif
/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/
/*! TPL System Boundaries */
#define BCC_772C_CHAIN_CNT_MAX_TPL  6U /**< Maximal number of daisy-chains in TPL mode. */
#define BCC_772C_DEVICE_CNT_MAX_TPL 62U /**< Maximal number of Battery Cell Controller devices in TPL mode. */

#define BCC_772C_ALL_CHAIN_TPL  7U   /**< Should be used as Chain Address if Global Write is required. **/
#define BCC_772C_ALL_DEVICE_TPL 63U /**< Should be used as Device Address if Global Write is required. **/

/*! BCC_772C Commands */
typedef enum
{
    BCC_772C_CMD_NOP = 0U, /**< NOP */
    BCC_772C_CMD_READ = 1U, /**< Read */
    BCC_772C_CMD_LOCAL_WRITE = 2U, /**< Write */
    BCC_772C_CMD_GLOBAL_WRITE = 3U /**< Global Write */
}Bcc_772c_BccCommandType;

/*! @brief Maximum register address */
#define BCC_772C_MAX_REG_ADDR 0x7FU
/*! @brief Maximum device address */
#define BCC_772C_MAX_DEV_ADDR 0x3FU
/*! @brief Register Address with Request/Response bit mask in communication frame */
#define BCC_772C_REG_ADDR_MASK      0x7FU
/*! @brief Register Address mask for second word in communication frame */
#define BCC_772C_REG_ADDR_WORD_MASK 0x7F00U
/*! @brief CADD[1:0] field bit mask */
#define BCC_772C_CADD01_DATA_MASK   0x3U
/*! @brief CADD[2] field bit mask */
#define BCC_772C_CADD2_DATA_MASK    0x4U
/*! @brief DADD(Device Address) field bit mask */
#define BCC_772C_DADD_DATA_MASK     0x3FU

/*! @brief Represents Register Address field shift in FRAME second 16bit */
#define BCC_772C_REG_ADDR_FIELD_SHIFT  8U
/*! @brief Represents DADD field shift in FRAME second 16bit */
#define BCC_772C_DADD_FIELD_SHIFT      0U
/*! @brief Represents CADD[2] field shift in FRAME second 16bit */
#define BCC_772C_CADD2_FIELD_SHIFT     4U
/*! @brief Represents CADD[1:0] field shift in FRAME last 16bit */
#define BCC_772C_CADD01_FIELD_SHIFT    10U
/*! @brief Represents CMD field shift in FRAME last 16bit */
#define BCC_772C_CMD_FIELD_SHIFT       8U

/**
* @brief Frame length in 16bit words and bytes
*/
#define BCC_772C_FRAME_LENGTH 3U /*< Frame length for MC33772C is 48 bits (3 * 16 bit) */
#define BCC_772C_FRAME_LENGTH_8BIT_RES 6U /*< Frame length for MC33772C is 48 bits (6 * 8 bit) */

/**
* @brief V2RES value expressed in nanoVolts/LSB
*/
#define BCC_772C_V2RES (600)

/**
* @brief Time between wakeup pulses
*/
#define BCC_772C_T_WAKE_DELAY_US (600U)
/**
* @brief Time the MCU shall wait after sending first wakeup message per device
*/
#define BCC_772C_T_WU_WAIT_US (750U)
/**
* @brief Number of registers in each memory map mirror
*/
#define BCC_772C_MEMORY_MAP_MIRROR_SIZE (8U)

/**
* @brief This value signal that a register isn't in memory map mirror
*/
#define BCC_772C_INVALID_MEMORY_MAP_INDEX (255U)

/**
* @brief Index of each mirrored register in the memory map mirror array
*/
#define BCC_772C_SYS_CFG1_LOCAL_INDEX                    (0U)
#define BCC_772C_SYS_CFG2_LOCAL_INDEX                    (1U)
#define BCC_772C_SYS_DIAG_LOCAL_INDEX                    (2U)
#define BCC_772C_ADC_CFG_LOCAL_INDEX                     (3U)
#define BCC_772C_ADC2_OFFSET_COMP_LOCAL_INDEX            (4U)
#define BCC_772C_OV_UV_EN_LOCAL_INDEX                    (5U)
#define BCC_772C_GPIO_CFG1_LOCAL_INDEX                   (6U)
#define BCC_772C_GPIO_CFG2_LOCAL_INDEX                   (7U)

/**
* @brief Reset value for each mirrored register in the memory map mirror array
*/
#define BCC_772C_MEMORY_MAP_POR \
    {   MC33772C_SYS_CFG1_POR_VAL, \
        MC33772C_SYS_CFG2_POR_VAL, \
        MC33772C_SYS_DIAG_POR_VAL, \
        MC33772C_ADC_CFG_POR_VAL,  \
        MC33772C_ADC2_OFFSET_COMP_POR_VAL, \
        MC33772C_OV_UV_EN_POR_VAL, \
        MC33772C_GPIO_CFG1_POR_VAL, \
        MC33772C_GPIO_CFG2_POR_VAL }

/**
* @brief Maximum number of elements in the hash table.
*/
#if (defined BMS_NUMBER_OF_TPL2_BJB_1_MAX_DEVICES)
#define BCC_772C_MAX_DEVICES (BMS_NUMBER_OF_TPL2_BJB_1_MAX_DEVICES)
#else
#define BCC_772C_MAX_DEVICES (1U)
#endif

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/
/**
 * @brief   Bcc_772c COMM error codes.
 *
 */
typedef enum
{
    BCC_772C_COM_SUCCESS        = 0x00U,   /*!< No error. */
    BCC_772C_COM_ADDR           = 0xA1U,   /*!< BCC Read Invalid register */
    BCC_772C_COM_MSGCNT         = 0xA2U,   /*!< Response message counter value does not match with expected. */
    BCC_772C_COM_TIMEOUT        = 0xA3U,   /*!< Communication timeout. */
    BCC_772C_COM_PARAM_RANGE    = 0xA4U,   /*!< Parameter out of range. */
    BCC_772C_COM_CRC            = 0xA5U,   /*!< Wrong CRC. */
    BCC_772C_COM_TX_FAIL        = 0xA6U,   /*!< MCU SPI failure. */
    BCC_772C_COM_RESPONSE       = 0xA7U,   /*!< Response command field error */
    BCC_772C_COM_TD_OVERFLOW    = 0xA8U,   /*!< The message will not fit the destination TD */
} Bcc_772c_CommErrorType;
/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/**
 * @brief   Bcc_772c chain state.
 *
 */
typedef struct
{
    uint8 DeviceNum;
} Bcc_772c_ChainStateType;

/**
 * @brief   Bcc_772c device state.
 *
 */
typedef struct
{
    uint16 MemoryMapMirror[BCC_772C_MEMORY_MAP_MIRROR_SIZE]; /**< @brief Memory map mirror array */
    uint8 DADD;             /**< @brief Device Address */
    uint8 CADD;             /**< @brief Chain Address */
} Bcc_772c_DeviceStateType;

/**
 * @brief   Bcc_772c element from hash map.
 *
 */
typedef struct
{
    Bcc_772c_DeviceStateType Device;
    boolean Allocated;
} Bcc_772c_HashMapElementType;

/**
 * @brief   Bcc_772c hash map containing all devices from each chain.
 *
 */
typedef struct
{
    Bcc_772c_HashMapElementType Elements[BCC_772C_MAX_DEVICES];
} Bcc_772c_HashMapType;

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_BCC_772C_TYPES_H */
