/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_TYPES_H
#define CDD_PHY_665A_TYPES_H

/**
*   @file CDD_Phy_665a_Types.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Std_Types.h"
#include "CDD_Phy_665a_Regs.h"
#include "CDD_Bms_common_Types.h"
#include "CDD_Bms_common_Cfg.h"
#include "Gpt.h"
#include "ComStack_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_VENDOR_ID_COM                    43
#define PHY_665A_AR_RELEASE_MAJOR_VERSION_COM     4
#define PHY_665A_AR_RELEASE_MINOR_VERSION_COM     7
#define PHY_665A_AR_RELEASE_REVISION_VERSION_COM  0
#define PHY_665A_SW_MAJOR_VERSION_COM             1
#define PHY_665A_SW_MINOR_VERSION_COM             0
#define PHY_665A_SW_PATCH_VERSION_COM             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_COM != STD_AR_RELEASE_MAJOR_VERSION) || \
         (PHY_665A_AR_RELEASE_MINOR_VERSION_COM != STD_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Types.h and StandardTypes.h are different"
    #endif

    /* Check if current file and Gpt header file are of the same Autosar version */
    #if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_COM != GPT_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_AR_RELEASE_MINOR_VERSION_COM != GPT_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Types.c and Gpt.h are different"
    #endif

    /* Check if current file and CDD_Bms_common_Types header file are of the same Autosar version */
    #if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_COM != BMS_COMMON_TYPES_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_AR_RELEASE_MINOR_VERSION_COM != BMS_COMMON_TYPES_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Types.h and CDD_Bms_common_Types.h are different"
    #endif

    /* Check if current file and ComStack_Types header file are of the same Autosar version */
    #if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_COM != COMTYPE_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_AR_RELEASE_MINOR_VERSION_COM != COMTYPE_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Types.h and ComStack_Types.h are different"
    #endif
#endif

/* Check if this file and CDD_Phy_665a_Regs.h are of the same vendor */
#if (PHY_665A_VENDOR_ID_COM != PHY_665A_REGS_VENDOR_ID)
#error "CDD_Phy_665a_Types.h and CDD_Phy_665a_Regs.h have different vendor ids"
#endif

/* Check if current file and CDD_Phy_665a_Regs header file are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_COM != PHY_665A_REGS_AR_RELEASE_MAJOR_VERSION) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION_COM != PHY_665A_REGS_AR_RELEASE_MINOR_VERSION) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION_COM != PHY_665A_REGS_AR_RELEASE_REVISION_VERSION))
#error "AutoSar Version Numbers of CDD_Phy_665a_Types.h and CDD_Phy_665a_Regs.h are different"
#endif

/* Check if current file and CDD_Phy_665a_Regs header file are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION_COM != PHY_665A_REGS_SW_MAJOR_VERSION) || \
     (PHY_665A_SW_MINOR_VERSION_COM != PHY_665A_REGS_SW_MINOR_VERSION) || \
     (PHY_665A_SW_PATCH_VERSION_COM != PHY_665A_REGS_SW_PATCH_VERSION))
#error "Software Version Numbers of CDD_Phy_665a_Types.h and CDD_Phy_665a_Regs.h are different"
#endif

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/
/**
 * Macro used to define internal oscillator source for SPI Phy_665a devices.
*/
#if (defined PHY_665A_RC_OSC)
#error PHY_665A_RC_OSC is already defined
#endif
#define PHY_665A_RC_OSC                                     (0U)

/**
 * Macro used to define external oscillator source for SPI Phy_665a devices.
*/
#if (defined PHY_665A_XTAL_OSC)
#error PHY_665A_XTAL_OSC is already defined
#endif
#define PHY_665A_XTAL_OSC                                   (1U)

/**
 * Macro to define the size of the error buffers used for internal error logging. Must be a power of 2.
*/
#if (defined PHY_665A_ERR_BUFFER_SIZE)
#error PHY_665A_ERR_BUFFER_SIZE is already defined
#endif
#define PHY_665A_ERR_BUFFER_SIZE    (8U)

/*
 * Macro used for defining .the maximum number of TPL Port channels present for PHY_665A device
*/
#if (defined PHY_665A_TPL_PORT_MAX_CNT)
#error PHY_665A_TPL_PORT_MAX_CNT is already defined
#endif
#define PHY_665A_TPL_PORT_MAX_CNT        0x04U

/*
 * Macro used for defining .the maximum number of GPIO channels present for PHY_665A device
*/
#if (defined PHY_665A_MAX_NUM_GPIO_CHANNELS)
#error PHY_665A_MAX_NUM_GPIO_CHANNELS is already defined
#endif
#define PHY_665A_MAX_NUM_GPIO_CHANNELS        0x08

/*
 * Macro used for defining maximum number of ports possible in Phy_665a device
*/
#if (defined PHY_665A_MAX_TPL_PORT_CNT)
#error PHY_665A_MAX_TPL_PORT_CNT is already defined
#endif
#define PHY_665A_MAX_TPL_PORT_CNT        0x04U
/*
 * Macro used for defining  chain address.
*/
#if (defined PHY_665A_CHAIN_ADDRESS)
#error PHY_665A_CHAIN_ADDRESS is already defined
#endif
#define PHY_665A_CHAIN_ADDRESS                0x0U
/*
 * Macro used for defining  Schedule time for a timer event is a 0 value (indicating no scheduling).
*/
#if (defined PHY_665A_INVALID_SCHED_TIME_ZERO)
#error PHY_665A_INVALID_SCHED_TIME_ZERO is already defined
#endif
#define PHY_665A_INVALID_SCHED_TIME_ZERO              0x0U

/*
 * Macro used for defining  uneneumerated device address.
*/
#if (defined PHY_665A_UNENUM_DEVICE_ADDRESS)
#error PHY_665A_UNENUM_DEVICE_ADDRESS is already defined
#endif
#define PHY_665A_UNENUM_DEVICE_ADDRESS   0x00U

/*
 * Macro used for defining  device address.
*/
#if (defined PHY_665A_DEVICE_ADDRESS)
#error PHY_665A_DEVICE_ADDRESS is already defined
#endif
#define PHY_665A_DEVICE_ADDRESS               0x1U

/*
 * Macro used for defining internal MADD.
*/
#if (defined PHY_665A_MASTER_ADDRESS)
#error PHY_665A_MASTER_ADDRESS is already defined
#endif
#define PHY_665A_MASTER_ADDRESS               0x0U
/*
 * Macro used for defining Global chain address.
*/
#if (defined PHY_665A_GLOBAL_CHAIN_ADDRESS)
#error PHY_665A_GLOBAL_CHAIN_ADDRESS is already defined
#endif
#define PHY_665A_GLOBAL_CHAIN_ADDRESS             0x07U

/*
 * Macro used for defining Global device address.
*/
#if (defined PHY_665A_GLOBAL_DEVICE_ADDRESS)
#error PHY_665A_GLOBAL_DEVICE_ADDRESS is already defined
#endif
#define PHY_665A_GLOBAL_DEVICE_ADDRESS            0x3FU

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining TPL3 command offset.
*/
#if (defined PHY_665A_TPL3_CMD_OFFSET)
#error PHY_665A_TPL3_CMD_OFFSET is already defined
#endif
#define PHY_665A_TPL3_CMD_OFFSET              0x0EU
/*
 * Macro used for defining TPL3 command mask .
*/
#if (defined PHY_665A_TPL3_CMD_MASK)
#error PHY_665A_TPL3_CMD_MASK is already defined
#endif
#define PHY_665A_TPL3_CMD_MASK                0x3U
/*
 * Macro used for defining TPL3  register address offset.
*/
#if (defined PHY_665A_TPL3_REG_OFFSET)
#error PHY_665A_TPL3_REG_OFFSET is already defined
#endif
#define PHY_665A_TPL3_REG_OFFSET              0x0U
/*
 * Macro used for defining tpl3 master address offset .
*/
#if (defined PHY_665A_TPL3_MADD_OFFSET)
#error PHY_665A_TPL3_MADD_OFFSET is already defined
#endif
#define PHY_665A_TPL3_MADD_OFFSET             0x0DU
/*
 * Macro used for defining tpl3 master address mask .
*/
#if (defined PHY_665A_TPL3_MADD_MASK)
#error PHY_665A_TPL3_MADD_MASK is already defined
#endif
#define PHY_665A_TPL3_MADD_MASK             0x01U

/*
 * Macro used for defining tpl3 chain address offset.
*/
#if (defined PHY_665A_TPL3_CADD_OFFSET)
#error PHY_665A_TPL3_CADD_OFFSET is already defined
#endif
#define PHY_665A_TPL3_CADD_OFFSET             0x0AU
/*
 * Macro used for defining tpl3 chain address mask.
*/
#if (defined PHY_665A_TPL3_CADD_MASK)
#error PHY_665A_TPL3_CADD_MASK is already defined
#endif
#define PHY_665A_TPL3_CADD_MASK               0x07U
/*
 * Macro used for defining tpl3 device address mask .
*/
#if (defined PHY_665A_TPL3_DADD_MASK)
#error PHY_665A_TPL3_DADD_MASK is already defined
#endif
#define PHY_665A_TPL3_DADD_MASK               0x3FU
/*
 * Macro used for defining tpl3 device address offset.
*/
#if (defined PHY_665A_TPL3_DADD_OFFSET)
#error PHY_665A_TPL3_DADD_OFFSET is already defined
#endif
#define PHY_665A_TPL3_DADD_OFFSET             0x04U
/*
 * Macro used for defining tpl3 message count offset.
*/
#if (defined PHY_665A_TPL3_MSGCNT_OFFSET)
#error PHY_665A_TPL3_MSGCNT_OFFSET is already defined
#endif
#define PHY_665A_TPL3_MSGCNT_OFFSET           0x00U
/*
 * Macro used for defining tpl3 message data length offset.
*/
#if (defined PHY_665A_TPL3_DATALEN_OFFSET)
#error PHY_665A_TPL3_DATALEN_OFFSET is already defined
#endif
#define PHY_665A_TPL3_DATALEN_OFFSET          0x0EU

/*
 * Macro used for defining tpl3 message data length mask.
*/
#if (defined PHY_665A_TPL3_DATALEN_MASK)
#error PHY_665A_TPL3_DATALEN_MASK is already defined
#endif
#define PHY_665A_TPL3_DATALEN_MASK            0x03U
/*
 * Macro used for defining tpl3 message register address  offset.
*/
#if (defined PHY_665A_TPL3_RADD_OFFSET)
#error PHY_665A_TPL3_RADD_OFFSET is already defined
#endif
#define PHY_665A_TPL3_RADD_OFFSET             0x00U
/*
 * Macro used for defining tpl3 message register address mask.
*/
#if (defined PHY_665A_TPL3_RADD_MASK)
#error PHY_665A_TPL3_RADD_MASK is already defined
#endif
#define PHY_665A_TPL3_RADD_MASK               0x3FFFU
/*
 * Macro used for defining tpl3 message reserved bits offset.
*/
#if (defined PHY_665A_TPL3_RESERVED_OFFSET)
#error PHY_665A_TPL3_RESERVED_OFFSET is already defined
#endif
#define PHY_665A_TPL3_RESERVED_OFFSET         0x0BU
/*
 * Macro used for defining tpl3 message reserved bits mask.
*/
#if (defined PHY_665A_TPL3_RESERVED_MASK)
#error PHY_665A_TPL3_RESERVED_MASK is already defined
#endif
#define PHY_665A_TPL3_RESERVED_MASK           0x1FU
/*
 * Macro used for defining tpl3 message Pad offset.
*/
#if (defined PHY_665A_TPL3_PAD_OFFSET)
#error PHY_665A_TPL3_PAD_OFFSET is already defined
#endif
#define PHY_665A_TPL3_PAD_OFFSET              0x0AU
/*
 * Macro used for defining tpl3 message Pad mask.
*/
#if (defined PHY_665A_TPL3_PAD_MASK)
#error PHY_665A_TPL3_PAD_MASK is already defined
#endif
#define PHY_665A_TPL3_PAD_MASK                0x01U
/*
 * Macro used for defining tpl3 message response length offset.
*/
#if (defined PHY_665A_TPL3_RESPLEN_OFFSET)
#error PHY_665A_TPL3_RESPLEN_OFFSET is already defined
#endif
#define PHY_665A_TPL3_RESPLEN_OFFSET          0x08U
/*
 * Macro used for defining tpl3 message response length mask.
*/
#if (defined PHY_665A_TPL3_RESPLEN_MASK)
#error PHY_665A_TPL3_RESPLEN_MASK is already defined
#endif
#define PHY_665A_TPL3_RESPLEN_MASK            0x03U
/*
 * Macro used for defining tpl3 message number of registers(NRT) offset.
*/
#if (defined PHY_665A_TPL3_NUMREG_OFFSET)
#error PHY_665A_TPL3_NUMREG_OFFSET is already defined
#endif
#define PHY_665A_TPL3_NUMREG_OFFSET           0x00U
/*
 * Macro used for defining tpl3 message number of registers(NRT) mask.
*/
#if (defined PHY_665A_TPL3_NUMREG_MASK)
#error PHY_665A_TPL3_NUMREG_MASK is already defined
#endif
#define PHY_665A_TPL3_NUMREG_MASK             0xFFU
/*
 * Macro used for defining tpl3 message No operation command.
*/
#if (defined PHY_665A_TPL3_NOP_CMD)
#error PHY_665A_TPL3_NOP_CMD is already defined
#endif
#define PHY_665A_TPL3_NOP_CMD                 0x00U
/*
 * Macro used for defining  tpl3 message read command.
*/
#if (defined PHY_665A_TPL3_READ_CMD)
#error PHY_665A_TPL3_READ_CMD is already defined
#endif
#define PHY_665A_TPL3_READ_CMD                0x01U
/*
 * Macro used for defining tpl3 message write command .
*/
#if (defined PHY_665A_TPL3_WRITE_CMD)
#error PHY_665A_TPL3_WRITE_CMD is already defined
#endif
#define PHY_665A_TPL3_WRITE_CMD               0x02U
/*
 * Macro used for defining tpl3 message response command.
*/
#if (defined PHY_665A_TPL3_RESPONSE_CMD)
#error PHY_665A_TPL3_RESPONSE_CMD is already defined
#endif
#define PHY_665A_TPL3_RESPONSE_CMD            0x03U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

/*
 * Macro used for defining for reading or writing one register in 665 device.
*/
#if (defined PHY_665A_ONE_REGISTER)
#error PHY_665A_ONE_REGISTER is already defined
#endif
#define PHY_665A_ONE_REGISTER                 0x00U
/*
 * Macro used for defining for reading or writing two register in 665 device.
*/
#if (defined PHY_665A_TWO_REGISTER)
#error PHY_665A_TWO_REGISTER is already defined
#endif
#define PHY_665A_TWO_REGISTER                 0x01U
/*
 * Macro used for defining for reading or writing three register in 665 device.
*/
#if (defined PHY_665A_THREE_REGISTER)
#error PHY_665A_THREE_REGISTER is already defined
#endif
#define PHY_665A_THREE_REGISTER               0x02U
/*
 * Macro used for defining for reading or writing four register in 665 device.
*/
#if (defined PHY_665A_FOUR_REGISTER)
#error PHY_665A_FOUR_REGISTER is already defined
#endif
#define PHY_665A_FOUR_REGISTER                 0x03U

/*
 * Macro used for defining for enabling of Padding.
*/
#if (defined PHY_665A_PAD_ENABLE)
#error PHY_665A_PAD_ENABLE is already defined
#endif
#define PHY_665A_PAD_ENABLE                   0x01U
/*
 * Macro used for defining for disabling of Padding.
*/
#if (defined PHY_665A_PAD_DISABLE)
#error PHY_665A_PAD_DISABLE is already defined
#endif
#define PHY_665A_PAD_DISABLE                  0x00U
/*
 * Macro used for defining  .
*/
#if (defined PHY_665A_READ_REQUEST_DATA_LEN)
#error PHY_665A_READ_REQUEST_DATA_LEN is already defined
#endif
#define PHY_665A_READ_REQUEST_DATA_LEN        0x00U
/*
 * Macro used for defining operand Sync low level field in schedule command register.
*/
#if (defined PHY_665A_LOWLEVEL)
#error PHY_665A_LOWLEVEL is already defined
#endif
#define PHY_665A_LOWLEVEL                     0x00U
/*
 * Macro used for defining operand Sync high level field in schedule command register.
*/
#if (defined PHY_665A_HIGHLEVEL)
#error PHY_665A_HIGHLEVEL is already defined
#endif
#define PHY_665A_HIGHLEVEL                    0x01U
/*
 * Macro used for defining operand Sync rising edge level field in schedule command register.
*/
#if (defined PHY_665A_RISINGEDGE)
#error PHY_665A_RISINGEDGE is already defined
#endif
#define PHY_665A_RISINGEDGE                   0x02U
/*
 * Macro used for defining operand Sync falling edge level field in schedule command register.
*/
#if (defined PHY_665A_FALLINGEDGE)
#error PHY_665A_FALLINGEDGE is already defined
#endif
#define PHY_665A_FALLINGEDGE                  0x03U
/*
 * Macro used for defining operand Sync (command field) in schedule command register.
*/
#if (defined PHY_665A_COMMAND)
#error PHY_665A_COMMAND is already defined
#endif
#define PHY_665A_COMMAND                      0x04U

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
 * Macro used for defining origin of Tpl2 message(Master/Save).
*/
#if (defined PHY_665A_TPL2_MS_OFFSET)
#error PHY_665A_TPL2_MS_OFFSET is already defined
#endif
#define PHY_665A_TPL2_MS_OFFSET 0x0FU
/*
 * Macro used for defining of Tpl2 message Register address offset.
*/
#if (defined PHY_665A_TPL2_RADD_OFFSET)
#error PHY_665A_TPL2_RADD_OFFSET is already defined
#endif
#define PHY_665A_TPL2_RADD_OFFSET 0x08U
/*
 * Macro used for defining of Tpl2 message master address offset.
*/
#if (defined PHY_665A_TPL2_MADD_OFFSET)
#error PHY_665A_TPL2_MADD_OFFSET is already defined
#endif
#define PHY_665A_TPL2_MADD_OFFSET 0x07U
/*
 * Macro used for defining of Tpl2 message chain address offset.
*/
#if (defined PHY_665A_TPL2_CADD1_OFFSET)
#error PHY_665A_TPL2_CADD1_OFFSET is already defined
#endif
#define PHY_665A_TPL2_CADD1_OFFSET 0x06U
/*
 * Macro used for defining of Tpl2 message device address offset.
*/
#if (defined PHY_665A_TPL2_DADD_OFFSET)
#error PHY_665A_TPL2_DADD_OFFSET is already defined
#endif
#define PHY_665A_TPL2_DADD_OFFSET   0x00U

/*
 * Macro used for defining of Tpl2  message count offset.
*/
#if (defined PHY_665A_TPL2_MSCNT_OFFSET)
#error PHY_665A_TPL2_MSCNT_OFFSET is already defined
#endif
#define PHY_665A_TPL2_MSCNT_OFFSET   0x0CU
/*
 * Macro used for defining of Tpl2 message chain address offset.
*/
#if (defined PHY_665A_TPL2_CADD2_OFFSET)
#error PHY_665A_TPL2_CADD2_OFFSET is already defined
#endif
#define PHY_665A_TPL2_CADD2_OFFSET   0x0AU
/*
 * Macro used for defining of Tpl2 message command offset.
*/
#if (defined PHY_665A_TPL2_CMD_OFFSET)
#error PHY_665A_TPL2_CMD_OFFSET is already defined
#endif
#define PHY_665A_TPL2_CMD_OFFSET   0x08U

#if (defined PHY_665A_TPL2_CMD_MASK)
#error PHY_665A_TPL2_CMD_MASK is already defined
#endif
#define PHY_665A_TPL2_CMD_MASK   0x03U
/*
 * Macro used for defining of Tpl2 message Crc offset.
*/
#if (defined PHY_665A_TPL2_CRC_OFFSET)
#error PHY_665A_TPL2_CRC_OFFSET is already defined
#endif
#define PHY_665A_TPL2_CRC_OFFSET   0x00U
/*
 * Macro used for defining of Tpl2 message reserved parameter bits.
*/
#if (defined PHY_665A_TPL2_RESERVED)
#error PHY_665A_TPL2_RESERVED is already defined
#endif
#define PHY_665A_TPL2_RESERVED   0x00U
/*
 * Macro used for defining of Tpl2 message reserved offset .
*/
#if (defined PHY_665A_TPL2_RESERVED_OFFSET)
#error PHY_665A_TPL2_RESERVED_OFFSET is already defined
#endif
#define PHY_665A_TPL2_RESERVED_OFFSET   0x08U
/*
 * Macro used for defining no of Registers per Transaction(NRT) for Tpl2 message.
*/
#if (defined PHY_665A_TPL2_NRT_OFFSET)
#error PHY_665A_TPL2_NRT_OFFSET is already defined
#endif
#define PHY_665A_TPL2_NRT_OFFSET   0x00U
/*
 * Macro used for defining device address for Tpl2 message .
*/
#if (defined PHY_665A_TPL2_DADD)
#error PHY_665A_TPL2_DADD is already defined
#endif
#define PHY_665A_TPL2_DADD   0x01U
/*
 * Macro used for defining master/slave for Tpl2 message.
*/
#if (defined PHY_665A_TPL2_MS)
#error PHY_665A_TPL2_MS is already defined
#endif
#define PHY_665A_TPL2_MS   0x00U
/*
 * Macro used for defining chain address for Tpl2 message.
*/
#if (defined PHY_665A_TPL2_CADD1)
#error PHY_665A_TPL2_CADD1 is already defined
#endif
#define PHY_665A_TPL2_CADD1   0x00U
/*
 * Macro used for defining message count for Tpl2 message.
*/
#if (defined PHY_665A_TPL2_MSGCNT)
#error PHY_665A_TPL2_MSGCNT is already defined
#endif
#define PHY_665A_TPL2_MSGCNT   0x00U

/*
 * Macro used for defining chain address for Tpl2 messag.
*/
#if (defined PHY_665A_TPL2_CADD2)
#error PHY_665A_TPL2_CADD2 is already defined
#endif
#define PHY_665A_TPL2_CADD2   0x00U

/*
 * Macro used for defining first byte in tpl2 message  .
*/
#if (defined PHY_665A_TPL2_MESSGE_FIRST_BYTE)
#error PHY_665A_TPL2_MESSGE_FIRST_BYTE is already defined
#endif
#define PHY_665A_TPL2_MESSGE_FIRST_BYTE   0x00U
/*
 * Macro used for defining second byte in tpl2 message.
*/
#if (defined PHY_665A_TPL2_MESSGE_SECOND_BYTE)
#error PHY_665A_TPL2_MESSGE_SECOND_BYTE is already defined
#endif
#define PHY_665A_TPL2_MESSGE_SECOND_BYTE   0x01U
/*
 * Macro used for defining third  byte in tpl2 message.
*/
#if (defined PHY_665A_TPL2_MESSGE_THIRD_BYTE)
#error PHY_665A_TPL2_MESSGE_THIRD_BYTE is already defined
#endif
#define PHY_665A_TPL2_MESSGE_THIRD_BYTE   0x02U
/*
 * Macro used for defining fourth  byte in tpl2 message.
*/
#if (defined PHY_665A_TPL2_MESSGE_FOURTH_BYTE)
#error PHY_665A_TPL2_MESSGE_FOURTH_BYTE is already defined
#endif
#define PHY_665A_TPL2_MESSGE_FOURTH_BYTE   0x03U
/*
 * Macro used for defining fifth byte in tpl2 message.
*/
#if (defined PHY_665A_TPL2_MESSGE_FIFTH_BYTE)
#error PHY_665A_TPL2_MESSGE_FIFTH_BYTE is already defined
#endif
#define PHY_665A_TPL2_MESSGE_FIFTH_BYTE   0x04U
/*
 * Macro used for defining sixth byte in tpl2 message .
*/
#if (defined PHY_665A_TPL2_MESSGE_SIXTH_BYTE)
#error PHY_665A_TPL2_MESSGE_SIXTH_BYTE is already defined
#endif
#define PHY_665A_TPL2_MESSGE_SIXTH_BYTE   0x05U
/*
 * Macro used for defining .
*/
#if (defined PHY_665A_TPL2_CRC_UNCALCULATED)
#error PHY_665A_TPL2_CRC_UNCALCULATED is already defined
#endif
#define PHY_665A_TPL2_CRC_UNCALCULATED   0x00U
/*
 * Macro used for defining the no of position a value should be shifted to extract the MSB of a hextat.
*/
#if (defined PHY_665A_TPL2_MSG_BYTE_OFFSET)
#error PHY_665A_TPL2_MSG_BYTE_OFFSET is already defined
#endif
#define PHY_665A_TPL2_MSG_BYTE_OFFSET   0x08U
/*
 * Macro used for extracting the LSB of a hextat with mask set to FF .
*/
#if (defined PHY_665A_TPL2_MSG_BYTE_MASK)
#error PHY_665A_TPL2_MSG_BYTE_MASK is already defined
#endif
#define PHY_665A_TPL2_MSG_BYTE_MASK   0xFFU
/*
 * Macro used for defining  no of bytes present in Tpl2 message .
*/
#if (defined PHY_665A_TPL2_MSG_BYTE_MAX)
#error PHY_665A_TPL2_MSG_BYTE_MAX is already defined
#endif
#define PHY_665A_TPL2_MSG_BYTE_MAX   0x06U

/*
 * Macro used for defining tpl2 message response length offset.
*/
#if (defined PHY_665A_TPL2_RESPLEN_OFFSET)
#error PHY_665A_TPL2_RESPLEN_OFFSET is already defined
#endif
#define PHY_665A_TPL2_RESPLEN_OFFSET          0x08U
/*
 * Macro used for defining tpl2 message response length mask.
*/
#if (defined PHY_665A_TPL2_RESPLEN_MASK)
#error PHY_665A_TPL2_RESPLEN_MASK is already defined
#endif
#define PHY_665A_TPL2_RESPLEN_MASK            0x03U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

/*
 * Macro used for defining tpl3 message 128 bit  pad length(Tpl3 message with data information of 4 registers along with one uint16 word  for prefix).
*/
#if (defined PHY_665A_MSG_PREFIX_PAD_128_LEN)
#error PHY_665A_MSG_PREFIX_PAD_128_LEN is already defined
#endif
#define PHY_665A_MSG_PREFIX_PAD_128_LEN   0x08U

/*
 * Macro used for defining tpl3/tpl2 message 64 bit  pad length.
*/
#if (defined PHY_665A_MSG_PREFIX_PAD_64_LEN)
#error PHY_665A_MSG_PREFIX_PAD_64_LEN is already defined
#endif
#define PHY_665A_MSG_PREFIX_PAD_64_LEN   0x04U

/*
 * Macro used for defining tpl3 message 48 bit hextat count.
*/
#if (defined PHY_665A_MSG_TPL2_48_BIT_HEX_CNT)
#error PHY_665A_MSG_TPL2_48_BIT_HEX_CNT is already defined
#endif
#define PHY_665A_MSG_TPL2_48_BIT_HEX_CNT   0x03U

/*
 * Macro used for defining tpl3 message 64 bit hextat count.
*/
#if (defined PHY_665A_MSG_TPL3_64_BIT_HEX_CNT)
#error PHY_665A_MSG_TPL3_64_BIT_HEX_CNT is already defined
#endif
#define PHY_665A_MSG_TPL3_64_BIT_HEX_CNT   0x04U

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining tpl3 message 80 bit hextat count.
*/
#if (defined PHY_665A_MSG_TPL3_80_BIT_HEX_CNT)
#error PHY_665A_MSG_TPL3_80_BIT_HEX_CNT is already defined
#endif
#define PHY_665A_MSG_TPL3_80_BIT_HEX_CNT   0x05U
/*
 * Macro used for defining tpl3 message 96 bit hextat count.
*/
#if (defined PHY_665A_MSG_TPL3_96_BIT_HEX_CNT)
#error PHY_665A_MSG_TPL3_96_BIT_HEX_CNT is already defined
#endif
#define PHY_665A_MSG_TPL3_96_BIT_HEX_CNT   0x06U
/*
 * Macro used for defining tpl3 message 112 bit hextat count.
*/
#if (defined PHY_665A_MSG_TPL3_112_BIT_HEX_CNT)
#error PHY_665A_MSG_TPL3_112_BIT_HEX_CNT is already defined
#endif
#define PHY_665A_MSG_TPL3_112_BIT_HEX_CNT   0x07U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

/*
 * Macro used for defining tpl3 message 48 bit prefix type.
*/
#if (defined PHY_665A_MSG_TPL2_48_PREFIX_TYPE)
#error PHY_665A_MSG_TPL2_48_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_TPL2_48_PREFIX_TYPE   0x02U

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining tpl3 message 64 bit prefix type.
*/
#if (defined PHY_665A_MSG_TPL3_64_PREFIX_TYPE)
#error PHY_665A_MSG_TPL3_64_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_TPL3_64_PREFIX_TYPE   0x04U
/*
 * Macro used for defining tpl3 message 80 bit prefix type.
*/
#if (defined PHY_665A_MSG_TPL3_80_PREFIX_TYPE)
#error PHY_665A_MSG_TPL3_80_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_TPL3_80_PREFIX_TYPE   0x05U
/*
 * Macro used for defining tpl3 message 96 bit prefix type.
*/
#if (defined PHY_665A_MSG_TPL3_96_PREFIX_TYPE)
#error PHY_665A_MSG_TPL3_96_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_TPL3_96_PREFIX_TYPE   0x06U
/*
 * Macro used for defining tpl3 message 112 bit prefix type.
*/
#if (defined PHY_665A_MSG_TPL3_112_PREFIX_TYPE)
#error PHY_665A_MSG_TPL3_112_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_TPL3_112_PREFIX_TYPE   0x07U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

/*
 * Macro used for defining tpl3 message no message type.
*/
#if (defined PHY_665A_MSG_NO_MSG_PREFIX_TYPE)
#error PHY_665A_MSG_NO_MSG_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_NO_MSG_PREFIX_TYPE       0x01U
/*
 * Macro used for defining tpl3 message reserved 1 field of prefix.
*/
#if (defined PHY_665A_MSG_RESERVED_1_PREFIX_TYPE)
#error PHY_665A_MSG_RESERVED_1_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_RESERVED_1_PREFIX_TYPE       0x00U
/*
 * Macro used for defining tpl3 message reserved 2 field of prefix.
*/
#if (defined PHY_665A_MSG_RESERVED_2_PREFIX_TYPE)
#error PHY_665A_MSG_RESERVED_2_PREFIX_TYPE is already defined
#endif
#define PHY_665A_MSG_RESERVED_2_PREFIX_TYPE       0x03U

/*
 * Macro used for defining tpl3 message autobaud pattern offset.
*/
#if (defined PHY_665A_MSG_AUTOBAUD_PATTERN_OFFSET)
#error PHY_665A_MSG_AUTOBAUD_PATTERN_OFFSET is already defined
#endif
#define PHY_665A_MSG_AUTOBAUD_PATTERN_OFFSET       0x08U
/*
 * Macro used for defining tpl3 message prefix type offset .
*/
#if (defined PHY_665A_MSG_PREFIX_TYPE_OFFSET)
#error PHY_665A_MSG_PREFIX_TYPE_OFFSET is already defined
#endif
#define PHY_665A_MSG_PREFIX_TYPE_OFFSET        0x05U
/*
 * Macro used for defining tpl3 message prefix type mask .
*/
#if (defined PHY_665A_MSG_PREFIX_TYPE_MASK)
#error PHY_665A_MSG_PREFIX_TYPE_MASK is already defined
#endif
#define PHY_665A_MSG_PREFIX_TYPE_MASK          0x07U
/*
 * Macro used for defining tpl3 message parity offset.
*/
#if (defined PHY_665A_MSG_PARITY_OFFSET)
#error PHY_665A_MSG_PARITY_OFFSET is already defined
#endif
#define PHY_665A_MSG_PARITY_OFFSET         0x00U
/*
 * Macro used for defining tpl3 message parity mask.
*/
#if (defined PHY_665A_MSG_PARITY_MASK)
#error PHY_665A_MSG_PARITY_MASK is already defined
#endif
#define PHY_665A_MSG_PARITY_MASK       0x01U

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining tpl3 message hold offset.
*/
#if (defined PHY_665A_MSG_TPL3_HOLD_OFFSET)
#error PHY_665A_MSG_TPL3_HOLD_OFFSET is already defined
#endif
#define PHY_665A_MSG_TPL3_HOLD_OFFSET       0x01U
/*
 * Macro used for defining tpl3 message sync offset .
*/
#if (defined PHY_665A_MSG_TPL3_SYNC_OFFSET)
#error PHY_665A_MSG_TPL3_SYNC_OFFSET is already defined
#endif
#define PHY_665A_MSG_TPL3_SYNC_OFFSET       0x02U
/*
 * Macro used for defining tpl3 message reserved offset.
*/
#if (defined PHY_665A_MSG_TPL3_RESERVED_OFFSET)
#error PHY_665A_MSG_TPL3_RESERVED_OFFSET is already defined
#endif
#define PHY_665A_MSG_TPL3_RESERVED_OFFSET       0x03U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

/*
 * Macro used for defining message Spi autobad pattern (already shifted in its correct place).
*/
#if (defined PHY_665A_SPI_PREFIX_AUTOBAUD_PATTERN)
#error PHY_665A_SPI_PREFIX_AUTOBAUD_PATTERN is already defined
#endif
#define PHY_665A_SPI_PREFIX_AUTOBAUD_PATTERN       0x5500U

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
 * Macro used for extracting no of bits from a specific position and returning the value of the extracted bits.
*/
#if (defined PHY_665A_TPL2_MSG_FIELD)
#error defined PHY_665A_TPL2_MSG_FIELD is already defined
#endif
#define PHY_665A_TPL2_MSG_FIELD(value, bits, pos) ((((uint16)1 << (bits)) - 1U) & ((value) >> ((pos) - 1U)))

/*
 * Macro used for extracting DADD from a TPL2 message.
*/
#if (defined PHY_665A_READ_TPL2_DADD)
#error defined PHY_665A_READ_TPL2_DADD is already defined
#endif
#define PHY_665A_READ_TPL2_DADD(value) PHY_665A_TPL2_MSG_FIELD(value, PHY_665A_TPL2_DADD_BITS, PHY_665A_TPL2_DADD_POSTION)

/*
 * Macro used for extracting CADD from a TPL2 message.
*/
#if (defined PHY_665A_READ_TPL2_CADD)
#error defined PHY_665A_READ_TPL2_CADD is already defined
#endif
#define PHY_665A_READ_TPL2_CADD(value1,value2)\
(uint8)(((PHY_665A_TPL2_MSG_FIELD(value1, PHY_665A_TPL2_CADD2_BITS, PHY_665A_TPL2_CADD2_POSTION))<<2)\
|(PHY_665A_TPL2_MSG_FIELD(value2, PHY_665A_TPL2_CADD1_BITS, PHY_665A_TPL2_CADD1_POSTION)))
/*
 * Macro used for defining the position for  command in tpl2 messgage.
*/
#if (defined PHY_665A_TPL2_CMD_POSTION)
#error defined PHY_665A_TPL2_CMD_POSTION is already defined
#endif
#define PHY_665A_TPL2_CMD_POSTION 0x09U
/*
 * Macro used for defining no of bits for command in tpl2 messgage.
*/
#if (defined PHY_665A_TPL2_CMD_BITS)
#error defined PHY_665A_TPL2_CMD_BITS is already defined
#endif
#define PHY_665A_TPL2_CMD_BITS 0x02U
/*
 * Macro used for defining no of bits for chain address in tpl2 messgage.
*/
#if (defined PHY_665A_TPL2_CADD1_BITS)
#error defined PHY_665A_TPL2_CADD1_BITS is already defined
#endif
#define PHY_665A_TPL2_CADD1_BITS 0x02U
/*
 * Macro used for defining the position for chain address in tpl2 messgage.
*/
#if (defined PHY_665A_TPL2_CADD1_POSTION)
#error defined PHY_665A_TPL2_CADD1_POSTION is already defined
#endif
#define PHY_665A_TPL2_CADD1_POSTION 0x0BU
/*
 * Macro used for defining the no of bits  for chain address in tpl2 messgage .
*/
#if (defined PHY_665A_TPL2_CADD2_BITS)
#error defined PHY_665A_TPL2_CADD2_BITS is already defined
#endif
#define PHY_665A_TPL2_CADD2_BITS 0x01U
/*
 * Macro used for defining the no of bits  for device address in tpl2 messgage .
*/
#if (defined PHY_665A_TPL2_DADD_BITS)
#error defined PHY_665A_TPL2_DADD_BITS is already defined
#endif
#define PHY_665A_TPL2_DADD_BITS 0x06U
/*
 * Macro used for defining position for device address in tpl2 message.
*/
#if (defined PHY_665A_TPL2_DADD_POSTION)
#error defined PHY_665A_TPL2_DADD_POSTION is already defined
#endif
#define PHY_665A_TPL2_DADD_POSTION 0x01U

/*
 * Macro used for defining the no of bits  for device address in tpl2 messgage .
*/
#if (defined PHY_665A_TPL2_MADD_BITS)
#error defined PHY_665A_TPL2_MADD_BITS is already defined
#endif
#define PHY_665A_TPL2_MADD_BITS 0x01U
/*
 * Macro used for defining position for device address in tpl2 message.
*/
#if (defined PHY_665A_TPL2_MADD_POSTION)
#error defined PHY_665A_TPL2_MADD_POSTION is already defined
#endif
#define PHY_665A_TPL2_MADD_POSTION 0x08U

/*
 * Macro used for defining position for Register address in tpl2 message.
*/
#if (defined PHY_665A_TPL2_RADD_POSTION)
#error defined PHY_665A_TPL2_RADD_POSTION is already defined
#endif
#define PHY_665A_TPL2_RADD_POSTION 0x09U
/*
 * Macro used for defining the no of bits  for register address in tpl2 messgage .
*/
#if (defined PHY_665A_TPL2_RADD_BITS)
#error defined PHY_665A_TPL2_RADD_BITS is already defined
#endif
#define PHY_665A_TPL2_RADD_BITS 0x07U
/*
 * Macro used for defining position for chain address in tpl2 message.
*/
#if (defined PHY_665A_TPL2_CADD2_POSTION)
#error defined PHY_665A_TPL2_CADD2_POSTION is already defined
#endif
#define PHY_665A_TPL2_CADD2_POSTION 0x07U
/*
 * Macro used for defining the no of bits for no of Registers per Transaction(NRT).
*/
#if (defined PHY_665A_TPL2_NUMREG_BITS)
#error defined PHY_665A_TPL2_NUMREG_BITS is already defined
#endif
#define PHY_665A_TPL2_NUMREG_BITS 0x07U
/*
 * Macro used for defining the position for no of Registers per Transaction(NRT) in tpl2 messgage .
*/
#if (defined PHY_665A_TPL2_NUMREG_POSTION)
#error defined PHY_665A_TPL2_NUMREG_POSTION is already defined
#endif
#define PHY_665A_TPL2_NUMREG_POSTION 0x01U
/*
 * Macro used for defining tpl2 write command value.
*/
#if (defined PHY_665A_TPL2_WRITE_CMD)
#error defined PHY_665A_TPL2_WRITE_CMD is already defined
#endif
#define PHY_665A_TPL2_WRITE_CMD 0x02U
/*
 * Macro used for defining tpl2 read operation command value.
*/
#if (defined PHY_665A_TPL2_READ_CMD)
#error defined PHY_665A_TPL2_READ_CMD is already defined
#endif
#define PHY_665A_TPL2_READ_CMD 0x01U
/*
 * Macro used for defining tpl2 no operation command value.
*/
#if (defined PHY_665A_TPL2_NOP_CMD)
#error defined PHY_665A_TPL2_NOP_CMD is already defined
#endif
#define PHY_665A_TPL2_NOP_CMD 0x00U
/*
 * Macro used for defining  tpl2 global write command value.
*/
#if (defined PHY_665A_TPL2_GLBL_WRITE_CMD)
#error defined PHY_665A_TPL2_GLBL_WRITE_CMD is already defined
#endif
#define PHY_665A_TPL2_GLBL_WRITE_CMD 0x03U
/*
 * Macro used for defining  tpl2 DADD Mask.
*/
#if (defined PHY_665A_TPL2_DADD_MASK)
#error defined PHY_665A_TPL2_DADD_MASK is already defined
#endif
#define PHY_665A_TPL2_DADD_MASK 0x3FU
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

/*
 * Macro used for defining  I2C Control Register Read Data Mask.
*/
#if (defined PHY_665A_I2C_READ_MASK)
#error defined PHY_665A_I2C_READ_MASK is already defined
#endif
#define PHY_665A_I2C_READ_MASK 0x0FU
/*
 * Macro used for defining  I2C Control Register Read Data offset.
*/
#if (defined PHY_665A_I2C_READ_POS)
#error defined PHY_665A_I2C_READ_POS is already defined
#endif
#define PHY_665A_I2C_READ_POS       (8U)
/*
 * Macro used for defining  I2C Control Register Start Data Mask.
*/
#if (defined PHY_665A_I2C_START_MASK)
#error defined PHY_665A_I2C_START_MASK is already defined
#endif
#define PHY_665A_I2C_START_MASK 0x0FU
/*
 * Macro used for defining  I2C Control Register Start Data offset.
*/
#if (defined PHY_665A_I2C_START_POS)
#error defined PHY_665A_I2C_START_POS is already defined
#endif
#define PHY_665A_I2C_START_POS      (0U)
/*
 * Macro used for defining  I2C Control Register Stop Data Mask.
*/
#if (defined PHY_665A_I2C_STOP_MASK)
#error defined PHY_665A_I2C_STOP_MASK is already defined
#endif
#define PHY_665A_I2C_STOP_MASK 0x01U
/*
 * Macro used for defining  I2C Control Register Stop Data offset.
*/
#if (defined PHY_665A_I2C_STOP_POS)
#error defined PHY_665A_I2C_STOP_POS is already defined
#endif
#define PHY_665A_I2C_STOP_POS       (4U)
/*
 * Macro used for defining  I2C Number of Data Registers
*/
#if (defined PHY_665A_I2C_NUM_DATA_REG)
#error defined PHY_665A_I2C_NUM_DATA_REG is already defined
#endif
#define PHY_665A_I2C_NUM_DATA_REG 0x07U
/*
 * Macro used for defining  I2C Data Register Packing offset.
*/
#if (defined PHY_665A_I2C_DATA_BYTE_SHIFT)
#error defined PHY_665A_I2C_DATA_BYTE_SHIFT is already defined
#endif
#define PHY_665A_I2C_DATA_BYTE_SHIFT 0x08U

/*
 * Macro used for defining the length of Request/Response field of PduId
*/
#if (defined PHY_665A_PDU_ID_REQ_RESP_FIELD_LENGTH)
#error PHY_665A_PDU_ID_REQ_RESP_FIELD_LENGTH is already defined
#endif
#define PHY_665A_PDU_ID_REQ_RESP_FIELD_LENGTH 0x01U

/*
 * Macro used for defining the offset of Request/Response field of PduId
*/
#if (defined PHY_665A_PDU_ID_REQ_RESP_FIELD_OFFSET)
#error PHY_665A_PDU_ID_REQ_RESP_FIELD_OFFSET is already defined
#endif
#define PHY_665A_PDU_ID_REQ_RESP_FIELD_OFFSET 0x07U

/*
 * Macro used for defining the length of Hardware config Id field of PduId
*/
#if (defined PHY_665A_PDU_ID_HW_CONFIG_ID_FIELD_LENGTH)
#error PHY_665A_PDU_ID_HW_CONFIG_ID_FIELD_LENGTH is already defined
#endif
#define PHY_665A_PDU_ID_HW_CONFIG_ID_FIELD_LENGTH 0x04U

/*
 * Macro used for defining the offset of Hardware config Id field of PduId
*/
#if (defined PHY_665A_PDU_ID_HW_CONFIG_ID_FIELD_OFFSET)
#error PHY_665A_PDU_ID_HW_CONFIG_ID_FIELD_OFFSET is already defined
#endif
#define PHY_665A_PDU_ID_HW_CONFIG_ID_FIELD_OFFSET 0x03U

/*
 * Macro used for defining the length of TPL type field of PduId
*/
#if (defined PHY_665A_PDU_ID_TPL_TYPE_FIELD_LENGTH)
#error PHY_665A_PDU_ID_TPL_TYPE_FIELD_LENGTH is already defined
#endif
#define PHY_665A_PDU_ID_TPL_TYPE_FIELD_LENGTH 0x03U

/*
 * Macro used for defining the offset of TPL type field of PduId
*/
#if (defined PHY_665A_PDU_ID_TPL_TYPE_FIELD_OFFSET)
#error PHY_665A_PDU_ID_TPL_TYPE_FIELD_OFFSET is already defined
#endif
#define PHY_665A_PDU_ID_TPL_TYPE_FIELD_OFFSET 0x00U

/*
 * Macro used for defining if Pdu received is a request
*/
#if (defined PHY_665A_PDU_ID_REQUEST_MSG)
#error PHY_665A_PDU_ID_REQUEST_MSG is already defined
#endif
#define PHY_665A_PDU_ID_REQUEST_MSG 0x00U

/*
 * Macro used for defining if Pdu received is a response
*/
#if (defined PHY_665A_PDU_ID_RESPONSE_MSG)
#error PHY_665A_PDU_ID_RESPONSE_MSG is already defined
#endif
#define PHY_665A_PDU_ID_RESPONSE_MSG 0x01U

/*
 * Macro used for defining if Pdu received is no message
*/
#if (defined PHY_665A_PDU_ID_TPL_TYPE_NO_MESSAGE)
#error PHY_665A_PDU_ID_TPL_TYPE_NO_MESSAGE is already defined
#endif
#define PHY_665A_PDU_ID_TPL_TYPE_NO_MESSAGE 0x01U

/*
 * Macro used for defining if Pdu received is of TPL2 type of 48 bit length
*/
#if (defined PHY_665A_PDU_ID_TPL2_48_BIT_TYPE)
#error PHY_665A_PDU_ID_TPL2_48_BIT_TYPE is already defined
#endif
#define PHY_665A_PDU_ID_TPL2_48_BIT_TYPE 0x02U

/*
 * Macro used for defining if Pdu received is of TPL3 type of 64 bit length
*/
#if (defined PHY_665A_PDU_ID_TPL3_64_BIT_TYPE)
#error PHY_665A_PDU_ID_TPL3_64_BIT_TYPE is already defined
#endif
#define PHY_665A_PDU_ID_TPL3_64_BIT_TYPE 0x04U

/*
 * Macro used for defining if Pdu received is of TPL3 type of 80 bit length
*/
#if (defined PHY_665A_PDU_ID_TPL3_80_BIT_TYPE)
#error PHY_665A_PDU_ID_TPL3_80_BIT_TYPE is already defined
#endif
#define PHY_665A_PDU_ID_TPL3_80_BIT_TYPE 0x05U

/*
 * Macro used for defining if Pdu received is of TPL3 type of 96 bit length
*/
#if (defined PHY_665A_PDU_ID_TPL3_96_BIT_TYPE)
#error PHY_665A_PDU_ID_TPL3_96_BIT_TYPE is already defined
#endif
#define PHY_665A_PDU_ID_TPL3_96_BIT_TYPE 0x06U

/*
 * Macro used for defining if Pdu received is of TPL3 type of 112 bit length
*/
#if (defined PHY_665A_PDU_ID_TPL3_112_BIT_TYPE)
#error PHY_665A_PDU_ID_TPL3_112_BIT_TYPE is already defined
#endif
#define PHY_665A_PDU_ID_TPL3_112_BIT_TYPE 0x07U

/*
 * Macro used for defining if Sdu length derived from DLC 6(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_DLC_6)
#error PHY_665A_SDU_LENGTH_DLC_6 is already defined
#endif
#define PHY_665A_SDU_LENGTH_DLC_6 0x06

/*
 * Macro used for defining if Sdu length derived from DLC 8(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_DLC_8)
#error PHY_665A_SDU_LENGTH_DLC_8 is already defined
#endif
#define PHY_665A_SDU_LENGTH_DLC_8 0x08

/*
 * Macro used for defining if Sdu length derived from DLC 9(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_DLC_9)
#error PHY_665A_SDU_LENGTH_DLC_9 is already defined
#endif
#define PHY_665A_SDU_LENGTH_DLC_9 0x0C

/*
 * Macro used for defining if Sdu length derived from DLC 10(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_DLC_10)
#error PHY_665A_SDU_LENGTH_DLC_10 is already defined
#endif
#define PHY_665A_SDU_LENGTH_DLC_10 0x10

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
 * Macro used for defining if Sdu length as per payload length derived from TPL type of Tpl2 48bit(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_TPL2_48_BIT)
#error PHY_665A_SDU_LENGTH_TPL2_48_BIT is already defined
#endif
#define PHY_665A_SDU_LENGTH_TPL2_48_BIT PHY_665A_SDU_LENGTH_DLC_6
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

#if (STD_ON == BMS_COMMON_ENABLE_TPL3)
/*
 * Macro used for defining if Sdu length as per payload length derived from TPL type of Tpl3 64bit(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_TPL3_64_BIT)
#error PHY_665A_SDU_LENGTH_TPL3_64_BIT is already defined
#endif
#define PHY_665A_SDU_LENGTH_TPL3_64_BIT PHY_665A_SDU_LENGTH_DLC_8

/*
 * Macro used for defining if Sdu length as per payload length derived from TPL type of Tpl3 80bit(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_TPL3_80_BIT)
#error PHY_665A_SDU_LENGTH_TPL3_80_BIT is already defined
#endif
#define PHY_665A_SDU_LENGTH_TPL3_80_BIT PHY_665A_SDU_LENGTH_DLC_9

/*
 * Macro used for defining if Sdu length as per payload length derived from TPL type of Tpl3 96bit(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_TPL3_96_BIT)
#error PHY_665A_SDU_LENGTH_TPL3_96_BIT is already defined
#endif
#define PHY_665A_SDU_LENGTH_TPL3_96_BIT PHY_665A_SDU_LENGTH_DLC_9


/*
 * Macro used for defining if Sdu length as per payload length derived from TPL type of Tpl3 112bit(bytes)
*/
#if (defined PHY_665A_SDU_LENGTH_TPL3_112_BIT)
#error PHY_665A_SDU_LENGTH_TPL3_112_BIT is already defined
#endif
#define PHY_665A_SDU_LENGTH_TPL3_112_BIT PHY_665A_SDU_LENGTH_DLC_10
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL3)*/

/*
 * Macro used for defining Sys Port Params Value
*/
#if (defined PHY_665A_SYS_PORT_PARAM_ENABLED)
#error defined PHY_665A_SYS_PORT_PARAM_ENABLED is already defined
#endif
#define PHY_665A_SYS_PORT_PARAM_ENABLED 0x01U

/*
 * Macro used for defining Sys Port Params Value
*/
#if (defined PHY_665A_SYS_PORT_PARAM_DISABLED)
#error defined PHY_665A_SYS_PORT_PARAM_DISABLED is already defined
#endif
#define PHY_665A_SYS_PORT_PARAM_DISABLED 0x00U

/*
 * Macro used for defining Sys Port Params CADD Max Value
*/
#if (defined PHY_665A_SYS_PORT_PARAM_CADD_MAX)
#error defined PHY_665A_SYS_PORT_PARAM_CADD_MAX is already defined
#endif
#define PHY_665A_SYS_PORT_PARAM_CADD_MAX 0x07U

/*
 * Macro used for defining Sys Port Params Timeout Max Value
*/
#if (defined PHY_665A_SYS_PORT_PARAM_TIMEOUT_MAX)
#error defined PHY_665A_SYS_PORT_PARAM_TIMEOUT_MAX is already defined
#endif
#define PHY_665A_SYS_PORT_PARAM_TIMEOUT_MAX 0x3FU

/*
 * Macro used for defining Sys Port Params CADD Init Value
*/
#if (defined PHY_665A_SYS_PORT_PARAM_CADD_INIT)
#error defined PHY_665A_SYS_PORT_PARAM_CADD_INIT is already defined
#endif
#define PHY_665A_SYS_PORT_PARAM_CADD_INIT 0x00U

/*
 * Macro used for defining Maximum Number of SYS TPL Ports
*/
#if (defined PHY_665A_SYS_NUM_PORT_MAX)
#error defined PHY_665A_SYS_NUM_PORT_MAX is already defined
#endif
#define PHY_665A_SYS_NUM_PORT_MAX 0x04U
/*
 * Macro used for defining Maximum Number of SYS TPL Ports
*/
#if (defined PHY_665A_SYS_NUM_PORT_INIT)
#error defined PHY_665A_SYS_NUM_PORT_INIT is already defined
#endif
#define PHY_665A_SYS_NUM_PORT_INIT 0x00U
/*
 * Macro used for defining Maximum Number of Params for each SYS TPL Ports
*/
#if (defined PHY_665A_SYS_NUM_PORT_PARAMS_MAX)
#error defined PHY_665A_SYS_NUM_PORT_PARAMS_MAX is already defined
#endif
#define PHY_665A_SYS_NUM_PORT_PARAMS_MAX 0x09U
/*
 * Macro used for defining Init value of Number Params for each SYS TPL Ports
*/
#if (defined PHY_665A_SYS_NUM_PORT_PARAMS_INIT)
#error defined PHY_665A_SYS_NUM_PORT_PARAMS_INIT is already defined
#endif
#define PHY_665A_SYS_NUM_PORT_PARAMS_INIT 0x00U
/*
 * Macro used for defining Maximum Number of PortId's w.r.t TPL Ports
*/
#if (defined PHY_665A_SYS_NUM_PORT_ID_MAX)
#error defined PHY_665A_SYS_NUM_PORT_ID_MAX is already defined
#endif
#define PHY_665A_SYS_NUM_PORT_ID_MAX 0x03U
/*
 * Macro used for defining Maximum Number of UID Registers
*/
#if (defined PHY_665A_SYS_UID_REG_MAX)
#error defined PHY_665A_SYS_UID_REG_MAX is already defined
#endif
#define PHY_665A_SYS_UID_REG_MAX 0x03U

/*
 * Macro used for defining Max GPIO Channels
*/
#if (defined PHY_665A_GPIO_NUM_CHANNEL_MAX)
#error defined PHY_665A_GPIO_NUM_CHANNEL_MAX is already defined
#endif
#define PHY_665A_GPIO_NUM_CHANNEL_MAX 0x08U

#if (STD_ON == BMS_COMMON_ENABLE_TPL2)
/*
 * Macro used for defining tpl2 global write command value.
*/
#if (defined PHY_665A_TPL2_GLOBAL_WRITE_CMD)
#error defined PHY_665A_TPL2_GLOBAL_WRITE_CMD is already defined
#endif
#define PHY_665A_TPL2_GLOBAL_WRITE_CMD 0x03U
#endif /*(STD_ON == BMS_COMMON_ENABLE_TPL2)*/

/*
 * Macro used for defining tpl write command value.
*/
#if (defined PHY_665A_WRITE_CMD)
#error defined PHY_665A_WRITE_CMD is already defined
#endif
#define PHY_665A_WRITE_CMD 0x02U

/*
 * Macro used for defining tpl read operation command value.
*/
#if (defined PHY_665A_READ_CMD)
#error defined PHY_665A_READ_CMD is already defined
#endif
#define PHY_665A_READ_CMD 0x01U

/*
 * Macro used for defining tpl no operation command value.
*/
#if (defined PHY_665A_NOP_CMD)
#error defined PHY_665A_NOP_CMD is already defined
#endif
#define PHY_665A_NOP_CMD 0x00U

/*==================================================================================================
*                                              ENUMS
==================================================================================================*/
typedef enum
{
    PHY_665A_NOT_STARTED_SYNCHRONIZATION_STATE,
    PHY_665A_SYNC_FEATURE_START_ENCOUNTERED_STATE,
    PHY_665A_PENDING_SYNCHRONIZATION_STATE,
    PHY_665A_TRIGG_ENCOUNTERED_SYNCHRONIZATION_STATE,
    PHY_665A_FINISHED_SYNCHRONIZATION_STATE,
    PHY_665A_TRIGGER_NOT_FOUND_SYNCHRONIZATION_STATE,
    PHY_665A_FAILED_SYNCHRONIZATION_STATE,
    PHY_665A_QUEUE_FLUSH_ENCOUNTERED_SYNCHRONIZATION_STATE,
    PHY_665A_QUEUE_FLUSH_TRANSMITTED_SYNCHRONIZATION_STATE,
    PHY_665A_INVALID_STATE
}Phy_665a_SynchStateType;

typedef enum
{
    PHY_665A_INACTIVE_SYNCHRONIZATION_MODE,
    PHY_665A_ACTIVE_SOFTWARE_SYNCHRONIZATION_MODE,
    PHY_665A_ACTIVE_HARDWARE_SYNCHRONIZATION_MODE
}Phy_665a_SynchModeType;

typedef enum
{
    PHY_665A_MSG_BATCH_INIT,
    PHY_665A_MSG_BATCH_PROGRESS,
    PHY_665A_MSG_BATCH_FAILED,
    PHY_665A_MSG_BATCH_TIME_OUT,
    PHY_665A_MSG_BATCH_FINISHED,
}Phy_665a_BatchStatusType;

typedef enum
{
    PHY_665A_INTERNAL_TD,
    PHY_665A_EXTERNAL_TD
}Phy_665a_TdScopeType;
/*
 * Enum  type used for defining the type of Internal Message.
*/
typedef enum
{
    PHY_665A_INT_NOP_MSG = 0,
    PHY_665A_INT_WR_MSG,
    PHY_665A_INT_RD_MSG,
    PHY_665A_INT_RD_CRC_MSG
}Phy_665a_IntMsgType;

/*
 * Enum  type used for defining the protocol used for CAN communication(standard CAN or CANFD).
*/
typedef enum
{
    PHY_665A_STD_CAN = 0,
    PHY_665A_CAN_FD
}Phy_665a_CanProtType;

/*
 * Enum  type used for defining the speed protocol used for CAN communication.
*/
typedef enum
{
    PHY_665A_CAN250 = 0,
    PHY_665A_CAN500,
    PHY_665A_CAN1M,
    PHY_665A_CAN2M,
    PHY_665A_CAN5M
}Phy_665a_CanProtSpeedType;

/*
 * Enum  type used for events of PHY_665a  .
*/
typedef enum
{
    PHY_665A_REQQUEUELOW = 0,
    PHY_665A_REQQUEUEHIGH,
    PHY_665A_RSPQUEUELOW,
    PHY_665A_RSPQUEUEHIGH,
    PHY_665A_REQQUEUENOTLOW,
    PHY_665A_REQQUEUENOTHIGH,
    PHY_665A_RSPQUEUENOTLOW,
    PHY_665A_RSPQUEUENOTHIGH,
    PHY_665A_GENERALERR,
    PHY_665A_MCUIFERR,
    PHY_665A_TPL0ERR,
    PHY_665A_TPL1ERR,
    PHY_665A_TPL2ERR,
    PHY_665A_TPL3ERR,
    PHY_665A_WAKE
}Phy_665a_Event;

/**
 * Information about the MC33665 Initialization State
 * The enumeration contains the list of the supported states durring initalization phase
 * @implements Phy_665a_InitializationStateType_enum
 */
typedef enum
{
    PHY_665A_DEVICE_UNINITIALIZED = 0u,  /**<Device is not initialized>*/
    PHY_665A_INITIALIZATION_IN_PROGRESS, /**<Device initilazation in progress>*/
    PHY_665A_INITIALIZATION_FINISHED,    /**<Device initilazation is finished on all devices>*/
    PHY_665A_INITIALIZATION_FAILED,      /**<Reported if any MC33665SA device on failed to initialize>*/
    PHY_665A_INITIALIZATION_TIMED_OUT,   /**<Reported in case of communication timeout>*/
    PHY_665A_INVALID_DEVICE,             /**<Device configuration index is not valid>*/
    PHY_665A_DEVICE_WAKEUP               /**<Device is awake>*/
} Phy_665a_InitializationStateType;


typedef enum
{
    PHY_665A_SYNC_OPERATIONAL,   /**<HW queue is not blocked>*/
    PHY_665A_SYNC_HALTED         /**<Sync mechanism failed and HW queue is blocked>*/
} Phy_665a_SyncOpType;

/*
 * enum  type used for holding Interrupts of PHY_665a  .
*/
typedef enum
{
    PHY_665A_INT0 = 0,
    PHY_665A_INT1,
    PHY_665A_INT2,
    PHY_665A_INT3
}Phy_665a_InterruptType;

/*
 * enum  type used for holding Target modes of PHY_665a  .
*/
typedef enum
{
    PHY_665A_SLEEP = 0x0AU,
    PHY_665A_RESET = 0x14U
}Phy_665a_TargetModeType;
/**
 * enum  type used for holding clear message status of PHY_665a  .
*/
typedef enum
{
    PHY_665A_NOTHING = 0,       /**< Keep current REQUEST and RESPONSE hardware queues unaffected */
    PHY_665A_CLEAR              /**< Clear the REQUEST and RESPONSE hardware queues */
}Phy_665a_ClearMessageType;

/**
 * enum  type used for holding message enabled status of PHY_665a  .
*/
typedef enum
{
    PHY_665A_MSGDISABLED = 0,   /**< RESPONSE messages are sent as soon as available */
    PHY_665A_MSGENABLED         /**< HOLD is activated. RESPONSE messages are buffered until HOLD is released */
}Phy_665a_HoldMessageType;

/*
 * enum  type used for holding TPL register bitfiels that can be changed during run time by application of PHY_665a TPL ports.
*/
typedef enum
{
    TIMEOUT = 0,    /* TPL Port Response Timeout.           Range (1 : 63) [us * 10] */
    CADD,           /* TPL Port Chain Address.              Range (1 : 6) */
    MADD,           /* TPL Port Master Address.             Range (STD_OFF : STD_ON) */
    PROTOCOL,       /* TPL Port Type Selection.             Range (PHY_TPL2 : PHY_TPL3)*/
    ALLCHAINS,      /* TPL Port AllChains (CADD 7) support. Range (STD_OFF : STD_ON) */
    RX,             /* TPL Port Reception Enable.           Range (STD_OFF : STD_ON) */
    EN              /* TPL Port Enabled                     Range (STD_OFF : STD_ON) */
}Phy_665a_TplPortParamType;

/*
 * enum  type used for holding START bytes configuration for I2C_CTRL register.
*/
typedef enum
{
    PHY_665A_SEND = 0x00,
    PHY_665A_SEND_1 = 0x01,
    PHY_665A_SEND_14 = 0x0E,
    PHY_665A_SEND_MAX = 0x0F
}Phy_665a_Start_BytesType;

/*
 * enum  type used for holding read bytes configuration I2C_CTRL register.
*/
typedef enum
{
    PHY_665A_NO_READ = 0x00,
    PHY_665A_READ_1 = 0x01,
    PHY_665A_READ_15 = 0x0F
}Phy_665a_Read_BytesType;


/*!
 * Type used for holding  different communication protocol.
 * @implements Phy_665aMcuIfProtcol_Type_enum
*/
typedef enum
{
    PHY_665A_CAN = 0U,
    PHY_665A_SPI,
}Phy_665aMcuIfProtcol_Type;

/**
 * Type used for holding  different types of SPI variant.
 * @implements Phy_665aSpiVariant_Type_enum
 */
typedef enum
{
    PHY_665A_SINGLE_SPI_SINGLE_CS = 0,
    PHY_665A_DUAL_SPI_MASTER_SLAVE
} Phy_665aSpiVariant_Type;

/*
 * enum  type used for holding  different TPL ports .
*/
typedef enum
{
    PHY_665A_TPL_PORT_0 = 0,
    PHY_665A_TPL_PORT_1,
    PHY_665A_TPL_PORT_2,
    PHY_665A_TPL_PORT_3
}Phy_665a_TplPortType;

typedef enum
{
    PHY_665A_SPI_FREQ_8MHZ = 8000U,
    PHY_665A_SPI_FREQ_10MHZ = 9600U
}Phy_665a_SpiFrequencyType;

/**
 * @brief Enumerated type used for holding  Gpio channels.
*/
typedef enum
{
    PHY_665A_CHANNEL0 = 0,  /**< GPIO0 */
    PHY_665A_CHANNEL1,      /**< GPIO1 */
    PHY_665A_CHANNEL2,      /**< GPIO2 */
    PHY_665A_CHANNEL3,      /**< GPIO3 */
    PHY_665A_CHANNEL4,      /**< GPIO4 */
    PHY_665A_CHANNEL5,      /**< GPIO5 */
    PHY_665A_CHANNEL6,      /**< GPIO6 */
    PHY_665A_CHANNEL7       /**< GPIO7 */
}Phy_665a_Gpio_ChannelIdType;

/*
 * enum  type used for holding   configuration parameters for  Gpio channels .
*/
typedef enum
{
    PHY_665A_OUTEN = 0,
    PHY_665A_INPEN,
    PHY_665A_PDEN,
    PHY_665A_ODEN
}Phy_665a_Gpio_ConfigType;

typedef enum
{
    PHY_665A_CAN_MSG = 0U,
    PHY_665A_CAN_FD_MSG
}Phy_665a_TplCanMsgFrameType;

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*
 * structure  type used for holding events and its corresponding value of PHY_665a  .
*/
typedef struct
{
    Phy_665a_Event EventId;
    boolean Value;
}Phy_665a_EventValType;

/**
 * @brief Structure type used for holding interrupts and their corresponding event sources and event activation flag.
*/
typedef struct
{
    Phy_665a_InterruptType Interrupt_Id;                       /**< Holder for Phy_665a configured interrupt number */
    Phy_665a_EventValType* ConfigArray;                        /**< Pointer to an array of Phy_665a_EventValType. Holds event type and activation flag */
}Phy_665a_Event_Config_TblType;

/*
 * structure  type used for holding TPL register bitfiels that can be changed during run time by application  and their corresponding values of PHY_665a TPL ports.
*/

typedef struct
{
    Phy_665a_TplPortParamType TplPortParameter;
    uint8 TplPortParamValue;
}Phy_665a_TplPortParamCfgType;

/*
 * structure  type used for holding TPL configuration array pointer, and number of parameters to be updated
*/
typedef struct
{
    Phy_665a_TplPortParamCfgType* TplPortParamCfgArray;
    uint8 NumOfParam;
}Phy_665a_TplPortConfigType;

/**
 * @brief Structure type used for holding Mulitple TPL configuration array, number of ports and an array of TPL Port Id's to be updated
*/
typedef struct
{
    Phy_665a_TplPortConfigType* TplPortConfigArray;    /**< Pointer to an array of Phy_665a_TplPortConfigType */
    uint8 NumOfPorts;                                  /**< Holder for the Phy_665a number of TPL ports to be configured */
    Phy_665a_TplPortType* TplPortId;                   /**< Pointer to array of TPL port IDs to be updated. Array length should be exactly as the previous parameter, NumOfPorts */
}Phy_665a_TplNumPortConfigType;

/**
 * @brief Structure type used for referring I2C control register.
*/
typedef struct
{
    Phy_665a_Read_BytesType Read;      /**< READ bytes configuration for I2C_CTRL register */
    boolean Stop;                      /**< STOP bit configuration for I2C_CTRL register */
    Phy_665a_Start_BytesType Start;    /**< START bytes configuration for I2C_CTRL register */
} I2cConfigCtrlReg_Type;

/*
 * structure  type used for holding  number of responses  and the length of responses.
*/
typedef struct
{
    uint8 RespNum;
    uint8 Resplen;
}Phy_665a_RespLengthType;

/*
 * enum  type used for holding  Send internal request status.
*/


/*
 * structure  type used for holding  configuration parameters for  Gpio channels and its corresponding value  .
*/
typedef struct
{
    Phy_665a_Gpio_ConfigType Gpio_Config;
    boolean Gpio_Value;
}Phy_665a_Gpio_Config_RegType;

/**
 * @brief Structure  type used for holding  configuration parameters for  Gpio channels and number of paramters to be configured.
*/
typedef struct
{
    Phy_665a_Gpio_ChannelIdType Gpio_ChannelId;                           /**< Holds the GPIO channel number. */
    Phy_665a_Gpio_Config_RegType* Gpio_Config_Array; /**< Pointer to an array of GPIO parameters an their correspondent enablement flag. */
    uint8 NumParam;                                                       /**< Number of parameters in the upper array. */
}Phy_665a_Gpio_Config_TblType;

typedef struct
{
    Phy_665a_Gpio_ChannelIdType ChannelId;
    uint8 ChannelOutLevel;
}Phy_665a_Gpio_SetOutputType;

/*
 * structure type used for holding  Spi communication configuration parameters.
*/
typedef struct
{
    Phy_665aSpiVariant_Type SpiVariant;
    Phy_665a_SpiFrequencyType MasterRespSpifrequecy;
}Phy_665aSpiConfigType;
/*
 * structure type used for holding  Can communication configuration parameters.
*/
typedef struct
{
    Phy_665a_CanProtType      CanRespProtocol;
    Phy_665a_CanProtSpeedType CanRespProtocolSpeed;
    uint16                    CanIf48BitsTpl2CanReqPdu;
    uint16                    CanIf48BitsTpl2CanFdReqPdu;
    uint16                    CanIf64BitsTpl3CanReqPdu;
    uint16                    CanIf64BitsTpl3CanFdReqPdu;
    uint16                    CanIf80BitsTpl3CanFdReqPdu;
    uint16                    CanIf96BitsTpl3CanFdReqPdu;
    uint16                    CanIf112BitsTpl3CanFdReqPdu;
    uint16                    CanIf48BitsTpl2CanFdRspPdu;
    uint16                    CanIf64BitsTpl3CanFdRspPdu;
    uint16                    CanIf80BitsTpl3CanFdRspPdu;
    uint16                    CanIf96BitsTpl3CanFdRspPdu;
    uint16                    CanIf112BitsTpl3CanFdRspPdu;
}Phy_665aCanConfigType;

typedef struct
{
    Phy_665a_Gpio_ChannelIdType GpioChannelId;
    uint8 IcuChannel;
}Phy_665a_SideBandGpioIcuCfgType;

/*
 * structure type used for holding  communication configuration parameters for 665 device.
*/
typedef struct
{
    Phy_665aMcuIfProtcol_Type McuIfProtcol;
    const Phy_665a_SideBandGpioIcuCfgType* ReqLowConfigPtr;
    const Phy_665a_SideBandGpioIcuCfgType* RespHighConfigPtr;
    const Phy_665aSpiConfigType* SpiConfigPtr;
    const Phy_665aCanConfigType* CanConfigPtr;
    uint8 RequestQueueSize;
    boolean Gpio_Support;
    boolean I2c_Support;
    boolean SyncSignalEnabled;
    Phy_665a_Gpio_ChannelIdType SyncSignalChannel;
    Gpt_ChannelType GptChannel;
}Phy_665aConfig_Type;

/*
 * structure type used for holding  read parameter information.
*/
typedef struct
{
    uint16 Pad;
    uint16 RespLen;
    uint16 NumReg;
}Phy_665a_ReadParameterType;


/**
 * Structure type to hold instances for I2C,GPIO,System communication,Scheduling and event handler registers
 @implements Phy_665a_RegistersType_struct
*/
typedef struct
{
    PHY_665A_SYS_CFG_CRC_REG_Type SysCrcReg;
    PHY_665A_SYS_COM_CFG_REG_Type SysComCfgReg;
    PHY_665A_SYS_COM_TO_CFG_REG_Type SysComToCfgReg;
    PHY_665A_SYS_MODE_REG_Type SysModeReg;
    PHY_665A_SYS_PORTx_CFG_REG_Type SysPort0CfgReg;
    PHY_665A_SYS_PORTx_CFG_REG_Type SysPort1CfgReg;
    PHY_665A_SYS_PORTx_CFG_REG_Type SysPort2CfgReg;
    PHY_665A_SYS_PORTx_CFG_REG_Type SysPort3CfgReg;
    PHY_665A_SYS_HOST_COM_CFG_REG_Type SysHostComCfgReg;
    PHY_665A_SYS_SPI_CFG_REG_Type SysSpiReg;
    PHY_665A_SYS_CAN_CFG_REG_Type SysCanReg;
    PHY_665A_SYS_UART_CFG_REG_Type SysUartReg;
    PHY_665A_SYS_FLT_CFG_REG_Type SysFltReg;
    PHY_665A_SYS_VERSION_REG_Type SysVersionReg;
    PHY_665A_SYS_UID_LOW_REG_Type SysUidLowReg;
    PHY_665A_SYS_UID_MID_REG_Type SysUidMidReg;
    PHY_665A_SYS_UID_HIGH_REG_Type SysUidHighReg;
    PHY_665A_SYS_PROD_VER_REG_Type SysProdVerReg;
    PHY_665A_SYS_QUEUE_SIZE_REG_Type SysQueueSizeReg;
    PHY_665A_SYS_REQ_QUEUE_CFG_REG_Type SysReqQueueCfgReg;
    PHY_665A_SYS_RESP_QUEUE_CFG_REG_Type SysRspQueueCfgReg;
    PHY_665A_SYS_QUEUE_CTRL_REG_Type SysQueueCtrlReg;
    PHY_665A_SYS_QUEUE_STAT_REG_Type SysQueueStatReg;
    PHY_665A_EVH_CFG_CRC_REG_Type EvhCrcReg;
    PHY_665A_EVH_INT_SEL_REG_Type EvhInt0SelCfgReg;
    PHY_665A_EVH_INT_SEL_REG_Type EvhInt1SelCfgReg;
    PHY_665A_EVH_INT_SEL_REG_Type EvhInt2SelCfgReg;
    PHY_665A_EVH_INT_SEL_REG_Type EvhInt3SelCfgReg;
    PHY_665A_EVH_INT0_OUT_CFG_REG_Type EvhInt0OutCfgReg;
    PHY_665A_EVH_INT1_OUT_CFG_REG_Type EvhInt1OutCfgReg;
    PHY_665A_EVH_INT2_OUT_CFG_REG_Type EvhInt2OutCfgReg;
    PHY_665A_EVH_INT3_OUT_CFG_REG_Type EvhInt3OutCfgReg;
    PHY_665A_EVH_WAKEUP_CFG_REG_Type EvhWakeupCfgReg;
    PHY_665A_EVH_WAKEUP_REASON_REG_Type EvhWakeupRsnReg;
    PHY_665A_EVH_RST_REASON_REG_Type EvhRstRsnReg;
    PHY_665A_EVH_QUEUE_STAT_REG_Type EvhQueueStatReg;
    PHY_665A_EVH_GRP_ERR_STAT_REG_Type EvhGrpErrStatReg;
    PHY_665A_EVH_GENERAL_ERR_STAT_REG_Type EvhGeneralErrStatReg;
    PHY_665A_EVH_MCUIF_ERR_STAT_REG_Type EvhMcuIfErrStatReg;
    PHY_665A_EVH_TPL0_ERR_STAT_REG_Type EvhTPL0ErrStatReg;
    PHY_665A_EVH_TPL1_ERR_STAT_REG_Type EvhTPL1ErrStatReg;
    PHY_665A_EVH_TPL2_ERR_STAT_REG_Type EvhTPL2ErrStatReg;
    PHY_665A_EVH_TPL3_ERR_STAT_REG_Type EvhTPL3ErrStatReg;
    PHY_665A_EVH_ACC_ERR_REG_Type EvhAccStatReg;
    PHY_665A_SCHED_CMD_REG_Type SchedCmdReg;
    PHY_665A_SCHED_EVENT_REG_Type SchedEventReg;
    PHY_665A_SCHED_STAT_REG_Type SchedStatReg;
    PHY_665A_GPIO_CFG0_REG_Type GpioCfg0Reg;
    PHY_665A_GPIO_CFG1_REG_Type GpioCfg1Reg;
    PHY_665A_GPIO_OUT_REG_Type GpioOutReg;
    PHY_665A_GPIO_IN_REG_Type GpioInReg;
    PHY_665A_I2C_CFG_REG_Type I2cCfgReg;
    PHY_665A_I2C_CTRL_REG_Type I2cCtrlReg;
    PHY_665A_I2C_STAT_REG_Type I2cStatReg;
    PHY_665A_I2C_DATA0_REG_Type I2cData0Reg;
    PHY_665A_I2C_DATA1_REG_Type I2cData1Reg;
    PHY_665A_I2C_DATA2_REG_Type I2cData2Reg;
    PHY_665A_I2C_DATA3_REG_Type I2cData3Reg;
    PHY_665A_I2C_DATA4_REG_Type I2cData4Reg;
    PHY_665A_I2C_DATA5_REG_Type I2cData5Reg;
    PHY_665A_I2C_DATA6_REG_Type I2cData6Reg;
} Phy_665a_RegistersType;

/*
 * A structure to hold the Internal TD address and repective request and response buffer sizes.
*/
typedef struct
{
    Phy_TDType* IntTdAddr;
    uint16 IntTdReqBuffSize;
    uint16 IntTdRespBuffSize;
}Phy_665a_IntTdAddrBuffInfoType;

typedef struct
{
    uint8  RequestMsgLength;
    Phy_665a_TplCanMsgFrameType Phy_665a_TplCanMsgFrame;
}Phy_665a_TplCanMsgInfoType;

typedef struct
{
    uint8 TplType;
    uint8 SduLength;
    uint16 PduId;
} Phy_665a_CanIfRxPduCheckType;

typedef struct
{
    uint8 PduResponseFlg;
    uint8 PduTplType;
    uint8 PduSduRespLenToCpy;
}Phy_665a_CanPduIdInfoType;

typedef struct
{
    uint16* CanRespBuffPtr;
    uint8 CanCommonRespBuffIdx;
    uint16 SizeDestArr;
    Phy_665a_CanPduIdInfoType Phy_665a_CanPduIdInfo;
}Phy_665a_CanPduBufferInfoType;

typedef struct
{
    Phy_665aMcuIfProtcol_Type TdMcuIfProtcol;
    boolean InternalTdFlg;
}Phy_665a_TdMcuIfProtDevIdxInfoType;

typedef struct
{
    uint16* MsgArrPtr;
    uint8* MsgSizeArrPtr;
    uint8 MsgSizeArrIdxTx;
    uint8 MsgSizeArrIdxProcessed;
}Phy_665a_CommonBufferInfoType;

typedef struct
{
    Phy_TDType* TransactionDescriptor;
    Phy_ErrorStatusType* ErrorStatus;
    Phy_665aMcuIfProtcol_Type TdMcuIfProtcol;
    boolean InternalTdFlg;
}Phy_665a_QueueStructInfoType;

typedef struct
{
    uint8 QueueSize;
    const uint8 QueueFrontIdx;
    uint8 QueueRearIdx;
    Phy_665a_QueueStructInfoType* QueuePtr;
}Phy_665a_SwQueueType;

typedef struct
{
    uint16 ProcessedReqMsgToTransmit;
    uint8 RspMsgToReceive;
    uint16* BatchRespBuffPtr;
    uint8 BatchExpRespHex;
    uint32 BatchTimeToTimeout;
    Phy_665a_BatchStatusType BatchStatus;
    boolean BatchLastMsgSchedFlg;
    boolean BatchLastIntMsgRdCrCFlg;
}Phy_665a_MsgBatchInfoType;

typedef struct
{
    uint16 SchedCmdDelayTime;
    uint8 SchedCmdChainId;
    boolean SchedCmdAckFlg;
}Phy_665a_SchedCmdInfoStructType;

typedef struct
{
    uint16* CanRespBuffPtr;
    Phy_665a_CanPduIdInfoType Phy_665a_CanPduIdInfo;
}Phy_665a_CanExtMsgPduBufferInfoType;

typedef struct
{
    boolean SchedCmdLastMsgAckFlg;
    uint8 SchedCmdLastMsgCounter;
    uint32 SchedTimeLastMsgUs;
}Phy_665a_SchedCmdLastMsgSideBandInfoType;

/*
 * A global structure to hold the information about the Transaction Descriptor, Error status,
   Td Tx Finish status, communication scope and sleep command.
*/
typedef struct
{
    Phy_TDType* GlobalTransacDescrPtr;
    Phy_ErrorStatusType* GlobalErrorStatusPtr;
    Phy_665a_CommonBufferInfoType CommonReqInfo;
    Phy_665aMcuIfProtcol_Type McuIfProtcol;
    boolean GptExpectedFlag;
    boolean TxExpectedFlag;
    boolean RxExpectedFlag;
    boolean IcuReqExpectedFlag;
    boolean IcuRspExpectedFlag;
    boolean ProcessingFinishFlag;
    boolean TxFinishFlag;
    boolean InternalTdFlg;
    boolean PhySleepFlg;
    boolean LowReqIrqEnableFlg;
    boolean HighRespIrqEnableFlg;
    boolean SyncFeatureContinueFlg;
    boolean SyncFeatureQueueFlushTdFlg;
    boolean Phy_665a_PostSlotFillTimerFlag;
    boolean PreSyncSchedTimeWaitTdFlg;
    uint8 SchedTimeWaitCounter;
    uint8 SchedTimeRepetitionCounter;
    uint8 DevIdx;
    uint8 ReqQueueInterrCnt;
    uint8 SyncTdAllNumMsgProcessed;
    uint8 SyncTdAllNumMsgTx;
    uint8 SyncTdExtNumMsgProcessed;
    uint8 SyncTdExtNumMsgTx;
    uint8 SyncTdRespRx;
    uint8 SpiPhy_665a_GptInterrCnt;
    uint16 NumberOfProcessedInternalRequests;
    uint16 NumberOfProcessedExternalRequests;
    uint16 NumberOfProcessedRequests;
    uint16 NumberOfTransmittedRequests;
    uint16 NumberOfReceivedResponses;
    uint16 ReceivedResponsesDataSize;
    uint32 TdTimeout;
    Phy_665a_SchedCmdLastMsgSideBandInfoType Phy_665a_SchedCmdLastMsgSideBandInfo;
    Phy_665a_SchedCmdInfoStructType Phy_665a_SchedTimeStruct;
    Phy_665a_MsgBatchInfoType MsgBatchInfo;
}Phy_665a_GlobalInfoType;

typedef struct
{
    uint8 MsgCmdCode;
    uint8 MsgCadd;
    uint8 MsgMadd;
    uint8 MsgDadd;
}Phy_665a_MsgParamType;

typedef struct
{
    uint8 SendingPortRxCnt;
    uint8 OtherPortRxCnt;
    uint8 MirrorReqRxCnt;
}Phy_665a_LoopBckInfoType;

typedef struct
{
    Phy_665a_SynchModeType    SyncModeInfo;
    Phy_665a_SynchStateType   SyncStateInfo;
    uint8                     SyncDevIdx;
    Phy_665a_SyncOpType       SyncOpState;
    uint8                     SyncNumAllReqProcessed;
    uint8                     SyncNumAllReqTransmitted;
    uint8                     SyncNumExtReqProcessed;
    uint8                     SyncNumExtReqTransmitted;
    uint8                     SyncNumRespExpected;
    uint8                     SyncNumRespExpectedFixed;
    uint8                     SyncLowReqInterrCnt;
    uint8                     SyncNumberOfReadRequests;
    uint32                    SyncTimeOut;
} Phy_665a_SyncModeStateInfoType;

typedef struct
{
    uint8 CmdCode;
    uint8 DataLen;
    uint16 RegAddr;
    uint16* Data;
    uint16* Message;
    Phy_665a_ReadParameterType* ReadParameter;
} Phy_665a_TplMsgInfoType;

typedef struct
{
    uint8 ErrSource;
    uint8 ErrCode;
} Phy_665a_ErrDescriptorType;

typedef struct
{
    Phy_665a_ErrDescriptorType ErrBuff[PHY_665A_ERR_BUFFER_SIZE];
    uint8 WriteOffset;
} Phy_665a_ErrBuffStructType;

typedef struct
{
    uint8 Cmd;
    uint8 Madd;
    uint8 Cadd;
    uint8 Dadd;
    uint8 MsgCnt;
    uint8 DataLen;
    uint16 Radd;
    uint8 Pad;
    uint8 RespLen;
    uint8 NumReg;
} Phy_665a_TplIdentifiersType;

typedef struct
{
    uint16* RequestPtr;
    uint8 ReqLenHex;
    Phy_665a_MsgParamType* ReqMsgParam;
    Phy_MsgInfoType Encoding;
    uint16 NumRespBytesPerDevice;
    uint16 NumRespPerDevice;
    Phy_665a_LoopBckInfoType* LoopBckInfo;
    uint16 Radd;
    uint16 HoldTimingOperand;
}Phy_665a_UnPackReqMsgType;

typedef struct
{
    uint32 IfBitsPerTimeUnit;
    uint32 TplTxTime;
    uint32 TplRxTime;
    uint32 IfRxTime;
    uint32 IfTxTime;
}Phy_665a_IfTimeoutDescType;



/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_TYPES_H */
