/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_BMS_COMMON_H
#define CDD_BMS_COMMON_H

/**
*   @file    CDD_Bms_common.h
*
*   @addtogroup CDD_BMS_COMMON
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bms_common_Cfg.h"
#include "CDD_PhyIf.h"

#if (BMS_COMMON_ENABLE_TPL3_BJB1 == STD_ON)
#include "Tpl3Bjb1TypesDef.h"
#endif



/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/

#define BMS_COMMON_MODULE_ID                    255
#define BMS_COMMON_VENDOR_ID                    43
#define BMS_COMMON_AR_RELEASE_MAJOR_VERSION     4
#define BMS_COMMON_AR_RELEASE_MINOR_VERSION     7
#define BMS_COMMON_AR_RELEASE_REVISION_VERSION  0
#define BMS_COMMON_SW_MAJOR_VERSION             1
#define BMS_COMMON_SW_MINOR_VERSION             0
#define BMS_COMMON_SW_PATCH_VERSION             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if this header file and CDD_Bcc_775a_Cfg.h are of the same vendor */
#if (BMS_COMMON_VENDOR_ID != BMS_COMMON_VENDOR_ID_CFG)
#error "CDD_Bms_common.h and CDD_Bms_common_Cfg.h have different vendor ids"
#endif

/* Check if current file and CDD_Bcc_775a_Cfg header file are of the same Autosar version */
#if ((BMS_COMMON_AR_RELEASE_MAJOR_VERSION != BMS_COMMON_AR_RELEASE_MAJOR_VERSION_CFG) || \
    (BMS_COMMON_AR_RELEASE_MINOR_VERSION != BMS_COMMON_AR_RELEASE_MINOR_VERSION_CFG) || \
    (BMS_COMMON_AR_RELEASE_REVISION_VERSION != BMS_COMMON_AR_RELEASE_REVISION_VERSION_CFG)  \
    )
#error "AutoSar Version Numbers of CDD_Bms_common.h and CDD_Bms_common_Cfg.h are different"
#endif

/* Check if current file and CDD_Bcc_775a_Cfg header file are of the same Software version */
#if ((BMS_COMMON_SW_MAJOR_VERSION != BMS_COMMON_SW_MAJOR_VERSION_CFG) || \
    (BMS_COMMON_SW_MINOR_VERSION != BMS_COMMON_SW_MINOR_VERSION_CFG) || \
    (BMS_COMMON_SW_PATCH_VERSION != BMS_COMMON_SW_PATCH_VERSION_CFG)    \
    )
#error "Software Version Numbers of CDD_Bms_common.h and CDD_Bms_common_Cfg.h are different"
#endif

/* Check if this header file and CDD_PhyIf are of the same vendor */
#if (BMS_COMMON_VENDOR_ID != PHYIF_VENDOR_ID)
#error "CDD_Bms_common.h and CDD_PhyIf have different vendor ids"
#endif

/* Check if current file and CDD_PhyIf header file are of the same Autosar version */
#if ((BMS_COMMON_AR_RELEASE_MAJOR_VERSION != PHYIF_AR_RELEASE_MAJOR_VERSION) || \
    (BMS_COMMON_AR_RELEASE_MINOR_VERSION != PHYIF_AR_RELEASE_MINOR_VERSION) || \
    (BMS_COMMON_AR_RELEASE_REVISION_VERSION != PHYIF_AR_RELEASE_REVISION_VERSION)   \
    )
#error "AutoSar Version Numbers of CDD_Bms_common.h and CDD_PhyIf are different"
#endif

/* Check if current file and CDD_PhyIf header file are of the same Software version */
#if ((BMS_COMMON_SW_MAJOR_VERSION != PHYIF_SW_MAJOR_VERSION) || \
    (BMS_COMMON_SW_MINOR_VERSION != PHYIF_SW_MINOR_VERSION) || \
    (BMS_COMMON_SW_PATCH_VERSION != PHYIF_SW_PATCH_VERSION) \
    )
#error "Software Version Numbers of CDD_Bms_common.h and CDD_PhyIf are different"
#endif

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/
#if (BMS_COMMON_DEV_ERROR_DETECT == STD_ON)
/**
* @brief API service called with wrong parameter.
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates Parameter shall not be a NULL pointer.
*/
#define BMS_COMMON_E_PARAM_POINTER_U8         ((uint8)0x00u)

/**
* @brief API service called wrong TD state,the only valid state is PHY_TS_IDLE.
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates TD append operation.
*/
#define BMS_COMMON_E_TD_NOT_CLEARED_U8           ((uint8)0x01u)

/**
* @brief API service called with wrong parameter.
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates Trigger type for SYNC feature selection.
*/
#define BMS_COMMON_E_TRIG_INVALID_U8         ((uint8)0x02u)

/**
* @brief API service called with wrong timeout parameter.
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates TD Timeout value selection.
*/
#define BMS_COMMON_E_TIMEOUT_INVALID_U8         ((uint8)0x03u)

/**
* @brief API service called with invalid TD size.
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates TD Timeout value selection.
*/
#define BMS_COMMON_E_REQMSGNUM_INVALID_U8        ((uint8)0x04u)

/**
* @brief API service called with invalid phy index value
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates TD Timeout value selection.
*/
#define BMS_COMMON_E_PHYINDEX_INVALID_U8         ((uint8)0x05u)

/**
* @brief API service called with invalid TPL protocol
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates TD Timeout value selection.
*/
#define BMS_COMMON_E_ENCODING_INVALID_U8         ((uint8)0x06u)
/**
* @brief API service called with invalid chain or device address
*
* @implements Bms_Common_ErrorCodes_Define
*/
/*
* @violates ChainAddr and DevAddr addresses are not configuration-compliant.
*/
#define BMS_COMMON_E_INVALID_ADDR_U8             ((uint8)0x07u)

/* Service IDs */
#endif
/**
* @brief API service ID for Bms_TD_Send function.
* @details Parameters used when raising an error or exception.
*
*/
#define BMS_TD_SEND_ID_U8  ((uint8)0x00u)

/**
* @brief API service ID for Bms_TD_Clear function.
* @details Parameters used when raising an error or exception.
*
*/
#define BMS_TD_CLEAR_ID_U8   ((uint8)0x01u)

/**
* @brief API service ID for Bms_TD_InsertPhyEvent function.
* @details Parameters used when raising an error or exception.
*
*/
#define BMS_TD_INSERTPHYEVENT_ID_U8 ((uint8)0x02u)

#if (PHY_SYNC_FEATURE_SUPPORT == STD_ON)
/**
* @brief API service ID for Bms_TD_InsertPhySyncTrigger function.
* @details Parameters used when raising an error or exception.
*
*/
#define BMS_TD_INSERTPHYSYNCTRIGGER_ID_U8            ((uint8)0x03u)
#endif

#if (BMS_COMMON_ENABLE_TPL3 == STD_ON)
/**
* @brief API service ID for Bms_Common_Tpl3CalcCrc function.
* @details Parameters used when raising an error or exception.
*/
#define BMS_COMMON_TPL3CALCCRC_ID_U8      ((uint8)0x04u)
#endif

#if (BMS_COMMON_ENABLE_TPL2 == STD_ON)
/**
* @brief API service ID for Bms_Common_Tpl2CalcCrc function.
* @details Parameters used when raising an error or exception.
*/
#define BMS_COMMON_TPL2CALCCRC_ID_U8      ((uint8)0x05u)
#endif

/**
* @brief API service ID for Bms_TD_Cancel function.
* @details Parameters used when raising an error or exception.
*/
#define BMS_TD_CANCEL_ID_U8 ((uint8)0x06u)

/**
* @brief API service ID for Bms_TD_SetParamRuntime function.
* @details Parameters used when raising an error or exception.
*/
#define BMS_TD_SETPARAM_ID_U8 ((uint8)0x07u)

/**
* @brief API service ID for Bms_CommonRegWriteRequest function.
* @details Parameters used when raising an error or exception.
*/
#define BMS_COMMONREGWRITEREQUEST_ID_U8 ((uint8)0x08u)
/*==================================================================================================
*                                STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/
#define BMS_COMMON_START_SEC_CODE
#include "Bms_common_MemMap.h"

/*!
 * @brief     This function is used to send the transaction descriptor to PHY
 * @details
 *          - Sync or Async: Asynchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in]       BmsTD              Pointer to TD to send to PHY
 * @param[inout]    ErrorStatus     Pointer to transaction error status returned by PHY
 *
 * @return      Std_ReturnType
 * @retval      E_OK                Transaction descriptor was successfully sent to PHY.
 * @retval      E_NOT_OK            Transaction descriptor was not successfully sent to PHY.
 *
 */
Std_ReturnType Bms_TD_Send(const Bms_TDType *BmsTD,
                           Phy_ErrorStatusType *ErrorStatus
                          );

/*!
 * @brief   This function is used to cancel all TDs in Phy queue
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take
 *            care that there is no simultaneous usage of the same BmsTD parameter.
 *
 * @param[inout]       void
 *
 * @return      void
 */
void Bms_TD_CancelAll(void);

 /*!
 * @brief   This function is used to cancel a specific TD
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take
 *            care that there is no simultaneous usage of the same BmsTD parameter.
 *
 * @param[inout]       BmsTD              Pointer to TD.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The counters were cleared and the buffers were overwritten successfully.
 * @retval      E_NOT_OK            The counters were not cleared and the buffers were not overwritten successfully.
 *
 */
Std_ReturnType Bms_TD_Cancel(const Bms_TDType * BmsTD);

 /*!
 * @brief   This function is used to clear the counters and overwrite the buffers.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take
 *            care that there is no simultaneous usage of the same BmsTD parameter.
 *
 * @param[inout]       BmsTD              Pointer to TD.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The counters were cleared and the buffers were overwritten successfully.
 * @retval      E_NOT_OK            The counters were not cleared and the buffers were not overwritten successfully.
 *
 */
Std_ReturnType Bms_TD_Clear(const Bms_TDType * BmsTD);

 /*!
 * @brief   This function is used to insert a PHY event message into a transaction descriptor
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Non-Reentrant
 *
 * @param[inout]    BmsTD       Address to the transaction descriptor in which this operation will be appended.
 * @param[in]       TypeOfPhyEvent  Type of PHY event on which to send the next frame.
 * @param[in]       Operand         For PHY_TIMER and PHY_SPECIAL is time from end of last frame and the value should be expressed in
 *                                  microseconds with a resolution of 100us. PHY_SPECIAL ignores the port protocol config.
 *                                  For RSPQUEUEFREE is minimum number of free entries in response queue.
 *                                  For PHY_SYNC can take values from 0 to 3 in case of Hardware SYNC (0 = low level, 1 = high level,
 *                                  2 = falling edge, 3 = rising edge on PHY SYNC pin) and value 4 for Software SYNC
 *                                  (4 = command, write to SCHED_EVENT.SYNC to create a scheduling event)
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The PHY event message was inserted successfully into the transaction descriptor.
 * @retval      E_NOT_OK            The PHY event message was not inserted successfully into the transaction descriptor.
 *
 */
Std_ReturnType Bms_TD_InsertPhyEvent(const Bms_TDType* BmsTD,
                                     Phy_EventType TypeOfPhyEvent,
                                     uint16 Operand
                                    );

#if (PHY_SYNC_FEATURE_SUPPORT == STD_ON)
/*!
 * @brief   This function is used to send the trigger for PHY SYNC feature.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same BmsTD parameter.
 *
 * @param[inout]    BmsTD                   Address to the Bms transaction descriptor.
 * @param[in]       TypeOfPhyTrigger        Supported type of PHY SYNC trigger.
 * @param[in]       HWTrigData              Pointer to PHY hardware SYNC runtime info.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The trigger was sent successfully.
 * @retval      E_NOT_OK            The trigger was not sent successfully.
 *
 */
Std_ReturnType Bms_TD_InsertPhySyncTrigger(const Bms_TDType* BmsTD,
                                           Phy_SyncTrigType TypeOfPhyTrigger,
                                           const Phy_HwSyncDataType* PhyHwSyncData
                                          );
#endif /* PHY_SYNC_FEATURE_SUPPORT == STD_ON */

#if (BMS_COMMON_ENABLE_TPL2 == STD_ON)
/*!
 * @brief This function calculates the CRC for a TPL2 message.
 * @details - Sync or Async: Synchronous
 *          - Reentrancy:    Non-Reentrant
 *
 * @param[in] Data     Pointer to the message.
 * @param[in] dataSize The size of the message.
 *
 * @return CRC value.
 *
 */
uint8 Bms_Common_Tpl2CalcCrc(const uint8 *Data,
                             uint8 DataSize
                            );
#endif /* BMS_COMMON_ENABLE_TPL2 == STD_ON */

#if (BMS_COMMON_ENABLE_TPL3 == STD_ON)

#if (BMS_COMMON_ENABLE_TPL3_CMU1 == STD_ON)
Std_ReturnType Bcc_775a_MEM_Update(uint8 ChainAddr, 
                                   uint8 DevAddr,
                                   const Bms_MemMapMirrorType* MemMapData
                                  );
#endif

#if (BMS_COMMON_ENABLE_TPL3_CMU2 == STD_ON)
Std_ReturnType Bcc_774a_MEM_Update(uint8 ChainAddr, 
                                   uint8 DevAddr,
                                   const Bms_MemMapMirrorType* MemMapData
                                  );
#endif

#if (BMS_COMMON_ENABLE_TPL3_BJB1 == STD_ON)
Std_ReturnType Tpl3Bjb1_MEM_Update(uint8 ChainAddr, 
                                   uint8 DevAddr,
                                   const Bms_MemMapMirrorType* MemMapData
                                  );
#endif

/*!
 * @brief   This function is used to updated memory map for every device type from a given chain.
 * @details
 *          - Sync or Async:    Synchronous
 *          - Reentrancy:       Reentrant
 *
 * @param[in]       ChainConfig          Address to the Tpl3ChainConfing structure.
 * @param[in]       Chain                Value of needed chain.
 * @param[in]       Address              Value of address from Memory Mirror Map.
 * @param[in]       Data                 Value to be stored in Memory Mirror Map.
 * @return      Std_ReturnType
 * @retval      E_OK                 Memory Map Mirror was successfully updated for every device type from given chain
 * @retval      E_NOT_OK             Memory Map Mirror was not successfully updated for every device type from given chain
 */
Std_ReturnType Bms_CommonRegWriteRequest(const BmsTpl3ChainConfigType *ChainConfig,
                                         uint8 Chain,
                                         uint16 Address,
                                         uint16 Data
                                        );
/*!
 * @brief This function calculates the CRC for a TPL3 message.
 * @details
 *          - Sync or Async: Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same Data parameter.
 *
 * @param[in] Data     Pointer to the message.
 * @param[in] DataSize The size of the message.
 *
 * @return CRC value.
 *
 */
uint16 Bms_Common_Tpl3CalcCrc(const uint16 *Data,
                              uint8 DataSize
                             );
#endif /* BMS_COMMON_ENABLE_TPL3 == STD_ON */

/*!
 * @brief This function configures a custom set of parameters for the specified transaction descriptor.
 * @details
 *          - Sync or Async: Synchronous
 *          - Reentrancy:       Reentrant
 *            Usage of reentrant capability is only allowed if the callers take care
 *            that there is no simultaneous usage of the same Data parameter.
 *
 * @param[in] BmsTD         Address to the Bms transaction descriptor.
 * @param[in] ParamType     Selected parameter to be configured.
 * @param[in] ParamValue    Value of selected parameter to be configured.
 *
 * @return      Std_ReturnType
 * @retval      E_OK                The parameter was configured successfully.
 * @retval      E_NOT_OK            The parameter was not configured successfully.
 *
 */
Std_ReturnType Bms_TD_SetParamRuntime(const Bms_TDType* BmsTD,
                                      Phy_RuntimeParamType ParamType,
                                      uint32 ParamValue
                                     );

#define BMS_COMMON_STOP_SEC_CODE
#include "Bms_common_MemMap.h"

/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_BMS_COMMON_H */
