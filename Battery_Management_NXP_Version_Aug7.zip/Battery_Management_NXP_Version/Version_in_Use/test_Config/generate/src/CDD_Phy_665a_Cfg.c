/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file CDD_Phy_665a_Cfg.c
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif
/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Phy_665a_Cfg.h"
#include "CDD_Phy_665a_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_VENDOR_ID_CFG_C                    43
#define PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG_C     4
#define PHY_665A_AR_RELEASE_MINOR_VERSION_CFG_C     7
#define PHY_665A_AR_RELEASE_REVISION_VERSION_CFG_C  0
#define PHY_665A_SW_MAJOR_VERSION_CFG_C             1
#define PHY_665A_SW_MINOR_VERSION_CFG_C             0
#define PHY_665A_SW_PATCH_VERSION_CFG_C             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_VENDOR_ID_CFG_C != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_Cfg.c and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG_C != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION_CFG_C != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION_CFG_C != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_Cfg.c and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION_CFG_C != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_SW_MINOR_VERSION_CFG_C != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_SW_PATCH_VERSION_CFG_C != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_Cfg.c and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same vendor */
#if (PHY_665A_VENDOR_ID_CFG_C != PHY_665A_VENDOR_ID_CFG)
#error "CDD_Phy_665a_Cfg.c and CDD_Phy_665a_Cfg.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG_C != PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION_CFG_C != PHY_665A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION_CFG_C != PHY_665A_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of CDD_Phy_665a_Cfg.c and CDD_Phy_665a_Cfg.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Cfg.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION_CFG_C != PHY_665A_SW_MAJOR_VERSION_CFG) || \
     (PHY_665A_SW_MINOR_VERSION_CFG_C != PHY_665A_SW_MINOR_VERSION_CFG) || \
     (PHY_665A_SW_PATCH_VERSION_CFG_C != PHY_665A_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of CDD_Phy_665a_Cfg.c and CDD_Phy_665a_Cfg.h are different"
#endif

/*==================================================================================================
*                           LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/

/*==================================================================================================
*                                          LOCAL MACROS
==================================================================================================*/

/*==================================================================================================
*                                         LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                         LOCAL VARIABLES
==================================================================================================*/

/*==================================================================================================
*                                        GLOBAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                        GLOBAL VARIABLES
==================================================================================================*/

#define PHY_665A_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Phy_665a_MemMap.h"


/**
 * Structure to store the request queue low interrupt configuration of PHY_665a_device_0.
*/
static const Phy_665a_SideBandGpioIcuCfgType Phy_665a_Device0ReqQueueLowCfg =
{
    PHY_665A_CHANNEL0,
    PHY_665A_DEVICE_0_ICU_GPIO0
};

static const Phy_665aSpiConfigType Phy_665a_Device0_SpiConfig =
{
    PHY_665A_DUAL_SPI_MASTER_SLAVE,
    PHY_665A_SPI_FREQ_8MHZ
};

const Phy_665aConfig_Type Phy_665a_Devices[PHY_665A_NUMBER_OF_665A_DEVICES] =
{
    {
        PHY_665A_SPI, /* MC33665A device 0 communication protocol */
        &Phy_665a_Device0ReqQueueLowCfg, /* RequestQueueLow sideband configuration data for MC33665A device 0 */
        NULL_PTR, /* ResponseQueueHigh sideband not used for MC33665A device 0 configuration */
        &Phy_665a_Device0_SpiConfig, /* SPI interface configuration for MC33665A device 0 */
        NULL_PTR, /* CAN interface configuration is disabled for MC33665A device 0 */
        12, /* RequestQueue size for MC33665A device 0 */
        (boolean)TRUE, /* GPIO support for MC33665A device 0 */
        (boolean)FALSE, /* I2C support for MC33665A device 0 */
        (boolean)TRUE, /* HW SYNC signaling is enabled for MC33665A device 0 */
        PHY_665A_CHANNEL5, /* HW SYNC signaling GPIO channel for MC33665A device 0 */
        PHY_665A_DEVICE_0_GPT_CHANNEL_CONFIG /* GPT channel for MC33665A device 0 */
    }
};

const Phy_665a_RegistersType Phy_665a_RegistersRomTbl[PHY_665A_NUMBER_OF_665A_DEVICES] =
{
    {
        {
            .unsigned_access = 0x6719 /*Sys_Crc*/
        },
        {
            .unsigned_access = 0x1 /*Sys_Com_Cfg_Reg*/
        },
        {
            .unsigned_access = 0xa5ff /*Sys_Com_To_Cfg_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Sys_Mode_Reg*/
        },
        {
            .unsigned_access = 0xfcaf /*Sys_Port0_Cfg_Reg*/
        },
        {
            .unsigned_access = 0xfced /*Sys_Port1_Cfg_Reg*/
        },
        {
            .unsigned_access = 0xfd0f /*Sys_Port2_Cfg_Reg*/
        },
        {
            .unsigned_access = 0xfe2e /*Sys_Port3_Cfg_Reg*/
        },
        {
            .unsigned_access = 0x500 /*Sys_Host_Com_Cfg*/
        },
        {
            .unsigned_access = 0x601 /*Sys_Spi_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Sys_Can_Reg*/
        },
        {
            .unsigned_access = 0xc000 /*Sys_Uart_Reg*/
        },
        {
            .unsigned_access = 0x1111 /*Sys_Flt_Reg*/
        },
        {
            .unsigned_access = 0x100 /*Sys_Version_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Sys_Uid_Low_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Sys_Uid_Mid_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Sys_Uid_High_Reg*/
        },
        {
            .unsigned_access = 0x100 /*Sys_Prod_Ver_Reg*/
        },
        {
            .unsigned_access = 0xc /*Sys_Queue_Size*/
        },
        {
            .unsigned_access = 0xa02 /*Sys_Req_Queue_Cfg_Reg*/
        },
        {
            .unsigned_access = 0x800 /*Sys_Rsp_Queue_Cfg_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Sys_Queue_Ctrl_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Sys_Queue_Stat_Reg*/
        },
        {
            .unsigned_access = 0xf4f3 /*Evh_Crc*/
        },
        {
            .unsigned_access = 0x1 /*Evh_INT0SelCfgReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_INT1SelCfgReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_INT2SelCfgReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_INT3SelCfgReg*/
        },
        {
            .unsigned_access = 0xaf /*Evh_Int0OutCfgReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_Int1OutCfgReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_Int2OutCfgReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_Int3OutCfgReg*/
        },
        {
            .unsigned_access = 0x8010 /*Evh_WakeupCfgReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_WakeupRsnReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_RstRsnReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_QueueStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_GrpErrStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_GeneralErrStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_McuIfErrStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_TPL0ErrStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_TPL1ErrStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_TPL2ErrStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_TPL3ErrStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Evh_TPL3AccStatReg*/
        },
        {
            .unsigned_access = 0x0 /*Sched_CmdReg*/
        },
        {
            .unsigned_access = 0x0 /*Sched_EventReg*/
        },
        {
            .unsigned_access = 0x0 /*Sched_StatReg*/
        },
        {
            .unsigned_access = 0x2f00 /*Gpio_Cfg0_Reg*/
        },
        {
            .unsigned_access = 0xf000 /*Gpio_Cfg1_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Gpio_Out_Reg*/
        },
        {
            .unsigned_access = 0x0 /*Gpio_In_Reg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_CfgReg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_CtrlReg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_StatReg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_Data0Reg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_Data1Reg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_Data2Reg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_Data3Reg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_Data4Reg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_Data5Reg*/
        },
        {
            .unsigned_access = 0x0 /*I2C_Data6Reg*/
        }
    }
};

#define PHY_665A_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_UNSPECIFIED
#include "Phy_665a_MemMap.h"
#define PHY_665A_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_INIT_UNSPECIFIED
#include "Phy_665a_MemMap.h"
Phy_665a_RegistersType Phy_665a_RegistersRamTbl[PHY_665A_NUMBER_OF_665A_DEVICES] =
{
    {
        {
            .unsigned_access = PHY_665A_SYS_CFG_CRC_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_COM_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_COM_TO_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_MODE_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_PORT0_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_PORT1_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_PORT2_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_PORT3_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_HOST_COM_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_SPI_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_CAN_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_UART_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_FLT_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_VERSION_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_UID_LOW_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_UID_MID_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_UID_HIGH_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_PROD_VER_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_QUEUE_SIZE_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_REQ_QUEUE_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_RSP_QUEUE_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_QUEUE_CTRL_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SYS_QUEUE_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_CFG_CRC_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT0_SEL_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT1_SEL_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT2_SEL_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT3_SEL_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT0_OUT_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT1_OUT_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT2_OUT_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_INT3_OUT_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_WAKEUP_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_WAKEUP_REASON_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_RST_REASON_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_QUEUE_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_GRP_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_GENERAL_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_MCUIF_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_TPL0_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_TPL1_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_TPL2_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_TPL3_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_EVH_ACC_ERR_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SCHED_CMD_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SCHED_EVENT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_SCHED_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_GPIO_CFG0_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_GPIO_CFG1_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_GPIO_OUT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_GPIO_IN_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_CFG_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_CTRL_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_STAT_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_DATA0_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_DATA1_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_DATA2_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_DATA3_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_DATA4_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_DATA5_REG_DEFAULT
        },
        {
            .unsigned_access = PHY_665A_I2C_DATA6_REG_DEFAULT
        }
    }
};


/*
 * Array used for storing the synchronization state of all configured devices.
*/
Phy_665a_SyncModeStateInfoType Phy_665a_SyncState[PHY_665A_NUMBER_OF_665A_DEVICES] =
{
    {
        PHY_665A_INACTIVE_SYNCHRONIZATION_MODE,
        PHY_665A_NOT_STARTED_SYNCHRONIZATION_STATE,
        PHY_665A_DEVICE_CONFIG0,
        PHY_665A_SYNC_OPERATIONAL,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0xFFFFFFFFUL
    }
};

#define PHY_665A_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

static uint16 InternalTDConfig_0ReqBuffer[INTERNALTDCONFIG_0_REQ_BUFF_SIZE];
static uint16 InternalTDConfig_0RespBuffer[INTERNALTDCONFIG_0_RESP_BUFF_SIZE];
static uint16 InternalTDConfig_1ReqBuffer[INTERNALTDCONFIG_1_REQ_BUFF_SIZE];
static uint16 InternalTDConfig_1RespBuffer[INTERNALTDCONFIG_1_RESP_BUFF_SIZE];
static uint16 InternalTDConfig_2ReqBuffer[INTERNALTDCONFIG_2_REQ_BUFF_SIZE];
static uint16 InternalTDConfig_2RespBuffer[INTERNALTDCONFIG_2_RESP_BUFF_SIZE];
static uint16 InternalTDConfig_3ReqBuffer[INTERNALTDCONFIG_3_REQ_BUFF_SIZE];
static uint16 InternalTDConfig_3RespBuffer[INTERNALTDCONFIG_3_RESP_BUFF_SIZE];
#define PHY_665A_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

Phy_TDType InternalTDConfig_0 =
{
    {
        InternalTDConfig_0ReqBuffer,
        0U,
        0U
    },
    {
        InternalTDConfig_0RespBuffer,
        0U,
        0U
    },
    PHY_TPL3_VARIABLE,
    0U,
    PHY_TS_IDLE,
    1000UL,
    0
};


Phy_TDType InternalTDConfig_1 =
{
    {
        InternalTDConfig_1ReqBuffer,
        0U,
        0U
    },
    {
        InternalTDConfig_1RespBuffer,
        0U,
        0U
    },
    PHY_TPL2_FIXED_48L,
    0U,
    PHY_TS_IDLE,
    1000UL,
    0
};


Phy_TDType InternalTDConfig_2 =
{
    {
        InternalTDConfig_2ReqBuffer,
        0U,
        0U
    },
    {
        InternalTDConfig_2RespBuffer,
        0U,
        0U
    },
    PHY_TPL3_FIXED_64L,
    0U,
    PHY_TS_IDLE,
    1000UL,
    0
};


Phy_TDType InternalTDConfig_3 =
{
    {
        InternalTDConfig_3ReqBuffer,
        0U,
        0U
    },
    {
        InternalTDConfig_3RespBuffer,
        0U,
        0U
    },
    PHY_TPL3_VARIABLE,
    0U,
    PHY_TS_IDLE,
    1000UL,
    0
};

#define PHY_665A_STOP_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Phy_665a_MemMap.h"


#define PHY_665A_START_SEC_CONST_UNSPECIFIED
#include "Phy_665a_MemMap.h"

const Phy_665a_IntTdAddrBuffInfoType Phy_665a_InternalTdAdrrBuffInfoTbl[PHY_665A_INTERNAL_TD_MAX] =
{
    {
        &InternalTDConfig_0,
        INTERNALTDCONFIG_0_REQ_BUFF_SIZE,
        INTERNALTDCONFIG_0_RESP_BUFF_SIZE
    },
    {
        &InternalTDConfig_1,
        INTERNALTDCONFIG_1_REQ_BUFF_SIZE,
        INTERNALTDCONFIG_1_RESP_BUFF_SIZE
    },
    {
        &InternalTDConfig_2,
        INTERNALTDCONFIG_2_REQ_BUFF_SIZE,
        INTERNALTDCONFIG_2_RESP_BUFF_SIZE
    },
    {
        &InternalTDConfig_3,
        INTERNALTDCONFIG_3_REQ_BUFF_SIZE,
        INTERNALTDCONFIG_3_RESP_BUFF_SIZE
    }
};

#define PHY_665A_STOP_SEC_CONST_UNSPECIFIED
#include "Phy_665a_MemMap.h"



/*==================================================================================================
*                                    LOCAL FUNCTION PROTOTYPES
==================================================================================================*/

/*==================================================================================================
*                                         LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                        GLOBAL FUNCTIONS
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

