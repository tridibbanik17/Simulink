/**   
*   @file    Spi_PBcfg.c
*   @implements Spi_PBcfg.c_Artifact
*   @version 3.0.0
*
*   @brief   AUTOSAR Spi - Post-Build(PB) configuration file code template.
*   @details Code template for Post-Build(PB) configuration file generation.
*
*   @addtogroup SPI_DRIVER_CONFIGURATION Spi Driver Configuration
*   @{
*/
/*==================================================================================================
*   Project              : RTD AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : LPSPI
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 3.0.0
*   Build Version        : S32K3_RTD_3_0_0_D2303_ASR_REL_4_7_REV_0000_20230331
*
*   Copyright 2020 - 2023 NXP Semiconductors NXP
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "Spi.h"
#include "Spi_Ipw_MBDT_PBcfg.h"

#if (SPI_DISABLE_DEM_REPORT_ERROR_STATUS == STD_OFF)
#include "Dem.h"
#endif

/*==================================================================================================
*                                    SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define SPI_MBDT_MODULE_ID_PBCFG_C                        83
#define SPI_MBDT_VENDOR_ID_PBCFG_C                        43
#define SPI_MBDT_AR_RELEASE_MAJOR_VERSION_PBCFG_C         4
#define SPI_MBDT_AR_RELEASE_MINOR_VERSION_PBCFG_C         7

#define SPI_MBDT_AR_RELEASE_REVISION_VERSION_PBCFG_C      0
#define SPI_MBDT_SW_MAJOR_VERSION_PBCFG_C                 3
#define SPI_MBDT_SW_MINOR_VERSION_PBCFG_C                 0
#define SPI_MBDT_SW_PATCH_VERSION_PBCFG_C                 0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and SPI header file are of the same vendor */
#if (SPI_MBDT_VENDOR_ID_PBCFG_C != SPI_VENDOR_ID)
    #error "Spi_PBCfg.c and Spi.h have different vendor ids"
#endif
/* Check if current file and SPI header file are of the same Autosar version */
#if ((SPI_MBDT_AR_RELEASE_MAJOR_VERSION_PBCFG_C    != SPI_AR_RELEASE_MAJOR_VERSION) || \
     (SPI_MBDT_AR_RELEASE_MINOR_VERSION_PBCFG_C    != SPI_AR_RELEASE_MINOR_VERSION) || \
     (SPI_MBDT_AR_RELEASE_REVISION_VERSION_PBCFG_C != SPI_AR_RELEASE_REVISION_VERSION))
    #error "AutoSar Version Numbers of Spi_PBCfg.c and Spi.h are different"
#endif
/* Check if current file and SPI header file are of the same Software version */
#if ((SPI_MBDT_SW_MAJOR_VERSION_PBCFG_C != SPI_SW_MAJOR_VERSION) || \
     (SPI_MBDT_SW_MINOR_VERSION_PBCFG_C != SPI_SW_MINOR_VERSION) || \
     (SPI_MBDT_SW_PATCH_VERSION_PBCFG_C != SPI_SW_PATCH_VERSION))
    #error "Software Version Numbers of Spi_PBCfg.c and Spi.h are different"
#endif

/* Check if current file and SPI header file are of the same vendor */
#if (SPI_MBDT_VENDOR_ID_PBCFG_C != SPI_IPW_VENDOR_ID_MBDT_PBCFG_H)
    #error "Spi_PBCfg.c and Spi_Ipw_PBCfg.h have different vendor ids"
#endif
/* Check if current file and SPI header file are of the same Autosar version */
#if ((SPI_MBDT_AR_RELEASE_MAJOR_VERSION_PBCFG_C    != SPI_IPW_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_H) || \
     (SPI_MBDT_AR_RELEASE_MINOR_VERSION_PBCFG_C    != SPI_IPW_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_H) || \
     (SPI_MBDT_AR_RELEASE_REVISION_VERSION_PBCFG_C != SPI_IPW_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_H ))
    #error "AutoSar Version Numbers of Spi_PBCfg.c and Spi_Ipw_PBCfg.h are different"
#endif
/* Check if current file and SPI header file are of the same Software version */
#if ((SPI_MBDT_SW_MAJOR_VERSION_PBCFG_C != SPI_IPW_SW_MAJOR_VERSION_MBDT_PBCFG_H) || \
     (SPI_MBDT_SW_MINOR_VERSION_PBCFG_C != SPI_IPW_SW_MINOR_VERSION_MBDT_PBCFG_H) || \
     (SPI_MBDT_SW_PATCH_VERSION_PBCFG_C != SPI_IPW_SW_PATCH_VERSION_MBDT_PBCFG_H))
    #error "Software Version Numbers of Spi_PBCfg.c and Spi_Ipw_PBCfg.h are different"
#endif

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
#if (SPI_DISABLE_DEM_REPORT_ERROR_STATUS == STD_OFF)
/* Check if current file and Dem.h file are of the same Autosar version */
#if ((SPI_MBDT_AR_RELEASE_MAJOR_VERSION_PBCFG_C    != DEM_AR_RELEASE_MAJOR_VERSION) || \
     (SPI_MBDT_AR_RELEASE_MINOR_VERSION_PBCFG_C    != DEM_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of Spi_PBCfg.c and Dem.h are different"
#endif
#endif
#endif

/*==================================================================================================
*                         LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                       LOCAL MACROS
==================================================================================================*/
/*==================================================================================================
*                                  LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                      GLOBAL FUNCTIONS
==================================================================================================*/
#define SPI_START_SEC_CODE
#include "Spi_MemMap.h"

/* List Of Notification Functions */
/* Job start/end Notifications */
/* Sequence End Notifications */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_1 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_2 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_3 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_4 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_5 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_6 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_7 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_8 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_9 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_10 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_11 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_12 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_13 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_14 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_15 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_16 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_17 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_18 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_19 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_20 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_21 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_22 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_23 */
extern void Phy_665a_SpiTxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_24 */
extern void Phy_665a_SpiRxSeqNotif(void); /* End Notification for Sequence SpiSequence_PHY_Rx */

#define SPI_STOP_SEC_CODE
#include "Spi_MemMap.h"
/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/

/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/
#if ((SPI_DMA_USED == STD_ON) && \
    ((SPI_LEVEL_DELIVERED == SPI_LEVEL1) || (SPI_LEVEL_DELIVERED == SPI_LEVEL2)))
    #define SPI_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
#else
    #define SPI_START_SEC_VAR_CLEARED_UNSPECIFIED
#endif /* ((SPI_DMA_USED == STD_ON) && ((SPI_LEVEL_DELIVERED == SPI_LEVEL1) ||
        (SPI_LEVEL_DELIVERED == SPI_LEVEL2))) */
#include "Spi_MemMap.h"

/* Buffers Descriptors for EB Channels and Allocate Buffers for IB Channels */
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_SBC, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_SBC, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_LSW, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_LSW, 4)
#endif
static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_TJA;
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_1, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_1, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_2, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_2, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_3, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_3, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_4, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_4, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_5, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_5, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_6, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_6, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_7, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_7, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_8, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_8, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_9, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_9, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_10, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_10, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_11, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_11, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_12, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_12, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_13, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_13, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_14, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_14, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_15, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_15, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_16, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_16, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_17, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_17, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_18, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_18, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_19, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_19, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_20, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_20, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_21, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_21, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_22, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_22, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_23, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_23, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_24, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_24, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_Rx, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_PHY_Rx, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000_2, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000_2, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000_3, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000_3, 4)
#endif
#if (CPU_TYPE == CPU_TYPE_64)
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000_4, 8)
#else
/** Compiler_Warning: It is intended for aligning memory. */
VAR_ALIGN(static Spi_BufferDescriptorType Spi_Buffer_MBDT_SpiChannel_HB2000_4, 4)
#endif

#if ((SPI_DMA_USED == STD_ON) && \
    ((SPI_LEVEL_DELIVERED == SPI_LEVEL1) || (SPI_LEVEL_DELIVERED == SPI_LEVEL2)))
    #define SPI_STOP_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
#else
    #define SPI_STOP_SEC_VAR_CLEARED_UNSPECIFIED
#endif /* ((SPI_DMA_USED == STD_ON) && ((SPI_LEVEL_DELIVERED == SPI_LEVEL1) ||
        (SPI_LEVEL_DELIVERED == SPI_LEVEL2))) */
#include "Spi_MemMap.h"

#define SPI_START_SEC_VAR_INIT_UNSPECIFIED
#include "Spi_MemMap.h"

/* Buffers Descriptors for IB Channels */

#define SPI_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Spi_MemMap.h"
/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/
#define SPI_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Spi_MemMap.h"

/* Channel Configuration */
/* Channel Configuration for SpiChannel_SBC */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_SBC_MBDT =
{
        EB,  /* BufferType IB or EB */
        32U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_FULL_DUPLEX,
              #endif
#endif

        (uint32)0U,  /* DefaultTransmitValue (configured) */
        10U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_SBC, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[0U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_LSW */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_LSW_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_FULL_DUPLEX,
              #endif
#endif

        (uint32)0U,  /* DefaultTransmitValue (configured) */
        2U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_LSW, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[1U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_TJA */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_TJA_MBDT =
{
        EB,  /* BufferType IB or EB */
        8U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_FULL_DUPLEX,
              #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        2U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_TJA, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[2U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_HB2000 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_HB2000_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_FULL_DUPLEX,
              #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        10U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_HB2000, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[3U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_1 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_1_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_1, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[4U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_2 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_2_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_2, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[5U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_3 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_3_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_3, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[6U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_4 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_4_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_4, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[7U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_5 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_5_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_5, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[8U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_6 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_6_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_6, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[9U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_7 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_7_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_7, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[10U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_8 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_8_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_8, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[11U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_9 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_9_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_9, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[12U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_10 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_10_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_10, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[13U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_11 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_11_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_11, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[14U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_12 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_12_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_12, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[15U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_13 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_13_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_13, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[16U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_14 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_14_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_14, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[17U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_15 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_15_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_15, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[18U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_16 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_16_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_16, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[19U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_17 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_17_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_17, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[20U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_18 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_18_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_18, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[21U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_19 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_19_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_19, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[22U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_20 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_20_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_20, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[23U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_21 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_21_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_21, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[24U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_22 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_22_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_22, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[25U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_23 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_23_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_23, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[26U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_24 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_24_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_TRANSMIT,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_24, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[27U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_PHY_Rx */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_PHY_Rx_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_HALF_DUPLEX_RECEIVE,
          #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        1000U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_PHY_Rx, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[28U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_HB2000_2 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_HB2000_2_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_FULL_DUPLEX,
              #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        10U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_HB2000_2, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[29U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_HB2000_3 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_HB2000_3_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_FULL_DUPLEX,
              #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        10U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_HB2000_3, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[30U] /* ChannelState pointer */
};
/* Channel Configuration for SpiChannel_HB2000_4 */
static const Spi_ChannelConfigType Spi_ChannelConfig_SpiChannel_HB2000_4_MBDT =
{
        EB,  /* BufferType IB or EB */
        16U,   /* Frame size */
        (boolean)FALSE, /* Bite order, 1:LSB, 0: MSB */
#ifdef SPI_HALF_DUPLEX_MODE_SUPPORT
  #if (STD_ON == SPI_HALF_DUPLEX_MODE_SUPPORT)
            SPI_FULL_DUPLEX,
              #endif
#endif

        (uint32)1U,  /* DefaultTransmitValue (configured) */
        10U, /* length of buffer */
        &Spi_Buffer_MBDT_SpiChannel_HB2000_4, /* BufferDescriptor */
        SPI_SPURIOUS_CORE_ID_U32,  /* Core Id */
        &Spi_axSpiChannelState[31U] /* ChannelState pointer */
};
/* Spi_aChannelConfigList_MBDT Channel Configuration */
static const Spi_ChannelsCfgType Spi_aChannelConfigList_MBDT[32] =
{
    /* SpiChannel_SBC */
    {
        &Spi_ChannelConfig_SpiChannel_SBC_MBDT
    },
    /* SpiChannel_LSW */
    {
        &Spi_ChannelConfig_SpiChannel_LSW_MBDT
    },
    /* SpiChannel_TJA */
    {
        &Spi_ChannelConfig_SpiChannel_TJA_MBDT
    },
    /* SpiChannel_HB2000 */
    {
        &Spi_ChannelConfig_SpiChannel_HB2000_MBDT
    },
    /* SpiChannel_PHY_1 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_1_MBDT
    },
    /* SpiChannel_PHY_2 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_2_MBDT
    },
    /* SpiChannel_PHY_3 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_3_MBDT
    },
    /* SpiChannel_PHY_4 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_4_MBDT
    },
    /* SpiChannel_PHY_5 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_5_MBDT
    },
    /* SpiChannel_PHY_6 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_6_MBDT
    },
    /* SpiChannel_PHY_7 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_7_MBDT
    },
    /* SpiChannel_PHY_8 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_8_MBDT
    },
    /* SpiChannel_PHY_9 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_9_MBDT
    },
    /* SpiChannel_PHY_10 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_10_MBDT
    },
    /* SpiChannel_PHY_11 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_11_MBDT
    },
    /* SpiChannel_PHY_12 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_12_MBDT
    },
    /* SpiChannel_PHY_13 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_13_MBDT
    },
    /* SpiChannel_PHY_14 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_14_MBDT
    },
    /* SpiChannel_PHY_15 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_15_MBDT
    },
    /* SpiChannel_PHY_16 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_16_MBDT
    },
    /* SpiChannel_PHY_17 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_17_MBDT
    },
    /* SpiChannel_PHY_18 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_18_MBDT
    },
    /* SpiChannel_PHY_19 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_19_MBDT
    },
    /* SpiChannel_PHY_20 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_20_MBDT
    },
    /* SpiChannel_PHY_21 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_21_MBDT
    },
    /* SpiChannel_PHY_22 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_22_MBDT
    },
    /* SpiChannel_PHY_23 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_23_MBDT
    },
    /* SpiChannel_PHY_24 */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_24_MBDT
    },
    /* SpiChannel_PHY_Rx */
    {
        &Spi_ChannelConfig_SpiChannel_PHY_Rx_MBDT
    },
    /* SpiChannel_HB2000_2 */
    {
        &Spi_ChannelConfig_SpiChannel_HB2000_2_MBDT
    },
    /* SpiChannel_HB2000_3 */
    {
        &Spi_ChannelConfig_SpiChannel_HB2000_3_MBDT
    },
    /* SpiChannel_HB2000_4 */
    {
        &Spi_ChannelConfig_SpiChannel_HB2000_4_MBDT
    }
};

/* Channel Assignment of Jobs */
/* SpiJob_SBC */
static const Spi_ChannelType Spi_SpiJob_SBC_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_SBC
};
/* SpiJob_LSW */
static const Spi_ChannelType Spi_SpiJob_LSW_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_LSW
};
/* SpiJob_TJA */
static const Spi_ChannelType Spi_SpiJob_TJA_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_TJA
};
/* SpiJob_HB2000_1 */
static const Spi_ChannelType Spi_SpiJob_HB2000_1_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_HB2000
};
/* SpiJob_HB2000_2 */
static const Spi_ChannelType Spi_SpiJob_HB2000_2_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_HB2000
};
/* SpiJob_HB2000_3 */
static const Spi_ChannelType Spi_SpiJob_HB2000_3_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_HB2000
};
/* SpiJob_HB2000_4 */
static const Spi_ChannelType Spi_SpiJob_HB2000_4_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_HB2000
};
/* SpiJob_PHY_665A_Tx1 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx1_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_1
};
/* SpiJob_PHY_665A_Tx2 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx2_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_2
};
/* SpiJob_PHY_665A_Tx3 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx3_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_3
};
/* SpiJob_PHY_665A_Tx4 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx4_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_4
};
/* SpiJob_PHY_665A_Tx5 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx5_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_5
};
/* SpiJob_PHY_665A_Tx6 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx6_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_6
};
/* SpiJob_PHY_665A_Tx7 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx7_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_7
};
/* SpiJob_PHY_665A_Tx8 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx8_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_8
};
/* SpiJob_PHY_665A_Tx9 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx9_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_9
};
/* SpiJob_PHY_665A_Tx10 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx10_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_10
};
/* SpiJob_PHY_665A_Tx11 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx11_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_11
};
/* SpiJob_PHY_665A_Tx12 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx12_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_12
};
/* SpiJob_PHY_665A_Tx13 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx13_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_13
};
/* SpiJob_PHY_665A_Tx14 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx14_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_14
};
/* SpiJob_PHY_665A_Tx15 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx15_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_15
};
/* SpiJob_PHY_665A_Tx16 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx16_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_16
};
/* SpiJob_PHY_665A_Tx17 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx17_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_17
};
/* SpiJob_PHY_665A_Tx18 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx18_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_18
};
/* SpiJob_PHY_665A_Tx19 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx19_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_19
};
/* SpiJob_PHY_665A_Tx20 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx20_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_20
};
/* SpiJob_PHY_665A_Tx21 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx21_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_21
};
/* SpiJob_PHY_665A_Tx22 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx22_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_22
};
/* SpiJob_PHY_665A_Tx23 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx23_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_23
};
/* SpiJob_PHY_665A_Tx24 */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Tx24_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_24
};
/* SpiJob_PHY_665A_Rx */
static const Spi_ChannelType Spi_SpiJob_PHY_665A_Rx_ChannelAssignment_MBDT[1] =
{
    SpiConf_SpiChannel_SpiChannel_PHY_Rx
};

/* Configuration of Jobs */
/* Job Configuration for SpiJob_SBC */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_SBC_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_SBC_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[0], /* JobState instance */
        CSIB0, /* HWUnit index */
        SPI_SpiExternalDevice_SBC, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_SBC] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_LSW */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_LSW_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_LSW_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[1], /* JobState instance */
        CSIB3, /* HWUnit index */
        SPI_SpiExternalDevice_LSW, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_LSW] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_TJA */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_TJA_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_TJA_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[2], /* JobState instance */
        CSIB5, /* HWUnit index */
        SPI_SpiExternalDevice_TJA, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_TJA] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_HB2000_1 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_HB2000_1_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_HB2000_1_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[3], /* JobState instance */
        CSIB4, /* HWUnit index */
        SPI_SpiExternalDevice_HB2000_1, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_HB2000_1] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_HB2000_2 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_HB2000_2_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_HB2000_2_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[4], /* JobState instance */
        CSIB4, /* HWUnit index */
        SPI_SpiExternalDevice_HB2000_2, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_HB2000_2] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_HB2000_3 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_HB2000_3_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_HB2000_3_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[5], /* JobState instance */
        CSIB4, /* HWUnit index */
        SPI_SpiExternalDevice_HB2000_3, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_HB2000_3] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_HB2000_4 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_HB2000_4_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_HB2000_4_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[6], /* JobState instance */
        CSIB4, /* HWUnit index */
        SPI_SpiExternalDevice_HB2000_4, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_HB2000_4] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx1 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx1_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx1_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[7], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx2 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx2_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx2_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[8], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx3 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx3_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx3_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[9], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx4 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx4_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx4_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[10], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx5 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx5_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx5_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[11], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx6 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx6_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx6_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[12], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx7 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx7_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx7_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[13], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx8 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx8_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx8_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[14], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx9 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx9_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx9_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[15], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx10 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx10_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx10_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[16], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx11 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx11_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx11_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[17], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx12 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx12_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx12_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[18], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx13 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx13_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx13_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[19], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx14 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx14_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx14_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[20], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx15 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx15_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx15_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[21], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx16 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx16_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx16_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[22], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx17 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx17_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx17_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[23], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx18 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx18_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx18_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[24], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx19 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx19_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx19_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[25], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx20 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx20_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx20_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[26], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx21 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx21_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx21_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[27], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx22 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx22_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx22_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[28], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx23 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx23_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx23_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[29], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Tx24 */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Tx24_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Tx24_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[30], /* JobState instance */
        CSIB2, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Tx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Tx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Job Configuration for SpiJob_PHY_665A_Rx */
static const Spi_JobConfigType Spi_JobConfig_SpiJob_PHY_665A_Rx_MBDT =
{
        (Spi_ChannelType)1U, /* NumChannels field */
        Spi_SpiJob_PHY_665A_Rx_ChannelAssignment_MBDT, /* List of Channels */
        NULL_PTR, /* End Notification */
        NULL_PTR, /* Start Notification */
        (sint8)0, /* Priority */
        SPI_SPURIOUS_CORE_ID_U32,    /* Core ID */
        &Spi_axSpiJobState[31], /* JobState instance */
        CSIB1, /* HWUnit index */
        SPI_SpiExternalDevice_PHY_665A_Rx, /* External Device */
        &Spi_aExternalDeviceConfigList_MBDT[SPI_SpiExternalDevice_PHY_665A_Rx] /* ExternalDeviceConfig - pointer to the external device configuration */
};
/* Spi_aJobConfigList_MBDT Job Configuration*/
static const Spi_JobsCfgType Spi_aJobConfigList_MBDT[32] =
{
    /* SpiJob_SBC */
    {
        &Spi_JobConfig_SpiJob_SBC_MBDT
    },
    /* SpiJob_LSW */
    {
        &Spi_JobConfig_SpiJob_LSW_MBDT
    },
    /* SpiJob_TJA */
    {
        &Spi_JobConfig_SpiJob_TJA_MBDT
    },
    /* SpiJob_HB2000_1 */
    {
        &Spi_JobConfig_SpiJob_HB2000_1_MBDT
    },
    /* SpiJob_HB2000_2 */
    {
        &Spi_JobConfig_SpiJob_HB2000_2_MBDT
    },
    /* SpiJob_HB2000_3 */
    {
        &Spi_JobConfig_SpiJob_HB2000_3_MBDT
    },
    /* SpiJob_HB2000_4 */
    {
        &Spi_JobConfig_SpiJob_HB2000_4_MBDT
    },
    /* SpiJob_PHY_665A_Tx1 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx1_MBDT
    },
    /* SpiJob_PHY_665A_Tx2 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx2_MBDT
    },
    /* SpiJob_PHY_665A_Tx3 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx3_MBDT
    },
    /* SpiJob_PHY_665A_Tx4 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx4_MBDT
    },
    /* SpiJob_PHY_665A_Tx5 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx5_MBDT
    },
    /* SpiJob_PHY_665A_Tx6 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx6_MBDT
    },
    /* SpiJob_PHY_665A_Tx7 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx7_MBDT
    },
    /* SpiJob_PHY_665A_Tx8 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx8_MBDT
    },
    /* SpiJob_PHY_665A_Tx9 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx9_MBDT
    },
    /* SpiJob_PHY_665A_Tx10 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx10_MBDT
    },
    /* SpiJob_PHY_665A_Tx11 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx11_MBDT
    },
    /* SpiJob_PHY_665A_Tx12 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx12_MBDT
    },
    /* SpiJob_PHY_665A_Tx13 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx13_MBDT
    },
    /* SpiJob_PHY_665A_Tx14 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx14_MBDT
    },
    /* SpiJob_PHY_665A_Tx15 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx15_MBDT
    },
    /* SpiJob_PHY_665A_Tx16 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx16_MBDT
    },
    /* SpiJob_PHY_665A_Tx17 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx17_MBDT
    },
    /* SpiJob_PHY_665A_Tx18 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx18_MBDT
    },
    /* SpiJob_PHY_665A_Tx19 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx19_MBDT
    },
    /* SpiJob_PHY_665A_Tx20 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx20_MBDT
    },
    /* SpiJob_PHY_665A_Tx21 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx21_MBDT
    },
    /* SpiJob_PHY_665A_Tx22 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx22_MBDT
    },
    /* SpiJob_PHY_665A_Tx23 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx23_MBDT
    },
    /* SpiJob_PHY_665A_Tx24 */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Tx24_MBDT
    },
    /* SpiJob_PHY_665A_Rx */
    {
        &Spi_JobConfig_SpiJob_PHY_665A_Rx_MBDT
    }
};

/* Job Assignment of Sequences  */
/* SpiSequence_SBC */
static const Spi_JobType Spi_SpiSequence_SBC_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_SBC 
};
/* SpiSequence_LSW */
static const Spi_JobType Spi_SpiSequence_LSW_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_LSW 
};
/* SpiSequence_TJA */
static const Spi_JobType Spi_SpiSequence_TJA_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_TJA 
};
/* SpiSequence_HB2000_1 */
static const Spi_JobType Spi_SpiSequence_HB2000_1_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_HB2000_1 
};
/* SpiSequence_HB2000_2 */
static const Spi_JobType Spi_SpiSequence_HB2000_2_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_HB2000_2 
};
/* SpiSequence_HB2000_3 */
static const Spi_JobType Spi_SpiSequence_HB2000_3_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_HB2000_3 
};
/* SpiSequence_HB2000_4 */
static const Spi_JobType Spi_SpiSequence_HB2000_4_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_HB2000_4 
};
/* SpiSequence_PHY_1 */
static const Spi_JobType Spi_SpiSequence_PHY_1_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 
};
/* SpiSequence_PHY_2 */
static const Spi_JobType Spi_SpiSequence_PHY_2_JobAssignment_MBDT[2] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 
};
/* SpiSequence_PHY_3 */
static const Spi_JobType Spi_SpiSequence_PHY_3_JobAssignment_MBDT[3] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 
};
/* SpiSequence_PHY_4 */
static const Spi_JobType Spi_SpiSequence_PHY_4_JobAssignment_MBDT[4] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 
};
/* SpiSequence_PHY_5 */
static const Spi_JobType Spi_SpiSequence_PHY_5_JobAssignment_MBDT[5] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 
};
/* SpiSequence_PHY_6 */
static const Spi_JobType Spi_SpiSequence_PHY_6_JobAssignment_MBDT[6] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 
};
/* SpiSequence_PHY_7 */
static const Spi_JobType Spi_SpiSequence_PHY_7_JobAssignment_MBDT[7] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 
};
/* SpiSequence_PHY_8 */
static const Spi_JobType Spi_SpiSequence_PHY_8_JobAssignment_MBDT[8] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 
};
/* SpiSequence_PHY_9 */
static const Spi_JobType Spi_SpiSequence_PHY_9_JobAssignment_MBDT[9] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 
};
/* SpiSequence_PHY_10 */
static const Spi_JobType Spi_SpiSequence_PHY_10_JobAssignment_MBDT[10] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 
};
/* SpiSequence_PHY_11 */
static const Spi_JobType Spi_SpiSequence_PHY_11_JobAssignment_MBDT[11] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 
};
/* SpiSequence_PHY_12 */
static const Spi_JobType Spi_SpiSequence_PHY_12_JobAssignment_MBDT[12] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 
};
/* SpiSequence_PHY_13 */
static const Spi_JobType Spi_SpiSequence_PHY_13_JobAssignment_MBDT[13] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 
};
/* SpiSequence_PHY_14 */
static const Spi_JobType Spi_SpiSequence_PHY_14_JobAssignment_MBDT[14] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 
};
/* SpiSequence_PHY_15 */
static const Spi_JobType Spi_SpiSequence_PHY_15_JobAssignment_MBDT[15] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 
};
/* SpiSequence_PHY_16 */
static const Spi_JobType Spi_SpiSequence_PHY_16_JobAssignment_MBDT[16] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 
};
/* SpiSequence_PHY_17 */
static const Spi_JobType Spi_SpiSequence_PHY_17_JobAssignment_MBDT[17] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 
};
/* SpiSequence_PHY_18 */
static const Spi_JobType Spi_SpiSequence_PHY_18_JobAssignment_MBDT[18] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx18 
};
/* SpiSequence_PHY_19 */
static const Spi_JobType Spi_SpiSequence_PHY_19_JobAssignment_MBDT[19] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx18 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx19 
};
/* SpiSequence_PHY_20 */
static const Spi_JobType Spi_SpiSequence_PHY_20_JobAssignment_MBDT[20] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx18 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx19 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx20 
};
/* SpiSequence_PHY_21 */
static const Spi_JobType Spi_SpiSequence_PHY_21_JobAssignment_MBDT[21] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx18 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx19 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx20 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx21 
};
/* SpiSequence_PHY_22 */
static const Spi_JobType Spi_SpiSequence_PHY_22_JobAssignment_MBDT[22] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx18 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx19 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx20 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx21 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx22 
};
/* SpiSequence_PHY_23 */
static const Spi_JobType Spi_SpiSequence_PHY_23_JobAssignment_MBDT[23] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx18 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx19 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx20 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx21 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx22 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx23 
};
/* SpiSequence_PHY_24 */
static const Spi_JobType Spi_SpiSequence_PHY_24_JobAssignment_MBDT[24] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx1 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx2 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx3 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx4 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx5 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx6 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx7 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx8 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx9 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx10 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx11 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx12 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx13 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx14 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx15 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx16 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx17 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx18 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx19 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx20 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx21 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx22 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx23 ,
    SpiConf_SpiJob_SpiJob_PHY_665A_Tx24 
};
/* SpiSequence_PHY_Rx */
static const Spi_JobType Spi_SpiSequence_PHY_Rx_JobAssignment_MBDT[1] =
{
    SpiConf_SpiJob_SpiJob_PHY_665A_Rx 
};

/* Configuration of Sequences */
/* Sequence Configuration for SpiSequence_SBC */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_SBC_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_SBC_JobAssignment_MBDT, /* List of Jobs */
        NULL_PTR, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_0_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_LSW */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_LSW_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_LSW_JobAssignment_MBDT, /* List of Jobs */
        NULL_PTR, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_1_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_TJA */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_TJA_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_TJA_JobAssignment_MBDT, /* List of Jobs */
        NULL_PTR, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_2_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_HB2000_1 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_HB2000_1_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_HB2000_1_JobAssignment_MBDT, /* List of Jobs */
        NULL_PTR, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_3_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_HB2000_2 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_HB2000_2_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_HB2000_2_JobAssignment_MBDT, /* List of Jobs */
        NULL_PTR, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_4_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_HB2000_3 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_HB2000_3_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_HB2000_3_JobAssignment_MBDT, /* List of Jobs */
        NULL_PTR, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_5_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_HB2000_4 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_HB2000_4_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_HB2000_4_JobAssignment_MBDT, /* List of Jobs */
        NULL_PTR, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_6_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_1 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_1_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_1_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_7_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_2 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_2_MBDT =
{
        (Spi_JobType)2U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_2_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_8_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_3 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_3_MBDT =
{
        (Spi_JobType)3U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_3_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_9_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_4 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_4_MBDT =
{
        (Spi_JobType)4U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_4_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_10_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_5 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_5_MBDT =
{
        (Spi_JobType)5U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_5_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_11_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_6 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_6_MBDT =
{
        (Spi_JobType)6U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_6_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_12_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_7 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_7_MBDT =
{
        (Spi_JobType)7U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_7_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_13_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_8 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_8_MBDT =
{
        (Spi_JobType)8U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_8_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_14_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_9 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_9_MBDT =
{
        (Spi_JobType)9U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_9_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_15_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_10 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_10_MBDT =
{
        (Spi_JobType)10U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_10_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_16_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_11 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_11_MBDT =
{
        (Spi_JobType)11U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_11_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_17_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_12 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_12_MBDT =
{
        (Spi_JobType)12U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_12_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_18_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_13 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_13_MBDT =
{
        (Spi_JobType)13U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_13_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_19_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_14 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_14_MBDT =
{
        (Spi_JobType)14U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_14_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_20_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_15 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_15_MBDT =
{
        (Spi_JobType)15U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_15_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_21_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_16 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_16_MBDT =
{
        (Spi_JobType)16U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_16_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_22_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_17 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_17_MBDT =
{
        (Spi_JobType)17U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_17_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_23_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_18 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_18_MBDT =
{
        (Spi_JobType)18U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_18_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_24_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_19 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_19_MBDT =
{
        (Spi_JobType)19U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_19_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_25_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_20 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_20_MBDT =
{
        (Spi_JobType)20U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_20_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_26_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_21 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_21_MBDT =
{
        (Spi_JobType)21U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_21_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_27_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_22 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_22_MBDT =
{
        (Spi_JobType)22U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_22_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_28_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_23 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_23_MBDT =
{
        (Spi_JobType)23U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_23_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_29_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_24 */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_24_MBDT =
{
        (Spi_JobType)24U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_24_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiTxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_30_MBDT
        #endif
};
/* Sequence Configuration for SpiSequence_PHY_Rx */
static const Spi_SequenceConfigType Spi_SequenceConfig_SpiSequence_PHY_Rx_MBDT =
{
        (Spi_JobType)1U,  /* Number of Job in Seq */
        SPI_SPURIOUS_CORE_ID_U32,
        Spi_SpiSequence_PHY_Rx_JobAssignment_MBDT, /* List of Jobs */
        &Phy_665a_SpiRxSeqNotif, /* End Notification */
        (uint8)FALSE  /* Interruptible */
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMAFASTTRANSFER_SUPPORT == STD_ON))
        , (boolean)FALSE /* Enable Dma fast transfer */
        #endif
        #if ((SPI_DMA_USED == STD_ON) && (SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT == STD_ON))
        ,(boolean)FALSE /* Enable ContMemTransferSequence */
        ,&Spi_DmaConMemTransferTxSeq_31_MBDT
        #endif
};
/* Spi_aSequenceConfigList_MBDT Sequence Configuration */
static const Spi_SeqsConfigType Spi_aSequenceConfigList_MBDT[32] =
{
    /* SpiSequence_SBC */
    {
        &Spi_SequenceConfig_SpiSequence_SBC_MBDT
    },
    /* SpiSequence_LSW */
    {
        &Spi_SequenceConfig_SpiSequence_LSW_MBDT
    },
    /* SpiSequence_TJA */
    {
        &Spi_SequenceConfig_SpiSequence_TJA_MBDT
    },
    /* SpiSequence_HB2000_1 */
    {
        &Spi_SequenceConfig_SpiSequence_HB2000_1_MBDT
    },
    /* SpiSequence_HB2000_2 */
    {
        &Spi_SequenceConfig_SpiSequence_HB2000_2_MBDT
    },
    /* SpiSequence_HB2000_3 */
    {
        &Spi_SequenceConfig_SpiSequence_HB2000_3_MBDT
    },
    /* SpiSequence_HB2000_4 */
    {
        &Spi_SequenceConfig_SpiSequence_HB2000_4_MBDT
    },
    /* SpiSequence_PHY_1 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_1_MBDT
    },
    /* SpiSequence_PHY_2 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_2_MBDT
    },
    /* SpiSequence_PHY_3 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_3_MBDT
    },
    /* SpiSequence_PHY_4 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_4_MBDT
    },
    /* SpiSequence_PHY_5 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_5_MBDT
    },
    /* SpiSequence_PHY_6 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_6_MBDT
    },
    /* SpiSequence_PHY_7 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_7_MBDT
    },
    /* SpiSequence_PHY_8 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_8_MBDT
    },
    /* SpiSequence_PHY_9 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_9_MBDT
    },
    /* SpiSequence_PHY_10 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_10_MBDT
    },
    /* SpiSequence_PHY_11 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_11_MBDT
    },
    /* SpiSequence_PHY_12 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_12_MBDT
    },
    /* SpiSequence_PHY_13 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_13_MBDT
    },
    /* SpiSequence_PHY_14 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_14_MBDT
    },
    /* SpiSequence_PHY_15 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_15_MBDT
    },
    /* SpiSequence_PHY_16 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_16_MBDT
    },
    /* SpiSequence_PHY_17 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_17_MBDT
    },
    /* SpiSequence_PHY_18 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_18_MBDT
    },
    /* SpiSequence_PHY_19 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_19_MBDT
    },
    /* SpiSequence_PHY_20 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_20_MBDT
    },
    /* SpiSequence_PHY_21 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_21_MBDT
    },
    /* SpiSequence_PHY_22 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_22_MBDT
    },
    /* SpiSequence_PHY_23 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_23_MBDT
    },
    /* SpiSequence_PHY_24 */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_24_MBDT
    },
    /* SpiSequence_PHY_Rx */
    {
        &Spi_SequenceConfig_SpiSequence_PHY_Rx_MBDT
    }
};
/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/
/* Spi Configuration */
static const Spi_ConfigType Spi_Config=
{
    9U,  /* MaxExternalDevice - number of external devices */
    31U, /* SpiMaxChannel - number of channels */
    31U, /* SpiMaxJob - number of jobs */
    31U, /* SpiMaxSequence - number of sequences */
    SPI_SPURIOUS_CORE_ID_U32,   /* SpiCoreUse - used core */
    Spi_aChannelConfigList_MBDT, /* ChannelConfig */
    Spi_aJobConfigList_MBDT, /* JobConfig */
    Spi_aSequenceConfigList_MBDT, /* SequenceConfig */
    Spi_aExternalDeviceConfigList_MBDT, /* ExternalDeviceConfig */
    Spi_aHwUnitConfigList_MBDT /* HWUnitConfig */
#if (SPI_DISABLE_DEM_REPORT_ERROR_STATUS == STD_OFF)
    ,{ (uint32)STD_OFF, (uint32)0U} /* SPI_E_HARDWARE_ERROR parameters*/
#endif /* SPI_DISABLE_DEM_REPORT_ERROR_STATUS == STD_OFF */  
};

const Spi_ConfigType * const Spi_PBCfgVariantPredefined[SPI_MAX_PARTITIONS]=
{
    &Spi_Config
};

#define SPI_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Spi_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */


