/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file    CDD_Bcc_774a_MBDT_PBcfg.c
*
*   @addtogroup CDD_BCC_774A
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bcc_774a.h"

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#define BCC_774A_MODULE_ID_MBDT_PBCFG_C                     255
#define BCC_774A_VENDOR_ID_MBDT_PBCFG_C                     43
#define BCC_774A_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C      4
#define BCC_774A_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C      7
#define BCC_774A_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C   0
#define BCC_774A_SW_MAJOR_VERSION_MBDT_PBCFG_C              1
#define BCC_774A_SW_MINOR_VERSION_MBDT_PBCFG_C              0
#define BCC_774A_SW_PATCH_VERSION_MBDT_PBCFG_C              2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and CDD_Bcc_774a header file are of the same vendor */
#if (BCC_774A_VENDOR_ID_MBDT_PBCFG_C != BCC_774A_VENDOR_ID)
     #error "CDD_Bcc_774a_MBDT_PBcfg.c and CDD_Bcc_774a.h have different vendor ids"
#endif
/* Check if current file and CDD_Bcc_774a header file are of the same Autosar version */
#if ((BCC_774A_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C    != BCC_774A_AR_RELEASE_MAJOR_VERSION) || \
     (BCC_774A_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C    != BCC_774A_AR_RELEASE_MINOR_VERSION) || \
     (BCC_774A_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C != BCC_774A_AR_RELEASE_REVISION_VERSION) \
    )
     #error "AutoSar Version Numbers of CDD_Bcc_774a_MBDT_PBcfg.c and CDD_Bcc_774a.h are different"
#endif
/* Check if current file and CDD_Bcc_774a header file are of the same Software version */
#if ((BCC_774A_SW_MAJOR_VERSION_MBDT_PBCFG_C != BCC_774A_SW_MAJOR_VERSION) || \
     (BCC_774A_SW_MINOR_VERSION_MBDT_PBCFG_C != BCC_774A_SW_MINOR_VERSION) || \
     (BCC_774A_SW_PATCH_VERSION_MBDT_PBCFG_C != BCC_774A_SW_PATCH_VERSION) \
    )
     #error "Software Version Numbers of CDD_Bcc_774a_MBDT_PBcfg.c and CDD_Bcc_774a.h are different"
#endif

/*==================================================================================================
*                                         LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                         LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                  LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL CONSTANTS
==================================================================================================*/

#define BCC_774A_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_774a_MemMap.h"

static const Bcc_774a_DeviceConfigType DeviceConfigSets_MBDT =
{
     /* SYS configuration sets */
     {
          /* SYS config 0 */
          {
               /* SysComToSupplyMsg */
               {
                    /* SYS_COM_TO_CFG */
                    (
                         (((uint16) 30) << MC33774_SYS_COM_TO_CFG_COMTO_SHIFT)
                    ),
                    /* SYS_SUPPLY_CFG */
                    (
                         (((uint16) 1) << MC33774_SYS_SUPPLY_CFG_VAUXACT_SHIFT) |
                         (((uint16) 1) << MC33774_SYS_SUPPLY_CFG_VAUXCYC_SHIFT) |
                         (((uint16) 0) << MC33774_SYS_SUPPLY_CFG_VDDCCYC_SHIFT) |
                         (((uint16) 1) << MC33774_SYS_SUPPLY_CFG_CURMATCH_SHIFT)
                    )
               },
               /* SysTplMsg */
               {
                    /* SYS_TPL_CFG */
                    (
                         (((uint16) 0) << MC33774_SYS_TPL_CFG_WAKEUPCOMP_SHIFT) |
                         (((uint16) 0) << MC33774_SYS_TPL_CFG_TXTERML_SHIFT) |
                         (((uint16) 0) << MC33774_SYS_TPL_CFG_TXTERMH_SHIFT) |
                         (((uint16) 1) << MC33774_SYS_TPL_CFG_RESPCFG_SHIFT)                    )
               },
               /* SysClkSyncMsg */
               {
                    /* SYS_CLK_SYNC_CTRL */
                    (
                         (((uint16) 0) << MC33774_SYS_CLK_SYNC_CTRL_SYNCCNT_SHIFT)
                    )
               },
               /* BUSFW value. Part of the SYS_COM_CFG register */
               (boolean) TRUE
          }
     },/* END SYS configuration sets */
     { /* GPIO configuration sets */
          /* GPIO config 0 */
          {
               /* GpioCfg0Cfg1Msg */
               {
                    /* GPIO_CFG0 */
                    (
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN0_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN1_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN2_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN3_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN4_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN5_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN6_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_INPEN7_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN0_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN1_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN2_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN3_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN4_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN5_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN6_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG0_OUTEN7_SHIFT)
                    ),
                    /* GPIO_CFG1 */
                    (
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN0_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN1_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN2_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN3_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN4_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN5_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN6_SHIFT) |
                         (((uint16) 0) << MC33774_GPIO_CFG1_ODEN7_SHIFT)
                    )
               }
          }
     },/* END GPIO configuration sets */
     { /* FEH Alarm configuration sets */
          /* FEH Alarm config 0 */
          {
               /* FehAlarmCfgOutCfgMsg */
               {
                    /* FEH_ALARM_CFG */
                    (
                         (((uint16) 0) << MC33774_FEH_ALARM_CFG_ALARMIN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_CFG_ALARMINHB_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_CFG_ALARMOUT_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_CFG_ALARMOUTHB_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_CFG_ALARMINHBINV_SHIFT)
                    ),
                    /* FEH_ALARM_OUT_CFG0 */
                    (
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_VCOV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_VCUV0_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_VCUV1_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN0OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN0UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN1OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN1UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN2OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN2UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN3OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_AIN3UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_ALARMIN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_WAKEUPIN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_BALRDY_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG0_SYSFLTEVT_SHIFT)
                    ),
                    /* FEH_ALARM_OUT_CFG1 */
                    (
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG1_BALPROT_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG1_AINAUV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ALARM_OUT_CFG1_AINAOV_SHIFT)
                    )
               }
          }
     },/* END FEH Alarm configuration sets */
     { /* FEH Wakeup configuration sets */
          /* FEH wakeup config 0 */
          {
               /* FehWakeupCfgMsg */
               {
                    /* FEH_WAKEUP_CFG0 */
                    (
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_VCOV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_VCUV0_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_VCUV1_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN0OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN0UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN1OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN1UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN2OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN2UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN3OV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_AIN3UV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_ALARMIN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_WAKEUPIN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_BALRDY_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_SYSFLTEVT_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG0_TPLWAKEUP_SHIFT)
                    ),
                    /* FEH_WAKEUP_CFG1 */
                    (
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG1_BALPROT_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG1_AINAUV_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_WAKEUP_CFG1_AINAOV_SHIFT)
                    )
               }
          }
     },/*END FEHWakeup configuration sets */
     { /* FEH events configuration sets */
          /* FEH events config 0 */
          {
               /* FehEventsSupPorCfgMsg */
               {
                    /* FEH_SUPPLY_FLT_POR_CFG0 */
                    (
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VANAUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_SHIFT)
                    ),
                    /* FEH_SUPPLY_FLT_POR_CFG1 */
                    (
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_POR_CFG1_VPREUVEN_SHIFT)
                    )
               },
               /* FehEventsComPorCfgMsg */
               {
                    /* FEH_COM_FLT_POR_CFG */
                    (
                         (((uint16) 0) << MC33774_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_COM_FLT_POR_CFG_COMTOEN_SHIFT)
                    )
               },
               /* FehEventsFltCfgMsg */
               {
                    /* FEH_SUPPLY_FLT_EVT_CFG0 */
                    (
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VANAUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_SHIFT)
                    ),
                    /* FEH_SUPPLY_FLT_EVT_CFG1 */
                    (
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_SUPPLY_FLT_EVT_CFG1_VPREUVEN_SHIFT)
                    ),
                    /* FEH_ANA_FLT_EVT_CFG */
                    (
                         (((uint16) 0) << MC33774_FEH_ANA_FLT_EVT_CFG_MONBISTEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ANA_FLT_EVT_CFG_BALFLTEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_SHIFT)
                    ),
                    /* FEH_COM_FLT_EVT_CFG */
                    (
                         (((uint16) 0) << MC33774_FEH_COM_FLT_EVT_CFG_FRAMEERREN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_COM_FLT_EVT_CFG_CRCERREN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_COM_FLT_EVT_CFG_RSPLENERREN_SHIFT)
                    )
               },
               /* FehEventsMeasFltEvtCfgMsg */
               {
                    /* FEH_MEAS_FLT_EVT_CFG */
                    (
                         (((uint16) 0) << MC33774_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_SHIFT) |
                         (((uint16) 0) << MC33774_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_SHIFT)
                    )
               }
          }
     },/* END FEH events configuration sets */
     { /* MSR configuration sets */
          /* MSR config 0 */
          {
               /* MsrAllmPerMsg */
               {
                    /* ALLM_PER_CTRL */
                    (
                         (((uint16) 16) << MC33774_PRMM_PER_CTRL_PERLEN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_PER_CTRL_PERCTRL_SHIFT)
                    )
               },
               /* MsrAllmVcVbMsg */
               {
                    /* ALLM_VCVB_CFG0 */
                    (
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB0EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB1EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB2EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB3EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB4EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB5EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB6EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB7EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB8EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB9EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB10EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB11EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB12EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB13EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB14EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG0_VCVB15EN_SHIFT)
                    ),
                    /* ALLM_VCVB_CFG1 */
                    (
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG1_VCVB16EN_SHIFT) |
                         (((uint16) 1) << MC33774_ALLM_VCVB_CFG1_VCVB17EN_SHIFT)
                    )
               },
               /* MsrPrmmAinMsg */
               {
                    /* PRMM_AIN_CFG */
                    (
                         (((uint16) 1) << MC33774_PRMM_AIN_CFG_AIN0EN_SHIFT) |
                         (((uint16) 1) << MC33774_PRMM_AIN_CFG_AIN1EN_SHIFT) |
                         (((uint16) 1) << MC33774_PRMM_AIN_CFG_AIN2EN_SHIFT) |
                         (((uint16) 1) << MC33774_PRMM_AIN_CFG_AIN3EN_SHIFT) |
                         (((uint16) 1) << MC33774_PRMM_AIN_CFG_AINAEN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_AIN_CFG_FLTAPPINV_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN0_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN1_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN2_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_AIN_CFG_RATIOMETRICAIN3_SHIFT)
                    )
               },
               /* MsrPrmmVcOvUvMsg */
               {
                    /* PRMM_VC_OV_UV_CFG0 */
                    (
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC0EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC1EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC2EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC3EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC4EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC5EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC6EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC7EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC8EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC9EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC10EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC11EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC12EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC13EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC14EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG0_VC15EN_SHIFT)
                    ),
                    /* PRMM_VC_OV_UV_CFG1 */
                    (
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG1_VC16EN_SHIFT) |
                         (((uint16) 0) << MC33774_PRMM_VC_OV_UV_CFG1_VC17EN_SHIFT)
                    ),
                    /* PRMM_VC_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33774_PRMM_VC_OV_TH_CFG_LIMIT_SHIFT)
                    ),
                    /* PRMM_VC_UV0_TH_CFG */
                    (
                         (((uint16) 0) << MC33774_PRMM_VC_UV0_TH_CFG_LIMIT_SHIFT)
                    )
               },
               /* MsrPrmmVcUv1ThMsg */
               {
                    /* PRMM_VC_UV1_TH_CFG */
                    (
                         (((uint16) 0) << MC33774_PRMM_VC_UV1_TH_CFG_LIMIT_SHIFT)
                    )
               },
               /* MsrPrmmAinOvMsg */
               {
                    /* PRMM_AIN0_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33774_PRMM_AIN0_OV_TH_CFG_LIMIT_SHIFT)
                    ),
                    /* PRMM_AIN1_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33774_PRMM_AIN1_OV_TH_CFG_LIMIT_SHIFT)
                    ),
                    /* PRMM_AIN2_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33774_PRMM_AIN2_OV_TH_CFG_LIMIT_SHIFT)
                    ),
                    /* PRMM_AIN3_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33774_PRMM_AIN3_OV_TH_CFG_LIMIT_SHIFT)
                    )
               },
               /* MsrPrmmAinAOvThMsg */
               {
                    /* PRMM_AINA_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33774_PRMM_AINA_OV_TH_CFG_LIMIT_SHIFT)
                    )
               },
               /* MsrPrmmAinUvMsg */
               {
                    /* PRMM_AIN0_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33774_PRMM_AIN0_UV_TH_CFG_LIMIT_SHIFT)
                    ),
                    /* PRMM_AIN1_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33774_PRMM_AIN1_UV_TH_CFG_LIMIT_SHIFT)
                    ),
                    /* PRMM_AIN2_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33774_PRMM_AIN2_UV_TH_CFG_LIMIT_SHIFT)
                    ),
                    /* PRMM_AIN3_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33774_PRMM_AIN3_UV_TH_CFG_LIMIT_SHIFT)
                    )
               },
               /* MsrPrmmAinAUvThMsg */
               {
                    /* PRMM_AINA_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33774_PRMM_AINA_UV_TH_CFG_LIMIT_SHIFT)
                    )
               },
               /* MsrSecmAinMsg */
               {
                    /* SECM_AIN_CFG */
                    (
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_AIN4EN_SHIFT) |
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_AIN5EN_SHIFT) |
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_AIN6EN_SHIFT) |
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_AIN7EN_SHIFT) |
                         (((uint16) 1) << MC33774_SECM_AIN_CFG_FLTAPPINV_SHIFT) |
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN4_SHIFT) |
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN5_SHIFT) |
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN6_SHIFT) |
                         (((uint16) 0) << MC33774_SECM_AIN_CFG_RATIOMETRICAIN7_SHIFT)
                    )
               }
          }
     }, /* END MSR configuration sets */
     { /* I2C configuration sets */
          /* I2C config 0 */
          {
               /* I2cCfgCtrlMsg */
               {
                    /* I2C_CFG */
                    (
                         (((uint16) 1) << MC33774_I2C_CFG_EN_SHIFT) |
                         (((uint16) 0) << MC33774_I2C_CFG_CLKSEL_SHIFT)
                    ),
                    /* I2C_CTRL */
                    (
                         (((uint16) 0) << MC33774_I2C_CTRL_START_SHIFT) |
                         (((uint16) 1) << MC33774_I2C_CTRL_STPAFTER_SHIFT) |
                         (((uint16) 0) << MC33774_I2C_CTRL_RDAFTER_SHIFT)
                    )
               }
          }
     } /* END I2C configuration parameters */
};

const Bcc_774a_DriverConfigType Bcc_774a_PBCfgVariantPredefined =
{
    &DeviceConfigSets_MBDT,
    &BmsTpl3ChainConfigList_MBDT[0]
};

#define BCC_774A_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_774a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

