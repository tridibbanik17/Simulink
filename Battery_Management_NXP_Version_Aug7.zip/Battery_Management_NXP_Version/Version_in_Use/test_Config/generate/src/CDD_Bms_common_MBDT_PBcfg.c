/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
/**
*   @file    CDD_Bms_common_MBDT_PBcfg.c
*
*   @addtogroup CDD_BMS_COMMON
*   @{
*/




#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bms_common_Cfg.h"

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#define BMS_COMMON_VENDOR_ID_MBDT_PBCFG_C                     43
#define BMS_COMMON_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C      4
#define BMS_COMMON_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C      7
#define BMS_COMMON_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C   0
#define BMS_COMMON_SW_MAJOR_VERSION_MBDT_PBCFG_C              1
#define BMS_COMMON_SW_MINOR_VERSION_MBDT_PBCFG_C              0
#define BMS_COMMON_SW_PATCH_VERSION_MBDT_PBCFG_C              2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

/* Check if current file and CDD_Bms_common_Cfg header file are of the same vendor */
#if (BMS_COMMON_VENDOR_ID_MBDT_PBCFG_C  != BMS_COMMON_VENDOR_ID_CFG)
    #error "Bms_common_MBDT_PBcfg.c and CDD_Bms_common_Cfg.h have different vendor ids"
#endif
/* Check if current file and CDD_Bms_common_Cfg header file are of the same Autosar version */
#if ((BMS_COMMON_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C     != BMS_COMMON_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (BMS_COMMON_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C     != BMS_COMMON_AR_RELEASE_MINOR_VERSION_CFG) || \
     (BMS_COMMON_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C  != BMS_COMMON_AR_RELEASE_REVISION_VERSION_CFG) \
     )
    #error "AutoSar Version Numbers of Bms_common_MBDT_PBcfg.c and CDD_Bms_common_Cfg.h are different"
#endif
/* Check if current file and CDD_Bms_common_Cfg header file are of the same Software version */
#if ((BMS_COMMON_SW_MAJOR_VERSION_MBDT_PBCFG_C  != BMS_COMMON_SW_MAJOR_VERSION_CFG) || \
     (BMS_COMMON_SW_MINOR_VERSION_MBDT_PBCFG_C  != BMS_COMMON_SW_MINOR_VERSION_CFG) || \
     (BMS_COMMON_SW_PATCH_VERSION_MBDT_PBCFG_C  != BMS_COMMON_SW_PATCH_VERSION_CFG) \
     )
    #error "Software Version Numbers of Bms_common_MBDT_PBcfg.c and CDD_Bms_common_Cfg.h are different"
#endif


/*==================================================================================================
*                                         LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                         LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                  LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/
#define BMS_COMMON_START_SEC_CONST_UNSPECIFIED
#include "Bms_common_MemMap.h"
/*List of TPL3 chains configuration */
const BmsTpl3ChainConfigType BmsTpl3ChainConfigList_MBDT[BMS_NUMBER_OF_TPL3_CHAINS] = 
{
    {
        1, /*Chain ID*/
        LOOPBACK_METHOD_1, /*Loopback Method*/
        /*Device list*/
        {  
            {
                TPL3_CMU_1,/*Device Type*/
                3,/*Number of devices*/
                1/*Start Address*/
            }
			,
                            {
                NO_DEVICE,/*Device Type*/
                0U,/*Number of devices*/
                0U/*Start Address*/
            }
            ,
                            {
                NO_DEVICE,/*Device Type*/
                0U,/*Number of devices*/
                0U/*Start Address*/
            }
            ,
                            {
                NO_DEVICE,/*Device Type*/
                0U,/*Number of devices*/
                0U/*Start Address*/
            }
            ,
                            {
                NO_DEVICE,/*Device Type*/
                0U,/*Number of devices*/
                0U/*Start Address*/
            }
            ,
                        
        }
    }
            
};
/*List of TPL2 chains configuration */
const BmsTpl2ChainConfigType BmsTpl2ChainConfigList_MBDT[BMS_NUMBER_OF_TPL2_CHAINS] = 
{
    {
        2, /*Chain ID*/
        /*Device list*/
        {  
            {
                TPL2_BJB_1,/*Device Type*/
                2,/*Number of devices*/
                1/*Start Address*/
            },
                            {
                NO_DEVICE,/*Device Type*/
                0U,/*Number of devices*/
                0U/*Start Address*/
            }
			,
                            {
                NO_DEVICE,/*Device Type*/
                0U,/*Number of devices*/
                0U/*Start Address*/
            }
			,
                        
        }
    }
	        
};
#define BMS_COMMON_STOP_SEC_CONST_UNSPECIFIED
#include "Bms_common_MemMap.h"

/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL CONSTANTS
==================================================================================================*/

#ifdef __cplusplus
}
#endif
/** @} */


