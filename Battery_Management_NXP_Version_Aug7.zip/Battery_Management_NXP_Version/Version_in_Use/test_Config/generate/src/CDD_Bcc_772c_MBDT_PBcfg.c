/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file    CDD_Bcc_772c_MBDT_PBcfg.c
*
*   @addtogroup CDD_BCC_772C
*   @{
*/


#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bcc_772c.h"

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#define BCC_772C_MODULE_ID_MBDT_PBCFG_C                    255
#define BCC_772C_VENDOR_ID_MBDT_PBCFG_C                    43
#define BCC_772C_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C     4
#define BCC_772C_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C     7
#define BCC_772C_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C  0
#define BCC_772C_SW_MAJOR_VERSION_MBDT_PBCFG_C             1
#define BCC_772C_SW_MINOR_VERSION_MBDT_PBCFG_C             0
#define BCC_772C_SW_PATCH_VERSION_MBDT_PBCFG_C             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and CDD_Bcc_772c header file are of the same vendor */
#if (BCC_772C_VENDOR_ID_MBDT_PBCFG_C != BCC_772C_VENDOR_ID)
    #error "CDD_Bcc_772c_MBDT_PBcfg.c and CDD_Bcc_772c.h have different vendor ids"
#endif
/* Check if current file and CDD_Bcc_772c header file are of the same Autosar version */
#if ((BCC_772C_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C    != BCC_772C_AR_RELEASE_MAJOR_VERSION) || \
     (BCC_772C_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C    != BCC_772C_AR_RELEASE_MINOR_VERSION) || \
     (BCC_772C_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C != BCC_772C_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of CDD_Bcc_772c_MBDT_PBcfg.c and CDD_Bcc_772c.h are different"
#endif
/* Check if current file and CDD_Bcc_772c header file are of the same Software version */
#if ((BCC_772C_SW_MAJOR_VERSION_MBDT_PBCFG_C != BCC_772C_SW_MAJOR_VERSION) || \
     (BCC_772C_SW_MINOR_VERSION_MBDT_PBCFG_C != BCC_772C_SW_MINOR_VERSION) || \
     (BCC_772C_SW_PATCH_VERSION_MBDT_PBCFG_C != BCC_772C_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of CDD_Bcc_772c_MBDT_PBcfg.c and CDD_Bcc_772c.h are different"
#endif

/*==================================================================================================
*                                         LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                         LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                  LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL CONSTANTS
==================================================================================================*/


#define BCC_772C_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

static const Bcc_772c_DeviceConfigType DeviceConfigSets_MBDT =
{
    /* SYS configuration sets */
    {

        /* SYS config 0 */
        {
            /* SysCfg1Msg */
            (
                /* CYCLIC_TIMER */
                (((uint16) MC33772C_SYS_CFG1_CYCLIC_TIMER_DISABLED_ENUM_VAL) << MC33772C_SYS_CFG1_CYCLIC_TIMER_SHIFT) |
                /* DIAG_TIMEOUT */
                (((uint16) MC33772C_SYS_CFG1_DIAG_TIMEOUT_0_1S_ENUM_VAL) << MC33772C_SYS_CFG1_DIAG_TIMEOUT_SHIFT) |
                /* FAULT_WAVE */
                (((uint16) MC33772C_SYS_CFG1_FAULT_WAVE_DISABLED_ENUM_VAL) << MC33772C_SYS_CFG1_FAULT_WAVE_SHIFT) |
                /* WAVE_DC_BITx */
                (((uint16) MC33772C_SYS_CFG1_WAVE_DC_BITX_500US_ENUM_VAL) << MC33772C_SYS_CFG1_WAVE_DC_BITX_SHIFT)
            ),
            /* SysCfg2Msg */
            (
                /* FLT_RST_CFG */
                (((uint16) MC33772C_SYS_CFG2_FLT_RST_CFG_COM_RESET_OSC_MON_RESET_ENUM_VAL) << MC33772C_SYS_CFG2_FLT_RST_CFG_SHIFT) |
                /* TIMEOUT_COMM */
                (((uint16) MC33772C_SYS_CFG2_TIMEOUT_COMM_256MS_ENUM_VAL) << MC33772C_SYS_CFG2_TIMEOUT_COMM_SHIFT) |
                /* NUMB_ODD */
                (((uint16) MC33772C_SYS_CFG2_NUMB_ODD_EVEN_ENUM_VAL) << MC33772C_SYS_CFG2_NUMB_ODD_SHIFT) |
                /* HAM_ENCOD */
                (((uint16) MC33772C_SYS_CFG2_HAMM_ENCOD_DECODE_ENUM_VAL) << MC33772C_SYS_CFG2_HAMM_ENCOD_SHIFT)
            )
        }

    },/* END SYS configuration sets */
    /* GPIO configuration sets */
    {
        /* GPIO config 0 */
        {
            /* GpioCfg1Msg*/
            (
                /* GPIO0_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO0_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO0_CFG_SHIFT) |
                /* GPIO1_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO1_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO1_CFG_SHIFT) |
                /* GPIO2_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO2_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO2_CFG_SHIFT) |
                /* GPIO3_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO3_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO3_CFG_SHIFT) |
                /* GPIO4_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO4_CFG_DIGITAL_OUT_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO4_CFG_SHIFT) |
                /* GPIO5_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO5_CFG_DIGITAL_OUT_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO5_CFG_SHIFT) |
                /* GPIO6_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO6_CFG_DIGITAL_OUT_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO6_CFG_SHIFT)
            ),
            /* GpioCfg2Msg */
            (
                /* GPIO2_SOC */
                (((uint16) MC33772C_GPIO_CFG2_GPIO2_SOC_ADC_TRG_DISABLED_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO2_SOC_SHIFT) |
                /* GPIO0_WU */
                (((uint16) MC33772C_GPIO_CFG2_GPIO0_WU_NO_WAKEUP_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO0_WU_SHIFT) |
                /* GPIO0_FLT_ACT */
                (((uint16) MC33772C_GPIO_CFG2_GPIO0_FLT_ACT_DISABLED_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO0_FLT_ACT_SHIFT)
            )
        },
        /* GPIO config 1 */
        {
            /* GpioCfg1Msg*/
            (
                /* GPIO0_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO0_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO0_CFG_SHIFT) |
                /* GPIO1_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO1_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO1_CFG_SHIFT) |
                /* GPIO2_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO2_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO2_CFG_SHIFT) |
                /* GPIO3_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO3_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO3_CFG_SHIFT) |
                /* GPIO4_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO4_CFG_DIGITAL_OUT_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO4_CFG_SHIFT) |
                /* GPIO5_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO5_CFG_DIGITAL_OUT_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO5_CFG_SHIFT) |
                /* GPIO6_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO6_CFG_DIGITAL_IN_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO6_CFG_SHIFT)
            ),
            /* GpioCfg2Msg */
            (
                /* GPIO2_SOC */
                (((uint16) MC33772C_GPIO_CFG2_GPIO2_SOC_ADC_TRG_DISABLED_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO2_SOC_SHIFT) |
                /* GPIO0_WU */
                (((uint16) MC33772C_GPIO_CFG2_GPIO0_WU_NO_WAKEUP_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO0_WU_SHIFT) |
                /* GPIO0_FLT_ACT */
                (((uint16) MC33772C_GPIO_CFG2_GPIO0_FLT_ACT_DISABLED_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO0_FLT_ACT_SHIFT)
            )
        },
        /* GPIO config 2 */
        {
            /* GpioCfg1Msg*/
            (
                /* GPIO0_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO0_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO0_CFG_SHIFT) |
                /* GPIO1_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO1_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO1_CFG_SHIFT) |
                /* GPIO2_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO2_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO2_CFG_SHIFT) |
                /* GPIO3_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO3_CFG_ANALOG_ABS_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO3_CFG_SHIFT) |
                /* GPIO4_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO4_CFG_DIGITAL_IN_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO4_CFG_SHIFT) |
                /* GPIO5_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO5_CFG_DIGITAL_IN_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO5_CFG_SHIFT) |
                /* GPIO6_CFG*/
                (((uint16) MC33772C_GPIO_CFG1_GPIO6_CFG_DIGITAL_IN_ENUM_VAL) << MC33772C_GPIO_CFG1_GPIO6_CFG_SHIFT)
            ),
            /* GpioCfg2Msg */
            (
                /* GPIO2_SOC */
                (((uint16) MC33772C_GPIO_CFG2_GPIO2_SOC_ADC_TRG_DISABLED_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO2_SOC_SHIFT) |
                /* GPIO0_WU */
                (((uint16) MC33772C_GPIO_CFG2_GPIO0_WU_NO_WAKEUP_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO0_WU_SHIFT) |
                /* GPIO0_FLT_ACT */
                (((uint16) MC33772C_GPIO_CFG2_GPIO0_FLT_ACT_DISABLED_ENUM_VAL) << MC33772C_GPIO_CFG2_GPIO0_FLT_ACT_SHIFT)
            )
        }

    },/* END GPIO configuration sets */

    /* FEH Alarm configuration sets */
    {

        /* FEH Alarm config 0 */
        {
            {
                /* FAULT_MASK1 */
                (
                    (((uint16) MC33772C_FAULT_MASK1_VPWR_OV_FLT_MASK_12_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_VPWR_OV_FLT_MASK_12_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_VPWR_LV_FLT_MASK_11_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_VPWR_LV_FLT_MASK_11_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_COM_LOSS_FLT_MASK_10_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_COM_LOSS_FLT_MASK_10_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_COM_ERR_FLT_MASK_9_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_COM_ERR_FLT_MASK_9_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_CSB_WUP_FLT_MASK_8_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_CSB_WUP_FLT_MASK_8_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_GPIO0_WUP_FLT_MASK_7_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_GPIO0_WUP_FLT_MASK_7_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_I2C_ERR_FLT_MASK_6_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_I2C_ERR_FLT_MASK_6_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_IS_OL_FLT_MASK_5_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_IS_OL_FLT_MASK_5_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_IS_OC_FLT_MASK_4_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_IS_OC_FLT_MASK_4_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_AN_OT_FLT_MASK_3_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_AN_OT_FLT_MASK_3_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_AN_UT_FLT_MASK_2_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_AN_UT_FLT_MASK_2_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_CT_OV_FLT_MASK_1_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_CT_OV_FLT_MASK_1_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK1_CT_UV_FLT_MASK_0_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK1_CT_UV_FLT_MASK_0_F_SHIFT)
                ),
                /* FAULT_MASK2 */
                (
                    (((uint16) MC33772C_FAULT_MASK2_VCOM_OV_FLT_MASK_15_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_VCOM_OV_FLT_MASK_15_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_VCOM_UV_FLT_MASK_14_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_VCOM_UV_FLT_MASK_14_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_VANA_OV_FLT_MASK_13_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_VANA_OV_FLT_MASK_13_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_VANA_UV_FLT_MASK_12_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_VANA_UV_FLT_MASK_12_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_ADC1_B_FLT_MASK_11_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_ADC1_B_FLT_MASK_11_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_ADC1_A_FLT_MASK_10_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_ADC1_A_FLT_MASK_10_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_GND_LOSS_FLT_MASK_9_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_GND_LOSS_FLT_MASK_9_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_AN_OPEN_FLT_MASK_6_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_AN_OPEN_FLT_MASK_6_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_GPIO_SHORT_FLT_MASK_5_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_GPIO_SHORT_FLT_MASK_5_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_CB_SHORT_FLT_MASK_4_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_CB_SHORT_FLT_MASK_4_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_CB_OPEN_FLT_MASK_3_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_CB_OPEN_FLT_MASK_3_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_OSC_ERR_FLT_MASK_2_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_OSC_ERR_FLT_MASK_2_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_DED_ERR_FLT_MASK_1_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_DED_ERR_FLT_MASK_1_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK2_FUSE_ERR_FLT_MASK_0_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK2_FUSE_ERR_FLT_MASK_0_F_SHIFT)
                ),
                /* FAULT_MASK3 */
                (
                    (((uint16) MC33772C_FAULT_MASK3_CC_OVR_FLT_MASK_15_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_CC_OVR_FLT_MASK_15_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_DIAG_TO_FLT_MASK_14_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_DIAG_TO_FLT_MASK_14_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_VCP_UV_MASK_13_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_VCP_UV_MASK_13_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_EOT_CB6_MASK_5_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_EOT_CB6_MASK_5_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_EOT_CB5_MASK_4_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_EOT_CB5_MASK_4_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_EOT_CB4_MASK_3_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_EOT_CB4_MASK_3_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_EOT_CB3_MASK_2_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_EOT_CB3_MASK_2_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_EOT_CB2_MASK_1_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_EOT_CB2_MASK_1_F_SHIFT) |
                    (((uint16) MC33772C_FAULT_MASK3_EOT_CB1_MASK_0_F_NOT_MASKED_ENUM_VAL) << MC33772C_FAULT_MASK3_EOT_CB1_MASK_0_F_SHIFT)
                ),
                /* WAKEUP_MASK1 */
                (
                    (((uint16) MC33772C_WAKEUP_MASK1_VPWR_OV_FLT_MASK_12_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_VPWR_OV_FLT_MASK_12_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK1_VPWR_LV_FLT_MASK_11_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_VPWR_LV_FLT_MASK_11_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK1_GPIO0_WUP_FLT_MASK_7_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_GPIO0_WUP_FLT_MASK_7_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK1_IS_OC_FLT_MASK_4_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_IS_OC_FLT_MASK_4_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK1_AN_OT_FLT_MASK_3_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_AN_OT_FLT_MASK_3_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK1_AN_UT_FLT_MASK_2_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_AN_UT_FLT_MASK_2_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK1_CT_OV_FLT_MASK_1_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_CT_OV_FLT_MASK_1_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK1_CT_UV_FLT_MASK_0_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK1_CT_UV_FLT_MASK_0_F_SHIFT)
                ),
                /* WAKEUP_MASK2 */
                (
                    (((uint16) MC33772C_WAKEUP_MASK2_VCOM_OV_FLT_MASK_15_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_VCOM_OV_FLT_MASK_15_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_VCOM_UV_FLT_MASK_14_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_VCOM_UV_FLT_MASK_14_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_VANA_OV_FLT_MASK_13_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_VANA_OV_FLT_MASK_13_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_VANA_UV_FLT_MASK_12_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_VANA_UV_FLT_MASK_12_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_ADC1_B_FLT_MASK_11_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_ADC1_B_FLT_MASK_11_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_ADC1_A_FLT_MASK_10_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_ADC1_A_FLT_MASK_10_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_GND_LOSS_FLT_MASK_9_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_GND_LOSS_FLT_MASK_9_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_GPIO_SHORT_FLT_MASK_5_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_GPIO_SHORT_FLT_MASK_5_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_CB_SHORT_FLT_MASK_4_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_CB_SHORT_FLT_MASK_4_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_OSC_ERR_FLT_MASK_2_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_OSC_ERR_FLT_MASK_2_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK2_DED_ERR_FLT_MASK_1_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK2_DED_ERR_FLT_MASK_1_F_SHIFT)
                ),
                /* WAKEUP_MASK3 */
                (
                    (((uint16) MC33772C_WAKEUP_MASK3_CC_OVR_FLT_MASK_15_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_CC_OVR_FLT_MASK_15_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK3_VCP_UV_MASK_13_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_VCP_UV_MASK_13_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK3_EOT_CB6_MASK_5_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_EOT_CB6_MASK_5_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK3_EOT_CB5_MASK_4_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_EOT_CB5_MASK_4_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK3_EOT_CB4_MASK_3_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_EOT_CB4_MASK_3_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK3_EOT_CB3_MASK_2_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_EOT_CB3_MASK_2_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK3_EOT_CB2_MASK_1_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_EOT_CB2_MASK_1_F_SHIFT) |
                    (((uint16) MC33772C_WAKEUP_MASK3_EOT_CB1_MASK_0_F_NOT_MASKED_ENUM_VAL) << MC33772C_WAKEUP_MASK3_EOT_CB1_MASK_0_F_SHIFT)
                )
            }
        }

    },/* END FEH Alarm configuration sets */
    /* MSR configuration sets */
    {
        /* MSR config 0 */
        {
            /* ADC_CFG */
            (
                /* PGA_GAIN */
                (((uint16) MC33772C_ADC_CFG_PGA_GAIN_AUTO_ENUM_VAL) << MC33772C_ADC_CFG_PGA_GAIN_SHIFT) |
                /* ADC1_A_DEF */
                (((uint16) MC33772C_ADC_CFG_ADC1_A_DEF_14_BIT_ENUM_VAL) << MC33772C_ADC_CFG_ADC1_A_DEF_SHIFT) |
                /* ADC1_B_DEF */
                (((uint16) MC33772C_ADC_CFG_ADC1_B_DEF_14_BIT_ENUM_VAL) << MC33772C_ADC_CFG_ADC1_B_DEF_SHIFT) |
                /* ADC2_DEF */
                (((uint16) MC33772C_ADC_CFG_ADC2_DEF_16_BIT_ENUM_VAL) << MC33772C_ADC_CFG_ADC2_DEF_SHIFT)
            )
            /* OV_UV_EN */
           ,(
                (((uint16) MC33772C_OV_UV_EN_CT1_OVUV_EN_ENABLED_ENUM_VAL) << MC33772C_OV_UV_EN_CT1_OVUV_EN_SHIFT) |
                (((uint16) MC33772C_OV_UV_EN_CT2_OVUV_EN_ENABLED_ENUM_VAL) << MC33772C_OV_UV_EN_CT2_OVUV_EN_SHIFT) |
                (((uint16) MC33772C_OV_UV_EN_CT3_OVUV_EN_ENABLED_ENUM_VAL) << MC33772C_OV_UV_EN_CT3_OVUV_EN_SHIFT) |
                (((uint16) MC33772C_OV_UV_EN_CT4_OVUV_EN_ENABLED_ENUM_VAL) << MC33772C_OV_UV_EN_CT4_OVUV_EN_SHIFT) |

                (((uint16) MC33772C_OV_UV_EN_CT5_OVUV_EN_ENABLED_ENUM_VAL) << MC33772C_OV_UV_EN_CT5_OVUV_EN_SHIFT) |
                (((uint16) MC33772C_OV_UV_EN_CT6_OVUV_EN_ENABLED_ENUM_VAL) << MC33772C_OV_UV_EN_CT6_OVUV_EN_SHIFT)
            )
        }
    } /* END MSR configuration sets */

     /* CC configuration sets */
    ,{
        /* CC config 0 */
        {
            /* ADC2_OFFSET_COMP */
            (
                /* CC_RST_CFG */
                (((uint16) MC33772C_ADC2_OFFSET_COMP_CC_RST_CFG_NO_ACTION_ENUM_VAL) << MC33772C_ADC2_OFFSET_COMP_CC_RST_CFG_SHIFT) |
                /* FREE_CNT */
                (((uint16) MC33772C_ADC2_OFFSET_COMP_FREE_CNT_CLAMP_ENUM_VAL) << MC33772C_ADC2_OFFSET_COMP_FREE_CNT_SHIFT)
            ),
            {
                /* TH_ISENSE_OC */
                ((uint16) 0),
                /* TH_COULOMB_CNT_MSB */
                ((uint16) 0),
                /* TH_COULOMB_CNT_LSB */
                ((uint16) 0)
            }
        }
    } /* END CC configuration sets */
};

const Bcc_772c_DriverConfigType Bcc_772c_PBCfgVariantPredefined =
{
    &DeviceConfigSets_MBDT,
    &BmsTpl2ChainConfigList_MBDT[0]
};
#define BCC_772C_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_772c_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

