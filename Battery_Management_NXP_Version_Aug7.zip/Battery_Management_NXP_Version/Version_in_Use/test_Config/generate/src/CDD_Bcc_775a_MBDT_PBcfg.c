/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file    CDD_Bcc_775a_MBDT_PBcfg.c
*
*   @addtogroup CDD_BCC_775A
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "CDD_Bcc_775a.h"

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#define BCC_775A_MODULE_ID_MBDT_PBCFG_C                     255
#define BCC_775A_VENDOR_ID_MBDT_PBCFG_C                     43
#define BCC_775A_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C      4
#define BCC_775A_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C      7
#define BCC_775A_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C   0
#define BCC_775A_SW_MAJOR_VERSION_MBDT_PBCFG_C              1
#define BCC_775A_SW_MINOR_VERSION_MBDT_PBCFG_C              0
#define BCC_775A_SW_PATCH_VERSION_MBDT_PBCFG_C              2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and CDD_Bcc_775a header file are of the same vendor */
#if (BCC_775A_VENDOR_ID_MBDT_PBCFG_C != BCC_775A_VENDOR_ID)
#error "CDD_Bcc_775a_MBDT_PBcfg.c and CDD_Bcc_775a.h have different vendor ids"
#endif
/* Check if current file and CDD_Bcc_775a header file are of the same Autosar version */
#if ((BCC_775A_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_C    != BCC_775A_AR_RELEASE_MAJOR_VERSION) || \
     (BCC_775A_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_C    != BCC_775A_AR_RELEASE_MINOR_VERSION) || \
     (BCC_775A_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_C != BCC_775A_AR_RELEASE_REVISION_VERSION) \
    )
#error "AutoSar Version Numbers of CDD_Bcc_775a_MBDT_PBcfg.c and CDD_Bcc_775a.h are different"
#endif
/* Check if current file and CDD_Bcc_775a header file are of the same Software version */
#if ((BCC_775A_SW_MAJOR_VERSION_MBDT_PBCFG_C != BCC_775A_SW_MAJOR_VERSION) || \
     (BCC_775A_SW_MINOR_VERSION_MBDT_PBCFG_C != BCC_775A_SW_MINOR_VERSION) || \
     (BCC_775A_SW_PATCH_VERSION_MBDT_PBCFG_C != BCC_775A_SW_PATCH_VERSION) \
    )
#error "Software Version Numbers of CDD_Bcc_775a_MBDT_PBcfg.c and CDD_Bcc_775a.h are different"
#endif

/*==================================================================================================
*                                         LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                         LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                  LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL CONSTANTS
==================================================================================================*/

#define BCC_775A_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_775a_MemMap.h"

static const Bcc_775a_DeviceConfigType DeviceConfigSets_MBDT =
{
     /* SYS configuration sets */
     {

          /* SYS config 0 */
          {
               /* SysComToSupplyMsg */
               {
                    /* SYS_COM_TO_CFG */
                    (
                         (((uint16) 30) << MC33775_SYS_COM_TO_CFG_COMTO_POS)
                    ),
                    /* SYS_SUPPLY_CFG */
                    (
                         (((uint16) 1) << MC33775_SYS_SUPPLY_CFG_VAUXACT_POS) |
                         (((uint16) 1) << MC33775_SYS_SUPPLY_CFG_VAUXCYC_POS) |
                         (((uint16) 0) << MC33775_SYS_SUPPLY_CFG_VDDCCYC_POS) |
                         (((uint16) 1) << MC33775_SYS_SUPPLY_CFG_CURMATCH_POS)
                    )
               },

               /* SysTplMsg */
               {
                    /* SYS_TPL_CFG */
                    (
                         (((uint16) 0) << MC33775_SYS_TPL_CFG_WAKEUPCOMPL_POS) |
                         (((uint16) 0) << MC33775_SYS_TPL_CFG_WAKEUPCOMPH_POS) |
                         (((uint16) 0) << MC33775_SYS_TPL_CFG_TXTERML_POS) |
                         (((uint16) 0) << MC33775_SYS_TPL_CFG_TXTERMH_POS) |
                         (((uint16) 1) << MC33775_SYS_TPL_CFG_DUALRESP_POS)
                    )
               },

               /* SysClkSyncMsg */
               {
                    /* SYS_CLK_SYNC_CTRL */
                    (
                         (((uint16) 0) << MC33775_SYS_CLK_SYNC_CTRL_SYNCCNT_POS)
                    )
               },

               /* BUSFW value. Part of the SYS_COM_CFG register */
               (boolean) TRUE
          }

     },/* END SYS configuration sets */


     { /* GPIO configuration sets */

          /* GPIO config 0 */
          {
               /* GpioCfg0Cfg1Msg */
               {

                    /* GPIO_CFG0 */
                    (
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN0_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN1_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN2_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN3_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN4_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN5_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN6_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_INPEN7_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN0_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN1_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN2_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN3_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN4_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN5_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN6_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG0_OUTEN7_POS)
                    ),
                    /* GPIO_CFG1 */
                    (
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN0_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN1_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN2_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN3_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN4_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN5_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN6_POS) |
                         (((uint16) 0) << MC33775_GPIO_CFG1_ODEN7_POS)
                    )
               }

          }

     },/* END GPIO configuration sets */


     { /* FEH Alarm configuration sets */

          /* FEH Alarm config 0 */
          {
               /* FehAlarmCfgOutCfgMsg */
               {

                    /* FEH_ALARM_CFG */
                    (
                         (((uint16) 0) << MC33775_FEH_ALARM_CFG_ALARMIN_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_CFG_ALARMINHB_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_CFG_ALARMOUT_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_CFG_ALARMOUTHB_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_CFG_ALARMINHBINV_POS)

                    ),
                    /* FEH_ALARM_OUT_CFG */
                    (
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_VCOV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_VCUV0_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_VCUV1_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN0OV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN0UV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN1OV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN1UV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN2OV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN2UV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN3OV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_AIN3UV_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_ALARMIN_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_WAKEUPIN_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_BALRDY_POS) |
                         (((uint16) 0) << MC33775_FEH_ALARM_OUT_CFG_SYSFLTEVT_POS)
                    )
               }

          }

     },/* END FEH Alarm configuration sets */


     { /*FEHWakeup configuration sets */

          /* FEH wakeup config 0 */
          {
               /* FehWakeupCfgMsg */
               {
                    /* FEH_WAKEUP_CFG */
                    (
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_VCOV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_VCUV0_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_VCUV1_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN0OV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN0UV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN1OV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN1UV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN2OV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN2UV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN3OV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_AIN3UV_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_ALARMIN_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_WAKEUPIN_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_BALRDY_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_SYSFLTEVT_POS) |
                         (((uint16) 0) << MC33775_FEH_WAKEUP_CFG_TPLWAKEUP_POS)
                    )
               }

          }

     },/*END FEHWakeup configuration sets */


     { /*FEH events configuration sets */

          /* FEH events config 0 */
          {
               /* FehEventsSupPorCfgMsg */
               {
                    /* FEH_SUPPLY_FLT_POR_CFG0 */
                    (
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VBATOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDAUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_V2P5AUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_AFECPUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMOCEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_IBIASPERMUCEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VPREREFSUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VAUXUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG0_VDDCUVEN_POS)
                    ),
                    /* FEH_SUPPLY_FLT_POR_CFG1 */
                    (
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG1_VBATLVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREREFSOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDCHCEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG1_VDDIOUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_POR_CFG1_VPREOVEN_POS)
                    )
               },
               /* FehEventsComPorCfgMsg */
               {
                    /* FEH_COM_FLT_POR_CFG */
                    (
                         (((uint16) 0) << MC33775_FEH_COM_FLT_POR_CFG_ERRCNTOFEN_POS) |
                         (((uint16) 0) << MC33775_FEH_COM_FLT_POR_CFG_COMTOEN_POS)
                    )
               },
               /* FehEventsFltCfgMsg */
               {
                    /* FEH_SUPPLY_FLT_EVT_CFG0 */
                    (
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VBATOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDAUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_V2P5AUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_AFECPUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMOCEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_IBIASPERMUCEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VPREREFSUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VAUXUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG0_VDDCUVEN_POS)
                    ),
                    /* FEH_SUPPLY_FLT_EVT_CFG1 */
                    (
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VBATLVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREREFSOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDCHCEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOOVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VDDIOUVEN_POS) |
                         (((uint16) 0) << MC33775_FEH_SUPPLY_FLT_EVT_CFG1_VPREOVEN_POS)
                    ),
                    /* FEH_ANA_FLT_EVT_CFG */
                    (
                         (((uint16) 0) << MC33775_FEH_ANA_FLT_EVT_CFG_MONBISTEN_POS) |
                         (((uint16) 0) << MC33775_FEH_ANA_FLT_EVT_CFG_BALFLTEN_POS) |
                         (((uint16) 0) << MC33775_FEH_ANA_FLT_EVT_CFG_FUSEFLTEN_POS)
                    ),
                    /* FEH_COM_FLT_EVT_CFG */
                    (
                         (((uint16) 0) << MC33775_FEH_COM_FLT_EVT_CFG_FRAMEERREN_POS) |
                         (((uint16) 0) << MC33775_FEH_COM_FLT_EVT_CFG_CRCERREN_POS) |
                         (((uint16) 0) << MC33775_FEH_COM_FLT_EVT_CFG_ERRCNTOFEN_POS) |
                         (((uint16) 0) << MC33775_FEH_COM_FLT_EVT_CFG_RSPLENERREN_POS)
                    )
               },
               /* FehEventsMeasFltEvtCfgMsg */
               {
                    /* FEH_MEAS_FLT_EVT_CFG */
                    (
                         (((uint16) 0) << MC33775_FEH_MEAS_FLT_EVT_CFG_PRIMCALCRCFLTEN_POS) |
                         (((uint16) 0) << MC33775_FEH_MEAS_FLT_EVT_CFG_SECCALCRCFLTEN_POS) |
                         (((uint16) 0) << MC33775_FEH_MEAS_FLT_EVT_CFG_SYNCMEASFLTEN_POS)
                    )
               }

          }

     },/* END FEH events configuration sets */


     { /* MSR configuration sets */

          /* MSR config 0 */
          {
               /* MsrAllmPerMsg */
               {
                    /* ALLM_PER_CTRL */
                    (
                         (((uint16) 16) << MC33775_PRMM_PER_CTRL_PERLEN_POS) |
                         (((uint16) 0) << MC33775_PRMM_PER_CTRL_PERCTRL_POS)
                    )
               },
               /* MsrAllmVcVbMsg */
               {
                    /* ALLM_VCVB_CFG */
                    (
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB0EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB1EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB2EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB3EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB4EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB5EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB6EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB7EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB8EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB9EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB10EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB11EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB12EN_POS) |
                         (((uint16) 1) << MC33775_ALLM_VCVB_CFG_VCVB13EN_POS)
                    )
               },
               /* MsrPrmmAinMsg */
               {
                    /* PRMM_AIN_CFG */
                    (
                         (((uint16) 1) << MC33775_PRMM_AIN_CFG_AIN0EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_AIN_CFG_AIN1EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_AIN_CFG_AIN2EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_AIN_CFG_AIN3EN_POS) |
                         (((uint16) 0) << MC33775_PRMM_AIN_CFG_VMODULEEN_POS) |
                         (((uint16) 0) << MC33775_PRMM_AIN_CFG_FLTAPPINV_POS) |
                         (((uint16) 0) << MC33775_PRMM_AIN_CFG_RATIOMETRICAIN0_POS) |
                         (((uint16) 0) << MC33775_PRMM_AIN_CFG_RATIOMETRICAIN1_POS) |
                         (((uint16) 0) << MC33775_PRMM_AIN_CFG_RATIOMETRICAIN2_POS) |
                         (((uint16) 0) << MC33775_PRMM_AIN_CFG_RATIOMETRICAIN3_POS)

                    )
               },
               /* MsrPrmmVdivMsg */
               {
                    /* PRMM_VDIV_CFG */
                    (
                         (((uint16) 1) << MC33775_PRMM_VDIV_CFG_VAUXEN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VDIV_CFG_VDDCEN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VDIV_CFG_VMODULEEN_POS)
                    )
               },
               /* MsrPrmmVcOvUvMsg */
               {
                    /* PRMM_VC_OV_UV_CFG */
                    (
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC0EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC1EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC2EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC3EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC4EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC5EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC6EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC7EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC8EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC9EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC10EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC11EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC12EN_POS) |
                         (((uint16) 1) << MC33775_PRMM_VC_OV_UV_CFG_VC13EN_POS)
                    ),
                    /* PRMM_VC_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33775_PRMM_VC_OV_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_VC_UV0_TH_CFG */
                    (
                         (((uint16) 22727) << MC33775_PRMM_VC_UV0_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_VC_UV1_TH_CFG */
                    (
                         (((uint16) 18182) << MC33775_PRMM_VC_UV1_TH_CFG_LIMIT_POS)
                    )
               },
               /* MsrPrmmAinOvMsg */
               {
                    /* PRMM_AIN0_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33775_PRMM_AIN0_OV_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_AIN1_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33775_PRMM_AIN1_OV_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_AIN2_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33775_PRMM_AIN2_OV_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_AIN3_OV_TH_CFG */
                    (
                         (((uint16) 32767) << MC33775_PRMM_AIN3_OV_TH_CFG_LIMIT_POS)
                    )
               },
               /* MsrPrmmAinUvMsg */
               {
                    /* PRMM_AIN0_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33775_PRMM_AIN0_UV_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_AIN1_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33775_PRMM_AIN1_UV_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_AIN2_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33775_PRMM_AIN2_UV_TH_CFG_LIMIT_POS)
                    ),
                    /* PRMM_AIN3_UV_TH_CFG */
                    (
                         (((uint16) 32769) << MC33775_PRMM_AIN3_UV_TH_CFG_LIMIT_POS)
                    )
               },
               /* MsrSecmAinMsg */
               {
                    /* SECM_AIN_CFG */
                    (
                         (((uint16) 1) << MC33775_SECM_AIN_CFG_AIN4EN_POS) |
                         (((uint16) 1) << MC33775_SECM_AIN_CFG_AIN5EN_POS) |
                         (((uint16) 1) << MC33775_SECM_AIN_CFG_AIN6EN_POS) |
                         (((uint16) 1) << MC33775_SECM_AIN_CFG_AIN7EN_POS) |
                         (((uint16) 1) << MC33775_SECM_AIN_CFG_FLTAPPINV_POS) |
                         (((uint16) 0) << MC33775_SECM_AIN_CFG_RATIOMETRICAIN4_POS) |
                         (((uint16) 0) << MC33775_SECM_AIN_CFG_RATIOMETRICAIN5_POS) |
                         (((uint16) 0) << MC33775_SECM_AIN_CFG_RATIOMETRICAIN6_POS) |
                         (((uint16) 0) << MC33775_SECM_AIN_CFG_RATIOMETRICAIN7_POS)
                    )
               },
               /* MsrSecmVdivMsg */
               {
                    /* SECM_VDIV_CFG */
                    (
                         (((uint16) 1) << MC33775_SECM_VDIV_CFG_VAUXEN_POS) |
                         (((uint16) 1) << MC33775_SECM_VDIV_CFG_VDDCEN_POS)
                    )
               }

          }
     }, /* END MSR configuration sets */

     { /* I2C configuration sets */

          /* I2C config 0 */
          {
               /* I2cCfgCtrlMsg */
               {
                    /* I2C_CFG */
                    (
                         (((uint16) 1) << MC33775_I2C_CFG_EN_POS) |
                         (((uint16) 0) << MC33775_I2C_CFG_CLKSEL_POS)
                    ),
                    /* I2C_CTRL */
                    (
                         (((uint16) 0) << MC33775_I2C_CTRL_START_POS) |
                         (((uint16) 1) << MC33775_I2C_CTRL_STPAFTER_POS) |
                         (((uint16) 0) << MC33775_I2C_CTRL_RDAFTER_POS)
                    )
               }
          }

     } /* END I2C configuration parameters */

};

const Bcc_775a_DriverConfigType Bcc_775a_PBCfgVariantPredefined =
{
    &DeviceConfigSets_MBDT,
    &BmsTpl3ChainConfigList_MBDT[0]
};

#define BCC_775A_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Bcc_775a_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */

