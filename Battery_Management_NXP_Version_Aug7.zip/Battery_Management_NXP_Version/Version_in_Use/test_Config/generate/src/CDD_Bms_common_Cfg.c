/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file    CDD_Bms_common_Cfg.c
*
*   @addtogroup CDD_BMS_COMMON
*   @{
*/


#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bms_common.h"

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#define BMS_COMMON_VENDOR_ID_CFG_C                     43
#define BMS_COMMON_AR_RELEASE_MAJOR_VERSION_CFG_C      4
#define BMS_COMMON_AR_RELEASE_MINOR_VERSION_CFG_C      7
#define BMS_COMMON_AR_RELEASE_REVISION_VERSION_CFG_C   0
#define BMS_COMMON_SW_MAJOR_VERSION_CFG_C              1
#define BMS_COMMON_SW_MINOR_VERSION_CFG_C              0
#define BMS_COMMON_SW_PATCH_VERSION_CFG_C              2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

/* Check if current file and CDD_Bms_common header file are of the same vendor */
#if (BMS_COMMON_VENDOR_ID_CFG_C  != BMS_COMMON_VENDOR_ID)
    #error "CDD_Bms_common_Cfg.c and CDD_Bms_common.h have different vendor ids"
#endif
/* Check if current file and CDD_Bms_common header file are of the same Autosar version */
#if ((BMS_COMMON_AR_RELEASE_MAJOR_VERSION_CFG_C     != BMS_COMMON_AR_RELEASE_MAJOR_VERSION) || \
    (BMS_COMMON_AR_RELEASE_MINOR_VERSION_CFG_C     != BMS_COMMON_AR_RELEASE_MINOR_VERSION) || \
    (BMS_COMMON_AR_RELEASE_REVISION_VERSION_CFG_C  != BMS_COMMON_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of CDD_Bms_common_Cfg.c and CDD_Bms_common.h are different"
#endif
/* Check if current file and CDD_Bms_common header file are of the same Software version */
#if ((BMS_COMMON_SW_MAJOR_VERSION_CFG_C  != BMS_COMMON_SW_MAJOR_VERSION) || \
    (BMS_COMMON_SW_MINOR_VERSION_CFG_C  != BMS_COMMON_SW_MINOR_VERSION) || \
    (BMS_COMMON_SW_PATCH_VERSION_CFG_C  != BMS_COMMON_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of CDD_Bms_common_Cfg.c and CDD_Bms_common.h are different"
#endif


/*==================================================================================================
*                                         LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
*                         LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
*                                  LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
*                                       GLOBAL CONSTANTS
==================================================================================================*/

#define BMS_COMMON_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Bms_common_MemMap.h"
/* Request and Response Buffers for Transaction Descriptors */
static uint16 Bcc772cTDCfg_0_ReqBuffer[512];
static uint16 Bcc772cTDCfg_0_RespBuffer[512];
static uint16 Bcc774aTDCfg_0_ReqBuffer[512];
static uint16 Bcc774aTDCfg_0_RespBuffer[512];
#define BMS_COMMON_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
#include "Bms_common_MemMap.h"

#define BMS_COMMON_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Bms_common_MemMap.h"
static Phy_TDType Bcc772cTDCfg_0_PhyTD =
{       
    {
        Bcc772cTDCfg_0_ReqBuffer,
        0,
        0
    },
    {
        Bcc772cTDCfg_0_RespBuffer,
        0U,
        0U
    },
    PHY_TPL2_FIXED_48L,
    0U,
    PHY_TS_IDLE,
    20000U,
    0U
};

Bms_TDType Bcc772cTDCfg_0 =
{
    &Bcc772cTDCfg_0_PhyTD,
    512U,
    512U,
    20000U
};
static Phy_TDType Bcc774aTDCfg_0_PhyTD =
{       
    {
        Bcc774aTDCfg_0_ReqBuffer,
        0,
        0
    },
    {
        Bcc774aTDCfg_0_RespBuffer,
        0U,
        0U
    },
    PHY_TPL3_VARIABLE,
    0U,
    PHY_TS_IDLE,
    20000U,
    0U
};

Bms_TDType Bcc774aTDCfg_0 =
{
    &Bcc774aTDCfg_0_PhyTD,
    512U,
    512U,
    20000U
};
Bms_TDType *Bms_TDList[2] = 
{
    &Bcc772cTDCfg_0
,
    &Bcc774aTDCfg_0

};


#define BMS_COMMON_STOP_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Bms_common_MemMap.h"

#ifdef __cplusplus
}
#endif

/** @} */


