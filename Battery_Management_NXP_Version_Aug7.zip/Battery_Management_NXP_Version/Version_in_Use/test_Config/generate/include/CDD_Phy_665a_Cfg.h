/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_PHY_665A_CFG_H
#define CDD_PHY_665A_CFG_H

/**
*   @file CDD_Phy_665a_Cfg.h
*
*   @addtogroup CDD_PHY_665A
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Phy_665a_Types.h"
#include "CDD_Bms_common_Types.h"
/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define PHY_665A_VENDOR_ID_CFG                    43
#define PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG     4
#define PHY_665A_AR_RELEASE_MINOR_VERSION_CFG     7
#define PHY_665A_AR_RELEASE_REVISION_VERSION_CFG  0
#define PHY_665A_SW_MAJOR_VERSION_CFG             1
#define PHY_665A_SW_MINOR_VERSION_CFG             0
#define PHY_665A_SW_PATCH_VERSION_CFG             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if this header file and CDD_Bms_common_Types.h are of the same Autosar version */
    #if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG != BMS_COMMON_TYPES_AR_RELEASE_MAJOR_VERSION) || \
        (PHY_665A_AR_RELEASE_MINOR_VERSION_CFG != BMS_COMMON_TYPES_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of CDD_Phy_665a_Cfg.h and CDD_Bms_common_Types.h are different"
    #endif
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same vendor */
#if (PHY_665A_VENDOR_ID_CFG != PHY_665A_VENDOR_ID_COM)
#error "CDD_Phy_665a_Cfg.h and CDD_Phy_665a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Autosar version */
#if ((PHY_665A_AR_RELEASE_MAJOR_VERSION_CFG != PHY_665A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (PHY_665A_AR_RELEASE_MINOR_VERSION_CFG != PHY_665A_AR_RELEASE_MINOR_VERSION_COM) || \
     (PHY_665A_AR_RELEASE_REVISION_VERSION_CFG != PHY_665A_AR_RELEASE_REVISION_VERSION_COM))
#error "AutoSar Version Numbers of CDD_Phy_665a_Cfg.h and CDD_Phy_665a_Types.h are different"
#endif

/* Check if this header file and CDD_Phy_665a_Types.h are of the same Software version */
#if ((PHY_665A_SW_MAJOR_VERSION_CFG != PHY_665A_SW_MAJOR_VERSION_COM) || \
     (PHY_665A_SW_MINOR_VERSION_CFG != PHY_665A_SW_MINOR_VERSION_COM) || \
     (PHY_665A_SW_PATCH_VERSION_CFG != PHY_665A_SW_PATCH_VERSION_COM))
#error "Software Version Numbers of CDD_Phy_665a_Cfg.h and CDD_Phy_665a_Types.h are different"
#endif

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/
/**
* @brief PHY_665A_DEV_ERROR_DETECT switch
* @details Switches the Development Error Detection and Notification ON or OFF.
* @implements PHY_665A_DEV_ERROR_DETECT_define
*/
#if (defined PHY_665A_DEV_ERROR_DETECT)
#error PHY_665A_DEV_ERROR_DETECT is already defined
#endif
#define PHY_665A_DEV_ERROR_DETECT (STD_ON)
/**
 * @brief PHY_665A_GLOBAL_BUFFER_SIZE
 * @details Macro used for defining the buffer size of the global resp and req buffers in SSpi usage.
 *          The value is computed by multiplying dual maximum TPL3 112bit request length + 1 hextet (for prefix) with RequestQueueSize (12).
 *          Dual size is needed due to cover maximum SPI busload (12 external requests and 12 internal requests in a single sequence transmission).
 * @implements PHY_665A_GLOBAL_BUFFER_SIZE_define
 */
#if (defined PHY_665A_GLOBAL_BUFFER_SIZE)
#error PHY_665A_GLOBAL_BUFFER_SIZE is already defined
#endif
#define PHY_665A_GLOBAL_BUFFER_SIZE (192U)

/**
 * @brief PHY_665A_SPIIF_TX_SEQUENCE_RANGE
 * @details Macro used for defining the allocated SPI sequences total for transmission.
 * @implements PHY_665A_SPIIF_TX_SEQUENCE_RANGE_define
 */
#if (defined PHY_665A_SPIIF_TX_SEQUENCE_RANGE)
#error PHY_665A_SPIIF_TX_SEQUENCE_RANGE is already defined
#endif
#define PHY_665A_SPIIF_TX_SEQUENCE_RANGE (24U)

/**
* @brief PHY_665A_RSP_QUEUE_HIGH_TRIGGER_MSGNUM
* @details Macro used for handling response queue high fill level on SPI variant.
* @implements PHY_665A_RSP_QUEUE_HIGH_TRIGGER_MSGNUM
*/
#if (defined PHY_665A_RSP_QUEUE_HIGH_TRIGGER_MSGNUM)
#error PHY_665A_RSP_QUEUE_HIGH_TRIGGER_MSGNUM is already defined
#endif
#define PHY_665A_RSP_QUEUE_HIGH_TRIGGER_MSGNUM (8U)

/**
* @brief PHY_665A_RSP_QUEUE_EXTRACTION_MSGNUM
* @details Macro used for handling responses extraction from queue on SPI variant.
* @implements PHY_665A_RSP_QUEUE_EXTRACTION_MSGNUM
*/
#if (defined PHY_665A_RSP_QUEUE_EXTRACTION_MSGNUM)
#error PHY_665A_RSP_QUEUE_EXTRACTION_MSGNUM is already defined
#endif
#define PHY_665A_RSP_QUEUE_EXTRACTION_MSGNUM (7U)

/**
* @brief PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED
* @details Macro used for checking queue feature support for SPI variant.
* @implements PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED
*/
#if (defined PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED)
#error PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED is already defined
#endif
#define PHY_665A_SPI_SW_QUEUE_SUPPORT_ENABLED (STD_OFF)

/**
* @brief PHY_665A_SPI_ASYNC_INIT_SUPPORT_ENABLED
* @details Macro used for enabling or disabling asynchronous initialization for SPI Phy_665a devices.
* @implements PHY_665A_SPI_ASYNC_INIT_SUPPORT_ENABLED_define
*/
#if (defined PHY_665A_SPI_ASYNC_INIT_SUPPORT_ENABLED)
#error PHY_665A_SPI_ASYNC_INIT_SUPPORT_ENABLED is already defined
#endif
#define PHY_665A_SPI_ASYNC_INIT_SUPPORT_ENABLED (STD_OFF)

/**
* @brief PHY_665A_SPI_OSC_SRC
* @details Macro used for identifying oscillator source used for determining the wake-up time.
* @implements PHY_665A_SPI_OSC_SRC
*/
#if (defined PHY_665A_SPI_OSC_SRC)
#error PHY_665A_SPI_OSC_SRC is already defined
#endif
#define PHY_665A_SPI_OSC_SRC (PHY_665A_RC_OSC)

/**
* @brief PHY_665A_WAKEUP_HW_DELAY
* @details Macro used for specifying the wake-up time based on oscillator source.
* @implements PHY_665A_WAKEUP_HW_DELAY
*/
#if (defined PHY_665A_WAKEUP_HW_DELAY)
#error PHY_665A_WAKEUP_HW_DELAY is already defined
#endif
#define PHY_665A_WAKEUP_HW_DELAY (600U)

/**
* @brief PHY_665A_CAN_SUPPORT_ENABLED
* @details Macro used for enabling or disabling CAN Mcu Interface protocol support for all the Phy_665a devices.
* @implements PHY_665A_CAN_SUPPORT_ENABLED_define
*/
#if (defined PHY_665A_CAN_SUPPORT_ENABLED)
#error PHY_665A_CAN_SUPPORT_ENABLED is already defined
#endif
#define PHY_665A_CAN_SUPPORT_ENABLED (STD_OFF)

/**
* @brief PHY_665A_SPI_SUPPORT_ENABLED
* @details Macro used for enabling or disabling Spi Mcu Interface protocol support for all the Phy_665a devices.
* @implements PHY_665A_SPI_SUPPORT_ENABLED_define
*/
#if (defined PHY_665A_SPI_SUPPORT_ENABLED)
#error PHY_665A_SPI_SUPPORT_ENABLED is already defined
#endif
#define PHY_665A_SPI_SUPPORT_ENABLED (STD_ON)

/**
* @brief PHY_665A_SPI_INDEX
* @details Macro used for identifying the phy index of the SPI phy_665a device
* @implements PHY_665A_SPI_INDEX
*/
#if (defined PHY_665A_SPI_INDEX)
#error PHY_665A_SPI_INDEX is already defined
#endif
#define PHY_665A_SPI_INDEX (0U)

/**
* @brief PHY_665A_SPI_GPT_CHANNEL
* @details Macro used for defining the GPT channel linked to PHY_665A_SPI_INDEX (0U).
* @implements PHY_665A_SPI_GPT_CHANNEL
*/
#if (defined PHY_665A_SPI_GPT_CHANNEL)
#error PHY_665A_SPI_GPT_CHANNEL is already defined
#endif
#define PHY_665A_SPI_GPT_CHANNEL (Gpt_ChannelType)(0x0U)

/**
* @brief PHY_665A_I2C_SUPPORT_ENABLED
* @details Macro used for enabling or disabling I2C configuration support for all the Phy_665a devices in the system.
* @implements PHY_665A_I2C_SUPPORT_ENABLED_define
*/
#if (defined PHY_665A_I2C_SUPPORT_ENABLED)
#error PHY_665A_I2C_SUPPORT_ENABLED is already defined
#endif
#define PHY_665A_I2C_SUPPORT_ENABLED (STD_OFF)


/**
* @brief PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS
* @details Macro used for defining Single Spi with Single CS Mcu Interface protocol Variant support for all the Phy_665a devices.
* @implements PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS_define
*/
#if (defined PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS)
#error PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS is already defined
#endif
#define PHY_665A_SPI_VARIANT_SINGLE_SPI_SINGLE_CS (0U)

/**
* @brief PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE
* @details Macro used for defining Dual Spi with Master Slave Mcu Interface protocol Variant support for all the Phy_665a devices.
* @implements PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE_define
*/
#if (defined PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE)
#error PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE is already defined
#endif
#define PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE (1U)

/**
* @brief PHY_665A_SPI_VARIANT
* @details Macro used for defining Spi Mcu Interface protocol Variant support for all the Phy_665a devices.
* @implements PHY_665A_SPI_VARIANT_define
*/
#if (defined PHY_665A_SPI_VARIANT)
#error PHY_665A_SPI_VARIANT is already defined
#endif
#define PHY_665A_SPI_VARIANT PHY_665A_SPI_VARIANT_DUAL_SPI_MASTER_SLAVE

/**
* @brief PHY_665A_NUMBER_OF_665A_DEVICES
* @details Macro used for defining the number of Phy_665a devices.
* @implements PHY_665A_NUMBER_OF_665A_DEVICES_define
*/
#if (defined PHY_665A_NUMBER_OF_665A_DEVICES)
#error PHY_665A_NUMBER_OF_665A_DEVICES is already defined
#endif
#define PHY_665A_NUMBER_OF_665A_DEVICES (1U)

/**
* @brief PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED
* @details Macro used for enabling or disabling the support for Sideband signal for all Phy_665a devices.
* @implements PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED_define
*/
#if (defined PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED)
#error PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED is already defined
#endif
#define PHY_665A_SIDE_BAND_SIGNAL_SUPPORT_ENABLED (STD_ON)


/**
* @brief PHY_665A_GPIO_CHANNEL_CONFIG_SUPPORT_ENABLED
* @details Macro used for enabling or disabling the support for Gpio Channel Configuration for all Phy_665a devices.
* @implements PHY_665A_GPIO_CHANNEL_CONFIG_SUPPORT_ENABLED_define
*/
#if (defined PHY_665A_GPIO_CHANNEL_CONFIG_SUPPORT_ENABLED)
#error PHY_665A_GPIO_CHANNEL_CONFIG_SUPPORT_ENABLED is already defined
#endif
#define PHY_665A_GPIO_CHANNEL_CONFIG_SUPPORT_ENABLED (STD_ON)


/**
* @brief PHY_665A_SPI_GPT_CLOCK_TICKS_1US
* @details Used to hold the number of edge aligned GPT ticks per microsecond for all SPI variants
* @implements GPT_SPI_CLOCK_TICKS_1US_define
*/
#if (defined PHY_665A_SPI_GPT_CLOCK_TICKS_1US)
#error PHY_665A_SPI_GPT_CLOCK_TICKS_1US is already defined
#endif
#define PHY_665A_SPI_GPT_CLOCK_TICKS_1US (48UL)

/**
* @brief PHY_665A_SPI_SEQUENCE_00
* @details Used to hold the sequence index for 1st TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_00_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_00)
#error PHY_665A_SPI_SEQUENCE_00 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_00 (Spi_SequenceType)(7U)

/**
* @brief PHY_665A_SPI_CHANNEL_00
* @details Used to hold the channel index for writing the 1st TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_00_define
*/
#if (defined PHY_665A_SPI_CHANNEL_00)
#error PHY_665A_SPI_CHANNEL_00 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_00 (Spi_ChannelType)(4U)

/**
* @brief PHY_665A_SPI_SEQUENCE_01
* @details Used to hold the sequence index for 2nd TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_01_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_01)
#error PHY_665A_SPI_SEQUENCE_01 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_01 (Spi_SequenceType)(8U)

/**
* @brief PHY_665A_SPI_CHANNEL_01
* @details Used to hold the channel index for writing the 2nd TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_01_define
*/
#if (defined PHY_665A_SPI_CHANNEL_01)
#error PHY_665A_SPI_CHANNEL_01 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_01 (Spi_ChannelType)(5U)

/**
* @brief PHY_665A_SPI_SEQUENCE_02
* @details Used to hold the sequence index for 3rd TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_02_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_02)
#error PHY_665A_SPI_SEQUENCE_02 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_02 (Spi_SequenceType)(9U)

/**
* @brief PHY_665A_SPI_CHANNEL_02
* @details Used to hold the channel index for writing the 3rd TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_02_define
*/
#if (defined PHY_665A_SPI_CHANNEL_02)
#error PHY_665A_SPI_CHANNEL_02 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_02 (Spi_ChannelType)(6U)

/**
* @brief PHY_665A_SPI_SEQUENCE_03
* @details Used to hold the sequence index for 4th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_03_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_03)
#error PHY_665A_SPI_SEQUENCE_03 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_03 (Spi_SequenceType)(10U)

/**
* @brief PHY_665A_SPI_CHANNEL_03
* @details Used to hold the channel index for writing the 4th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_03_define
*/
#if (defined PHY_665A_SPI_CHANNEL_03)
#error PHY_665A_SPI_CHANNEL_03 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_03 (Spi_ChannelType)(7U)

/**
* @brief PHY_665A_SPI_SEQUENCE_04
* @details Used to hold the sequence index for 5th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_04_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_04)
#error PHY_665A_SPI_SEQUENCE_04 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_04 (Spi_SequenceType)(11U)

/**
* @brief PHY_665A_SPI_CHANNEL_04
* @details Used to hold the channel index for writing the 5th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_04_define
*/
#if (defined PHY_665A_SPI_CHANNEL_04)
#error PHY_665A_SPI_CHANNEL_04 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_04 (Spi_ChannelType)(8U)

/**
* @brief PHY_665A_SPI_SEQUENCE_05
* @details Used to hold the sequence index for 6th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_05_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_05)
#error PHY_665A_SPI_SEQUENCE_05 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_05 (Spi_SequenceType)(12U)

/**
* @brief PHY_665A_SPI_CHANNEL_05
* @details Used to hold the channel index for writing the 6th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_05_define
*/
#if (defined PHY_665A_SPI_CHANNEL_05)
#error PHY_665A_SPI_CHANNEL_05 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_05 (Spi_ChannelType)(9U)

/**
* @brief PHY_665A_SPI_SEQUENCE_06
* @details Used to hold the sequence index for 7th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_06_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_06)
#error PHY_665A_SPI_SEQUENCE_06 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_06 (Spi_SequenceType)(13U)

/**
* @brief PHY_665A_SPI_CHANNEL_06
* @details Used to hold the channel index for writing the 7th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_06_define
*/
#if (defined PHY_665A_SPI_CHANNEL_06)
#error PHY_665A_SPI_CHANNEL_06 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_06 (Spi_ChannelType)(10U)

/**
* @brief PHY_665A_SPI_SEQUENCE_07
* @details Used to hold the sequence index for 8th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_07_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_07)
#error PHY_665A_SPI_SEQUENCE_07 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_07 (Spi_SequenceType)(14U)

/**
* @brief PHY_665A_SPI_CHANNEL_07
* @details Used to hold the channel index for writing the 8th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_07_define
*/
#if (defined PHY_665A_SPI_CHANNEL_07)
#error PHY_665A_SPI_CHANNEL_07 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_07 (Spi_ChannelType)(11U)

/**
* @brief PHY_665A_SPI_SEQUENCE_08
* @details Used to hold the sequence index for 9th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_08_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_08)
#error PHY_665A_SPI_SEQUENCE_08 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_08 (Spi_SequenceType)(15U)

/**
* @brief PHY_665A_SPI_CHANNEL_08
* @details Used to hold the channel index for writing the 9th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_08_define
*/
#if (defined PHY_665A_SPI_CHANNEL_08)
#error PHY_665A_SPI_CHANNEL_08 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_08 (Spi_ChannelType)(12U)

/**
* @brief PHY_665A_SPI_SEQUENCE_09
* @details Used to hold the sequence index for 10th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_09_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_09)
#error PHY_665A_SPI_SEQUENCE_09 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_09 (Spi_SequenceType)(16U)

/**
* @brief PHY_665A_SPI_CHANNEL_09
* @details Used to hold the channel index for writing the 10th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_09_define
*/
#if (defined PHY_665A_SPI_CHANNEL_09)
#error PHY_665A_SPI_CHANNEL_09 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_09 (Spi_ChannelType)(13U)

/**
* @brief PHY_665A_SPI_SEQUENCE_10
* @details Used to hold the sequence index for 11th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_10_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_10)
#error PHY_665A_SPI_SEQUENCE_10 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_10 (Spi_SequenceType)(17U)

/**
* @brief PHY_665A_SPI_CHANNEL_10
* @details Used to hold the channel index for writing the 11th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_10_define
*/
#if (defined PHY_665A_SPI_CHANNEL_10)
#error PHY_665A_SPI_CHANNEL_10 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_10 (Spi_ChannelType)(14U)

/**
* @brief PHY_665A_SPI_SEQUENCE_11
* @details Used to hold the sequence index for 12th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_11_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_11)
#error PHY_665A_SPI_SEQUENCE_11 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_11 (Spi_SequenceType)(18U)

/**
* @brief PHY_665A_SPI_CHANNEL_11
* @details Used to hold the channel index for writing the 12th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_11_define
*/
#if (defined PHY_665A_SPI_CHANNEL_11)
#error PHY_665A_SPI_CHANNEL_11 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_11 (Spi_ChannelType)(15U)

/**
* @brief PHY_665A_SPI_SEQUENCE_12
* @details Used to hold the sequence index for 13th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_12_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_12)
#error PHY_665A_SPI_SEQUENCE_12 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_12 (Spi_SequenceType)(19U)

/**
* @brief PHY_665A_SPI_CHANNEL_12
* @details Used to hold the channel index for writing the 13th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_12_define
*/
#if (defined PHY_665A_SPI_CHANNEL_12)
#error PHY_665A_SPI_CHANNEL_12 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_12 (Spi_ChannelType)(16U)

/**
* @brief PHY_665A_SPI_SEQUENCE_13
* @details Used to hold the sequence index for 14th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_13_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_13)
#error PHY_665A_SPI_SEQUENCE_13 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_13 (Spi_SequenceType)(20U)

/**
* @brief PHY_665A_SPI_CHANNEL_13
* @details Used to hold the channel index for writing the 14th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_13_define
*/
#if (defined PHY_665A_SPI_CHANNEL_13)
#error PHY_665A_SPI_CHANNEL_13 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_13 (Spi_ChannelType)(17U)

/**
* @brief PHY_665A_SPI_SEQUENCE_14
* @details Used to hold the sequence index for 15th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_14_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_14)
#error PHY_665A_SPI_SEQUENCE_14 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_14 (Spi_SequenceType)(21U)

/**
* @brief PHY_665A_SPI_CHANNEL_14
* @details Used to hold the channel index for writing the 15th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_14_define
*/
#if (defined PHY_665A_SPI_CHANNEL_14)
#error PHY_665A_SPI_CHANNEL_14 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_14 (Spi_ChannelType)(18U)

/**
* @brief PHY_665A_SPI_SEQUENCE_15
* @details Used to hold the sequence index for 16th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_15_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_15)
#error PHY_665A_SPI_SEQUENCE_15 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_15 (Spi_SequenceType)(22U)

/**
* @brief PHY_665A_SPI_CHANNEL_15
* @details Used to hold the channel index for writing the 16th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_15_define
*/
#if (defined PHY_665A_SPI_CHANNEL_15)
#error PHY_665A_SPI_CHANNEL_15 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_15 (Spi_ChannelType)(19U)

/**
* @brief PHY_665A_SPI_SEQUENCE_16
* @details Used to hold the sequence index for 17th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_16_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_16)
#error PHY_665A_SPI_SEQUENCE_16 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_16 (Spi_SequenceType)(23U)

/**
* @brief PHY_665A_SPI_CHANNEL_16
* @details Used to hold the channel index for writing the 17th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_16_define
*/
#if (defined PHY_665A_SPI_CHANNEL_16)
#error PHY_665A_SPI_CHANNEL_16 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_16 (Spi_ChannelType)(20U)

/**
* @brief PHY_665A_SPI_SEQUENCE_17
* @details Used to hold the sequence index for 18th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_17_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_17)
#error PHY_665A_SPI_SEQUENCE_17 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_17 (Spi_SequenceType)(24U)

/**
* @brief PHY_665A_SPI_CHANNEL_17
* @details Used to hold the channel index for writing the 18th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_17_define
*/
#if (defined PHY_665A_SPI_CHANNEL_17)
#error PHY_665A_SPI_CHANNEL_17 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_17 (Spi_ChannelType)(21U)

/**
* @brief PHY_665A_SPI_SEQUENCE_18
* @details Used to hold the sequence index for 19th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_18_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_18)
#error PHY_665A_SPI_SEQUENCE_18 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_18 (Spi_SequenceType)(25U)

/**
* @brief PHY_665A_SPI_CHANNEL_18
* @details Used to hold the channel index for writing the 19th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_18_define
*/
#if (defined PHY_665A_SPI_CHANNEL_18)
#error PHY_665A_SPI_CHANNEL_18 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_18 (Spi_ChannelType)(22U)

/**
* @brief PHY_665A_SPI_SEQUENCE_19
* @details Used to hold the sequence index for 20th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_19_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_19)
#error PHY_665A_SPI_SEQUENCE_19 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_19 (Spi_SequenceType)(26U)

/**
* @brief PHY_665A_SPI_CHANNEL_19
* @details Used to hold the channel index for writing the 20th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_19_define
*/
#if (defined PHY_665A_SPI_CHANNEL_19)
#error PHY_665A_SPI_CHANNEL_19 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_19 (Spi_ChannelType)(23U)

/**
* @brief PHY_665A_SPI_SEQUENCE_20
* @details Used to hold the sequence index for 21st TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_20_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_20)
#error PHY_665A_SPI_SEQUENCE_20 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_20 (Spi_SequenceType)(27U)

/**
* @brief PHY_665A_SPI_CHANNEL_20
* @details Used to hold the channel index for writing the 21st TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_20_define
*/
#if (defined PHY_665A_SPI_CHANNEL_20)
#error PHY_665A_SPI_CHANNEL_20 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_20 (Spi_ChannelType)(24U)

/**
* @brief PHY_665A_SPI_SEQUENCE_21
* @details Used to hold the sequence index for 22nd TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_21_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_21)
#error PHY_665A_SPI_SEQUENCE_21 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_21 (Spi_SequenceType)(28U)

/**
* @brief PHY_665A_SPI_CHANNEL_21
* @details Used to hold the channel index for writing the 22nd TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_21_define
*/
#if (defined PHY_665A_SPI_CHANNEL_21)
#error PHY_665A_SPI_CHANNEL_21 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_21 (Spi_ChannelType)(25U)

/**
* @brief PHY_665A_SPI_SEQUENCE_22
* @details Used to hold the sequence index for 23rd TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_22_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_22)
#error PHY_665A_SPI_SEQUENCE_22 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_22 (Spi_SequenceType)(29U)

/**
* @brief PHY_665A_SPI_CHANNEL_22
* @details Used to hold the channel index for writing the 23rd TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_22_define
*/
#if (defined PHY_665A_SPI_CHANNEL_22)
#error PHY_665A_SPI_CHANNEL_22 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_22 (Spi_ChannelType)(26U)

/**
* @brief PHY_665A_SPI_SEQUENCE_23
* @details Used to hold the sequence index for 24th TD message in the request buffer
* @implements PHY_665A_SPI_SEQUENCE_23_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_23)
#error PHY_665A_SPI_SEQUENCE_23 is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_23 (Spi_SequenceType)(30U)

/**
* @brief PHY_665A_SPI_CHANNEL_23
* @details Used to hold the channel index for writing the 24th TD message in its EB
* @implements PHY_665A_SPI_CHANNEL_23_define
*/
#if (defined PHY_665A_SPI_CHANNEL_23)
#error PHY_665A_SPI_CHANNEL_23 is already defined
#endif
#define PHY_665A_SPI_CHANNEL_23 (Spi_ChannelType)(27U)

/**
* @brief PHY_665A_SPI_SEQUENCE_RX
* @details Used to hold the single sequence index used for transferring received SPI data into TD response buffer
* @implements PHY_665A_SPI_SEQUENCE_RX_define
*/
#if (defined PHY_665A_SPI_SEQUENCE_RX)
#error PHY_665A_SPI_SEQUENCE_RX is already defined
#endif
#define PHY_665A_SPI_SEQUENCE_RX (Spi_SequenceType)(31U)

/**
* @brief PHY_665A_SPI_CHANNEL_RX
* @details Used to hold the RX channel index for writing in its EB
* @implements PHY_665A_SPI_CHANNEL_RX_define
*/
#if (defined PHY_665A_SPI_CHANNEL_RX)
#error PHY_665A_SPI_CHANNEL_RX is already defined
#endif
#define PHY_665A_SPI_CHANNEL_RX (Spi_ChannelType)(28U)

#define PHY_665A_RX_DMA_CHANNEL DMA_LOGIC_CH_0


/**
* @brief PHY_665A_DEV_0_GPIO_CHNL_CFG_COUNT
* @details Macro used for defining the count of Gpio channel configured for Phy_665a_device_0.
* @implements PHY_665A_DEV_0_GPIO_CHNL_CFG_COUNT_define
*/
#if (defined PHY_665A_DEV_0_GPIO_CHNL_CFG_COUNT)
#error PHY_665A_DEV_0_GPIO_CHNL_CFG_COUNT is already defined
#endif
#define PHY_665A_DEV_0_GPIO_CHNL_CFG_COUNT (0x5U)

/**
* @brief PHY_665A_DEVICE_PHY_665A_DEVICECONFIG_0
* @details Macro used for defining the device Idx for Phy_665a_device_PHY_665A_DEVICECONFIG_0.
* @implements PHY_665A_DEVICE_PHY_665A_DEVICECONFIG_0_define
*/
#if (defined PHY_665A_DEVICE_PHY_665A_DEVICECONFIG_0)
#error PHY_665A_DEVICE_PHY_665A_DEVICECONFIG_0 is already defined
#endif
#define PHY_665A_DEVICE_PHY_665A_DEVICECONFIG_0 (0x0U)


/**
* @brief PHY_665A_DEVICE_CONFIG0
* @details Macro used for defining the device Idx for Phy_665a_device_0.
* @implements PHY_665A_DEVICE_CONFIG0_define
*/
#if (defined PHY_665A_DEVICE_CONFIG0)
#error PHY_665A_DEVICE_CONFIG0 is already defined
#endif
#define PHY_665A_DEVICE_CONFIG0 (0x0U)


/**
* @brief PHY_665A_DEVICE_0_ICU_GPIO0
* @details Macro used for defining the ICU channel mapped to Gpio_Channel_GPIO0 for Phy_665a_device_0
* @implements PHY_665A_DEVICE_0_ICU_GPIO0_define
*/
#if (defined PHY_665A_DEVICE_0_ICU_GPIO0)
#error PHY_665A_DEVICE_0_ICU_GPIO0 is already defined
#endif
#define PHY_665A_DEVICE_0_ICU_GPIO0 (0x0U)

/**
* @brief PHY_665A_DEVICE_0_GPT_CHANNEL_CONFIG
* @details  Macro used for defining the GPT channel used for Phy_665a_device_0.
* @implements PHY_665A_DEVICE_0_GPT_CHANNEL_CONFIG_define
*/
#if (defined PHY_665A_DEVICE_0_GPT_CHANNEL_CONFIG)
#error PHY_665A_DEVICE_0_GPT_CHANNEL_CONFIG is already defined
#endif
#define PHY_665A_DEVICE_0_GPT_CHANNEL_CONFIG (0x0U)

/**
* @brief INTERNALTDCONFIG_0_REQ_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Request messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_0.
* @implements INTERNALTDCONFIG_0_REQ_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_0_REQ_BUFF_SIZE)
#error INTERNALTDCONFIG_0_REQ_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_0_REQ_BUFF_SIZE 0x100U

/**
* @brief INTERNALTDCONFIG_0_RESP_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Response messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_0.
* @implements INTERNALTDCONFIG_0_RESP_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_0_RESP_BUFF_SIZE)
#error INTERNALTDCONFIG_0_RESP_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_0_RESP_BUFF_SIZE 0x100U

/**
* @brief INTERNALTDCONFIG_1_REQ_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Request messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_1.
* @implements INTERNALTDCONFIG_1_REQ_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_1_REQ_BUFF_SIZE)
#error INTERNALTDCONFIG_1_REQ_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_1_REQ_BUFF_SIZE 0x100U

/**
* @brief INTERNALTDCONFIG_1_RESP_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Response messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_1.
* @implements INTERNALTDCONFIG_1_RESP_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_1_RESP_BUFF_SIZE)
#error INTERNALTDCONFIG_1_RESP_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_1_RESP_BUFF_SIZE 0x100U

/**
* @brief INTERNALTDCONFIG_2_REQ_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Request messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_2.
* @implements INTERNALTDCONFIG_2_REQ_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_2_REQ_BUFF_SIZE)
#error INTERNALTDCONFIG_2_REQ_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_2_REQ_BUFF_SIZE 0x100U

/**
* @brief INTERNALTDCONFIG_2_RESP_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Response messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_2.
* @implements INTERNALTDCONFIG_2_RESP_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_2_RESP_BUFF_SIZE)
#error INTERNALTDCONFIG_2_RESP_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_2_RESP_BUFF_SIZE 0x100U

/**
* @brief INTERNALTDCONFIG_3_REQ_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Request messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_3.
* @implements INTERNALTDCONFIG_3_REQ_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_3_REQ_BUFF_SIZE)
#error INTERNALTDCONFIG_3_REQ_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_3_REQ_BUFF_SIZE 0x100U

/**
* @brief INTERNALTDCONFIG_3_RESP_BUFF_SIZE
* @details Macro used for defining the size of Buffer used for storing the internal Response messages that are to be sent to MC33665A devices using the internal TD InternalTDConfig_3.
* @implements INTERNALTDCONFIG_3_RESP_BUFF_SIZE_define
*/
#if (defined INTERNALTDCONFIG_3_RESP_BUFF_SIZE)
#error INTERNALTDCONFIG_3_RESP_BUFF_SIZE is already defined
#endif
#define INTERNALTDCONFIG_3_RESP_BUFF_SIZE 0x100U

/**
* @brief PHY_665A_INTERNAL_TD_MAX
* @details Macro used for defining the number of internal TDs to be used for all the PHY_665A devices.
* @implements PHY_665A_INTERNAL_TD_MAX_define
*/
#if (defined PHY_665A_INTERNAL_TD_MAX)
#error PHY_665A_INTERNAL_TD_MAX is already defined
#endif
#define PHY_665A_INTERNAL_TD_MAX (0x4U)

/*==================================================================================================
*                                            ENUMS
==================================================================================================*/

/*==================================================================================================
*                               STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/
#define PHY_665A_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

/*
 * Variable used for storing the Transaction Descriptor information for the internal InternalTDConfig_0 that are to be sent to MC33665A devices.
*/
extern Phy_TDType InternalTDConfig_0;


/*
 * Variable used for storing the Transaction Descriptor information for the internal InternalTDConfig_1 that are to be sent to MC33665A devices.
*/
extern Phy_TDType InternalTDConfig_1;


/*
 * Variable used for storing the Transaction Descriptor information for the internal InternalTDConfig_2 that are to be sent to MC33665A devices.
*/
extern Phy_TDType InternalTDConfig_2;


/*
 * Variable used for storing the Transaction Descriptor information for the internal InternalTDConfig_3 that are to be sent to MC33665A devices.
*/
extern Phy_TDType InternalTDConfig_3;

#define PHY_665A_STOP_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_CONST_UNSPECIFIED
#include "Phy_665a_MemMap.h"
/*
 * Constant used for storing the Transaction Descriptor addresses and their respective request and response buffer sizes for all the internal TD of all the PHY_665A Devices.
*/
extern const Phy_665a_IntTdAddrBuffInfoType Phy_665a_InternalTdAdrrBuffInfoTbl[];
#define PHY_665A_STOP_SEC_CONST_UNSPECIFIED
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Phy_665a_MemMap.h"
/*
 * Constant used for storing the configuration of PHY_665A devices.
*/
extern const Phy_665aConfig_Type Phy_665a_Devices[PHY_665A_NUMBER_OF_665A_DEVICES];

/*
 * Rom Table used for storing the static pre compile time configuration of all PHY_665A devices registers.
*/
extern const Phy_665a_RegistersType Phy_665a_RegistersRomTbl[];
#define PHY_665A_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Phy_665a_MemMap.h"

#define PHY_665A_START_SEC_VAR_INIT_UNSPECIFIED
#include "Phy_665a_MemMap.h"
/*
 * Ram Table used for storing the dynamic run time configuration of all PHY_665A devices registers.
*/
extern Phy_665a_RegistersType Phy_665a_RegistersRamTbl[];

/*
 * Array used for storing the synchronization state of all Phy_665a devices.
*/
extern Phy_665a_SyncModeStateInfoType Phy_665a_SyncState[PHY_665A_NUMBER_OF_665A_DEVICES];

#define PHY_665A_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Phy_665a_MemMap.h"

/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_PHY_665A_CFG_H */

