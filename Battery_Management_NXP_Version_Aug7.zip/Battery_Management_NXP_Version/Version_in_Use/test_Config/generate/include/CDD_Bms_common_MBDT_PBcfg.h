/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
#ifndef BMS_COMMON_MBDT_PBCFG_H
#define BMS_COMMON_MBDT_PBCFG_H

/**
*   @file    CDD_Bms_common_MBDT_PBcfg.h
*
*   @addtogroup CDD_BMS_COMMON
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bms_common_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define BMS_COMMON_VENDOR_ID_MBDT_PBCFG                     43
#define BMS_COMMON_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG      4
#define BMS_COMMON_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG      7
#define BMS_COMMON_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG   0
#define BMS_COMMON_SW_MAJOR_VERSION_MBDT_PBCFG              1
#define BMS_COMMON_SW_MINOR_VERSION_MBDT_PBCFG              0
#define BMS_COMMON_SW_PATCH_VERSION_MBDT_PBCFG              2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if this header file and CDD_Bms_common_Types.h are of the same vendor */
#if (BMS_COMMON_VENDOR_ID_MBDT_PBCFG  != BMS_COMMON_TYPES_VENDOR_ID)
#error "CDD_Bms_common_MBDT_PBcfg.h and CDD_Bms_common_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Bms_common_Types.h are of the same Autosar version */
#if ((BMS_COMMON_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG != BMS_COMMON_TYPES_AR_RELEASE_MAJOR_VERSION) || \
    (BMS_COMMON_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG != BMS_COMMON_TYPES_AR_RELEASE_MINOR_VERSION) || \
    (BMS_COMMON_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG != BMS_COMMON_TYPES_AR_RELEASE_REVISION_VERSION) \
    )
#error "AutoSar Version Numbers of CDD_Bms_common_MBDT_PBcfg.h and CDD_Bms_common_Types.h are different"
#endif

/* Check if this header file and CDD_Bms_common_Types.h are of the same Software version */
#if ((BMS_COMMON_SW_MAJOR_VERSION_MBDT_PBCFG != BMS_COMMON_TYPES_SW_MAJOR_VERSION) || \
    (BMS_COMMON_SW_MINOR_VERSION_MBDT_PBCFG  != BMS_COMMON_TYPES_SW_MINOR_VERSION) || \
    (BMS_COMMON_SW_PATCH_VERSION_MBDT_PBCFG != BMS_COMMON_TYPES_SW_PATCH_VERSION)  \
    )
#error "Software Version Numbers of CDD_Bms_common_MBDT_PBcfg.h and CDD_Bms_common_Types.h are different"
#endif
/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/
/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/

/**
* @brief Define number of TPL3 chains.
* @details Define number of TPL3 chains.
*/
#if !(defined BMS_NUMBER_OF_TPL3_CHAINS)
#define BMS_NUMBER_OF_TPL3_CHAINS               (1U)
#endif

/**
* @brief Define number of TPL2 chains.
* @details Define number of TPL2 chains.
*/
#if !(defined BMS_NUMBER_OF_TPL2_CHAINS)
#define BMS_NUMBER_OF_TPL2_CHAINS               (1U)
#endif



/*==================================================================================================
*                                            ENUMS
==================================================================================================*/

/*==================================================================================================
*                               STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

#define BMS_COMMON_START_SEC_CONST_UNSPECIFIED
#include "Bms_common_MemMap.h"
/*TPL3 chains  List*/
extern const BmsTpl3ChainConfigType BmsTpl3ChainConfigList_MBDT[BMS_NUMBER_OF_TPL3_CHAINS];
/*TPL2 chains  List*/
extern const BmsTpl2ChainConfigType BmsTpl2ChainConfigList_MBDT[BMS_NUMBER_OF_TPL2_CHAINS];
#define BMS_COMMON_STOP_SEC_CONST_UNSPECIFIED
#include "Bms_common_MemMap.h"

/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* BMS_COMMON_MBDT_PBCFG_H */

