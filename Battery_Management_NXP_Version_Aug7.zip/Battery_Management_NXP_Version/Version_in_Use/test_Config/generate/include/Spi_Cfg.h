/**
*   @file    Spi_Cfg.h
*   @version 3.0.0
*
*   @brief   AUTOSAR Spi - Spi configuration header file.
*   @details This file is the header containing all the necessary information for SPI
*            module configuration(s).
*   @addtogroup SPI_DRIVER_CONFIGURATION Spi Driver Configuration
*   @{
*/
/*==================================================================================================
*   Project              : RTD AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : LPSPI
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 3.0.0
*   Build Version        : S32K3_RTD_3_0_0_D2303_ASR_REL_4_7_REV_0000_20230331
*
*   Copyright 2020 - 2023 NXP Semiconductors NXP
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
#ifndef SPI_CFG_H
#define SPI_CFG_H

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
* 4) user callback header files
==================================================================================================*/
#include "Mcal.h"
#include "OsIf.h"

#include "Spi_MBDT_PBcfg.h"
#include "Spi_Ipw_Cfg.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/

#define SPI_VENDOR_ID_CFG                       43
#define SPI_AR_RELEASE_MAJOR_VERSION_CFG        4
#define SPI_AR_RELEASE_MINOR_VERSION_CFG        7
#define SPI_AR_RELEASE_REVISION_VERSION_CFG     0
#define SPI_SW_MAJOR_VERSION_CFG                3
#define SPI_SW_MINOR_VERSION_CFG                0
#define SPI_SW_PATCH_VERSION_CFG                0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Mcal header file are of the same Autosar version */
    #if ((SPI_AR_RELEASE_MAJOR_VERSION_CFG != MCAL_AR_RELEASE_MAJOR_VERSION) || \
         (SPI_AR_RELEASE_MINOR_VERSION_CFG != MCAL_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of Spi_Cfg.h and Mcal.h are different"
    #endif

    /* Check if the current file and OsIf.h header file are of the same version */
    #if ((SPI_AR_RELEASE_MAJOR_VERSION_CFG != OSIF_AR_RELEASE_MAJOR_VERSION) || \
         (SPI_AR_RELEASE_MINOR_VERSION_CFG != OSIF_AR_RELEASE_MINOR_VERSION))
    #error "AutoSar Version Numbers of Spi_Cfg.h and OsIf.h are different"
    #endif
#endif

/* Check if Spi_MBDT_PBcfg header file and Spi configuration header file are of the same vendor */
#if (SPI_VENDOR_ID_MBDT_PBCFG_H != SPI_VENDOR_ID_CFG)
    #error "Spi_MBDT_PBcfg.h and Spi_Cfg.h have different vendor IDs"
#endif
    /* Check if Spi_MBDT_PBcfg header file and Spi  configuration header file are of the same Autosar version */
#if ((SPI_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG_H != SPI_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (SPI_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG_H != SPI_AR_RELEASE_MINOR_VERSION_CFG) || \
     (SPI_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG_H != SPI_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of Spi_MBDT_PBcfg.h and Spi_Cfg.h are different"
#endif
/* Check if Spi_MBDT_PBcfg header file and Spi configuration header file are of the same software version */
#if ((SPI_SW_MAJOR_VERSION_MBDT_PBCFG_H != SPI_SW_MAJOR_VERSION_CFG) || \
     (SPI_SW_MINOR_VERSION_MBDT_PBCFG_H != SPI_SW_MINOR_VERSION_CFG) || \
     (SPI_SW_PATCH_VERSION_MBDT_PBCFG_H != SPI_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of Spi_MBDT_PBcfg.h and Spi_Cfg.h are different"
#endif

/* Check if Spi_Ipw_Cfg header file and Spi configuration header file are of the same vendor */
#if (SPI_IPW_VENDOR_ID_CFG_H != SPI_VENDOR_ID_CFG)
    #error "Spi_Ipw_Cfg.h and Spi_Cfg.h have different vendor IDs"
#endif
    /* Check if Spi_Ipw_Cfg header file and Spi configuration header file are of the same Autosar version */
#if ((SPI_IPW_AR_RELEASE_MAJOR_VERSION_CFG_H != SPI_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (SPI_IPW_AR_RELEASE_MINOR_VERSION_CFG_H != SPI_AR_RELEASE_MINOR_VERSION_CFG) || \
     (SPI_IPW_AR_RELEASE_REVISION_VERSION_CFG_H != SPI_AR_RELEASE_REVISION_VERSION_CFG))
#error "AutoSar Version Numbers of Spi_Ipw_Cfg.h and Spi_Cfg.h are different"
#endif
/* Check if Spi_Ipw_Cfg header file and Spi configuration header file are of the same software version */
#if ((SPI_IPW_SW_MAJOR_VERSION_CFG_H != SPI_SW_MAJOR_VERSION_CFG) || \
     (SPI_IPW_SW_MINOR_VERSION_CFG_H != SPI_SW_MINOR_VERSION_CFG) || \
     (SPI_IPW_SW_PATCH_VERSION_CFG_H != SPI_SW_PATCH_VERSION_CFG))
#error "Software Version Numbers of Spi_Ipw_Cfg.h and Spi_Cfg.h are different"
#endif
/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/
/**
* @brief Switches the Development Error functionality ON or OFF.
* @details Switches the Development Error Detection and Notification ON or OFF.
* @implements SPI_DEV_ERROR_DETECT_define
*/
#define SPI_DEV_ERROR_DETECT           STD_ON
/**
* @brief Switches the Version Information API functionality ON or OFF.
* @details Switches the Spi_GetVersionInfo function ON or OFF.
*/
#define SPI_VERSION_INFO_API           STD_ON
/**
* @brief Switches the Interruptible Sequences handling functionality ON or OFF. 
* @details This parameter depends on SPI_LEVEL_DELIVERED value. 
*        It is only used for SPI_LEVEL_DELIVERED configured to 1 or 2.
* @implements SPI_INTERRUPTIBLE_SEQ_ALLOWED_define
*/
#define SPI_INTERRUPTIBLE_SEQ_ALLOWED           STD_OFF
/**
* @brief Switches the Spi_GetHWUnitStatus function ON or OFF.
* @details Switches the Spi_GetHWUnitStatus function ON or OFF.
* @implements SPI_HW_STATUS_API_define
*/
#define SPI_HW_STATUS_API           STD_ON
/**
* @brief Switches the Spi_Cancel function ON or OFF.
* @details Switches the Spi_Cancel function ON or OFF. (see chapter 8.3.13)
* @implements SPI_CANCEL_API_define
*/
#define SPI_CANCEL_API           STD_ON
/* Only Internal Buffers are allowed in Handler Driver.*/
#define SPI_USAGE0                          0x00u

/* Only External Buffers are allowed in Handler Driver.*/
#define SPI_USAGE1                          0x01u

/* Both Buffer types are allowd in Handler Driver. */
#define SPI_USAGE2                          0x02u

/**
* @brief Selects the SPI Handler Driver Channel Buffers usage allowed and delivered.
* @details Selects the SPI Handler Driver Channel Buffers usage allowed and delivered.
*        (see chapter 7.2.1)
* @implements SPI_CHANNEL_BUFFERS_ALLOWED_define
*/
#define SPI_CHANNEL_BUFFERS_ALLOWED           SPI_USAGE1
/* The LEVEL 0 Simple Synchronous SPI Handler Driver functionalities are selected.*/
#define SPI_LEVEL0                          0x00u

/* The LEVEL 1 Basic Asynchronous SPI Handler Driver functionalities are selected.*/
#define SPI_LEVEL1                          0x01u

/* The LEVEL 2 Enhanced SPI Handler Driver functionalities are selected. */
#define SPI_LEVEL2                          0x02u

/**
* @brief Selects the SPI Handler Driver level of scalable functionality.
* @details Selects the SPI Handler Driver level of scalable functionality that 
* is available and delivered. (see chapter 7.1)
* @implements SPI_LEVEL_DELIVERED_define
*/
#define SPI_LEVEL_DELIVERED            SPI_LEVEL2
/**
* @brief Defines the maximum number of supported channels.
* @details Defines the maximum number of supported channels
*     for all the driver configurations.
*/
#define SpiConf_SpiChannel_SpiChannel_SBC    ((Spi_ChannelType)0U)
#define SpiConf_SpiChannel_SpiChannel_LSW    ((Spi_ChannelType)1U)
#define SpiConf_SpiChannel_SpiChannel_TJA    ((Spi_ChannelType)2U)
#define SpiConf_SpiChannel_SpiChannel_HB2000    ((Spi_ChannelType)3U)
#define SpiConf_SpiChannel_SpiChannel_PHY_1    ((Spi_ChannelType)4U)
#define SpiConf_SpiChannel_SpiChannel_PHY_2    ((Spi_ChannelType)5U)
#define SpiConf_SpiChannel_SpiChannel_PHY_3    ((Spi_ChannelType)6U)
#define SpiConf_SpiChannel_SpiChannel_PHY_4    ((Spi_ChannelType)7U)
#define SpiConf_SpiChannel_SpiChannel_PHY_5    ((Spi_ChannelType)8U)
#define SpiConf_SpiChannel_SpiChannel_PHY_6    ((Spi_ChannelType)9U)
#define SpiConf_SpiChannel_SpiChannel_PHY_7    ((Spi_ChannelType)10U)
#define SpiConf_SpiChannel_SpiChannel_PHY_8    ((Spi_ChannelType)11U)
#define SpiConf_SpiChannel_SpiChannel_PHY_9    ((Spi_ChannelType)12U)
#define SpiConf_SpiChannel_SpiChannel_PHY_10    ((Spi_ChannelType)13U)
#define SpiConf_SpiChannel_SpiChannel_PHY_11    ((Spi_ChannelType)14U)
#define SpiConf_SpiChannel_SpiChannel_PHY_12    ((Spi_ChannelType)15U)
#define SpiConf_SpiChannel_SpiChannel_PHY_13    ((Spi_ChannelType)16U)
#define SpiConf_SpiChannel_SpiChannel_PHY_14    ((Spi_ChannelType)17U)
#define SpiConf_SpiChannel_SpiChannel_PHY_15    ((Spi_ChannelType)18U)
#define SpiConf_SpiChannel_SpiChannel_PHY_16    ((Spi_ChannelType)19U)
#define SpiConf_SpiChannel_SpiChannel_PHY_17    ((Spi_ChannelType)20U)
#define SpiConf_SpiChannel_SpiChannel_PHY_18    ((Spi_ChannelType)21U)
#define SpiConf_SpiChannel_SpiChannel_PHY_19    ((Spi_ChannelType)22U)
#define SpiConf_SpiChannel_SpiChannel_PHY_20    ((Spi_ChannelType)23U)
#define SpiConf_SpiChannel_SpiChannel_PHY_21    ((Spi_ChannelType)24U)
#define SpiConf_SpiChannel_SpiChannel_PHY_22    ((Spi_ChannelType)25U)
#define SpiConf_SpiChannel_SpiChannel_PHY_23    ((Spi_ChannelType)26U)
#define SpiConf_SpiChannel_SpiChannel_PHY_24    ((Spi_ChannelType)27U)
#define SpiConf_SpiChannel_SpiChannel_PHY_Rx    ((Spi_ChannelType)28U)
#define SpiConf_SpiChannel_SpiChannel_HB2000_2    ((Spi_ChannelType)29U)
#define SpiConf_SpiChannel_SpiChannel_HB2000_3    ((Spi_ChannelType)30U)
#define SpiConf_SpiChannel_SpiChannel_HB2000_4    ((Spi_ChannelType)31U)
#define SPI_MAX_CHANNEL 32U
/**
* @brief Total number of Jobs configured.
* @details Defines the maximum number of supported jobs
*     for all the driver configurations.
*/
#define SpiConf_SpiJob_SpiJob_SBC    ((Spi_JobType)0U)
#define SpiConf_SpiJob_SpiJob_LSW    ((Spi_JobType)1U)
#define SpiConf_SpiJob_SpiJob_TJA    ((Spi_JobType)2U)
#define SpiConf_SpiJob_SpiJob_HB2000_1    ((Spi_JobType)3U)
#define SpiConf_SpiJob_SpiJob_HB2000_2    ((Spi_JobType)4U)
#define SpiConf_SpiJob_SpiJob_HB2000_3    ((Spi_JobType)5U)
#define SpiConf_SpiJob_SpiJob_HB2000_4    ((Spi_JobType)6U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx1    ((Spi_JobType)7U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx2    ((Spi_JobType)8U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx3    ((Spi_JobType)9U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx4    ((Spi_JobType)10U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx5    ((Spi_JobType)11U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx6    ((Spi_JobType)12U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx7    ((Spi_JobType)13U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx8    ((Spi_JobType)14U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx9    ((Spi_JobType)15U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx10    ((Spi_JobType)16U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx11    ((Spi_JobType)17U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx12    ((Spi_JobType)18U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx13    ((Spi_JobType)19U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx14    ((Spi_JobType)20U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx15    ((Spi_JobType)21U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx16    ((Spi_JobType)22U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx17    ((Spi_JobType)23U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx18    ((Spi_JobType)24U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx19    ((Spi_JobType)25U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx20    ((Spi_JobType)26U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx21    ((Spi_JobType)27U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx22    ((Spi_JobType)28U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx23    ((Spi_JobType)29U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Tx24    ((Spi_JobType)30U)
#define SpiConf_SpiJob_SpiJob_PHY_665A_Rx    ((Spi_JobType)31U)
#define SPI_MAX_JOB 32U
/**
* @brief Total number of Sequences configured.
* @details Defines the maximum number of supported sequences
*     for all the driver configurations.
*/
#define SpiConf_SpiSequence_SpiSequence_SBC    ((Spi_SequenceType)0U)
#define SpiConf_SpiSequence_SpiSequence_LSW    ((Spi_SequenceType)1U)
#define SpiConf_SpiSequence_SpiSequence_TJA    ((Spi_SequenceType)2U)
#define SpiConf_SpiSequence_SpiSequence_HB2000_1    ((Spi_SequenceType)3U)
#define SpiConf_SpiSequence_SpiSequence_HB2000_2    ((Spi_SequenceType)4U)
#define SpiConf_SpiSequence_SpiSequence_HB2000_3    ((Spi_SequenceType)5U)
#define SpiConf_SpiSequence_SpiSequence_HB2000_4    ((Spi_SequenceType)6U)
#define SpiConf_SpiSequence_SpiSequence_PHY_1    ((Spi_SequenceType)7U)
#define SpiConf_SpiSequence_SpiSequence_PHY_2    ((Spi_SequenceType)8U)
#define SpiConf_SpiSequence_SpiSequence_PHY_3    ((Spi_SequenceType)9U)
#define SpiConf_SpiSequence_SpiSequence_PHY_4    ((Spi_SequenceType)10U)
#define SpiConf_SpiSequence_SpiSequence_PHY_5    ((Spi_SequenceType)11U)
#define SpiConf_SpiSequence_SpiSequence_PHY_6    ((Spi_SequenceType)12U)
#define SpiConf_SpiSequence_SpiSequence_PHY_7    ((Spi_SequenceType)13U)
#define SpiConf_SpiSequence_SpiSequence_PHY_8    ((Spi_SequenceType)14U)
#define SpiConf_SpiSequence_SpiSequence_PHY_9    ((Spi_SequenceType)15U)
#define SpiConf_SpiSequence_SpiSequence_PHY_10    ((Spi_SequenceType)16U)
#define SpiConf_SpiSequence_SpiSequence_PHY_11    ((Spi_SequenceType)17U)
#define SpiConf_SpiSequence_SpiSequence_PHY_12    ((Spi_SequenceType)18U)
#define SpiConf_SpiSequence_SpiSequence_PHY_13    ((Spi_SequenceType)19U)
#define SpiConf_SpiSequence_SpiSequence_PHY_14    ((Spi_SequenceType)20U)
#define SpiConf_SpiSequence_SpiSequence_PHY_15    ((Spi_SequenceType)21U)
#define SpiConf_SpiSequence_SpiSequence_PHY_16    ((Spi_SequenceType)22U)
#define SpiConf_SpiSequence_SpiSequence_PHY_17    ((Spi_SequenceType)23U)
#define SpiConf_SpiSequence_SpiSequence_PHY_18    ((Spi_SequenceType)24U)
#define SpiConf_SpiSequence_SpiSequence_PHY_19    ((Spi_SequenceType)25U)
#define SpiConf_SpiSequence_SpiSequence_PHY_20    ((Spi_SequenceType)26U)
#define SpiConf_SpiSequence_SpiSequence_PHY_21    ((Spi_SequenceType)27U)
#define SpiConf_SpiSequence_SpiSequence_PHY_22    ((Spi_SequenceType)28U)
#define SpiConf_SpiSequence_SpiSequence_PHY_23    ((Spi_SequenceType)29U)
#define SpiConf_SpiSequence_SpiSequence_PHY_24    ((Spi_SequenceType)30U)
#define SpiConf_SpiSequence_SpiSequence_PHY_Rx    ((Spi_SequenceType)31U)
#define SPI_MAX_SEQUENCE 32U
#define CSIB0 ((uint8)0u)
#define CSIB1 ((uint8)1u)
#define CSIB2 ((uint8)2u)
#define CSIB3 ((uint8)3u)
#define CSIB4 ((uint8)4u)
#define CSIB5 ((uint8)5u)

/**
* @brief Total number of SpiPhyUnit configured.
*/
#define SPI_MAX_HWUNIT 6U

/**
* @brief Defines the external devices the driver will use.
* @details Reference to the external device used by this job.
*/
#define SPI_SpiExternalDevice_SBC  ((Spi_ExternalDeviceType)0u)
#define SPI_SpiExternalDevice_LSW  ((Spi_ExternalDeviceType)1u)
#define SPI_SpiExternalDevice_TJA  ((Spi_ExternalDeviceType)2u)
#define SPI_SpiExternalDevice_HB2000_1  ((Spi_ExternalDeviceType)3u)
#define SPI_SpiExternalDevice_PHY_665A_Tx  ((Spi_ExternalDeviceType)4u)
#define SPI_SpiExternalDevice_PHY_665A_Rx  ((Spi_ExternalDeviceType)5u)
#define SPI_SpiExternalDevice_HB2000_2  ((Spi_ExternalDeviceType)6u)
#define SPI_SpiExternalDevice_HB2000_3  ((Spi_ExternalDeviceType)7u)
#define SPI_SpiExternalDevice_HB2000_4  ((Spi_ExternalDeviceType)8u)

/**
* @brief   Switches the Production Error Detection and Notification OFF
*
* @implements SPI_DISABLE_DEM_REPORT_ERROR_STATUS_define
* 
*/
#define SPI_DISABLE_DEM_REPORT_ERROR_STATUS  (STD_ON)
/*==================================================================================================
 *                                     DEFINES AND MACROS
==================================================================================================*/

/**
* @brief Define values for Autosar configuration variants.
* @details Define values for Autosar configuration variants.
*/
#define SPI_VARIANT_PRECOMPILE  (0)
#define SPI_VARIANT_POSTBUILD   (1)
#define SPI_VARIANT_LINKTIME    (2)

/**
* @brief Defines the use of Pre-Compile(PC) support
* @details VARIANT-PRE-COMPILE: Only parameters with "Pre-compile time" configu-ration are allowed 
*        in this variant.
*/
/* Pre-Compile(PC) Support. */
#define SPI_CONFIG_VARIANT  SPI_VARIANT_PRECOMPILE

/**
* @brief Define precompile support.
* @details Define precompile support if VARIANT-PRE-COMPILE or VARIANT-LINK-TIME is selected and number of variant <=1.
*/
#define SPI_PRECOMPILE_SUPPORT (STD_ON)

/**
* @brief Defines the "Number of Loops" timeout.
* @details Defines the "Number of Loops" timeout used by Spi_SyncTransmit and Spi_AsyncTransmit
*        function during the wait on TX/RX transmission to complete one frame.
*        One timeout unit means that no TX or RX was executed(the IF statements are returning FALSE).
*/
#define SPI_TIMEOUT_COUNTER_U32     ((uint32)50000)

/**
* @brief Allow simultaneous calls to Spi_SyncTransmit() for different threads.
* @details Two concurrent calls to Spi_SyncTransmit() will be allowed only if the related sequences
*       do not share HW units.
*/
#define SPI_SUPPORT_CONCURRENT_SYNC_TRANSMIT  (STD_OFF)

/*==================================================================================================
 *                                           SpiAutosarExt DEFINES
==================================================================================================*/
/**
* @brief If enabled, the asyncronous operation mode (POLLING or INTERRUPT)
* @details If enabled, the asyncronous operation mode (POLLING or INTERRUPT) can
*       be defined independently for each HWUnit using Spi_SetHWUnitAsyncMode().
* @implements SPI_HWUNIT_ASYNC_MODE_define
*/
#define SPI_HWUNIT_ASYNC_MODE           STD_ON

/**
* @brief If enabled, allows to configure more than 256 sequences, jobs and channels.
*/
#define SPI_ALLOW_BIGSIZE_COLLECTIONS           (STD_OFF)

/**
* @brief If enabled, SPI_MAIN_FUNCTION_PERIOD defines the cycle time of the function Spi_MainFunction_Handling in seconds
*/
#define SPI_MAIN_FUNCTION_PERIOD            (1/100)

/**
* @brief Total number of partitions configured in Ecu.
*/
#define SPI_MAX_PARTITIONS             (1U)

/**
* @brief          Enable Multicore Support.
* @details        When SpiGeneral/SpiMulticoreSupport = TRUE,
*                 the SPI driver can be configured to support multicore.
*/
#define SPI_MULTICORE_ENABLED          (STD_OFF)

#if (STD_OFF == SPI_MULTICORE_ENABLED)
/**
* @brief Defines default CodeId value which is assigned to HWUnits, Sequences, Jobs and Channels in the case multicore is not enabled.
*/
    #define SPI_SPURIOUS_CORE_ID_U32        ((uint32)0UL)
#endif

#if (STD_ON == SPI_MULTICORE_ENABLED)
    #define Spi_GetCoreID     ((uint32)OsIf_GetCoreID())
#else
    #define Spi_GetCoreID     SPI_SPURIOUS_CORE_ID_U32
#endif

/**
* @brief  Slave support
*/
#define SPI_SLAVE_SUPPORT SPI_IPW_SLAVE_SUPPORT

/**
* @brief Defines if transfers are made using DMA or FIFO.
* @details Defines if transfers are made using DMA or FIFO.
* @implements SPI_DMA_USED_define
*/
#define SPI_DMA_USED SPI_IPW_DMA_USED

/**
* @brief If enabled, allows dual MCU clock configuration settings.
* @details If enabled, allows dual MCU clock configuration settings.
* @implements SPI_DUAL_CLOCK_MODE_define
*/
#define SPI_DUAL_CLOCK_MODE SPI_IPW_DUAL_CLOCK_MODE

/**
* @brief If enabled, allows to Sequence transfer in Dma Fast mode.
*/
#define SPI_ENABLE_DMAFASTTRANSFER_SUPPORT  SPI_IPW_ENABLE_DMAFASTTRANSFER_SUPPORT
/**
* @brief If enabled, allows to Sequence transfer in Dma RX Adjacent mode.
*/
#define SPI_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT  SPI_IPW_ENABLE_DMA_CONT_MEM_TRANSFER_SUPPORT
/**
* @brief Half duplex mode enable .
*/
#ifdef SPI_IPW_SPI_HALF_DUPLEX_MODE_SUPPORT
#define SPI_HALF_DUPLEX_MODE_SUPPORT  SPI_IPW_SPI_HALF_DUPLEX_MODE_SUPPORT
#endif

/*==================================================================================================
*                                            ENUMS
==================================================================================================*/


/*==================================================================================================
*                               STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/


/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/


/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif

#endif /*SPI_CFG_H*/

/** @} */

