/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : Phy_665a
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_BCC_772C_CFG_H
#define CDD_BCC_772C_CFG_H

/**
*   @file CDD_Bcc_772c_Cfg.h
*
*   @addtogroup  CDD_BCC_772C
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif


/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bcc_772c_Types.h"
#include "CDD_Bcc_772c_Regs.h"

#include "CDD_Bcc_772c_MBDT_PBcfg.h"
/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define BCC_772C_VENDOR_ID_CFG                    43
#define BCC_772C_MODULE_ID_CFG                    255
#define BCC_772C_AR_RELEASE_MAJOR_VERSION_CFG     4
#define BCC_772C_AR_RELEASE_MINOR_VERSION_CFG     7
#define BCC_772C_AR_RELEASE_REVISION_VERSION_CFG  0
#define BCC_772C_SW_MAJOR_VERSION_CFG             1
#define BCC_772C_SW_MINOR_VERSION_CFG             0
#define BCC_772C_SW_PATCH_VERSION_CFG             2

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
/* Check if this header file and CDD_Bcc_772c_Types.h are of the same vendor */
#if (BCC_772C_VENDOR_ID_CFG != BCC_772C_VENDOR_ID_COM)
#error "CDD_Bcc_772c_Cfg.h and CDD_Bcc_772c_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Bcc_772c_Types.h are of the same Autosar version */
#if ((BCC_772C_AR_RELEASE_MAJOR_VERSION_CFG != BCC_772C_AR_RELEASE_MAJOR_VERSION_COM) || \
     (BCC_772C_AR_RELEASE_MINOR_VERSION_CFG != BCC_772C_AR_RELEASE_MINOR_VERSION_COM) || \
     (BCC_772C_AR_RELEASE_REVISION_VERSION_CFG != BCC_772C_AR_RELEASE_REVISION_VERSION_COM) \
    )
#error "AutoSar Version Numbers of CDD_Bcc_772c_Cfg.h and CDD_Bcc_772c_Types.h are different"
#endif

/* Check if this header file and CDD_Bcc_772c_Types.h are of the same Software version */
#if ((BCC_772C_SW_MAJOR_VERSION_CFG != BCC_772C_SW_MAJOR_VERSION_COM) || \
     (BCC_772C_SW_MINOR_VERSION_CFG != BCC_772C_SW_MINOR_VERSION_COM) || \
     (BCC_772C_SW_PATCH_VERSION_CFG != BCC_772C_SW_PATCH_VERSION_COM) \
    )
#error "Software Version Numbers of CDD_Bcc_772c_Cfg.h and CDD_Bcc_772c_Types.h are different"
#endif

/* Check if CDD_Bcc_772c_MBDT_PBcfg header file and CDD_Bcc_772c configuration header file are of the same vendor */
#if (BCC_772C_VENDOR_ID_MBDT_PBCFG != BCC_772C_VENDOR_ID_CFG)
    #error "CDD_Bcc_772c_MBDT_PBcfg.h and CDD_Bcc_772c_Cfg.h have different vendor IDs"
#endif
/* Check if CDD_Bcc_772c_MBDT_PBcfg header file and CDD_Bcc_772c configuration header file are of the same Autosar version */
#if ((BCC_772C_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG != BCC_772C_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (BCC_772C_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG != BCC_772C_AR_RELEASE_MINOR_VERSION_CFG) || \
     (BCC_772C_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG != BCC_772C_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of CDD_Bcc_772c_MBDT_PBcfg.h and CDD_Bcc_772c_Cfg.h are different"
#endif
/* Check if CDD_Bcc_772c_MBDT_PBcfg header file and CDD_Bcc_772c configuration header file are of the same software version */
#if ((BCC_772C_SW_MAJOR_VERSION_MBDT_PBCFG != BCC_772C_SW_MAJOR_VERSION_CFG) || \
     (BCC_772C_SW_MINOR_VERSION_MBDT_PBCFG != BCC_772C_SW_MINOR_VERSION_CFG) || \
     (BCC_772C_SW_PATCH_VERSION_MBDT_PBCFG != BCC_772C_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of CDD_Bcc_772c_MBDT_PBcfg.h and CDD_Bcc_772c_Cfg.h are different"
#endif

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/
/**
* @brief Switches the Development Error functionality ON or OFF.
* @details Switches the Development Error Detection and Notification ON or OFF.
*/
#define BCC_772C_DEV_ERROR_DETECT        (STD_OFF)

/**
* @brief Define precompile support.
* @details Define precompile support if VariantPreCompile is selected and number of variant <=1.
* @implements BCC_772C_PRECOMPILE_SUPPORT_define
*/
#define BCC_772C_PRECOMPILE_SUPPORT     (STD_ON)

/**
* @brief Define I2C support.
* @details Define I2C support.
* @implements BCC_772C_I2C_SUPPORT_define
*/
#define BCC_772C_I2C_SUPPORT        (STD_ON)

/**
* @brief Define GPIO support.
* @details Define GPIO support.
* @implements BCC_772C_GPIO_SUPPORT_define
*/
#define BCC_772C_GPIO_SUPPORT        (STD_ON)

/**
* @brief Define BAL support.
* @details Define BAL support.
* @implements BCC_772C_BAL_SUPPORT_define
*/
#define BCC_772C_BAL_SUPPORT        (STD_ON)

/**
* @brief Define FEH support.
* @details Define FEH support.
* @implements BCC_772C_FEH_SUPPORT_define
*/
#define BCC_772C_FEH_SUPPORT        (STD_ON)

/**
* @brief Define SPI support.
* @details Define SPI support.
* @implements BCC_772C_SPI_SUPPORT_define
*/
#define BCC_772C_SPI_SUPPORT        (STD_OFF)


/**
* @brief Define hardware silicon version
*/
#define BCC_772C_SILICON_A1        (STD_OFF)

/**
* @brief Define hardware silicon version
*/
#define BCC_772C_SILICON_A2        (STD_OFF)

/**
* @brief Define hardware silicon version
*/
#define BCC_772C_SILICON_P1        (STD_ON)

/**
* @brief Define hardware silicon version
*/
#define BCC_772C_SILICON_P2        (STD_OFF)

/**
* @brief Define hardware silicon version
*/
#define BCC_772C_SILICON_C0        (STD_OFF)

/**
* @brief Define hardware silicon version
*/
#define BCC_772C_SILICON_C1        (STD_OFF)

/**
* @brief Define CC support.
* @details Define CC support.
*/
#define BCC_772C_CC_SUPPORT        (STD_ON)


/**
* @brief Number of SYS configurations
*/
#define BCC_772C_SYS_CONFIGS_MAX             (1U)
/**
* @brief Number of GPIO configurations
*/
#define BCC_772C_GPIO_CONFIGS_MAX            (3U)
/**
* @brief Number of FEH configurations
*/
#define BCC_772C_FEH_CONFIGS_MAX             (1U)
/**
* @brief Number of MSR configurations
*/
#define BCC_772C_MSR_CONFIGS_MAX             (1U)
/**
* @brief Number of CC configurations
*/
#define BCC_772C_CC_CONFIGS_MAX              (1U)

#define BCC_772C_COMM_MODE_SPI 0
#define BCC_772C_COMM_MODE_TPL 1
#define BCC_772C_COMM_MODE BCC_772C_COMM_MODE_SPI

/*==================================================================================================
*                                            ENUMS
==================================================================================================*/

/*==================================================================================================
*                               STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
typedef struct
{
    uint16 SysCfg1Msg; /**< Configuration data for register SYS_CFG1 */
    uint16 SysCfg2Msg; /**< Configuration data for register SYS_CFG2 */
} Bcc_772c_SYS_ConfigType;

#if (BCC_772C_GPIO_SUPPORT == STD_ON)
/*
 * Bcc_772c GPIO configuration.
 */
typedef struct
{
    uint16 GpioCfg1Msg;
    uint16 GpioCfg2Msg;
} Bcc_772c_GPIO_ConfigType;
#endif /* (BCC_772C_GPIO_SUPPORT == STD_ON) */

#if (BCC_772C_FEH_SUPPORT == STD_ON)
typedef struct
{
    uint16 FehMask[6U];
} Bcc_772c_FEH_ConfigType;
#endif /* (BCC_772C_FEH_SUPPORT == STD_ON) */

typedef struct
{
    uint16 MsrAdcCfg;
    uint16 MsrOvUvEn;
} Bcc_772c_MSR_ConfigType;


#if (BCC_772C_CC_SUPPORT == STD_ON)
typedef struct
{
    uint16 CCAdc2Cfg;
    uint16 CcThCfg[3U];
} Bcc_772c_CC_ConfigType;
#endif /* (BCC_772C_CC_SUPPORT == STD_ON) */

typedef struct
{
    Bcc_772c_SYS_ConfigType SystemConfig[BCC_772C_SYS_CONFIGS_MAX];
#if (BCC_772C_GPIO_SUPPORT == STD_ON)
    Bcc_772c_GPIO_ConfigType GpioConfig[BCC_772C_GPIO_CONFIGS_MAX];
#endif
#if (BCC_772C_FEH_SUPPORT == STD_ON)
    Bcc_772c_FEH_ConfigType FehConfig[BCC_772C_FEH_CONFIGS_MAX];
#endif
    Bcc_772c_MSR_ConfigType MsrConfig[BCC_772C_MSR_CONFIGS_MAX];
#if (BCC_772C_CC_SUPPORT == STD_ON)
    Bcc_772c_CC_ConfigType CcConfig[BCC_772C_CC_CONFIGS_MAX];
#endif
} Bcc_772c_DeviceConfigType;

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_BCC_772C_CFG_H */

