/*==================================================================================================
*   Project              : BMS SDK AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : 
*   Dependencies         : 
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.2
*   Build Version        : S32K3_BMS_SDK_1_0_2_D2307_ASR_REL_4_7_REV_0000_20230728
*
*   (c) Copyright 2020 - 2023 NXP Semiconductors
*   All Rights Reserved.
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef CDD_BCC_774A_CFG_H
#define CDD_BCC_774A_CFG_H

/**
*   @file    CDD_Bcc_774a_Cfg.h
*
*   @addtogroup CDD_BCC_774A
*   @{
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CDD_Bcc_774a_Types.h"

#include "CDD_Bcc_774a_Regs_90V.h"
#include "CDD_Bcc_774a_MBDT_PBcfg.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define BCC_774A_MODULE_ID_CFG                    255
#define BCC_774A_VENDOR_ID_CFG                    43
#define BCC_774A_AR_RELEASE_MAJOR_VERSION_CFG     4
#define BCC_774A_AR_RELEASE_MINOR_VERSION_CFG     7
#define BCC_774A_AR_RELEASE_REVISION_VERSION_CFG  0
#define BCC_774A_SW_MAJOR_VERSION_CFG             1
#define BCC_774A_SW_MINOR_VERSION_CFG             0
#define BCC_774A_SW_PATCH_VERSION_CFG             2

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if this header file and CDD_Bcc_774a_Types.h are of the same vendor */
#if (BCC_774A_VENDOR_ID_CFG != BCC_774A_VENDOR_ID_COM)
#error "CDD_Bcc_774a_Cfg.h and CDD_Bcc_774a_Types.h have different vendor ids"
#endif

/* Check if this header file and CDD_Bcc_774a_Types.h are of the same Autosar version */
#if ((BCC_774A_AR_RELEASE_MAJOR_VERSION_CFG != BCC_774A_AR_RELEASE_MAJOR_VERSION_COM) || \
     (BCC_774A_AR_RELEASE_MINOR_VERSION_CFG != BCC_774A_AR_RELEASE_MINOR_VERSION_COM) || \
     (BCC_774A_AR_RELEASE_REVISION_VERSION_CFG != BCC_774A_AR_RELEASE_REVISION_VERSION_COM) \
    )
#error "AutoSar Version Numbers of CDD_Bcc_774a_Cfg.h and CDD_Bcc_774a_Types.h are different"
#endif

/* Check if this header file and CDD_Bcc_774a_Types.h are of the same Software version */
#if ((BCC_774A_SW_MAJOR_VERSION_CFG != BCC_774A_SW_MAJOR_VERSION_COM) || \
     (BCC_774A_SW_MINOR_VERSION_CFG != BCC_774A_SW_MINOR_VERSION_COM) || \
     (BCC_774A_SW_PATCH_VERSION_CFG != BCC_774A_SW_PATCH_VERSION_COM) \
    )
#error "Software Version Numbers of CDD_Bcc_774a_Cfg.h and CDD_Bcc_774a_Types.h are different"
#endif

/* Check if CDD_Bcc_774a_MBDT_PBcfg header file and CDD_Bcc_774a configuration header file are of the same vendor */
#if (BCC_774A_VENDOR_ID_MBDT_PBCFG != BCC_774A_VENDOR_ID_CFG)
#error "CDD_Bcc_774a_MBDT_PBcfg.h and CDD_Bcc_774a_Cfg.h have different vendor IDs"
#endif
/* Check if CDD_Bcc_774a_MBDT_PBcfg header file and CDD_Bcc_774a configuration header file are of the same Autosar version */
#if ((BCC_774A_AR_RELEASE_MAJOR_VERSION_MBDT_PBCFG != BCC_774A_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (BCC_774A_AR_RELEASE_MINOR_VERSION_MBDT_PBCFG != BCC_774A_AR_RELEASE_MINOR_VERSION_CFG) || \
     (BCC_774A_AR_RELEASE_REVISION_VERSION_MBDT_PBCFG != BCC_774A_AR_RELEASE_REVISION_VERSION_CFG) \
    )
#error "AutoSar Version Numbers of CDD_Bcc_774a_MBDT_PBcfg.h and CDD_Bcc_774a_Cfg.h are different"
#endif
/* Check if CDD_Bcc_774a_MBDT_PBcfg header file and CDD_Bcc_774a configuration header file are of the same software version */
#if ((BCC_774A_SW_MAJOR_VERSION_MBDT_PBCFG != BCC_774A_SW_MAJOR_VERSION_CFG) || \
     (BCC_774A_SW_MINOR_VERSION_MBDT_PBCFG != BCC_774A_SW_MINOR_VERSION_CFG) || \
     (BCC_774A_SW_PATCH_VERSION_MBDT_PBCFG != BCC_774A_SW_PATCH_VERSION_CFG) \
    )
#error "Software Version Numbers of CDD_Bcc_774a_MBDT_PBcfg.h and CDD_Bcc_774a_Cfg.h are different"
#endif

/*==================================================================================================
*                                          CONSTANTS
==================================================================================================*/
/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/
/**
* @brief Switches the Development Error functionality ON or OFF.
* @details Switches the Development Error Detection and Notification ON or OFF.
*/
#define BCC_774A_DEV_ERROR_DETECT        (STD_OFF)

/**
* @brief Define precompile support.
* @details Define precompile support if VARIANT-PRE-COMPILE is selected and number of variant <=1.
*/
#define BCC_774A_PRECOMPILE_SUPPORT     (STD_ON)

/**
* @brief Define I2C support.
* @details Define I2C support.
*/
#define BCC_774A_I2C_SUPPORT        (STD_ON)

/**
* @brief Define GPIO support.
* @details Define GPIO support.
*/
#define BCC_774A_GPIO_SUPPORT        (STD_ON)

/**
* @brief Define SPI support.
* @details Define SPI support.
* @implements BCC_774A_SPI_SUPPORT_define
*/
#define BCC_774A_SPI_SUPPORT        (STD_OFF)

/**
* @brief Define FEH alarm support.
* @details Define FEH alarm support.
*/
#define BCC_774A_FEH_ALARM_SUPPORT        (STD_ON)

/**
* @brief Define FEH wakeup support.
* @details Define FEH wakeup support.
*/
#define BCC_774A_FEH_WAKEUP_SUPPORT        (STD_ON)

/**
* @brief Define FEH events support.
* @details Define FEH events support.
*/
#define BCC_774A_FEH_EVENTS_SUPPORT        (STD_ON)

/**
* @brief Define BAL support.
* @details Define BAL support.
*/
#define BCC_774A_BAL_SUPPORT        (STD_ON)

/**
* @brief Number of SYS configurations
*/
#define BCC_774A_SYS_CONFIGS_MAX             (1U)
/**
* @brief Number of GPIO configurations
*/
#define BCC_774A_GPIO_CONFIGS_MAX            (1U)
/**
* @brief Number of FEH alarm configurations
*/
#define BCC_774A_FEH_ALARM_CONFIGS_MAX       (1U)
/**
* @brief Number of FEH wakeup configurations
*/
#define BCC_774A_FEH_WAKEUP_CONFIGS_MAX      (1U)
/**
* @brief Number of FEH events configurations
*/
#define BCC_774A_FEH_EVENTS_CONFIGS_MAX      (1U)
/**
* @brief Number of MSR configurations
*/
#define BCC_774A_MSR_CONFIGS_MAX             (1U)
/**
* @brief Number of I2C configurations
*/
#define BCC_774A_I2C_CONFIGS_MAX             (1U)

/*==================================================================================================
*                                            ENUMS
==================================================================================================*/

/*==================================================================================================
*                               STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
#if (BCC_774A_GPIO_SUPPORT == STD_ON)
/**
 * @brief   Bcc_774a GPIO configuration.
 *
 */
typedef struct
{
    uint16 GpioCfg0Cfg1Msg[BCC_774A_2REG_DATA];
} Bcc_774a_GPIO_ConfigType;
#endif /* (BCC_774A_GPIO_SUPPORT == STD_ON) */

#if (BCC_774A_FEH_ALARM_SUPPORT == STD_ON)
/**
 * @brief   Bcc_774a FEH alarm configuration.
 *
 */
typedef struct
{
    uint16 FehAlarmCfgOutCfgMsg[BCC_774A_3REG_DATA];
} Bcc_774a_FEH_AlarmConfigType;
#endif /* (BCC_774A_FEH_ALARM_SUPPORT == STD_ON) */

#if (BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON)
/**
 * @brief   Bcc_774a FEH wakeup configuration.
 *
 */
typedef struct
{
    uint16 FehWakeupCfgMsg[BCC_774A_2REG_DATA];
} Bcc_774a_FEH_WakeupConfigType;
#endif /* (BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON) */

#if (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON)
/**
 * @brief   Bcc_774a FEH events configuration.
 *
 */
typedef struct
{
    uint16 FehEventsSupPorCfgMsg[BCC_774A_2REG_DATA];
    uint16 FehEventsComPorCfgMsg[BCC_774A_1REG_DATA];
    uint16 FehEventsFltCfgMsg[BCC_774A_4REG_DATA];
    uint16 FehEventsMeasFltEvtCfgMsg[BCC_774A_1REG_DATA];
} Bcc_774a_FEH_EventsConfigType;
#endif /* (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON) */

#if (BCC_774A_I2C_SUPPORT == STD_ON)
/**
 * @brief   Bcc_774a I2C configuration.
 *
 */
typedef struct
{
    uint16 I2cCfgCtrlMsg[BCC_774A_2REG_DATA];
} Bcc_774a_I2C_ConfigType;
#endif /* (BCC_774A_I2C_SUPPORT == STD_ON) */

/**
* @brief Bcc_774a device configuration type.
* @details Bcc_774a device configuration type.
*/
typedef struct
{
    Bcc_774a_SYS_ConfigType        SysConfig[BCC_774A_SYS_CONFIGS_MAX];
#if (BCC_774A_GPIO_SUPPORT == STD_ON)
    Bcc_774a_GPIO_ConfigType       GpioConfig[BCC_774A_GPIO_CONFIGS_MAX];
#endif
#if (BCC_774A_FEH_ALARM_SUPPORT == STD_ON)
    Bcc_774a_FEH_AlarmConfigType   FehAlarmConfig[BCC_774A_FEH_ALARM_CONFIGS_MAX];
#endif
#if (BCC_774A_FEH_WAKEUP_SUPPORT == STD_ON)
    Bcc_774a_FEH_WakeupConfigType  FehWakeupConfig[BCC_774A_FEH_WAKEUP_CONFIGS_MAX];
#endif
#if (BCC_774A_FEH_EVENTS_SUPPORT == STD_ON)
    Bcc_774a_FEH_EventsConfigType  FehEventsConfig[BCC_774A_FEH_EVENTS_CONFIGS_MAX];
#endif
    Bcc_774a_MSR_ConfigType        MsrConfig[BCC_774A_MSR_CONFIGS_MAX];
#if (BCC_774A_I2C_SUPPORT == STD_ON)
    Bcc_774a_I2C_ConfigType        I2cConfig[BCC_774A_I2C_CONFIGS_MAX];
#endif
} Bcc_774a_DeviceConfigType;

/*==================================================================================================
*                                GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/
/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* CDD_BCC_774A_CFG_H */

