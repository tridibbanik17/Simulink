function [RMSE, MAXE, ConvergenceTime, SOC_EKF, SOC_Real, E1] = ConvergenceTime(X, Y, I_Offset, V_Offset, Initial_SOC)

    % Extract and offset input data
    Current     = X(:,1) + I_Offset;
    VT_Real     = X(:,2) + V_Offset;
    Temperature = X(:,3);
    SOC_Real    = Y;
    L           = length(Current);
    Time        = (1:L)';  % Column vector for consistency

    % Prepare Simulink input
    simIn = Simulink.SimulationInput('Main_Simulink_ConvergenceTime');
    simIn = simIn.setVariable('Current', Current);
    simIn = simIn.setVariable('VT_Real', VT_Real);
    simIn = simIn.setVariable('Temperature', Temperature);
    simIn = simIn.setVariable('SOC_Real', SOC_Real);
    simIn = simIn.setVariable('L', L);
    simIn = simIn.setVariable('Time', Time);
    simIn = simIn.setVariable('Initial_SOC', Initial_SOC);

    % Run Simulink model
    out = sim(simIn);

    % Extract and clean output
    SOC_EKF = out.SOC_Estimated;
    SOC_EKF(1) = [];  % Remove first sample if needed
    E1 = SOC_EKF - SOC_Real;

    % Error metrics
    RMSE = sqrt(mean(E1.^2));
    MAXE = max(abs(E1));

    % Convergence time calculation
    threshold = 0.03;  % 3% error threshold
    idx = find(abs(E1) <= threshold, 1);  % First index within threshold

    if ~isempty(idx)
        ConvergenceTime = Time(idx);
    else
        ConvergenceTime = NaN;  % No convergence found
    end
end