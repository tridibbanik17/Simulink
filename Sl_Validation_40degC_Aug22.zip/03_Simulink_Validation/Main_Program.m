% McMaster Automotive Resource Centre (MARC)
% Electrical Engineer: Romulo Navega Vieira, PhD Candidate - M.Sc and MBA
% Extended Kalman Filter - Memory Use and Execution Time



%% Plot LA92 Drive Cycle - Case Study for 40degC
clc; clear all; close all;
load 5_LA92_40C_Samsung50G.mat

Current     = X(:,1);
VT_Real     = X(:,2);
Temperature = X(:,3);
SOC_Real    = Y;
L           = length(Current);
Time        = 1:1:length(Current);

% Run Simulink File - Extended Kalman Filter
sim('Main_Simulink.slx')
ans.SOC_Estimated(1) = [];
SOC_EKF = ans.SOC_Estimated;

RMSE_LA92   = rmse(SOC_EKF, SOC_Real);
Aux         = Time./3600;

figure(1)
plot(Aux, SOC_Real*100, LineWidth = 2.5)
hold on
plot(Aux, SOC_EKF*100, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
hold off

grid on
legend('Actual', 'EKF')
ylabel('State of Charge (%)') 
xlabel('Time (Hour)')
title('LA92 at 40°C')
ax = gca; 
ylim([0 100])
ax.FontSize = 18; 

saveas(gcf,'Fig01.png')

E1    = 100*(SOC_EKF-SOC_Real);
MaxE1 = max(abs(E1));

figure(2)
plot(Aux, E1, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
grid on
ax = gca; 
ax.FontSize = 18;
Leg1 = sprintf("EKF - RMSE = %.2f (%%) and MAXE = %.2f (%%)", RMSE_LA92*100, MaxE1);
Leg = legend(Leg1);
Leg.FontSize = 12;
ylabel('State of Charge Error (%)')
xlabel('Time (Hour)') 
ylim([-17 30])
yline(5, '-', 'Threshold: +5%', 'LabelVerticalAlignment', 'top', 'HandleVisibility', 'off');
yline(-5, '-', 'Threshold: -5%', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
saveas(gcf,'Fig02.png')

%% Plot US06 Drive Cycle - Case Study for 40degC
clc; 
load 7_US06_40C_Samsung50G.mat

Current     = X(:,1);
VT_Real     = X(:,2);
Temperature = X(:,3);
SOC_Real    = Y;
L           = length(Current);
Time        = 1:1:length(Current);

% Run Simulink File - Extended Kalman Filter
sim('Main_Simulink.slx')
ans.SOC_Estimated(1) = [];
SOC_EKF = ans.SOC_Estimated;

RMSE_US06  = rmse(SOC_EKF, SOC_Real);
Aux         = Time./3600;

figure(3)
plot(Aux, SOC_Real*100, LineWidth = 2.5)
hold on
plot(Aux, SOC_EKF*100, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
hold off

grid on
legend('Actual', 'EKF')
ylabel('State of Charge (%)') 
xlabel('Time (Hour)')
title('US06 at 40°C')
ax = gca; 
ylim([0 100])
ax.FontSize = 18; 

saveas(gcf,'Fig03.png')

E1    = 100*(SOC_EKF-SOC_Real);
MaxE1 = max(abs(E1));

figure(4)
plot(Aux, E1, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
grid on
ax = gca; 
ax.FontSize = 18;
Leg1 = sprintf("EKF - RMSE = %.2f (%%) and MAXE = %.2f (%%)", RMSE_US06*100, MaxE1);
Leg = legend(Leg1);
Leg.FontSize = 12;
ylabel('State of Charge Error (%)')
xlabel('Time (Hour)') 
ylim([-17 30])
yline(5, '-', 'Threshold: +5%', 'LabelVerticalAlignment', 'top', 'HandleVisibility', 'off');
yline(-5, '-', 'Threshold: -5%', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
saveas(gcf,'Fig04.png')


%% Plot HWCUST Drive Cycle - Case Study for 40degC
clc; 
load 11_HWCUST2_40C_Samsung50G.mat

Current     = X(:,1);
VT_Real     = X(:,2);
Temperature = X(:,3);
SOC_Real    = Y;
L           = length(Current);
Time        = 1:1:length(Current);

% Run Simulink File - Extended Kalman Filter
sim('Main_Simulink.slx')
ans.SOC_Estimated(1) = [];
SOC_EKF = ans.SOC_Estimated;

RMSE_HWCUST2   = rmse(SOC_EKF, SOC_Real);
Aux         = Time./3600;

figure(5)
plot(Aux, SOC_Real*100, LineWidth = 2.5)
hold on
plot(Aux, SOC_EKF*100, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
hold off

grid on
legend('Actual', 'EKF')
ylabel('State of Charge (%)') 
xlabel('Time (Hour)')
title('HWCUST2 at 40°C')
ax = gca; 
ylim([0 100])
ax.FontSize = 18; 

saveas(gcf,'Fig05.png')

E1    = 100*(SOC_EKF-SOC_Real);
MaxE1 = max(abs(E1));

figure(6)
plot(Aux, E1, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
grid on
ax = gca; 
ax.FontSize = 18;
Leg1 = sprintf("EKF - RMSE = %.2f (%%) and MAXE = %.2f (%%)", RMSE_HWCUST2*100, MaxE1);
Leg = legend(Leg1);
Leg.FontSize = 12;
ylabel('State of Charge Error (%)')
xlabel('Time (Hour)') 
ylim([-17 30])
yline(5, '-', 'Threshold: +5%', 'LabelVerticalAlignment', 'top', 'HandleVisibility', 'off');
yline(-5, '-', 'Threshold: -5%', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
saveas(gcf,'Fig06.png')

%% Plot HWGRADE Drive Cycle - Case Study for 40degC
clc; 
load 15_HWGRADE2_40C_Samsung50G.mat

Current     = X(:,1);
VT_Real     = X(:,2);
Temperature = X(:,3);
SOC_Real    = Y;
L           = length(Current);
Time        = 1:1:length(Current);

% Run Simulink File - Extended Kalman Filter
sim('Main_Simulink.slx')
ans.SOC_Estimated(1) = [];
SOC_EKF = ans.SOC_Estimated;

RMSE_HWGRADE2   = rmse(SOC_EKF, SOC_Real);
Aux         = Time./3600;

figure(7)
plot(Aux, SOC_Real*100, LineWidth = 2.5)
hold on
plot(Aux, SOC_EKF*100, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
hold off

grid on
legend('Actual', 'EKF')
ylabel('State of Charge (%)') 
xlabel('Time (Hour)')
title('HWGRADE2 at 40°C')
ax = gca; 
ylim([0 100])
ax.FontSize = 18; 

saveas(gcf,'Fig07.png')

E1    = 100*(SOC_EKF-SOC_Real);
MaxE1 = max(abs(E1));

figure(8)
plot(Aux, E1, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
grid on
ax = gca; 
ax.FontSize = 18;
Leg1 = sprintf("EKF - RMSE = %.2f (%%) and MAXE = %.2f (%%)", RMSE_HWGRADE2*100, MaxE1);
Leg = legend(Leg1);
Leg.FontSize = 12;
ylabel('State of Charge Error (%)')
xlabel('Time (Hour)') 
ylim([-17 30])
yline(5, '-', 'Threshold: +5%', 'LabelVerticalAlignment', 'top', 'HandleVisibility', 'off');
yline(-5, '-', 'Threshold: -5%', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
saveas(gcf,'Fig08.png')

%%  Case Study for 40degC - No measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,0,0);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,0,0);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,0,0);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,0,0);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,0,0);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,0,0);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,0,0);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];


%%  Case Study for 40degC - 150mA of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,-0.150,0);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,-0.150,0);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,-0.150,0);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,-0.150,0);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,-0.150,0);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,-0.150,0);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,-0.150,0);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_n150_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_n150_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];

%%  Case Study for 40degC - 50mA of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,-0.050,0);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,-0.050,0);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,-0.050,0);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,-0.050,0);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,-0.050,0);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,-0.050,0);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,-0.050,0);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_n50_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_n50_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];

%%  Case Study for 40degC +50mA of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,+0.050,0);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,+0.050,0);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,+0.050,0);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,+0.050,0);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,+0.050,0);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,+0.050,0);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,+0.050,0);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_p50_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_p50_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];

%%  Case Study for 40degC +150mA of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,+0.150,0);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,+0.150,0);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,+0.150,0);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,+0.150,0);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,+0.150,0);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,+0.150,0);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,+0.150,0);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_p150_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_p150_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];

%%  Case Study for 40degC -10mV of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,0,-0.01);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,0,-0.01);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,0,-0.01);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,0,-0.01);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,0,-0.01);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,0,-0.01);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,0,-0.01);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_n10_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_n10_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];

%%  Case Study for 40degC -5mV of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,0,-0.005);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,0,-0.005);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,0,-0.005);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,0,-0.005);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,0,-0.005);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,0,-0.005);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,0,-0.005);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_n5_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_n5_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];

%%  Case Study for 40degC +5mV of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,0,+0.005);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,0,+0.005);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,0,+0.005);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,0,+0.005);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,0,+0.005);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,0,+0.005);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,0,+0.005);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_p5_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_p5_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];

%%  Case Study for 40degC +10mV of measurement error
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92] = Offset(X,Y,0,+0.010);

load 7_US06_40C_Samsung50G.mat
[RMSE_US06,MAXE_US06] = Offset(X,Y,0,+0.010);

load 11_HWCUST2_40C_Samsung50G.mat
[RMSE_HWCUST2,MAXE_HWCUST2] = Offset(X,Y,0,+0.010);

load 15_HWGRADE2_40C_Samsung50G.mat
[RMSE_HWGRADE2,MAXE_HWGRADE2] = Offset(X,Y,0,+0.010);

load 6_0.5Charge_40C_Samsung50G.mat
[RMSE_CC1,MAXE_CC1] = Offset(X,Y,0,+0.010);

load 8_0.5Charge_40C_Samsung50G.mat
[RMSE_CC2,MAXE_CC2] = Offset(X,Y,0,+0.010);

load 12_0.5Charge_40C_Samsung50G.mat
[RMSE_CC3,MAXE_CC3] = Offset(X,Y,0,+0.010);

RMSE_CC_avrg = mean([RMSE_CC1 RMSE_CC2 RMSE_CC3]);
MAXE_CC_avrg = mean([MAXE_CC1 MAXE_CC2 MAXE_CC3]);

RMSE_avrg = mean([RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg]);
MAXE_avrg = mean([MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg]);

RMSE_p10_Global = [RMSE_avrg RMSE_LA92 RMSE_US06 RMSE_HWCUST2 RMSE_HWGRADE2 RMSE_CC_avrg];
MAXE_p10_Global = [MAXE_avrg MAXE_LA92 MAXE_US06 MAXE_HWCUST2 MAXE_HWGRADE2 MAXE_CC_avrg];


%% Convergence Time Analysis - 
load 5_LA92_40C_Samsung50G.mat
[RMSE_LA92,MAXE_LA92,Time_LA92,SOC_EKF,SOC_Real,E1] = ConvergenceTime(X,Y,0,0,0.7);
Time        = 1:1:length(SOC_EKF);
Aux         = Time./3600;

figure(9)
plot(Aux, SOC_Real*100, LineWidth = 2.5)
hold on
plot(Aux, SOC_EKF*100, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
hold off

grid on
legend('Actual', 'EKF')
ylabel('State of Charge (%)') 
xlabel('Time (Hour)')
title('LA92 at 40°C with Wrong Initial SOC')
ax = gca; 
ylim([0 100])
ax.FontSize = 18; 

saveas(gcf,'Fig09.png')

figure(10)
plot(Aux, E1, Color = [0.8500 0.3250 0.0980], LineWidth = 2)
grid on
ax = gca; 
ax.FontSize = 18;
Leg1 = sprintf("EKF - RMSE = %.2f (%%) and MAXE = %.2f (%%)", RMSE_LA92*100, MAXE_LA92*100);
Leg = legend(Leg1);
Leg.FontSize = 12;
ylabel('State of Charge Error (%)')
xlabel('Time (Hour)') 
ylim([-30 10])
yline(5, '-', 'Threshold: +5%', 'LabelVerticalAlignment', 'top', 'HandleVisibility', 'off');
yline(-5, '-', 'Threshold: -5%', 'LabelVerticalAlignment', 'bottom', 'HandleVisibility', 'off');
saveas(gcf,'Fig10.png')



%% Saving all variables on the Excel file

AuxExcel = [RMSE_Global RMSE_n150_Global RMSE_n50_Global RMSE_p50_Global RMSE_p150_Global RMSE_n10_Global RMSE_n5_Global RMSE_p5_Global RMSE_p10_Global];
writematrix(AuxExcel, 'General Results and Plots - Drive Cycles - EKF.xlsx', 'Sheet', 'General', 'Range', 'R31');

AuxExcel = [MAXE_Global MAXE_n150_Global MAXE_n50_Global MAXE_p50_Global MAXE_p150_Global MAXE_n10_Global MAXE_n5_Global MAXE_p5_Global MAXE_p10_Global];
writematrix(AuxExcel, 'General Results and Plots - Drive Cycles - EKF.xlsx', 'Sheet', 'General', 'Range', 'R32');

close all; clear all;