function [RMSE, MAXE] = Offset(X, Y, I_Offset, V_Offset)

    % Apply offsets to input data
    Current     = X(:,1) + I_Offset;
    VT_Real     = X(:,2) + V_Offset;
    Temperature = X(:,3);
    SOC_Real    = Y;
    L           = length(Current);
    Time        = (1:L)';  % Column vector for consistency

    % Prepare Simulink input
    simIn = Simulink.SimulationInput('Main_Simulink');
    simIn = simIn.setVariable('Current', Current);
    simIn = simIn.setVariable('VT_Real', VT_Real);
    simIn = simIn.setVariable('Temperature', Temperature);
    simIn = simIn.setVariable('SOC_Real', SOC_Real);
    simIn = simIn.setVariable('L', L);
    simIn = simIn.setVariable('Time', Time);

    % Run Simulink model
    out = sim(simIn);

    % Extract and clean output
    SOC_EKF = out.SOC_Estimated;
    SOC_EKF(1) = [];  % Remove first sample if needed

    % Compute error metrics
    RMSE = sqrt(mean((SOC_EKF - SOC_Real).^2));
    MAXE = max(abs(SOC_EKF - SOC_Real));
end