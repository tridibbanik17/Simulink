% Raw text input (you can load this from a file or paste it directly)
rawText = fileread('cellCapacity.txt');  % Replace with your actual file name

% Extract all numeric values using regular expressions
values = regexp(rawText, 'value = (\d+\.\d+)', 'tokens');

% Convert from cell array of tokens to numeric array
capacitanceVals = cellfun(@(x) str2double(x{1}), values);

% Reshape into a single row (each value in a column)
capacitanceRow = reshape(capacitanceVals, 1, []);

capacitanceCol = capacitanceRow.';

% Write to Excel using writematrix
filename = 'cellCapacitanceVal.xlsx';
writematrix(capacitanceCol, filename);  % Writes starting at A1 by default