%This script changes the inital SOC of all of the module in BWCMAC_108P34S/Pack1
%The inital SOC are random numbers between 0.75 to 1

% Model base
model = 'pack_105s34p_structured';
assemblyBasePath = 'Pack1/ModuleAssembly';
assemblyCounts = [24, 27, 27, 27]; % Number of modules in Assembly1 to Assembly4

% Loop through each ModuleAssembly
for assemblyIdx = 1:length(assemblyCounts)
    numModules = assemblyCounts(assemblyIdx);
    assemblyPath = [assemblyBasePath, num2str(assemblyIdx)];

    % Loop through each module inside the assembly
    for moduleIdx = 1:numModules
        % Full block path to module
        blockPath = sprintf('%s/%s/Module%02d', model, assemblyPath, moduleIdx);
        % Generate random SOC
        socVal = 0.75 + 0.05 * rand();
        
        % Apply to model
        set_param(blockPath, 'socCell_specify', 1);
        set_param(blockPath, 'socCell', num2str(socVal));

        % Log to command window
        fprintf('Set socInit = %.3f for %s\n', socVal, blockPath);
    end
end
